import { Dropdown } from 'resumegen';
import { useEffect, useRef } from 'react';

function OpenDropdown({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // Dropdown.Trigger is a <div onClick>; the Dropdown root is also a div, so
    // querySelector('div') grabs the root and clicks nothing. Click the inner
    // button and let React's delegation bubble it to the trigger's handler.
    const trigger = ref.current?.querySelector('button');
    if (trigger) trigger.click();
  }, []);
  // inline-block so Dropdown's own `relative` root shrinks to the trigger — otherwise
  // it spans the full width and Content's `right-0` flings the menu to the page edge.
  return <div ref={ref} className="inline-block">{children}</div>;
}

export function AccountMenu() {
  return (
    <div style={{ paddingBottom: '160px' }}>
      <OpenDropdown>
        <Dropdown>
          <Dropdown.Trigger>
            <button className="flex items-center gap-1 rounded bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm ring-1 ring-gray-300 hover:bg-gray-50">
              My Account
              <svg className="ml-1 h-4 w-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </Dropdown.Trigger>
          {/* align="left" anchors the menu under the trigger. The default "right" uses
              end-0, which parks the menu at the far edge of the preview cell. */}
          <Dropdown.Content align="left">
            <div className="py-1">
              <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer">Profile</div>
              <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer">Billing</div>
              <div className="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100 cursor-pointer">Sign Out</div>
            </div>
          </Dropdown.Content>
        </Dropdown>
      </OpenDropdown>
    </div>
  );
}
