import { AutocompleteInput } from 'resumegen';
import { useState } from 'react';

export function JobRole() {
  const [value, setValue] = useState('Software Engineer');
  return (
    <div className="w-72">
      <AutocompleteInput
        endpoint="job-roles"
        value={value}
        onChange={setValue}
        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
        placeholder="Search job roles…"
      />
    </div>
  );
}

export function Empty() {
  const [value, setValue] = useState('');
  return (
    <div className="w-72">
      <AutocompleteInput
        endpoint="job-titles"
        value={value}
        onChange={setValue}
        className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
        placeholder="Search job titles…"
      />
    </div>
  );
}
