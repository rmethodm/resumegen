import { TextInput } from 'resumegen';

export function Default() {
  return (
    <div className="w-72">
      <TextInput className="w-full" type="text" placeholder="Enter your email" />
    </div>
  );
}

export function WithValue() {
  return (
    <div className="w-72">
      <TextInput className="w-full" type="text" defaultValue="jane.smith@example.com" />
    </div>
  );
}

export function Password() {
  return (
    <div className="w-72">
      <TextInput className="w-full" type="password" defaultValue="supersecret" />
    </div>
  );
}

// No Disabled cell: TextInput applies no disabled styling (unlike PrimaryButton /
// SecondaryButton / DangerButton, which use opacity-50 cursor-not-allowed), so a
// disabled cell renders identically to WithValue and teaches the design agent nothing.
