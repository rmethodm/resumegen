# Design Sync Notes

## Setup — synth-entry mode (private repo workaround)

This repo has no `dist/` and no published npm package. Three things needed to work:

1. **`--entry ./ds-entry.tsx`** — synthetic barrel exporting all 16 components; passed to the converter so it doesn't look in `node_modules/resumegen`.
2. **`"name": "resumegen"` in `package.json`** — `dts.mjs:loadDts()` walks up from `typesRoot` looking for a package.json with a `name` field. Without one it walks to filesystem root and crashes with `ENOENT: /package.json`.
3. **`componentSrcMap` in config** — no `.d.ts` files (`noEmit: true` in tsconfig), so `exportedNames()` returns empty. Populating `componentSrcMap` with all 16 names + source paths injects them into the component set regardless.

The `ds-entry.tsx` at project root is the stable synthetic barrel; keep it in sync when adding components.

## The Tailwind content glob MUST include the previews

**This was a real, shipped bug — found 2026-07-21, present in the 2026-06-26 sync.**

`buildCmd`'s original `--content` glob covered only `./resources/js/Components/**/*.tsx`. Preview
files live in `.design-sync/previews/` and were **not scanned**, so any utility class used *only* in a
preview was never generated into `components.css`. The classes silently didn't exist, and the cards
rendered without them:

- `ApplicationLogo` — `h-9` / `h-16` missing, so Default and Large rendered at identical intrinsic size
- `Modal` — `p-6`, `mt-2`, `mt-4`, `mt-6`, `justify-end` missing: text flush to the panel edge, no
  vertical rhythm, buttons left-aligned instead of right, content overflowing the panel
- `TextInput` — `w-72` missing, so values clipped mid-string

The glob now ends `,./.design-sync/previews/**/*.tsx`. **Never narrow it back.** The failure mode is
nasty because it is invisible per-component — each card just looks slightly wrong in its own way, and
three separate reviewers diagnosed three unrelated causes before the shared root cause surfaced. If
new cards look unstyled or unspaced, check this glob before anything else.

## CSS — stable compiled path

Vite output has hashed filenames (`app-BA-x6MAk.css`). Compiled a dedicated stable-path CSS:

```
npx tailwindcss -i ./resources/css/app.css -o ./.design-sync/components.css --content './resources/js/Components/**/*.tsx'
```

`buildCmd` in config handles this on re-sync. The `.design-sync/components.css` file is committed (not .gitignored) so diffs show Tailwind changes.

## Known benign render warns

- **`[RENDER_THIN] ApplicationLogo`** — SVG-only component, no text content. Playwright paint detection can't measure SVG pixels. Confirmed renders correctly from screenshot.
- **`[RENDER_THIN] Modal`** — headlessui Dialog uses `position: fixed`. Measured height collapses to 0px in validation context (no viewport). Confirmed renders correctly from screenshot (full overlay visible).

These two warns are non-blocking and expected. Do not rework the previews for them.

## Component gaps found while grading (in the app, not the sync)

These are real inconsistencies in `resources/js/Components/`, surfaced by the preview grading. None
were fixed — changing app components is out of scope for a sync. Reported to the user 2026-07-21.

- **`TextInput` applies no disabled styling.** `PrimaryButton`, `SecondaryButton` and `DangerButton`
  all use `opacity-50 cursor-not-allowed`; `TextInput` has no `disabled:` variant at all, so a
  disabled field is pixel-identical to a filled one. The preview's `Disabled` cell was **removed**
  rather than ship a variant that doesn't vary. If the component ever gains a disabled treatment,
  add the cell back.
- **`AutocompleteInput` ships no default styling.** Its `className={className}` has no fallback, so
  with no `className` it renders a bare, unstyled browser input. The preview now passes the same
  classes `Pages/Onboarding/Wizard.tsx` uses. Both facts are documented in `conventions.md`.

## Preview gotcha — forcing a headless-ui Dropdown open

`Dropdown.Trigger` is a plain `<div onClick={toggleOpen}>`, and the `Dropdown` root is *also* a div.
`ref.current?.querySelector('div')` therefore grabs the **root** and clicks something with no handler,
leaving the menu shut. Query the inner `button` instead and let React's event delegation bubble the
click to the trigger's handler.

## Re-sync risks — what can silently go stale

- **The Claude Design project was deleted between syncs.** On 2026-07-21 the pinned `projectId`
  (`294ecd74-…`) returned 404 and the account had no design projects at all, so the verification
  anchor was gone and all 16 components re-verified from scratch. `projectId` is now
  `56acb0bc-2354-4760-b583-b8a9ea8baa7d`. If a sync ever reports the project missing again, that is
  what happened — create a fresh one and re-pin; nothing in the repo is lost, only the anchor.
- **`conventions.md` drifted badly and was caught only by the validation pass.** Its brand-colour
  table documented a navy palette (`#1e293b`, `#0f172a`, `#cbd5e1`, `#3b82f6`, `#2563eb`, `#475569`)
  — **six values that appear nowhere in the components.** The system is actually indigo→violet
  (`#4f46e5` → `#7c3aed`). Corrected 2026-07-21. Re-run the grep check every sync: a header that
  names classes which don't resolve is worse than no header, because the design agent trusts it and
  emits silently off-brand styling.
- **Grades live in the gitignored `.cache/`, so a fresh clone or a lost project re-grades all 16.**
  Budget for that; it is not a failure.
- **`components.css` is committed** so palette changes show up in diffs. If it looks unchanged after
  a component restyle, `buildCmd` didn't run.

## Re-sync checklist — when adding new components

1. Add export to `ds-entry.tsx`
2. Add `"NewComponent": "resources/js/Components/NewComponent.tsx"` to `componentSrcMap` in `.design-sync/config.json`
3. Create `.design-sync/previews/NewComponent.tsx` with at least 2 variants
4. Run: `node .ds-sync/package-build.mjs --entry ./ds-entry.tsx`
5. Run: `node .ds-sync/package-validate.mjs ./ds-bundle`
6. Run re-sync to upload

## Excluded from sync

- `NavLink` — Inertia router-coupled, no standalone use
- `ResponsiveNavLink` — same as NavLink
- `UpgradeModal` — **no longer exists**; deleted with billing on 2026-07-14. The `null` entry in
  `componentSrcMap` is a harmless tombstone. Do not re-raise it.
- `CommandPalette` — calls the Ziggy `route()` global at module scope (`NAV` is built at import time)
  and fetches search results from the API on open. Rendering it standalone needs both a `route()` shim
  and a fetch stub. Excluded 2026-07-21 by explicit decision; do not re-propose without a reason.
