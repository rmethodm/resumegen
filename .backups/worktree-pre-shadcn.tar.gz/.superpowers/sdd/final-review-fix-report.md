# Final Whole-Branch Review — Fix Report (layout-four + command-palette)

## Finding 1 (CRITICAL) — migration backfill silent no-op

**File:** `database/migrations/2026_07_14_130000_add_search_text_to_resumes_table.php`

`saveQuietly()` saves inside `withoutEvents`, so `Resume::saving` (the only thing
that populates `search_text`) never fired during backfill — every backfilled row
got NULL `search_text`.

**Fix:** replaced `$resume->saveQuietly();` with an event-firing save that
suppresses the `updated_at` bump:

```php
$resume->timestamps = false;
$resume->save();
```

**Test added:** `tests/Feature/ResumeSearchTextTest.php::test_saving_repopulates_null_search_text`
— creates a resume via factory, nulls `search_text` directly via
`DB::table('resumes')->update(['search_text' => null])` (bypassing model events,
same as a raw backfill target row would be), refetches the model, does the
event-firing save, and asserts `search_text` is repopulated and contains the
expected content. This is the previously-untested path that was broken.

```
php artisan test --compact --filter=ResumeSearchTextTest
...
Tests:    3 passed (9 assertions)
Duration: 0.34s
```

## Finding 2 (IMPORTANT) — /search has no rate limit

**File:** `routes/web.php`

Added `->middleware('throttle:30,1')` to the `/search` route, matching the
existing throttle convention used by `/jobs/salary` and other user-triggered
endpoints in the same file.

```php
Route::get('/search', SearchController::class)->name('search')->middleware('throttle:30,1');
```

## Finding 3 (MINOR) — A/B variant resumes may leak into search

**File:** `app/Http/Controllers/SearchController.php` — **no change made.**

Checked `ResumeBuilderController::index()`: it scopes resumes with
`$user->resumes()->nonSnapshot()`. `Resume::scopeNonSnapshot()`
(`app/Models/Resume.php:85-88`) only filters `where('is_snapshot', false)` — it
does **not** exclude A/B child variants (`ab_parent_id` is exposed in the index
payload for the UI, but rows with a non-null `ab_parent_id` are still included
in the list). Since the index itself treats variants as ordinary resumes, the
search query (which also filters only on `is_snapshot`) is already consistent
with the index's notion of "a resume." No filter added — adding one would have
made search *diverge* from the index rather than match it.

```
php artisan test --compact --filter=SearchTest
...
Tests:    5 passed (10 assertions)
Duration: 0.29s
```

## Verification

- `vendor/bin/pint --dirty --format agent` → `{"tool":"pint","result":"passed"}`
- Files changed: migration, `tests/Feature/ResumeSearchTextTest.php`,
  `routes/web.php`. `SearchController.php` untouched (finding 3 required no
  change).
