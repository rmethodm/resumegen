### Task 2: Build the palette and drawer

Replace the tabbed full-width panel with a narrow palette, and move field editing into an overlay drawer.

**Files:**
- Create: `resources/js/Pages/ResumeBuilder/Partials/SectionDrawer.tsx`
- Create: `resources/js/Pages/ResumeBuilder/Partials/SectionPalette.tsx`
- Modify: `resources/js/Pages/ResumeBuilder/Edit.tsx` — delete `renderForm()`, the resize handle (`:1224-1233`), and `sidebarOpen`/`panelWidth`/`startResize` (`:527`, `:533`, `:536`); rewrite the `<aside>` (`:1236-1245`).

**Interfaces:**
- Consumes: `SectionKey`, `SectionEntry`, `SECTIONS` from Task 1.
- Produces:
  ```ts
  // SectionDrawer.tsx
  export default function SectionDrawer(props: {
      title: string;
      onClose: () => void;
      children: React.ReactNode;
  }): JSX.Element;

  // SectionPalette.tsx
  export default function SectionPalette(props: {
      entries: SectionEntry[];        // in sectionOrder, contact first
      activeKey: SectionKey | null;
      onSelect: (key: SectionKey) => void;
      onDragEnd: (event: DragEndEvent) => void;
      sensors: ReturnType<typeof useSensors>;
      sectionOrder: string[];
  }): JSX.Element;
  ```
  `SectionKey` and `SectionEntry` must be exported from `Edit.tsx` for these imports to resolve.

- [ ] **Step 1: Export the types from `Edit.tsx`**

Change the Task 1 declarations to:

```tsx
export type SectionKey = 'contact' | 'summary' | 'experience' | 'education' | 'skills' | 'custom';

export type SectionEntry = {
    key: SectionKey;
    label: string;
    isDraggable: boolean;
    isComplete: () => boolean;
    render: () => React.ReactNode;
};
```

- [ ] **Step 2: Create `SectionDrawer.tsx`**

```tsx
import { useEffect } from 'react';
import { XMarkIcon } from '@heroicons/react/24/outline';

type Props = {
    title: string;
    onClose: () => void;
    children: React.ReactNode;
};

/**
 * Overlays the preview column while one section's fields are edited.
 * Positioning shell only — owns no field logic and no resume state.
 */
export default function SectionDrawer({ title, onClose, children }: Props) {
    useEffect(() => {
        const onKey = (e: KeyboardEvent) => {
            if (e.key === 'Escape') { onClose(); }
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [onClose]);

    return (
        <div
            role="dialog"
            aria-label={title}
            className="absolute inset-y-0 right-0 z-20 flex w-full max-w-[640px] flex-col border-l border-[#cbd5e1] bg-white shadow-[0_8px_30px_rgba(15,23,42,0.18)]"
        >
            <div className="flex shrink-0 items-center justify-between border-b border-[#eeeef5] px-5 py-3">
                <span className="text-sm font-semibold text-[#0f172a]">{title}</span>
                <button
                    type="button"
                    onClick={onClose}
                    aria-label="Close section"
                    className="rounded-md p-1.5 text-[#94a3b8] transition-colors hover:bg-[#f1f5f9] hover:text-[#4f46e5]"
                >
                    <XMarkIcon className="h-4 w-4" />
                </button>
            </div>
            <div className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
                {children}
            </div>
        </div>
    );
}
```

Note: **no backdrop and no click-outside-to-close.** A backdrop would dim the preview, which is the one thing this layout exists to keep prominent, and click-outside would fire while the user is reaching for the palette. Esc and the close button are the two ways out.

- [ ] **Step 3: Verify the heroicons import path matches the codebase**

Run:

```bash
grep -n "from '@heroicons" resources/js/Pages/ResumeBuilder/Edit.tsx | head -3
```

If `Edit.tsx` imports from `@heroicons/react/24/outline`, the import above is correct. If it uses a different variant (`20/solid`), match it and swap `XMarkIcon` accordingly. Do not add a new icon package.

- [ ] **Step 4: Create `SectionPalette.tsx`**

```tsx
import { DndContext, closestCenter, type DragEndEvent, type useSensors } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Bars3Icon } from '@heroicons/react/24/outline';
import type { SectionEntry, SectionKey } from '../Edit';

type Props = {
    entries: SectionEntry[];
    activeKey: SectionKey | null;
    onSelect: (key: SectionKey) => void;
    onDragEnd: (event: DragEndEvent) => void;
    sensors: ReturnType<typeof useSensors>;
    sectionOrder: string[];
};

function PaletteRow({ entry, active, onSelect }: { entry: SectionEntry; active: boolean; onSelect: () => void }) {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: entry.key });
    const style = { transform: CSS.Transform.toString(transform), transition };

    return (
        <div
            ref={setNodeRef}
            style={style}
            className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 transition-colors ${
                active ? 'border-[#4f46e5] bg-[#eef2ff]' : 'border-[#eeeef5] hover:border-[#c7c7d9] hover:bg-[#f8fafc]'
            }`}
        >
            {entry.isDraggable && (
                <button
                    type="button"
                    aria-label={`Reorder ${entry.label}`}
                    className="cursor-grab touch-none text-[#cbd5e1] hover:text-[#94a3b8]"
                    {...attributes}
                    {...listeners}
                >
                    <Bars3Icon className="h-3.5 w-3.5" />
                </button>
            )}
            <button
                type="button"
                onClick={onSelect}
                className={`flex-1 text-left text-sm ${active ? 'font-semibold text-[#4f46e5]' : 'text-[#1e293b]'}`}
            >
                {entry.label}
            </button>
            <span
                aria-hidden
                className={`h-1.5 w-1.5 shrink-0 rounded-full ${entry.isComplete() ? 'bg-[#4f46e5]' : 'bg-[#e2e8f0]'}`}
            />
        </div>
    );
}

/** The section list. Click a row to edit it; drag the handle to reorder. */
export default function SectionPalette({ entries, activeKey, onSelect, onDragEnd, sensors, sectionOrder }: Props) {
    const pinned = entries.filter(e => !e.isDraggable);
    const sortable = entries.filter(e => e.isDraggable);

    return (
        <div className="space-y-1.5">
            {pinned.map(entry => (
                <PaletteRow key={entry.key} entry={entry} active={activeKey === entry.key} onSelect={() => onSelect(entry.key)} />
            ))}
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
                <SortableContext items={sectionOrder} strategy={verticalListSortingStrategy}>
                    <div className="space-y-1.5">
                        {sortable.map(entry => (
                            <PaletteRow key={entry.key} entry={entry} active={activeKey === entry.key} onSelect={() => onSelect(entry.key)} />
                        ))}
                    </div>
                </SortableContext>
            </DndContext>
        </div>
    );
}
```

`handleSectionDragEnd` (`Edit.tsx:1001`) is passed straight through as `onDragEnd` and needs no change — it reorders `sectionOrder` by id, and the ids are the same section keys as before.

- [ ] **Step 5: Add drawer state to `Edit.tsx`**

Next to the other `useState` calls. **Name it `drawerSection`, not `openSection`** — `openSections` (plural, `Edit.tsx:596`) already exists as the accordion state and the two would be trivially confused on sight:

```tsx
const [drawerSection, setDrawerSection] = useState<SectionKey | null>(null);
```

- [ ] **Step 6: Rewrite the `<aside>` and mount the drawer**

Replace `Edit.tsx:1224-1245` (the resize handle and the aside header) and the tab-content block. The preview column at `:1211-1222` gains `relative` so the drawer can position against it:

```tsx
<div className="flex flex-wrap items-start bg-[#f1f5f9]">
    {/* Left column: the document. Drawer overlays this. */}
    <div className="relative min-h-[calc(100vh-3.5rem)] min-w-[320px] flex-1 bg-[#e2e3ee] px-8 py-6">
        <div className="mb-2 flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-[0.05em] text-[#94a3b8]">Live preview</span>
            <span className="text-[10px] text-[#a0a0b0]">{TEMPLATE_LABELS[template] ?? template} template</span>
        </div>
        <div className="relative h-[calc(100vh-9rem)] overflow-hidden rounded-md bg-white shadow-[0_8px_30px_rgba(79,70,229,0.12)]">
            {renderPreviewFrames()}
        </div>

        {drawerSection && (
            <SectionDrawer
                title={SECTIONS[drawerSection].label}
                onClose={() => setDrawerSection(null)}
            >
                {SECTIONS[drawerSection].render()}
            </SectionDrawer>
        )}
    </div>

    {/* Right palette — fixed width, no collapse, no resize. */}
    <aside
        className="sticky top-0 max-h-screen w-[300px] shrink-0 self-start overflow-y-auto border-l border-[#cbd5e1] bg-white"
        style={{ minHeight: 'calc(100vh - 3.5rem)' }}
    >
        <div className="flex gap-2 border-b border-[#eeeef5] p-3">
            <a href={route('builder.docx', resume.id)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[#0f172a] py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1e293b]">
                <ArrowDownTrayIcon className="h-3.5 w-3.5" /> DOCX
            </a>
            <a href={route('builder.pdf', resume.id)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-[#cbd5e1] py-2 text-xs font-semibold text-[#475569] transition-colors hover:border-[#a5b4fc] hover:bg-[#f8fafc] hover:text-[#4f46e5]">
                <ArrowDownTrayIcon className="h-3.5 w-3.5" /> PDF
            </a>
        </div>

        <div className="space-y-4 p-3">
            {recruiterNote && (
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                    <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-amber-700">Recruiter note</p>
                    <p className="text-sm leading-relaxed text-amber-900">{recruiterNote}</p>
                </div>
            )}

            <div>
                <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.05em] text-[#94a3b8]">Sections</p>
                <SectionPalette
                    entries={[SECTIONS.contact, ...sectionOrder.map(k => SECTIONS[k as SectionKey]).filter(Boolean)]}
                    activeKey={drawerSection}
                    onSelect={setDrawerSection}
                    onDragEnd={handleSectionDragEnd}
                    sensors={sensors}
                    sectionOrder={sectionOrder}
                />
            </div>
        </div>
    </aside>
</div>
```

- [ ] **Step 7: Relocate the remaining tab content**

The old `RIGHT_TABS` panel held Design, Optimize, and Share content besides Sections. Those are **not** deleted — they move below the section list in the palette, each wrapped in the existing `PanelCard` (`Edit.tsx:PanelCard`) so they collapse:

- **Design** — template picker and font controls (currently `Edit.tsx:1286` onward)
- **Optimize** — `StrengthScorePanel`, `AtsMatchPanel`, AI actions
- **Share** — active-link count and the `/shares` link, unchanged

Move each block verbatim into a `<PanelCard>` in the palette's `space-y-4` container. Then delete `RIGHT_TABS` (`:445`), `rightTab`/`setRightTab` (`:528`), and the tab bar (`:1249-1263`).

At 300px these blocks are narrower than they were. If the template picker's `grid-cols-3` (`:1296`) is too cramped, drop it to `grid-cols-2` — that is the only expected width casualty.

- [ ] **Step 8: Delete the dead code**

```bash
grep -n "sidebarOpen\|panelWidth\|startResize\|renderForm\|rightTab\|RIGHT_TABS" resources/js/Pages/ResumeBuilder/Edit.tsx
```

Every hit must be gone. Also remove now-unused imports (`ChevronRightIcon`/`ChevronLeftIcon` if the collapse button was their only user).

- [ ] **Step 9: Typecheck**

Run: `npx tsc --noEmit`
Expected: exits 0. Unused-import errors here are the signal that Step 8 was incomplete.

- [ ] **Step 10: Verify in the browser**

Run `npm run dev`, open a resume:
- Page loads with the preview visible and **no drawer open**.
- Clicking each palette row opens the drawer with that section's fields.
- Editing a field, then closing the drawer, shows the change in the preview.
- Esc and the × both close the drawer.
- Dragging a palette handle reorders sections, and the preview reflects the new order.
- The completion dot fills for sections with content.

- [ ] **Step 11: Run the backend tests**

Run: `php artisan test --compact --filter=ResumeBuilder`
Expected: PASS. These assert save and prop behavior; the refactor moved JSX between callers and must not have touched either. A failure here means the refactor changed behavior it was not supposed to.

- [ ] **Step 12: Commit**

```bash
git add resources/js/Pages/ResumeBuilder/Edit.tsx resources/js/Pages/ResumeBuilder/Partials/SectionDrawer.tsx resources/js/Pages/ResumeBuilder/Partials/SectionPalette.tsx
git commit -m "feat: builder palette and section drawer over preview"
```

---

