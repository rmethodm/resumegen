# Builder preview-left / skills-in-panel experiment — progress

Base: fdbbca3 (branch experiment/preview-left-skills-panel off main; pre-existing WIP left uncommitted, incl. tiny Edit.tsx WIP net -15 lines)
Plan: docs/superpowers/plans/2026-07-17-builder-preview-left-skills-panel.md

Task 1: complete (commit fdbbca3..626d846, review clean; 1 minor: helpers are inline closures not pure components — brief-mandated shape)
Task 2: complete (commit 626d846..d8be51f, review clean; build+SkillsLayoutTest independently re-run green by reviewer)

FINAL whole-branch review (opus, range fdbbca3..d8be51f): GO. 2 minor:
  - toggle a11y (aria-pressed/role=group) -> FIXED 36856a3 (build clean)
  - photo-controller WIP bundled in 626d846 -> out of scope (user's pre-existing WIP, left uncommitted by choice)
Deferred: manual browser walkthrough (agent cannot drive browser) — for user.
Feature commits: 626d846 d8be51f 36856a3

---

# Builder palette + section drawer (plan 2026-07-19)

Base: a7e9a65 (branch experiment/preview-left-skills-panel)
Plan: docs/superpowers/plans/2026-07-19-builder-preview-left-palette.md
Pre-flight: stashed unrelated JobSearch+AI WIP as stash@{0} — MUST `git stash pop` after final review.
Note: stash@{1} is pre-existing and not ours — do not touch.

Task 1: complete (commits a7e9a65..ebfc933, review clean)
  - Plan's SectionKey union was WRONG; corrected to contact|summary|experience|projects|education|skills|certifications (matches DEFAULT_SECTION_ORDER at Edit.tsx:439). Tasks 2-3 must use this.
  - Implementer added `optional: boolean` to SectionEntry to preserve badges on projects/certifications. Reviewer confirmed justified.
  - Reviewer independently verified 33/33 onBlur={save} preserved, labels/order/optional exact.
  - MINOR (open): no live browser verification anywhere in this plan — no browser available to agents. Visual baseline is recoverable via `git checkout ebfc933`.
NOTE: user committed their own JobSearch WIP as e95edb5 (between Task 1 and Task 2), consuming our stash@{0}. Confirmed benign by user. Our commits stayed clean (Edit.tsx + 2 Partials only). No re-stash; working tree has user's template PNGs + untitled.md — DO NOT TOUCH.
KNOWN ISSUE (user's code, out of our scope): SSRF in JobSearchController via JobUrlImporter, now committed in e95edb5.
Task 2: complete (commits e95edb5..fac51d0 = 89ef1ff impl + fac51d0 fixes, review clean after 1 fix round)
  - Review found Important a11y gap (no aria-modal/focus trap/focus restore) -> fixed in fac51d0, re-review Approved.
  - Also trimmed dead openSections keys.
  - MINOR (open, for final review): drawer initial focus lands on the x close button (first in DOM order) rather than first field. Debatable, not a defect.
  - MINOR (open, pre-existing): Safari doesn't focus <button> on mouse click, so focus restoration may no-op there. Not introduced by this work.
Task 3: complete (commits fac51d0..0f236b2, review clean, no findings)
  - Reviewer worked the CSS abspos math: drawer clamps to 640px at lg+, left re-solved post-clamp, no overflow at any width.
Task 4: complete. Full verification: tsc clean, npm run build ok, php artisan test 474 passed (1438 assertions), pint passed.
FINAL whole-branch review (opus, builder-scoped diff a7e9a65..HEAD -- ResumeBuilder/): GO.
  2 Important -> fixed in 557c1c2 (hidden-preview PDF storm below lg; DEFAULT_SECTION_ORDER typing)
  5 Minor -> fixed in 557c1c2 (skills dot vs narratives, contact chrome, drawer key, drag opacity, redundant relative)
  Verify review (opus) caught fixer OVERCLAIMING: item 2's cast was never dropped, and the drawer key exposed a new
  focus-restore ordering bug. Both closed in 5e2ea61 (explicit restoreFocusTo prop threaded from palette click).
  Re-verified after 5e2ea61: tsc clean, build ok, 474 passed.
OPEN / NOT DONE:
  - NO live browser verification anywhere in this plan. No agent had a browser driver. Every visual and interaction
    claim rests on static reasoning. THIS IS THE ONE REAL GAP — needs a human click-through.
  - Accepted by final review, not fixed: initial mount below lg still triggers one server-side PDF render (one per
    page load, not per blur); useSortable runs for the pinned Contact row outside any DndContext (verified inert).
Feature commits: ebfc933 89ef1ff fac51d0 0f236b2 557c1c2 5e2ea61
Stash note: our stash@{0} was consumed by the owner's own commit e95edb5 — confirmed benign, nothing to restore.
