### Task 3: Narrow-screen collapse

Below 1024px, show one pane at a time: palette full-width, drawer full-screen, preview hidden.

**Files:**
- Modify: `resources/js/Pages/ResumeBuilder/Edit.tsx` (the layout block from Task 2, Step 6)
- Modify: `resources/js/Pages/ResumeBuilder/Partials/SectionDrawer.tsx`

**Interfaces:**
- Consumes: `drawerSection` state from Task 2. No new state — the same value drives both layouts.
- Produces: nothing new.

- [ ] **Step 1: Make the preview column hide below `lg`**

On the preview column's wrapper:

```tsx
<div className="relative hidden min-h-[calc(100vh-3.5rem)] min-w-[320px] flex-1 bg-[#e2e3ee] px-8 py-6 lg:block">
```

- [ ] **Step 2: Make the palette full-width below `lg`**

On the `<aside>`:

```tsx
<aside
    className="sticky top-0 max-h-screen w-full shrink-0 self-start overflow-y-auto border-l border-[#cbd5e1] bg-white lg:w-[300px]"
    style={{ minHeight: 'calc(100vh - 3.5rem)' }}
>
```

- [ ] **Step 3: Move the drawer out of the hidden column on small screens**

The drawer currently lives inside the preview column, which is now `hidden` below `lg` — so it would disappear with it. Move the `{drawerSection && <SectionDrawer .../>}` block out to be a **direct child of the outer `flex` container**, and make the drawer fixed-position on small screens:

In `SectionDrawer.tsx`, change the root element's className to:

```tsx
className="fixed inset-0 z-30 flex w-full flex-col bg-white lg:absolute lg:inset-y-0 lg:left-auto lg:right-[300px] lg:z-20 lg:max-w-[640px] lg:border-l lg:border-[#cbd5e1] lg:shadow-[0_8px_30px_rgba(15,23,42,0.18)]"
```

and give the outer layout container `relative` so the `lg:absolute` positioning anchors to it:

```tsx
<div className="relative flex flex-wrap items-start bg-[#f1f5f9]">
```

The `lg:right-[300px]` offset keeps the drawer clear of the palette now that it is positioned against the whole layout rather than the preview column.

- [ ] **Step 4: Typecheck**

Run: `npx tsc --noEmit`
Expected: exits 0.

- [ ] **Step 5: Verify at each breakpoint**

Run `npm run dev` and check in devtools device toolbar at **375px, 768px, 1024px, 1280px, 1440px**:
- At 375px and 768px: no preview, palette fills the width, opening a section covers the screen, closing returns to the palette.
- At 1024px and above: preview visible, palette 300px on the right, drawer overlays the preview without covering the palette.
- **No horizontal scrolling at any width.** Confirm by checking `document.body.scrollWidth <= window.innerWidth` in the console.

- [ ] **Step 6: Commit**

```bash
git add resources/js/Pages/ResumeBuilder/Edit.tsx resources/js/Pages/ResumeBuilder/Partials/SectionDrawer.tsx
git commit -m "feat: collapse builder to single pane below lg"
```

---

