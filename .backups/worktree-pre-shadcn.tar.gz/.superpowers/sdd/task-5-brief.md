### Task 5: Move builder sidebar to the right

**Files:**
- Modify: `resources/js/Pages/ResumeBuilder/Edit.tsx:690-904` (the `flex items-start` row and its `<aside>`)
- Test: none (layout-only; visual verification)

**Interfaces:**
- Consumes: the global sidebar's builder-route icon-rail behavior (already handled in Task 3 via `route().current('builder.edit')` → `collapsed` default).
- Produces: builder editor with its panel on the right edge.

- [ ] **Step 1: Reorder the flex children**

In `resources/js/Pages/ResumeBuilder/Edit.tsx`, the row at line 690 is `<div className="flex items-start bg-[#f1f5f9]">` with the `<aside>` (line 693) as its FIRST child, followed by the editor `<main>`/content as later siblings.

Move the `<aside>...</aside>` block (lines 693-904) to be the LAST child of that flex row (after the editor content, before the row's closing `</div>`).

Then change the aside's border from right to left: on line 693, change `border-r` to `border-l`:

```tsx
                <aside className={`sticky top-0 self-start overflow-y-auto bg-white border-l border-[#cbd5e1] transition-all duration-200 ${sidebarOpen ? 'w-56' : 'w-14'}`} style={{ minHeight: 'calc(100vh - 3.5rem)' }}>
```

Also, on the collapse/expand toggle row inside the aside (line 694, `<div className="flex justify-end ...">`), change `justify-end` to `justify-start` so the collapse chevron points into the editor rather than off-screen. (Cosmetic; verify direction visually and pick whichever points toward the content.)

- [ ] **Step 2: Build**

Run: `npm run build`
Expected: compiles clean.

- [ ] **Step 3: Manual smoke check**

Open a resume in the builder. Expected: global nav is a thin icon rail on the far left; the editor content is in the middle; the template/AI/checklist/ATS panel is on the right edge with a left border. Editing, saving, and preview still work.

- [ ] **Step 4: Commit**

```bash
git add resources/js/Pages/ResumeBuilder/Edit.tsx
git commit -m "Move builder tools panel to the right edge"
```

---

