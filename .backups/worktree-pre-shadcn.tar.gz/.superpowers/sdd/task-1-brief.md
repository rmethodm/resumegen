### Task 1: Extract the section registry

Convert `renderForm()`'s per-section JSX into a keyed registry, with no visual change yet. The panel still renders every section in order; this is a pure refactor whose only observable effect is that `tsc` now enforces section completeness.

**Files:**
- Modify: `resources/js/Pages/ResumeBuilder/Edit.tsx:1020-1178` (the `renderForm` body)

**Interfaces:**
- Consumes: existing state — `sectionOrder`, `openSections`, `toggleSection`, `highlightSection`, `save`, and every section's state/setters.
- Produces:
  ```ts
  type SectionKey = 'contact' | 'summary' | 'experience' | 'education' | 'skills' | 'custom';
  type SectionEntry = {
      key: SectionKey;
      label: string;
      isDraggable: boolean;   // contact is pinned; the rest reorder
      isComplete: () => boolean;
      render: () => React.ReactNode;   // fields only — no card chrome, no DraggableSection wrapper
  };
  const SECTIONS: Record<SectionKey, SectionEntry>
  ```
  `SECTIONS` is built inside the component (its closures capture state), not at module scope.

- [ ] **Step 1: Add the types above `Edit.tsx`'s component**

Place immediately after the existing `RIGHT_TABS` declaration (`Edit.tsx:445`):

```tsx
type SectionKey = 'contact' | 'summary' | 'experience' | 'education' | 'skills' | 'custom';

type SectionEntry = {
    key: SectionKey;
    label: string;
    isDraggable: boolean;
    isComplete: () => boolean;
    render: () => React.ReactNode;
};
```

- [ ] **Step 2: Confirm the real section key set**

The literal union above is a starting guess. Run:

```bash
grep -n "key === '" resources/js/Pages/ResumeBuilder/Edit.tsx
```

Every `key === 'x'` branch inside `renderForm`'s `sectionOrder.map` is a section. Widen or narrow the `SectionKey` union to match **exactly**, and confirm against the `sectionOrder` default at `Edit.tsx:513`. If they disagree, the `sectionOrder` default is authoritative — it is what the saved data contains.

- [ ] **Step 3: Build the registry, moving JSX verbatim**

Inside the component, replacing the `renderForm` definition. For each section, move the **inner** JSX — the children of `<DraggableSection>`, not the wrapper — into that entry's `render`. The wrapper chrome is re-added by the caller in Task 2, so it must not be duplicated inside `render`.

Worked example for `summary`, taken from the current `Edit.tsx:1058-1075`:

```tsx
const SECTIONS: Record<SectionKey, SectionEntry> = {
    summary: {
        key: 'summary',
        label: 'Professional Summary',
        isDraggable: true,
        isComplete: () => summary.trim().length > 0,
        render: () => (
            <>
                <FTextarea
                    value={summary}
                    onChange={setSummary}
                    onBlur={save}
                    placeholder="Write a brief 2–4 sentence overview of your background and what you bring to a role."
                    rows={5}
                />
                <p className="text-right text-xs text-[#94a3b8]">{Math.max(0, 1000 - summary.length)} characters remaining</p>
                {renderBulletTools(
                    'summary',
                    summary,
                    s => { setSummary(s); markGenerated('summary'); setTimeout(save, 0); },
                    handleGenerateSummary,
                )}
            </>
        ),
    },
    // ...one entry per key confirmed in Step 2, same treatment
};
```

Rules while moving:
- Do not retype the JSX — cut and paste it, then fix only the wrapper. Retyping introduces transcription bugs in ~400 lines.
- Every `onBlur={save}` stays exactly where it is.
- `contact` gets `isDraggable: false` (it is pinned, `Edit.tsx:1032-1049`) and its `render` is the `<div className="grid grid-cols-1 gap-3 ...">` at `:1040`, without the surrounding card and toggle button.
- `isComplete` should be a cheap truthiness check on that section's state — e.g. `experience.length > 0`, `contact.full_name.trim().length > 0`. It drives a palette dot, nothing load-bearing.

- [ ] **Step 4: Keep `renderForm()` working, now built from the registry**

Do not delete `renderForm()` yet — Task 2 does that. Rewrite its body to consume the registry so the app stays runnable and you can diff the rendering visually:

```tsx
const renderForm = (): React.ReactNode => (
    <div className="mx-auto max-w-2xl space-y-4 px-4">
        <div className="overflow-hidden rounded-xl border border-[#cbd5e1] bg-white shadow-[0_1px_2px_rgba(15,23,42,0.06),0_1px_3px_rgba(15,23,42,0.10)] px-5 py-4 space-y-2">
            <FLabel>Resume Name</FLabel>
            <FInput value={name} onChange={setName} onBlur={save} placeholder="My Resume" />
            <p className="text-xs text-[#94a3b8]">File: <span className="font-mono">{pdfFilename}</span></p>
        </div>

        <div className="overflow-hidden rounded-xl border border-[#cbd5e1] bg-white shadow-[0_1px_2px_rgba(15,23,42,0.06),0_1px_3px_rgba(15,23,42,0.10)]">
            <button type="button" className="flex w-full items-center gap-3 px-4 py-4 text-left" onClick={() => { toggleSection('contact'); highlightSection('contact'); }}>
                <span className="w-[18px]" />
                <span className="flex-1 text-sm font-semibold text-[#0f172a]">{SECTIONS.contact.label}</span>
                <svg className={`h-4 w-4 text-[#94a3b8] transition-transform ${openSections.contact ? '' : 'rotate-180'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" /></svg>
            </button>
            {openSections.contact && SECTIONS.contact.render()}
        </div>

        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleSectionDragEnd}>
            <SortableContext items={sectionOrder} strategy={verticalListSortingStrategy}>
                {sectionOrder.map(key => {
                    const entry = SECTIONS[key as SectionKey];
                    if (!entry) return null;
                    return (
                        <DraggableSection
                            key={entry.key}
                            id={entry.key}
                            title={entry.label}
                            optional={entry.key === 'summary'}
                            open={openSections[entry.key as keyof typeof openSections]}
                            onToggle={() => { toggleSection(entry.key); highlightSection(entry.key); }}
                        >
                            {entry.render()}
                        </DraggableSection>
                    );
                })}
            </SortableContext>
        </DndContext>
    </div>
);
```

- [ ] **Step 5: Typecheck**

Run: `npx tsc --noEmit`
Expected: exits 0. A missing key in `SECTIONS` is reported as `Property 'x' is missing in type ... but required in type 'Record<SectionKey, SectionEntry>'` — that is the completeness guarantee working. Add the missing entry rather than loosening the type to `Partial<>`.

- [ ] **Step 6: Verify no visual regression**

Run `npm run dev`, open a resume in the builder, and confirm against the pre-change UI:
- every section appears, in the same order
- expand/collapse still works per section
- drag-to-reorder still works
- editing a field and clicking away still shows "Saving…" then "Saved", and the preview updates

This is the one moment where a pure refactor can be checked against a known-good UI. Do not skip it — after Task 2 the old layout is gone and there is nothing left to diff against.

- [ ] **Step 7: Commit**

```bash
git add resources/js/Pages/ResumeBuilder/Edit.tsx
git commit -m "refactor: extract builder sections into a keyed registry"
```

---

