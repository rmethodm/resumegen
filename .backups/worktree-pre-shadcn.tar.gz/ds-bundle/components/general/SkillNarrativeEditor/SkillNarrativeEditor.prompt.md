SkillNarrativeEditor from resumegen. Use via `window.Resumegen.SkillNarrativeEditor` (bundle loaded from the root `_ds_bundle.js`).
