import * as React from 'react';

/**
 * SkillNarrativeEditor — from resumegen@0.0.0.
 */
export interface SkillNarrativeEditorProps {
  [key: string]: unknown;
}

export declare const SkillNarrativeEditor: React.ComponentType<SkillNarrativeEditorProps>;
