// Re-export of resumegen@0.0.0 SkillNarrativeEditor. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { SkillNarrativeEditor: window.Resumegen.SkillNarrativeEditor });
