Modal from resumegen. Use via `window.Resumegen.Modal` (bundle loaded from the root `_ds_bundle.js`).
