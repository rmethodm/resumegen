// Re-export of resumegen@0.0.0 Modal. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { Modal: window.Resumegen.Modal });
