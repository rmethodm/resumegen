import * as React from 'react';

/**
 * Modal — from resumegen@0.0.0.
 */
export interface ModalProps {
  [key: string]: unknown;
}

export declare const Modal: React.ComponentType<ModalProps>;
