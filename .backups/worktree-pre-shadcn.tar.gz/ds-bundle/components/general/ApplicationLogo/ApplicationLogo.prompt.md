ApplicationLogo from resumegen. Use via `window.Resumegen.ApplicationLogo` (bundle loaded from the root `_ds_bundle.js`).
