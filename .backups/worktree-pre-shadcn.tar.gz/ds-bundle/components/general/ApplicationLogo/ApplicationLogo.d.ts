import * as React from 'react';

/**
 * ApplicationLogo — from resumegen@0.0.0.
 */
export interface ApplicationLogoProps {
  [key: string]: unknown;
}

export declare const ApplicationLogo: React.ComponentType<ApplicationLogoProps>;
