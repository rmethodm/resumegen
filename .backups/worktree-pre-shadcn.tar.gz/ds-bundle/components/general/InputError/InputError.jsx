// Re-export of resumegen@0.0.0 InputError. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { InputError: window.Resumegen.InputError });
