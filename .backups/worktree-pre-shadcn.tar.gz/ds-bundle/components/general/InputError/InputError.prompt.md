InputError from resumegen. Use via `window.Resumegen.InputError` (bundle loaded from the root `_ds_bundle.js`).
