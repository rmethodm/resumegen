import * as React from 'react';

/**
 * InputError — from resumegen@0.0.0.
 */
export interface InputErrorProps {
  [key: string]: unknown;
}

export declare const InputError: React.ComponentType<InputErrorProps>;
