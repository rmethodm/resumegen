QRCodeDisplay from resumegen. Use via `window.Resumegen.QRCodeDisplay` (bundle loaded from the root `_ds_bundle.js`).
