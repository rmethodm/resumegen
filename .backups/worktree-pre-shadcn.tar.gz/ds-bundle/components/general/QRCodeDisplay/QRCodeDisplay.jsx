// Re-export of resumegen@0.0.0 QRCodeDisplay. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { QRCodeDisplay: window.Resumegen.QRCodeDisplay });
