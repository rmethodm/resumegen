import * as React from 'react';

/**
 * QRCodeDisplay — from resumegen@0.0.0.
 */
export interface QRCodeDisplayProps {
  [key: string]: unknown;
}

export declare const QRCodeDisplay: React.ComponentType<QRCodeDisplayProps>;
