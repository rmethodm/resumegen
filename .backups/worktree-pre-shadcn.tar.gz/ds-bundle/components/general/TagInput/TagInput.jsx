// Re-export of resumegen@0.0.0 TagInput. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { TagInput: window.Resumegen.TagInput });
