TagInput from resumegen. Use via `window.Resumegen.TagInput` (bundle loaded from the root `_ds_bundle.js`).
