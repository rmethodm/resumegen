import * as React from 'react';

/**
 * TagInput — from resumegen@0.0.0.
 */
export interface TagInputProps {
  [key: string]: unknown;
}

export declare const TagInput: React.ComponentType<TagInputProps>;
