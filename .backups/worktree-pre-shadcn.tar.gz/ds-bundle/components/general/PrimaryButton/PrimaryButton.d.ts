import * as React from 'react';

/**
 * PrimaryButton — from resumegen@0.0.0.
 */
export interface PrimaryButtonProps {
  [key: string]: unknown;
}

export declare const PrimaryButton: React.ComponentType<PrimaryButtonProps>;
