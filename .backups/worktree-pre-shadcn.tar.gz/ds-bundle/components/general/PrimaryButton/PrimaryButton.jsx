// Re-export of resumegen@0.0.0 PrimaryButton. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { PrimaryButton: window.Resumegen.PrimaryButton });
