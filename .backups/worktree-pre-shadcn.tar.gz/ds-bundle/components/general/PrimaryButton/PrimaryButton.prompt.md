PrimaryButton from resumegen. Use via `window.Resumegen.PrimaryButton` (bundle loaded from the root `_ds_bundle.js`).
