TextInput from resumegen. Use via `window.Resumegen.TextInput` (bundle loaded from the root `_ds_bundle.js`).
