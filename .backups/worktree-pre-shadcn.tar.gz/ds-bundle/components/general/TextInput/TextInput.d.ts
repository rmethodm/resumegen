import * as React from 'react';

/**
 * TextInput — from resumegen@0.0.0.
 */
export interface TextInputProps {
  [key: string]: unknown;
}

export declare const TextInput: React.ComponentType<TextInputProps>;
