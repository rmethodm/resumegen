Dropdown from resumegen. Use via `window.Resumegen.Dropdown` (bundle loaded from the root `_ds_bundle.js`).
