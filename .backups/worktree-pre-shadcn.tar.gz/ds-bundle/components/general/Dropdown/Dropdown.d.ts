import * as React from 'react';

/**
 * Dropdown — from resumegen@0.0.0.
 */
export interface DropdownProps {
  [key: string]: unknown;
}

export declare const Dropdown: React.ComponentType<DropdownProps>;
