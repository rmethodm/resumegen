// Re-export of resumegen@0.0.0 Dropdown. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { Dropdown: window.Resumegen.Dropdown });
