import * as React from 'react';

/**
 * DangerButton — from resumegen@0.0.0.
 */
export interface DangerButtonProps {
  [key: string]: unknown;
}

export declare const DangerButton: React.ComponentType<DangerButtonProps>;
