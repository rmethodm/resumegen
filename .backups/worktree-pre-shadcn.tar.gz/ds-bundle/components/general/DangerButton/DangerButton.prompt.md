DangerButton from resumegen. Use via `window.Resumegen.DangerButton` (bundle loaded from the root `_ds_bundle.js`).
