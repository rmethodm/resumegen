// Re-export of resumegen@0.0.0 DangerButton. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { DangerButton: window.Resumegen.DangerButton });
