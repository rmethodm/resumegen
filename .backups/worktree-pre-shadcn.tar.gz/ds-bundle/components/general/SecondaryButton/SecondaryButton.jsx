// Re-export of resumegen@0.0.0 SecondaryButton. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { SecondaryButton: window.Resumegen.SecondaryButton });
