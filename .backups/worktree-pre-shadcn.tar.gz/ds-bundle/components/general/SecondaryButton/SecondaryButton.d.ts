import * as React from 'react';

/**
 * SecondaryButton — from resumegen@0.0.0.
 */
export interface SecondaryButtonProps {
  [key: string]: unknown;
}

export declare const SecondaryButton: React.ComponentType<SecondaryButtonProps>;
