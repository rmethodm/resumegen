SecondaryButton from resumegen. Use via `window.Resumegen.SecondaryButton` (bundle loaded from the root `_ds_bundle.js`).
