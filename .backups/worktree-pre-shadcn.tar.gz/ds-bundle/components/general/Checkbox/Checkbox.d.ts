import * as React from 'react';

/**
 * Checkbox — from resumegen@0.0.0.
 */
export interface CheckboxProps {
  [key: string]: unknown;
}

export declare const Checkbox: React.ComponentType<CheckboxProps>;
