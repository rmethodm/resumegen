Checkbox from resumegen. Use via `window.Resumegen.Checkbox` (bundle loaded from the root `_ds_bundle.js`).
