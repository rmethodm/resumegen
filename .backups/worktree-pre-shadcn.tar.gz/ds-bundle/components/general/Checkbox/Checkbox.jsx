// Re-export of resumegen@0.0.0 Checkbox. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { Checkbox: window.Resumegen.Checkbox });
