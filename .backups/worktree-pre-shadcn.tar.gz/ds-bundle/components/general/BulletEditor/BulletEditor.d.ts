import * as React from 'react';

/**
 * BulletEditor — from resumegen@0.0.0.
 */
export interface BulletEditorProps {
  [key: string]: unknown;
}

export declare const BulletEditor: React.ComponentType<BulletEditorProps>;
