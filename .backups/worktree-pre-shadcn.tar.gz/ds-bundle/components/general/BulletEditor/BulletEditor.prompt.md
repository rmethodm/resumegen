BulletEditor from resumegen. Use via `window.Resumegen.BulletEditor` (bundle loaded from the root `_ds_bundle.js`).
