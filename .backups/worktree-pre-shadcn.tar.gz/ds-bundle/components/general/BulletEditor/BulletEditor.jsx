// Re-export of resumegen@0.0.0 BulletEditor. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { BulletEditor: window.Resumegen.BulletEditor });
