AutocompleteInput from resumegen. Use via `window.Resumegen.AutocompleteInput` (bundle loaded from the root `_ds_bundle.js`).
