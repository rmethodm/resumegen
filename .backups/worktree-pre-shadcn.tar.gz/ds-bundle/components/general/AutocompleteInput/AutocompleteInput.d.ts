import * as React from 'react';

/**
 * AutocompleteInput — from resumegen@0.0.0.
 */
export interface AutocompleteInputProps {
  [key: string]: unknown;
}

export declare const AutocompleteInput: React.ComponentType<AutocompleteInputProps>;
