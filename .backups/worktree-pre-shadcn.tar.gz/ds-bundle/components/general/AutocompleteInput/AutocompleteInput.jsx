// Re-export of resumegen@0.0.0 AutocompleteInput. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { AutocompleteInput: window.Resumegen.AutocompleteInput });
