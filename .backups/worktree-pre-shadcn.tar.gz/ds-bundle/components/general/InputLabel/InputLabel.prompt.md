InputLabel from resumegen. Use via `window.Resumegen.InputLabel` (bundle loaded from the root `_ds_bundle.js`).
