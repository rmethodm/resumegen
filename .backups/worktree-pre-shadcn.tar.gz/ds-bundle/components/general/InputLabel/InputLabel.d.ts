import * as React from 'react';

/**
 * InputLabel — from resumegen@0.0.0.
 */
export interface InputLabelProps {
  [key: string]: unknown;
}

export declare const InputLabel: React.ComponentType<InputLabelProps>;
