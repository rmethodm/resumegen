// Re-export of resumegen@0.0.0 InputLabel. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { InputLabel: window.Resumegen.InputLabel });
