SkillGroupEditor from resumegen. Use via `window.Resumegen.SkillGroupEditor` (bundle loaded from the root `_ds_bundle.js`).
