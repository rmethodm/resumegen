import * as React from 'react';

/**
 * SkillGroupEditor — from resumegen@0.0.0.
 */
export interface SkillGroupEditorProps {
  [key: string]: unknown;
}

export declare const SkillGroupEditor: React.ComponentType<SkillGroupEditorProps>;
