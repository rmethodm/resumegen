// Re-export of resumegen@0.0.0 SkillGroupEditor. Implementation is in the root _ds_bundle.js (window.Resumegen).
Object.assign(window, { SkillGroupEditor: window.Resumegen.SkillGroupEditor });
