# Resumegen UI — Design Agent Conventions

## Wrapping and setup

No provider or root wrapper is required. Import components directly and render them:

```jsx
import { PrimaryButton, TextInput, Modal } from 'resumegen';

function MyScreen() {
  return (
    <div className="p-6">
      <TextInput type="email" placeholder="Enter email" />
      <PrimaryButton>Continue</PrimaryButton>
    </div>
  );
}
```

Components are self-contained — no ThemeProvider, RouterProvider, or context setup needed. The only exception: `Dropdown.Link` renders an Inertia router link; avoid it in standalone designs and use plain `<a>` tags or `<div>` items inside `Dropdown.Content` instead.

## Styling idiom — Tailwind utility classes

These components use Tailwind CSS utility classes. Use the same vocabulary for all layout glue and custom elements you build alongside the library components.

**Brand colors (exact values used throughout the system):**
| Role | Class / Value |
|---|---|
| Primary action | `bg-gradient-to-br from-[#4f46e5] to-[#7c3aed]` (indigo → violet gradient) |
| Secondary surface | `bg-white border border-[#eeeef5] text-[#71717a]`, hover `bg-[#fafafe]` |
| Danger / destructive | `bg-red-600 hover:bg-red-500`, `uppercase tracking-widest` |
| Focus ring | `focus:ring-[#4f46e5] focus:border-[#4f46e5]` |
| Body text | `text-[#0f0f1a]` (near-black) |
| Muted text | `text-[#71717a]`; lighter still `text-[#a0a0b0]` |
| Accent (tags, badges) | `bg-indigo-100 text-indigo-800`; accent text `text-[#4338ca]` |
| Border | `border-[#eeeef5]`, `border-gray-300`, or `border-gray-200` |

**Typography:** `text-sm font-medium` for labels and body; `text-xs` for metadata; `font-semibold` for headings. The page font (`Figtree`) is served by Google Fonts at runtime — the bundle does not ship it; headless or offline renders fall back to system-ui.

**Spacing:** Prefer `gap-2` / `gap-3` for element spacing, `p-4` / `p-6` for container padding, `mt-1` / `mt-2` for stacked form fields.

**Read before styling:** `styles.css` (imports `_ds_bundle.css` — all component styles) and each component's `.prompt.md` for prop API.

## Component-specific notes

**PrimaryButton / SecondaryButton / DangerButton** — pass children for button text. They accept all standard `ButtonHTMLAttributes`. Add `disabled` to show the disabled state.

**TextInput** — accepts all `InputHTMLAttributes` plus `isFocused?: boolean`. Wrap with `InputLabel` above and `InputError` below for full form field pattern. It has no width of its own — set width on a wrapper (`w-full`, `w-72`). Note it applies **no** disabled styling, unlike the buttons; if you need a visibly disabled field, add `disabled:opacity-50` yourself.

**Modal** — always pass `show={boolean}` and `onClose`. Wrap content in `<div className="p-6">`. Use `maxWidth` prop (`'sm'|'md'|'lg'|'xl'|'2xl'`) to control dialog width.

**Dropdown** — compound component: `Dropdown > Dropdown.Trigger > <button>` + `Dropdown.Content > <items>`. Content is a white rounded panel with `py-1`; add `px-4 py-2 text-sm text-gray-700` items inside.

**BulletEditor / TagInput / SkillGroupEditor / SkillNarrativeEditor** — controlled: pass `value/tags/groups/narratives` state and an `onChange` handler. Initialize with `useState`.

**AutocompleteInput** — requires `endpoint: 'job-roles' | 'job-titles'` and a live API. In standalone designs, show it with a static `value` prop to represent the filled state. It ships **no** default styling: with no `className` it renders a bare browser input, so always pass the field classes, e.g. `mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500`.

**QRCodeDisplay** — pass a `url` string; renders a canvas QR code. Optional `size` (default 128px).

## Idiomatic build snippet

```jsx
import { PrimaryButton, SecondaryButton, TextInput, InputLabel, InputError, Modal } from 'resumegen';
import { useState } from 'react';

function ShareModal({ show, onClose }) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  return (
    <Modal show={show} onClose={onClose} maxWidth="md">
      <div className="p-6">
        <h2 className="text-lg font-semibold text-[#0f0f1a]">Share Resume</h2>
        <p className="mt-1 text-sm text-[#71717a]">Invite a collaborator by email.</p>
        <div className="mt-4 flex flex-col gap-1">
          <InputLabel htmlFor="email" value="Email address" />
          <TextInput
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="colleague@company.com"
          />
          {error && <InputError message={error} />}
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <SecondaryButton onClick={onClose}>Cancel</SecondaryButton>
          <PrimaryButton onClick={() => { /* submit */ }}>Send Invite</PrimaryButton>
        </div>
      </div>
    </Modal>
  );
}
```

# Resumegen (resumegen@0.0.0)

This design system is the published resumegen React library, bundled as a single
browser global. All 16 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.Resumegen`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).
- `guidelines/` — the design system's own usage guidance (4 doc(s), see `guidelines/index.md`). Read these before composing larger layouts.

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.Resumegen.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { ApplicationLogo } = window.Resumegen;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<ApplicationLogo />);
```

## Tokens

59 CSS custom properties from resumegen. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (8): `--tw-border-spacing-x`, `--tw-border-spacing-y`, `--tw-ring-offset-color`, …
- **spacing** (1): `--tw-ring-inset`
- **shadow** (4): `--tw-ring-offset-shadow`, `--tw-ring-shadow`, `--tw-shadow`, …
- **other** (46): `--tw-translate-x`, `--tw-translate-y`, `--tw-rotate`, …

## Components

### general
- `ApplicationLogo`
- `AutocompleteInput`
- `BulletEditor`
- `Checkbox`
- `DangerButton`
- `Dropdown`
- `InputError`
- `InputLabel`
- `Modal`
- `PrimaryButton`
- `QRCodeDisplay`
- `SecondaryButton`
- `SkillGroupEditor`
- `SkillNarrativeEditor`
- `TagInput`
- `TextInput`
