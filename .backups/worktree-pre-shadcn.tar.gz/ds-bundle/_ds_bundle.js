/* @ds-bundle: {"namespace":"Resumegen","components":[{"name":"ApplicationLogo","sourcePath":"components/general/ApplicationLogo/ApplicationLogo.jsx"},{"name":"AutocompleteInput","sourcePath":"components/general/AutocompleteInput/AutocompleteInput.jsx"},{"name":"BulletEditor","sourcePath":"components/general/BulletEditor/BulletEditor.jsx"},{"name":"Checkbox","sourcePath":"components/general/Checkbox/Checkbox.jsx"},{"name":"DangerButton","sourcePath":"components/general/DangerButton/DangerButton.jsx"},{"name":"Dropdown","sourcePath":"components/general/Dropdown/Dropdown.jsx"},{"name":"InputError","sourcePath":"components/general/InputError/InputError.jsx"},{"name":"InputLabel","sourcePath":"components/general/InputLabel/InputLabel.jsx"},{"name":"Modal","sourcePath":"components/general/Modal/Modal.jsx"},{"name":"PrimaryButton","sourcePath":"components/general/PrimaryButton/PrimaryButton.jsx"},{"name":"QRCodeDisplay","sourcePath":"components/general/QRCodeDisplay/QRCodeDisplay.jsx"},{"name":"SecondaryButton","sourcePath":"components/general/SecondaryButton/SecondaryButton.jsx"},{"name":"SkillGroupEditor","sourcePath":"components/general/SkillGroupEditor/SkillGroupEditor.jsx"},{"name":"SkillNarrativeEditor","sourcePath":"components/general/SkillNarrativeEditor/SkillNarrativeEditor.jsx"},{"name":"TagInput","sourcePath":"components/general/TagInput/TagInput.jsx"},{"name":"TextInput","sourcePath":"components/general/TextInput/TextInput.jsx"}],"sourceHashes":{"components/general/ApplicationLogo/ApplicationLogo.jsx":"b3ed9ca9a5c6","components/general/ApplicationLogo/ApplicationLogo.d.ts":"6a057654ae15","components/general/ApplicationLogo/ApplicationLogo.prompt.md":"f70d107965e2","components/general/AutocompleteInput/AutocompleteInput.jsx":"feac576673e6","components/general/AutocompleteInput/AutocompleteInput.d.ts":"c3affceea350","components/general/AutocompleteInput/AutocompleteInput.prompt.md":"4d48cf719264","components/general/BulletEditor/BulletEditor.jsx":"9d4793f6746f","components/general/BulletEditor/BulletEditor.d.ts":"f172bea4c508","components/general/BulletEditor/BulletEditor.prompt.md":"1f2639ca208d","components/general/Checkbox/Checkbox.jsx":"98a7d8de2081","components/general/Checkbox/Checkbox.d.ts":"fd504515dbd4","components/general/Checkbox/Checkbox.prompt.md":"89b68741c9e6","components/general/DangerButton/DangerButton.jsx":"b59e5af22be7","components/general/DangerButton/DangerButton.d.ts":"ad7f2e4842a3","components/general/DangerButton/DangerButton.prompt.md":"3edb23b256d7","components/general/Dropdown/Dropdown.jsx":"09f8b41ee1d0","components/general/Dropdown/Dropdown.d.ts":"293bca06a38a","components/general/Dropdown/Dropdown.prompt.md":"26ce2f96ae87","components/general/InputError/InputError.jsx":"7bc9bfaea00e","components/general/InputError/InputError.d.ts":"a33c0cfc89fe","components/general/InputError/InputError.prompt.md":"4cb1536af98d","components/general/InputLabel/InputLabel.jsx":"6620318cb2f5","components/general/InputLabel/InputLabel.d.ts":"9cb16bfda6f0","components/general/InputLabel/InputLabel.prompt.md":"467594ad05a6","components/general/Modal/Modal.jsx":"8202015c1f5a","components/general/Modal/Modal.d.ts":"30d232612446","components/general/Modal/Modal.prompt.md":"bcd9e8243a5e","components/general/PrimaryButton/PrimaryButton.jsx":"e803fe9a6f10","components/general/PrimaryButton/PrimaryButton.d.ts":"564bcaf7af70","components/general/PrimaryButton/PrimaryButton.prompt.md":"c967903fbd9a","components/general/QRCodeDisplay/QRCodeDisplay.jsx":"0d0dc588c6fb","components/general/QRCodeDisplay/QRCodeDisplay.d.ts":"ece421b15e27","components/general/QRCodeDisplay/QRCodeDisplay.prompt.md":"c475a6862eda","components/general/SecondaryButton/SecondaryButton.jsx":"bc6d2ace71c9","components/general/SecondaryButton/SecondaryButton.d.ts":"fee703ef1c06","components/general/SecondaryButton/SecondaryButton.prompt.md":"077b713928ba","components/general/SkillGroupEditor/SkillGroupEditor.jsx":"ba8f098c4d1c","components/general/SkillGroupEditor/SkillGroupEditor.d.ts":"8bc78549c573","components/general/SkillGroupEditor/SkillGroupEditor.prompt.md":"ad6048c8dc24","components/general/SkillNarrativeEditor/SkillNarrativeEditor.jsx":"9b2037bbfd98","components/general/SkillNarrativeEditor/SkillNarrativeEditor.d.ts":"59f07e8d92b1","components/general/SkillNarrativeEditor/SkillNarrativeEditor.prompt.md":"6ed9b84b9674","components/general/TagInput/TagInput.jsx":"02760a5099ae","components/general/TagInput/TagInput.d.ts":"32da3b1a6ba3","components/general/TagInput/TagInput.prompt.md":"d8017c608794","components/general/TextInput/TextInput.jsx":"c21defda8a3b","components/general/TextInput/TextInput.d.ts":"aa76ade7df32","components/general/TextInput/TextInput.prompt.md":"477d39a21394"},"inlinedExternals":["@floating-ui/core","@floating-ui/dom","@floating-ui/react","@floating-ui/react-dom","@floating-ui/utils","@headlessui/react","@heroicons/react","@inertiajs/core","@inertiajs/react","@react-aria/focus","@react-aria/interactions","@tanstack/react-virtual","@tanstack/virtual-core","axios","call-bind-apply-helpers","call-bound","clsx","dijkstrajs","dunder-proto","es-define-property","es-errors","es-object-atoms","function-bind","get-intrinsic","get-proto","gopd","has-symbols","hasown","laravel-precognition","lodash-es","math-intrinsics","object-inspect","qrcode","qs","react-aria","react-stately","side-channel","side-channel-list","side-channel-map","side-channel-weakmap","tabbable","use-sync-external-store"],"builtBy":"cc-design-sync"} */
"use strict";
var Resumegen = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e6) {
      throw err = [e6], e6;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e6) {
      throw mod = 0, e6;
    }
  };
  var __export = (target, all3) => {
    for (var name in all3)
      __defProp(target, name, { get: all3[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports2, module2) {
      init_define_import_meta_env();
      var R2 = window.React;
      function np(p6, k6) {
        var o12 = {};
        for (var x8 in p6) if (x8 !== "children") o12[x8] = p6[x8];
        if (k6 !== void 0) o12.key = k6;
        return o12;
      }
      function jsx17(t11, p6, k6) {
        var c12 = p6 && p6.children;
        return c12 === void 0 ? R2.createElement(t11, np(p6, k6)) : R2.createElement(t11, np(p6, k6), c12);
      }
      function jsxs9(t11, p6, k6) {
        return R2.createElement.apply(R2, [t11, np(p6, k6)].concat(p6.children));
      }
      module2.exports = R2;
      module2.exports.jsx = jsx17;
      module2.exports.jsxs = jsxs9;
      module2.exports.jsxDEV = function(t11, p6, k6, s11) {
        return (s11 ? jsxs9 : jsx17)(t11, p6, k6);
      };
      module2.exports.Fragment = R2.Fragment;
    }
  });

  // shim:react-dom-shim
  var require_react_dom_shim = __commonJS({
    "shim:react-dom-shim"(exports2, module2) {
      init_define_import_meta_env();
      var D5 = window.ReactDOM;
      var n12 = function() {
      };
      module2.exports = Object.assign({ preload: n12, preinit: n12, preconnect: n12, prefetchDNS: n12, preloadModule: n12, preinitModule: n12 }, D5);
    }
  });

  // node_modules/use-sync-external-store/cjs/use-sync-external-store-with-selector.development.js
  var require_use_sync_external_store_with_selector_development = __commonJS({
    "node_modules/use-sync-external-store/cjs/use-sync-external-store-with-selector.development.js"(exports2) {
      "use strict";
      init_define_import_meta_env();
      (function() {
        function is(x8, y4) {
          return x8 === y4 && (0 !== x8 || 1 / x8 === 1 / y4) || x8 !== x8 && y4 !== y4;
        }
        "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
        var React6 = require_react_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore = React6.useSyncExternalStore, useRef10 = React6.useRef, useEffect15 = React6.useEffect, useMemo9 = React6.useMemo, useDebugValue = React6.useDebugValue;
        exports2.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual2) {
          var instRef = useRef10(null);
          if (null === instRef.current) {
            var inst = { hasValue: false, value: null };
            instRef.current = inst;
          } else inst = instRef.current;
          instRef = useMemo9(
            function() {
              function memoizedSelector(nextSnapshot) {
                if (!hasMemo) {
                  hasMemo = true;
                  memoizedSnapshot = nextSnapshot;
                  nextSnapshot = selector(nextSnapshot);
                  if (void 0 !== isEqual2 && inst.hasValue) {
                    var currentSelection = inst.value;
                    if (isEqual2(currentSelection, nextSnapshot))
                      return memoizedSelection = currentSelection;
                  }
                  return memoizedSelection = nextSnapshot;
                }
                currentSelection = memoizedSelection;
                if (objectIs(memoizedSnapshot, nextSnapshot))
                  return currentSelection;
                var nextSelection = selector(nextSnapshot);
                if (void 0 !== isEqual2 && isEqual2(currentSelection, nextSelection))
                  return memoizedSnapshot = nextSnapshot, currentSelection;
                memoizedSnapshot = nextSnapshot;
                return memoizedSelection = nextSelection;
              }
              var hasMemo = false, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
              return [
                function() {
                  return memoizedSelector(getSnapshot());
                },
                null === maybeGetServerSnapshot ? void 0 : function() {
                  return memoizedSelector(maybeGetServerSnapshot());
                }
              ];
            },
            [getSnapshot, getServerSnapshot, selector, isEqual2]
          );
          var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
          useEffect15(
            function() {
              inst.hasValue = true;
              inst.value = value;
            },
            [value]
          );
          useDebugValue(value);
          return value;
        };
        "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
      })();
    }
  });

  // node_modules/use-sync-external-store/with-selector.js
  var require_with_selector = __commonJS({
    "node_modules/use-sync-external-store/with-selector.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      if (false) {
        module2.exports = null;
      } else {
        module2.exports = require_use_sync_external_store_with_selector_development();
      }
    }
  });

  // node_modules/es-errors/type.js
  var require_type = __commonJS({
    "node_modules/es-errors/type.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = TypeError;
    }
  });

  // (disabled):node_modules/object-inspect/util.inspect
  var require_util = __commonJS({
    "(disabled):node_modules/object-inspect/util.inspect"() {
      init_define_import_meta_env();
    }
  });

  // node_modules/object-inspect/index.js
  var require_object_inspect = __commonJS({
    "node_modules/object-inspect/index.js"(exports2, module2) {
      init_define_import_meta_env();
      var hasMap = typeof Map === "function" && Map.prototype;
      var mapSizeDescriptor = Object.getOwnPropertyDescriptor && hasMap ? Object.getOwnPropertyDescriptor(Map.prototype, "size") : null;
      var mapSize = hasMap && mapSizeDescriptor && typeof mapSizeDescriptor.get === "function" ? mapSizeDescriptor.get : null;
      var mapForEach = hasMap && Map.prototype.forEach;
      var hasSet = typeof Set === "function" && Set.prototype;
      var setSizeDescriptor = Object.getOwnPropertyDescriptor && hasSet ? Object.getOwnPropertyDescriptor(Set.prototype, "size") : null;
      var setSize = hasSet && setSizeDescriptor && typeof setSizeDescriptor.get === "function" ? setSizeDescriptor.get : null;
      var setForEach = hasSet && Set.prototype.forEach;
      var hasWeakMap = typeof WeakMap === "function" && WeakMap.prototype;
      var weakMapHas = hasWeakMap ? WeakMap.prototype.has : null;
      var hasWeakSet = typeof WeakSet === "function" && WeakSet.prototype;
      var weakSetHas = hasWeakSet ? WeakSet.prototype.has : null;
      var hasWeakRef = typeof WeakRef === "function" && WeakRef.prototype;
      var weakRefDeref = hasWeakRef ? WeakRef.prototype.deref : null;
      var booleanValueOf = Boolean.prototype.valueOf;
      var objectToString2 = Object.prototype.toString;
      var functionToString = Function.prototype.toString;
      var $match = String.prototype.match;
      var $slice = String.prototype.slice;
      var $replace = String.prototype.replace;
      var $toUpperCase = String.prototype.toUpperCase;
      var $toLowerCase = String.prototype.toLowerCase;
      var $test = RegExp.prototype.test;
      var $concat = Array.prototype.concat;
      var $join = Array.prototype.join;
      var $arrSlice = Array.prototype.slice;
      var $floor = Math.floor;
      var bigIntValueOf = typeof BigInt === "function" ? BigInt.prototype.valueOf : null;
      var gOPS = Object.getOwnPropertySymbols;
      var symToString = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? Symbol.prototype.toString : null;
      var hasShammedSymbols = typeof Symbol === "function" && typeof Symbol.iterator === "object";
      var toStringTag2 = typeof Symbol === "function" && Symbol.toStringTag && (typeof Symbol.toStringTag === hasShammedSymbols ? "object" : "symbol") ? Symbol.toStringTag : null;
      var isEnumerable = Object.prototype.propertyIsEnumerable;
      var gPO = (typeof Reflect === "function" ? Reflect.getPrototypeOf : Object.getPrototypeOf) || ([].__proto__ === Array.prototype ? function(O5) {
        return O5.__proto__;
      } : null);
      function addNumericSeparator(num, str) {
        if (num === Infinity || num === -Infinity || num !== num || num && num > -1e3 && num < 1e3 || $test.call(/e/, str)) {
          return str;
        }
        var sepRegex = /[0-9](?=(?:[0-9]{3})+(?![0-9]))/g;
        if (typeof num === "number") {
          var int = num < 0 ? -$floor(-num) : $floor(num);
          if (int !== num) {
            var intStr = String(int);
            var dec = $slice.call(str, intStr.length + 1);
            return $replace.call(intStr, sepRegex, "$&_") + "." + $replace.call($replace.call(dec, /([0-9]{3})/g, "$&_"), /_$/, "");
          }
        }
        return $replace.call(str, sepRegex, "$&_");
      }
      var utilInspect = require_util();
      var inspectCustom = utilInspect.custom;
      var inspectSymbol = isSymbol2(inspectCustom) ? inspectCustom : null;
      var quotes = {
        __proto__: null,
        "double": '"',
        single: "'"
      };
      var quoteREs = {
        __proto__: null,
        "double": /(["\\])/g,
        single: /(['\\])/g
      };
      module2.exports = function inspect_(obj, options, depth, seen) {
        var opts = options || {};
        if (has2(opts, "quoteStyle") && !has2(quotes, opts.quoteStyle)) {
          throw new TypeError('option "quoteStyle" must be "single" or "double"');
        }
        if (has2(opts, "maxStringLength") && (typeof opts.maxStringLength === "number" ? opts.maxStringLength < 0 && opts.maxStringLength !== Infinity : opts.maxStringLength !== null)) {
          throw new TypeError('option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`');
        }
        var customInspect = has2(opts, "customInspect") ? opts.customInspect : true;
        if (typeof customInspect !== "boolean" && customInspect !== "symbol") {
          throw new TypeError("option \"customInspect\", if provided, must be `true`, `false`, or `'symbol'`");
        }
        if (has2(opts, "indent") && opts.indent !== null && opts.indent !== "	" && !(parseInt(opts.indent, 10) === opts.indent && opts.indent > 0)) {
          throw new TypeError('option "indent" must be "\\t", an integer > 0, or `null`');
        }
        if (has2(opts, "numericSeparator") && typeof opts.numericSeparator !== "boolean") {
          throw new TypeError('option "numericSeparator", if provided, must be `true` or `false`');
        }
        var numericSeparator = opts.numericSeparator;
        if (typeof obj === "undefined") {
          return "undefined";
        }
        if (obj === null) {
          return "null";
        }
        if (typeof obj === "boolean") {
          return obj ? "true" : "false";
        }
        if (typeof obj === "string") {
          return inspectString(obj, opts);
        }
        if (typeof obj === "number") {
          if (obj === 0) {
            return Infinity / obj > 0 ? "0" : "-0";
          }
          var str = String(obj);
          return numericSeparator ? addNumericSeparator(obj, str) : str;
        }
        if (typeof obj === "bigint") {
          var bigIntStr = String(obj) + "n";
          return numericSeparator ? addNumericSeparator(obj, bigIntStr) : bigIntStr;
        }
        var maxDepth = typeof opts.depth === "undefined" ? 5 : opts.depth;
        if (typeof depth === "undefined") {
          depth = 0;
        }
        if (depth >= maxDepth && maxDepth > 0 && typeof obj === "object") {
          return isArray3(obj) ? "[Array]" : "[Object]";
        }
        var indent = getIndent(opts, depth);
        if (typeof seen === "undefined") {
          seen = [];
        } else if (indexOf(seen, obj) >= 0) {
          return "[Circular]";
        }
        function inspect(value, from, noIndent) {
          if (from) {
            seen = $arrSlice.call(seen);
            seen.push(from);
          }
          if (noIndent) {
            var newOpts = {
              depth: opts.depth
            };
            if (has2(opts, "quoteStyle")) {
              newOpts.quoteStyle = opts.quoteStyle;
            }
            return inspect_(value, newOpts, depth + 1, seen);
          }
          return inspect_(value, opts, depth + 1, seen);
        }
        if (typeof obj === "function" && !isRegExp2(obj)) {
          var name = nameOf(obj);
          var keys2 = arrObjKeys(obj, inspect);
          return "[Function" + (name ? ": " + name : " (anonymous)") + "]" + (keys2.length > 0 ? " { " + $join.call(keys2, ", ") + " }" : "");
        }
        if (isSymbol2(obj)) {
          var symString = hasShammedSymbols ? $replace.call(String(obj), /^(Symbol\(.*\))_[^)]*$/, "$1") : symToString.call(obj);
          return typeof obj === "object" && !hasShammedSymbols ? markBoxed(symString) : symString;
        }
        if (isElement(obj)) {
          var s11 = "<" + $toLowerCase.call(String(obj.nodeName));
          var attrs = obj.attributes || [];
          for (var i12 = 0; i12 < attrs.length; i12++) {
            s11 += " " + attrs[i12].name + "=" + wrapQuotes(quote(attrs[i12].value), "double", opts);
          }
          s11 += ">";
          if (obj.childNodes && obj.childNodes.length) {
            s11 += "...";
          }
          s11 += "</" + $toLowerCase.call(String(obj.nodeName)) + ">";
          return s11;
        }
        if (isArray3(obj)) {
          if (obj.length === 0) {
            return "[]";
          }
          var xs = arrObjKeys(obj, inspect);
          if (indent && !singleLineValues(xs)) {
            return "[" + indentedJoin(xs, indent) + "]";
          }
          return "[ " + $join.call(xs, ", ") + " ]";
        }
        if (isError(obj)) {
          var parts = arrObjKeys(obj, inspect);
          if (!("cause" in Error.prototype) && "cause" in obj && !isEnumerable.call(obj, "cause")) {
            return "{ [" + String(obj) + "] " + $join.call($concat.call("[cause]: " + inspect(obj.cause), parts), ", ") + " }";
          }
          if (parts.length === 0) {
            return "[" + String(obj) + "]";
          }
          return "{ [" + String(obj) + "] " + $join.call(parts, ", ") + " }";
        }
        if (typeof obj === "object" && customInspect) {
          if (inspectSymbol && typeof obj[inspectSymbol] === "function" && utilInspect) {
            return utilInspect(obj, { depth: maxDepth - depth });
          } else if (customInspect !== "symbol" && typeof obj.inspect === "function") {
            return obj.inspect();
          }
        }
        if (isMap2(obj)) {
          var mapParts = [];
          if (mapForEach) {
            mapForEach.call(obj, function(value, key) {
              mapParts.push(inspect(key, obj, true) + " => " + inspect(value, obj));
            });
          }
          return collectionOf("Map", mapSize.call(obj), mapParts, indent);
        }
        if (isSet2(obj)) {
          var setParts = [];
          if (setForEach) {
            setForEach.call(obj, function(value) {
              setParts.push(inspect(value, obj));
            });
          }
          return collectionOf("Set", setSize.call(obj), setParts, indent);
        }
        if (isWeakMap(obj)) {
          return weakCollectionOf("WeakMap");
        }
        if (isWeakSet(obj)) {
          return weakCollectionOf("WeakSet");
        }
        if (isWeakRef(obj)) {
          return weakCollectionOf("WeakRef");
        }
        if (isNumber2(obj)) {
          return markBoxed(inspect(Number(obj)));
        }
        if (isBigInt(obj)) {
          return markBoxed(inspect(bigIntValueOf.call(obj)));
        }
        if (isBoolean2(obj)) {
          return markBoxed(booleanValueOf.call(obj));
        }
        if (isString2(obj)) {
          return markBoxed(inspect(String(obj)));
        }
        if (typeof window !== "undefined" && obj === window) {
          return "{ [object Window] }";
        }
        if (typeof globalThis !== "undefined" && obj === globalThis || typeof global !== "undefined" && obj === global) {
          return "{ [object globalThis] }";
        }
        if (!isDate2(obj) && !isRegExp2(obj)) {
          var ys = arrObjKeys(obj, inspect);
          var isPlainObject3 = gPO ? gPO(obj) === Object.prototype : obj instanceof Object || obj.constructor === Object;
          var protoTag = obj instanceof Object ? "" : "null prototype";
          var stringTag5 = !isPlainObject3 && toStringTag2 && Object(obj) === obj && toStringTag2 in obj ? $slice.call(toStr(obj), 8, -1) : protoTag ? "Object" : "";
          var constructorTag = isPlainObject3 || typeof obj.constructor !== "function" ? "" : obj.constructor.name ? obj.constructor.name + " " : "";
          var tag = constructorTag + (stringTag5 || protoTag ? "[" + $join.call($concat.call([], stringTag5 || [], protoTag || []), ": ") + "] " : "");
          if (ys.length === 0) {
            return tag + "{}";
          }
          if (indent) {
            return tag + "{" + indentedJoin(ys, indent) + "}";
          }
          return tag + "{ " + $join.call(ys, ", ") + " }";
        }
        return String(obj);
      };
      function wrapQuotes(s11, defaultStyle, opts) {
        var style = opts.quoteStyle || defaultStyle;
        var quoteChar = quotes[style];
        return quoteChar + s11 + quoteChar;
      }
      function quote(s11) {
        return $replace.call(String(s11), /"/g, "&quot;");
      }
      function canTrustToString(obj) {
        return !toStringTag2 || !(typeof obj === "object" && (toStringTag2 in obj || typeof obj[toStringTag2] !== "undefined"));
      }
      function isArray3(obj) {
        return toStr(obj) === "[object Array]" && canTrustToString(obj);
      }
      function isDate2(obj) {
        return toStr(obj) === "[object Date]" && canTrustToString(obj);
      }
      function isRegExp2(obj) {
        return toStr(obj) === "[object RegExp]" && canTrustToString(obj);
      }
      function isError(obj) {
        return toStr(obj) === "[object Error]" && canTrustToString(obj);
      }
      function isString2(obj) {
        return toStr(obj) === "[object String]" && canTrustToString(obj);
      }
      function isNumber2(obj) {
        return toStr(obj) === "[object Number]" && canTrustToString(obj);
      }
      function isBoolean2(obj) {
        return toStr(obj) === "[object Boolean]" && canTrustToString(obj);
      }
      function isSymbol2(obj) {
        if (hasShammedSymbols) {
          return obj && typeof obj === "object" && obj instanceof Symbol;
        }
        if (typeof obj === "symbol") {
          return true;
        }
        if (!obj || typeof obj !== "object" || !symToString) {
          return false;
        }
        try {
          symToString.call(obj);
          return true;
        } catch (e6) {
        }
        return false;
      }
      function isBigInt(obj) {
        if (!obj || typeof obj !== "object" || !bigIntValueOf) {
          return false;
        }
        try {
          bigIntValueOf.call(obj);
          return true;
        } catch (e6) {
        }
        return false;
      }
      var hasOwn = Object.prototype.hasOwnProperty || function(key) {
        return key in this;
      };
      function has2(obj, key) {
        return hasOwn.call(obj, key);
      }
      function toStr(obj) {
        return objectToString2.call(obj);
      }
      function nameOf(f11) {
        if (f11.name) {
          return f11.name;
        }
        var m6 = $match.call(functionToString.call(f11), /^function\s*([\w$]+)/);
        if (m6) {
          return m6[1];
        }
        return null;
      }
      function indexOf(xs, x8) {
        if (xs.indexOf) {
          return xs.indexOf(x8);
        }
        for (var i12 = 0, l10 = xs.length; i12 < l10; i12++) {
          if (xs[i12] === x8) {
            return i12;
          }
        }
        return -1;
      }
      function isMap2(x8) {
        if (!mapSize || !x8 || typeof x8 !== "object") {
          return false;
        }
        try {
          mapSize.call(x8);
          try {
            setSize.call(x8);
          } catch (s11) {
            return true;
          }
          return x8 instanceof Map;
        } catch (e6) {
        }
        return false;
      }
      function isWeakMap(x8) {
        if (!weakMapHas || !x8 || typeof x8 !== "object") {
          return false;
        }
        try {
          weakMapHas.call(x8, weakMapHas);
          try {
            weakSetHas.call(x8, weakSetHas);
          } catch (s11) {
            return true;
          }
          return x8 instanceof WeakMap;
        } catch (e6) {
        }
        return false;
      }
      function isWeakRef(x8) {
        if (!weakRefDeref || !x8 || typeof x8 !== "object") {
          return false;
        }
        try {
          weakRefDeref.call(x8);
          return true;
        } catch (e6) {
        }
        return false;
      }
      function isSet2(x8) {
        if (!setSize || !x8 || typeof x8 !== "object") {
          return false;
        }
        try {
          setSize.call(x8);
          try {
            mapSize.call(x8);
          } catch (m6) {
            return true;
          }
          return x8 instanceof Set;
        } catch (e6) {
        }
        return false;
      }
      function isWeakSet(x8) {
        if (!weakSetHas || !x8 || typeof x8 !== "object") {
          return false;
        }
        try {
          weakSetHas.call(x8, weakSetHas);
          try {
            weakMapHas.call(x8, weakMapHas);
          } catch (s11) {
            return true;
          }
          return x8 instanceof WeakSet;
        } catch (e6) {
        }
        return false;
      }
      function isElement(x8) {
        if (!x8 || typeof x8 !== "object") {
          return false;
        }
        if (typeof HTMLElement !== "undefined" && x8 instanceof HTMLElement) {
          return true;
        }
        return typeof x8.nodeName === "string" && typeof x8.getAttribute === "function";
      }
      function inspectString(str, opts) {
        if (str.length > opts.maxStringLength) {
          var remaining = str.length - opts.maxStringLength;
          var trailer = "... " + remaining + " more character" + (remaining > 1 ? "s" : "");
          return inspectString($slice.call(str, 0, opts.maxStringLength), opts) + trailer;
        }
        var quoteRE = quoteREs[opts.quoteStyle || "single"];
        quoteRE.lastIndex = 0;
        var s11 = $replace.call($replace.call(str, quoteRE, "\\$1"), /[\x00-\x1f]/g, lowbyte);
        return wrapQuotes(s11, "single", opts);
      }
      function lowbyte(c12) {
        var n12 = c12.charCodeAt(0);
        var x8 = {
          8: "b",
          9: "t",
          10: "n",
          12: "f",
          13: "r"
        }[n12];
        if (x8) {
          return "\\" + x8;
        }
        return "\\x" + (n12 < 16 ? "0" : "") + $toUpperCase.call(n12.toString(16));
      }
      function markBoxed(str) {
        return "Object(" + str + ")";
      }
      function weakCollectionOf(type) {
        return type + " { ? }";
      }
      function collectionOf(type, size, entries, indent) {
        var joinedEntries = indent ? indentedJoin(entries, indent) : $join.call(entries, ", ");
        return type + " (" + size + ") {" + joinedEntries + "}";
      }
      function singleLineValues(xs) {
        for (var i12 = 0; i12 < xs.length; i12++) {
          if (indexOf(xs[i12], "\n") >= 0) {
            return false;
          }
        }
        return true;
      }
      function getIndent(opts, depth) {
        var baseIndent;
        if (opts.indent === "	") {
          baseIndent = "	";
        } else if (typeof opts.indent === "number" && opts.indent > 0) {
          baseIndent = $join.call(Array(opts.indent + 1), " ");
        } else {
          return null;
        }
        return {
          base: baseIndent,
          prev: $join.call(Array(depth + 1), baseIndent)
        };
      }
      function indentedJoin(xs, indent) {
        if (xs.length === 0) {
          return "";
        }
        var lineJoiner = "\n" + indent.prev + indent.base;
        return lineJoiner + $join.call(xs, "," + lineJoiner) + "\n" + indent.prev;
      }
      function arrObjKeys(obj, inspect) {
        var isArr = isArray3(obj);
        var xs = [];
        if (isArr) {
          xs.length = obj.length;
          for (var i12 = 0; i12 < obj.length; i12++) {
            xs[i12] = has2(obj, i12) ? inspect(obj[i12], obj) : "";
          }
        }
        var syms = typeof gOPS === "function" ? gOPS(obj) : [];
        var symMap;
        if (hasShammedSymbols) {
          symMap = {};
          for (var k6 = 0; k6 < syms.length; k6++) {
            symMap["$" + syms[k6]] = syms[k6];
          }
        }
        for (var key in obj) {
          if (!has2(obj, key)) {
            continue;
          }
          if (isArr && String(Number(key)) === key && key < obj.length) {
            continue;
          }
          if (hasShammedSymbols && symMap["$" + key] instanceof Symbol) {
            continue;
          } else if ($test.call(/[^\w$]/, key)) {
            xs.push(inspect(key, obj) + ": " + inspect(obj[key], obj));
          } else {
            xs.push(key + ": " + inspect(obj[key], obj));
          }
        }
        if (typeof gOPS === "function") {
          for (var j7 = 0; j7 < syms.length; j7++) {
            if (isEnumerable.call(obj, syms[j7])) {
              xs.push("[" + inspect(syms[j7]) + "]: " + inspect(obj[syms[j7]], obj));
            }
          }
        }
        return xs;
      }
    }
  });

  // node_modules/side-channel-list/index.js
  var require_side_channel_list = __commonJS({
    "node_modules/side-channel-list/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var inspect = require_object_inspect();
      var $TypeError = require_type();
      var listGetNode = function(list, key, isDelete) {
        var prev = list;
        var curr;
        for (; (curr = prev.next) != null; prev = curr) {
          if (curr.key === key) {
            prev.next = curr.next;
            if (!isDelete) {
              curr.next = /** @type {NonNullable<typeof list.next>} */
              list.next;
              list.next = curr;
            }
            return curr;
          }
        }
      };
      var listGet = function(objects, key) {
        if (!objects) {
          return void 0;
        }
        var node = listGetNode(objects, key);
        return node && node.value;
      };
      var listSet = function(objects, key, value) {
        var node = listGetNode(objects, key);
        if (node) {
          node.value = value;
        } else {
          objects.next = /** @type {import('./list.d.ts').ListNode<typeof value, typeof key>} */
          {
            // eslint-disable-line no-param-reassign, no-extra-parens
            key,
            next: objects.next,
            value
          };
        }
      };
      var listHas = function(objects, key) {
        if (!objects) {
          return false;
        }
        return !!listGetNode(objects, key);
      };
      var listDelete = function(objects, key) {
        if (objects) {
          return listGetNode(objects, key, true);
        }
      };
      module2.exports = function getSideChannelList() {
        var $o;
        var channel = {
          assert: function(key) {
            if (!channel.has(key)) {
              throw new $TypeError("Side channel does not contain " + inspect(key));
            }
          },
          "delete": function(key) {
            var deletedNode = listDelete($o, key);
            if (deletedNode && $o && !$o.next) {
              $o = void 0;
            }
            return !!deletedNode;
          },
          get: function(key) {
            return listGet($o, key);
          },
          has: function(key) {
            return listHas($o, key);
          },
          set: function(key, value) {
            if (!$o) {
              $o = {
                next: void 0
              };
            }
            listSet(
              /** @type {NonNullable<typeof $o>} */
              $o,
              key,
              value
            );
          }
        };
        return channel;
      };
    }
  });

  // node_modules/es-object-atoms/index.js
  var require_es_object_atoms = __commonJS({
    "node_modules/es-object-atoms/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Object;
    }
  });

  // node_modules/es-errors/index.js
  var require_es_errors = __commonJS({
    "node_modules/es-errors/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Error;
    }
  });

  // node_modules/es-errors/eval.js
  var require_eval = __commonJS({
    "node_modules/es-errors/eval.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = EvalError;
    }
  });

  // node_modules/es-errors/range.js
  var require_range = __commonJS({
    "node_modules/es-errors/range.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = RangeError;
    }
  });

  // node_modules/es-errors/ref.js
  var require_ref = __commonJS({
    "node_modules/es-errors/ref.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = ReferenceError;
    }
  });

  // node_modules/es-errors/syntax.js
  var require_syntax = __commonJS({
    "node_modules/es-errors/syntax.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = SyntaxError;
    }
  });

  // node_modules/es-errors/uri.js
  var require_uri = __commonJS({
    "node_modules/es-errors/uri.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = URIError;
    }
  });

  // node_modules/math-intrinsics/abs.js
  var require_abs = __commonJS({
    "node_modules/math-intrinsics/abs.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Math.abs;
    }
  });

  // node_modules/math-intrinsics/floor.js
  var require_floor = __commonJS({
    "node_modules/math-intrinsics/floor.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Math.floor;
    }
  });

  // node_modules/math-intrinsics/max.js
  var require_max = __commonJS({
    "node_modules/math-intrinsics/max.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Math.max;
    }
  });

  // node_modules/math-intrinsics/min.js
  var require_min = __commonJS({
    "node_modules/math-intrinsics/min.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Math.min;
    }
  });

  // node_modules/math-intrinsics/pow.js
  var require_pow = __commonJS({
    "node_modules/math-intrinsics/pow.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Math.pow;
    }
  });

  // node_modules/math-intrinsics/round.js
  var require_round = __commonJS({
    "node_modules/math-intrinsics/round.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Math.round;
    }
  });

  // node_modules/math-intrinsics/isNaN.js
  var require_isNaN = __commonJS({
    "node_modules/math-intrinsics/isNaN.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Number.isNaN || function isNaN2(a15) {
        return a15 !== a15;
      };
    }
  });

  // node_modules/math-intrinsics/sign.js
  var require_sign = __commonJS({
    "node_modules/math-intrinsics/sign.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var $isNaN = require_isNaN();
      module2.exports = function sign(number) {
        if ($isNaN(number) || number === 0) {
          return number;
        }
        return number < 0 ? -1 : 1;
      };
    }
  });

  // node_modules/gopd/gOPD.js
  var require_gOPD = __commonJS({
    "node_modules/gopd/gOPD.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Object.getOwnPropertyDescriptor;
    }
  });

  // node_modules/gopd/index.js
  var require_gopd = __commonJS({
    "node_modules/gopd/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var $gOPD = require_gOPD();
      if ($gOPD) {
        try {
          $gOPD([], "length");
        } catch (e6) {
          $gOPD = null;
        }
      }
      module2.exports = $gOPD;
    }
  });

  // node_modules/es-define-property/index.js
  var require_es_define_property = __commonJS({
    "node_modules/es-define-property/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var $defineProperty = Object.defineProperty || false;
      if ($defineProperty) {
        try {
          $defineProperty({}, "a", { value: 1 });
        } catch (e6) {
          $defineProperty = false;
        }
      }
      module2.exports = $defineProperty;
    }
  });

  // node_modules/has-symbols/shams.js
  var require_shams = __commonJS({
    "node_modules/has-symbols/shams.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = function hasSymbols() {
        if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
          return false;
        }
        if (typeof Symbol.iterator === "symbol") {
          return true;
        }
        var obj = {};
        var sym = /* @__PURE__ */ Symbol("test");
        var symObj = Object(sym);
        if (typeof sym === "string") {
          return false;
        }
        if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
          return false;
        }
        if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
          return false;
        }
        var symVal = 42;
        obj[sym] = symVal;
        for (var _4 in obj) {
          return false;
        }
        if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
          return false;
        }
        if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
          return false;
        }
        var syms = Object.getOwnPropertySymbols(obj);
        if (syms.length !== 1 || syms[0] !== sym) {
          return false;
        }
        if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
          return false;
        }
        if (typeof Object.getOwnPropertyDescriptor === "function") {
          var descriptor = (
            /** @type {PropertyDescriptor} */
            Object.getOwnPropertyDescriptor(obj, sym)
          );
          if (descriptor.value !== symVal || descriptor.enumerable !== true) {
            return false;
          }
        }
        return true;
      };
    }
  });

  // node_modules/has-symbols/index.js
  var require_has_symbols = __commonJS({
    "node_modules/has-symbols/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var origSymbol = typeof Symbol !== "undefined" && Symbol;
      var hasSymbolSham = require_shams();
      module2.exports = function hasNativeSymbols() {
        if (typeof origSymbol !== "function") {
          return false;
        }
        if (typeof Symbol !== "function") {
          return false;
        }
        if (typeof origSymbol("foo") !== "symbol") {
          return false;
        }
        if (typeof /* @__PURE__ */ Symbol("bar") !== "symbol") {
          return false;
        }
        return hasSymbolSham();
      };
    }
  });

  // node_modules/get-proto/Reflect.getPrototypeOf.js
  var require_Reflect_getPrototypeOf = __commonJS({
    "node_modules/get-proto/Reflect.getPrototypeOf.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
    }
  });

  // node_modules/get-proto/Object.getPrototypeOf.js
  var require_Object_getPrototypeOf = __commonJS({
    "node_modules/get-proto/Object.getPrototypeOf.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var $Object = require_es_object_atoms();
      module2.exports = $Object.getPrototypeOf || null;
    }
  });

  // node_modules/function-bind/implementation.js
  var require_implementation = __commonJS({
    "node_modules/function-bind/implementation.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
      var toStr = Object.prototype.toString;
      var max = Math.max;
      var funcType = "[object Function]";
      var concatty = function concatty2(a15, b8) {
        var arr = [];
        for (var i12 = 0; i12 < a15.length; i12 += 1) {
          arr[i12] = a15[i12];
        }
        for (var j7 = 0; j7 < b8.length; j7 += 1) {
          arr[j7 + a15.length] = b8[j7];
        }
        return arr;
      };
      var slicy = function slicy2(arrLike, offset) {
        var arr = [];
        for (var i12 = offset || 0, j7 = 0; i12 < arrLike.length; i12 += 1, j7 += 1) {
          arr[j7] = arrLike[i12];
        }
        return arr;
      };
      var joiny = function(arr, joiner) {
        var str = "";
        for (var i12 = 0; i12 < arr.length; i12 += 1) {
          str += arr[i12];
          if (i12 + 1 < arr.length) {
            str += joiner;
          }
        }
        return str;
      };
      module2.exports = function bind2(that) {
        var target = this;
        if (typeof target !== "function" || toStr.apply(target) !== funcType) {
          throw new TypeError(ERROR_MESSAGE + target);
        }
        var args = slicy(arguments, 1);
        var bound;
        var binder = function() {
          if (this instanceof bound) {
            var result = target.apply(
              this,
              concatty(args, arguments)
            );
            if (Object(result) === result) {
              return result;
            }
            return this;
          }
          return target.apply(
            that,
            concatty(args, arguments)
          );
        };
        var boundLength = max(0, target.length - args.length);
        var boundArgs = [];
        for (var i12 = 0; i12 < boundLength; i12++) {
          boundArgs[i12] = "$" + i12;
        }
        bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
        if (target.prototype) {
          var Empty = function Empty2() {
          };
          Empty.prototype = target.prototype;
          bound.prototype = new Empty();
          Empty.prototype = null;
        }
        return bound;
      };
    }
  });

  // node_modules/function-bind/index.js
  var require_function_bind = __commonJS({
    "node_modules/function-bind/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var implementation = require_implementation();
      module2.exports = Function.prototype.bind || implementation;
    }
  });

  // node_modules/call-bind-apply-helpers/functionCall.js
  var require_functionCall = __commonJS({
    "node_modules/call-bind-apply-helpers/functionCall.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Function.prototype.call;
    }
  });

  // node_modules/call-bind-apply-helpers/functionApply.js
  var require_functionApply = __commonJS({
    "node_modules/call-bind-apply-helpers/functionApply.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = Function.prototype.apply;
    }
  });

  // node_modules/call-bind-apply-helpers/reflectApply.js
  var require_reflectApply = __commonJS({
    "node_modules/call-bind-apply-helpers/reflectApply.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      module2.exports = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
    }
  });

  // node_modules/call-bind-apply-helpers/actualApply.js
  var require_actualApply = __commonJS({
    "node_modules/call-bind-apply-helpers/actualApply.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var bind2 = require_function_bind();
      var $apply = require_functionApply();
      var $call = require_functionCall();
      var $reflectApply = require_reflectApply();
      module2.exports = $reflectApply || bind2.call($call, $apply);
    }
  });

  // node_modules/call-bind-apply-helpers/index.js
  var require_call_bind_apply_helpers = __commonJS({
    "node_modules/call-bind-apply-helpers/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var bind2 = require_function_bind();
      var $TypeError = require_type();
      var $call = require_functionCall();
      var $actualApply = require_actualApply();
      module2.exports = function callBindBasic(args) {
        if (args.length < 1 || typeof args[0] !== "function") {
          throw new $TypeError("a function is required");
        }
        return $actualApply(bind2, $call, args);
      };
    }
  });

  // node_modules/dunder-proto/get.js
  var require_get = __commonJS({
    "node_modules/dunder-proto/get.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var callBind = require_call_bind_apply_helpers();
      var gOPD = require_gopd();
      var hasProtoAccessor;
      try {
        hasProtoAccessor = /** @type {{ __proto__?: typeof Array.prototype }} */
        [].__proto__ === Array.prototype;
      } catch (e6) {
        if (!e6 || typeof e6 !== "object" || !("code" in e6) || e6.code !== "ERR_PROTO_ACCESS") {
          throw e6;
        }
      }
      var desc = !!hasProtoAccessor && gOPD && gOPD(
        Object.prototype,
        /** @type {keyof typeof Object.prototype} */
        "__proto__"
      );
      var $Object = Object;
      var $getPrototypeOf = $Object.getPrototypeOf;
      module2.exports = desc && typeof desc.get === "function" ? callBind([desc.get]) : typeof $getPrototypeOf === "function" ? (
        /** @type {import('./get')} */
        function getDunder(value) {
          return $getPrototypeOf(value == null ? value : $Object(value));
        }
      ) : false;
    }
  });

  // node_modules/get-proto/index.js
  var require_get_proto = __commonJS({
    "node_modules/get-proto/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var reflectGetProto = require_Reflect_getPrototypeOf();
      var originalGetProto = require_Object_getPrototypeOf();
      var getDunderProto = require_get();
      module2.exports = reflectGetProto ? function getProto(O5) {
        return reflectGetProto(O5);
      } : originalGetProto ? function getProto(O5) {
        if (!O5 || typeof O5 !== "object" && typeof O5 !== "function") {
          throw new TypeError("getProto: not an object");
        }
        return originalGetProto(O5);
      } : getDunderProto ? function getProto(O5) {
        return getDunderProto(O5);
      } : null;
    }
  });

  // node_modules/hasown/index.js
  var require_hasown = __commonJS({
    "node_modules/hasown/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var call = Function.prototype.call;
      var $hasOwn = Object.prototype.hasOwnProperty;
      var bind2 = require_function_bind();
      module2.exports = bind2.call(call, $hasOwn);
    }
  });

  // node_modules/get-intrinsic/index.js
  var require_get_intrinsic = __commonJS({
    "node_modules/get-intrinsic/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var undefined2;
      var $Object = require_es_object_atoms();
      var $Error = require_es_errors();
      var $EvalError = require_eval();
      var $RangeError = require_range();
      var $ReferenceError = require_ref();
      var $SyntaxError = require_syntax();
      var $TypeError = require_type();
      var $URIError = require_uri();
      var abs = require_abs();
      var floor = require_floor();
      var max = require_max();
      var min = require_min();
      var pow = require_pow();
      var round = require_round();
      var sign = require_sign();
      var $Function = Function;
      var getEvalledConstructor = function(expressionSyntax) {
        try {
          return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
        } catch (e6) {
        }
      };
      var $gOPD = require_gopd();
      var $defineProperty = require_es_define_property();
      var throwTypeError = function() {
        throw new $TypeError();
      };
      var ThrowTypeError = $gOPD ? (function() {
        try {
          arguments.callee;
          return throwTypeError;
        } catch (calleeThrows) {
          try {
            return $gOPD(arguments, "callee").get;
          } catch (gOPDthrows) {
            return throwTypeError;
          }
        }
      })() : throwTypeError;
      var hasSymbols = require_has_symbols()();
      var getProto = require_get_proto();
      var $ObjectGPO = require_Object_getPrototypeOf();
      var $ReflectGPO = require_Reflect_getPrototypeOf();
      var $apply = require_functionApply();
      var $call = require_functionCall();
      var needsEval = {};
      var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined2 : getProto(Uint8Array);
      var INTRINSICS = {
        __proto__: null,
        "%AggregateError%": typeof AggregateError === "undefined" ? undefined2 : AggregateError,
        "%Array%": Array,
        "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined2 : ArrayBuffer,
        "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined2,
        "%AsyncFromSyncIteratorPrototype%": undefined2,
        "%AsyncFunction%": needsEval,
        "%AsyncGenerator%": needsEval,
        "%AsyncGeneratorFunction%": needsEval,
        "%AsyncIteratorPrototype%": needsEval,
        "%Atomics%": typeof Atomics === "undefined" ? undefined2 : Atomics,
        "%BigInt%": typeof BigInt === "undefined" ? undefined2 : BigInt,
        "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined2 : BigInt64Array,
        "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined2 : BigUint64Array,
        "%Boolean%": Boolean,
        "%DataView%": typeof DataView === "undefined" ? undefined2 : DataView,
        "%Date%": Date,
        "%decodeURI%": decodeURI,
        "%decodeURIComponent%": decodeURIComponent,
        "%encodeURI%": encodeURI,
        "%encodeURIComponent%": encodeURIComponent,
        "%Error%": $Error,
        "%eval%": eval,
        // eslint-disable-line no-eval
        "%EvalError%": $EvalError,
        "%Float16Array%": typeof Float16Array === "undefined" ? undefined2 : Float16Array,
        "%Float32Array%": typeof Float32Array === "undefined" ? undefined2 : Float32Array,
        "%Float64Array%": typeof Float64Array === "undefined" ? undefined2 : Float64Array,
        "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined2 : FinalizationRegistry,
        "%Function%": $Function,
        "%GeneratorFunction%": needsEval,
        "%Int8Array%": typeof Int8Array === "undefined" ? undefined2 : Int8Array,
        "%Int16Array%": typeof Int16Array === "undefined" ? undefined2 : Int16Array,
        "%Int32Array%": typeof Int32Array === "undefined" ? undefined2 : Int32Array,
        "%isFinite%": isFinite,
        "%isNaN%": isNaN,
        "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined2,
        "%JSON%": typeof JSON === "object" ? JSON : undefined2,
        "%Map%": typeof Map === "undefined" ? undefined2 : Map,
        "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
        "%Math%": Math,
        "%Number%": Number,
        "%Object%": $Object,
        "%Object.getOwnPropertyDescriptor%": $gOPD,
        "%parseFloat%": parseFloat,
        "%parseInt%": parseInt,
        "%Promise%": typeof Promise === "undefined" ? undefined2 : Promise,
        "%Proxy%": typeof Proxy === "undefined" ? undefined2 : Proxy,
        "%RangeError%": $RangeError,
        "%ReferenceError%": $ReferenceError,
        "%Reflect%": typeof Reflect === "undefined" ? undefined2 : Reflect,
        "%RegExp%": RegExp,
        "%Set%": typeof Set === "undefined" ? undefined2 : Set,
        "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
        "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined2 : SharedArrayBuffer,
        "%String%": String,
        "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined2,
        "%Symbol%": hasSymbols ? Symbol : undefined2,
        "%SyntaxError%": $SyntaxError,
        "%ThrowTypeError%": ThrowTypeError,
        "%TypedArray%": TypedArray,
        "%TypeError%": $TypeError,
        "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined2 : Uint8Array,
        "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined2 : Uint8ClampedArray,
        "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined2 : Uint16Array,
        "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined2 : Uint32Array,
        "%URIError%": $URIError,
        "%WeakMap%": typeof WeakMap === "undefined" ? undefined2 : WeakMap,
        "%WeakRef%": typeof WeakRef === "undefined" ? undefined2 : WeakRef,
        "%WeakSet%": typeof WeakSet === "undefined" ? undefined2 : WeakSet,
        "%Function.prototype.call%": $call,
        "%Function.prototype.apply%": $apply,
        "%Object.defineProperty%": $defineProperty,
        "%Object.getPrototypeOf%": $ObjectGPO,
        "%Math.abs%": abs,
        "%Math.floor%": floor,
        "%Math.max%": max,
        "%Math.min%": min,
        "%Math.pow%": pow,
        "%Math.round%": round,
        "%Math.sign%": sign,
        "%Reflect.getPrototypeOf%": $ReflectGPO
      };
      if (getProto) {
        try {
          null.error;
        } catch (e6) {
          errorProto = getProto(getProto(e6));
          INTRINSICS["%Error.prototype%"] = errorProto;
        }
      }
      var errorProto;
      var doEval = function doEval2(name) {
        var value;
        if (name === "%AsyncFunction%") {
          value = getEvalledConstructor("async function () {}");
        } else if (name === "%GeneratorFunction%") {
          value = getEvalledConstructor("function* () {}");
        } else if (name === "%AsyncGeneratorFunction%") {
          value = getEvalledConstructor("async function* () {}");
        } else if (name === "%AsyncGenerator%") {
          var fn = doEval2("%AsyncGeneratorFunction%");
          if (fn) {
            value = fn.prototype;
          }
        } else if (name === "%AsyncIteratorPrototype%") {
          var gen = doEval2("%AsyncGenerator%");
          if (gen && getProto) {
            value = getProto(gen.prototype);
          }
        }
        INTRINSICS[name] = value;
        return value;
      };
      var LEGACY_ALIASES = {
        __proto__: null,
        "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
        "%ArrayPrototype%": ["Array", "prototype"],
        "%ArrayProto_entries%": ["Array", "prototype", "entries"],
        "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
        "%ArrayProto_keys%": ["Array", "prototype", "keys"],
        "%ArrayProto_values%": ["Array", "prototype", "values"],
        "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
        "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
        "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
        "%BooleanPrototype%": ["Boolean", "prototype"],
        "%DataViewPrototype%": ["DataView", "prototype"],
        "%DatePrototype%": ["Date", "prototype"],
        "%ErrorPrototype%": ["Error", "prototype"],
        "%EvalErrorPrototype%": ["EvalError", "prototype"],
        "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
        "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
        "%FunctionPrototype%": ["Function", "prototype"],
        "%Generator%": ["GeneratorFunction", "prototype"],
        "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
        "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
        "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
        "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
        "%JSONParse%": ["JSON", "parse"],
        "%JSONStringify%": ["JSON", "stringify"],
        "%MapPrototype%": ["Map", "prototype"],
        "%NumberPrototype%": ["Number", "prototype"],
        "%ObjectPrototype%": ["Object", "prototype"],
        "%ObjProto_toString%": ["Object", "prototype", "toString"],
        "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
        "%PromisePrototype%": ["Promise", "prototype"],
        "%PromiseProto_then%": ["Promise", "prototype", "then"],
        "%Promise_all%": ["Promise", "all"],
        "%Promise_reject%": ["Promise", "reject"],
        "%Promise_resolve%": ["Promise", "resolve"],
        "%RangeErrorPrototype%": ["RangeError", "prototype"],
        "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
        "%RegExpPrototype%": ["RegExp", "prototype"],
        "%SetPrototype%": ["Set", "prototype"],
        "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
        "%StringPrototype%": ["String", "prototype"],
        "%SymbolPrototype%": ["Symbol", "prototype"],
        "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
        "%TypedArrayPrototype%": ["TypedArray", "prototype"],
        "%TypeErrorPrototype%": ["TypeError", "prototype"],
        "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
        "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
        "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
        "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
        "%URIErrorPrototype%": ["URIError", "prototype"],
        "%WeakMapPrototype%": ["WeakMap", "prototype"],
        "%WeakSetPrototype%": ["WeakSet", "prototype"]
      };
      var bind2 = require_function_bind();
      var hasOwn = require_hasown();
      var $concat = bind2.call($call, Array.prototype.concat);
      var $spliceApply = bind2.call($apply, Array.prototype.splice);
      var $replace = bind2.call($call, String.prototype.replace);
      var $strSlice = bind2.call($call, String.prototype.slice);
      var $exec = bind2.call($call, RegExp.prototype.exec);
      var rePropName2 = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
      var reEscapeChar2 = /\\(\\)?/g;
      var stringToPath2 = function stringToPath3(string) {
        var first = $strSlice(string, 0, 1);
        var last = $strSlice(string, -1);
        if (first === "%" && last !== "%") {
          throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
        } else if (last === "%" && first !== "%") {
          throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
        }
        var result = [];
        $replace(string, rePropName2, function(match, number, quote, subString) {
          result[result.length] = quote ? $replace(subString, reEscapeChar2, "$1") : number || match;
        });
        return result;
      };
      var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
        var intrinsicName = name;
        var alias;
        if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
          alias = LEGACY_ALIASES[intrinsicName];
          intrinsicName = "%" + alias[0] + "%";
        }
        if (hasOwn(INTRINSICS, intrinsicName)) {
          var value = INTRINSICS[intrinsicName];
          if (value === needsEval) {
            value = doEval(intrinsicName);
          }
          if (typeof value === "undefined" && !allowMissing) {
            throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
          }
          return {
            alias,
            name: intrinsicName,
            value
          };
        }
        throw new $SyntaxError("intrinsic " + name + " does not exist!");
      };
      module2.exports = function GetIntrinsic(name, allowMissing) {
        if (typeof name !== "string" || name.length === 0) {
          throw new $TypeError("intrinsic name must be a non-empty string");
        }
        if (arguments.length > 1 && typeof allowMissing !== "boolean") {
          throw new $TypeError('"allowMissing" argument must be a boolean');
        }
        if ($exec(/^%?[^%]*%?$/, name) === null) {
          throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
        }
        var parts = stringToPath2(name);
        var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
        var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
        var intrinsicRealName = intrinsic.name;
        var value = intrinsic.value;
        var skipFurtherCaching = false;
        var alias = intrinsic.alias;
        if (alias) {
          intrinsicBaseName = alias[0];
          $spliceApply(parts, $concat([0, 1], alias));
        }
        for (var i12 = 1, isOwn = true; i12 < parts.length; i12 += 1) {
          var part = parts[i12];
          var first = $strSlice(part, 0, 1);
          var last = $strSlice(part, -1);
          if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
            throw new $SyntaxError("property names with quotes must have matching quotes");
          }
          if (part === "constructor" || !isOwn) {
            skipFurtherCaching = true;
          }
          intrinsicBaseName += "." + part;
          intrinsicRealName = "%" + intrinsicBaseName + "%";
          if (hasOwn(INTRINSICS, intrinsicRealName)) {
            value = INTRINSICS[intrinsicRealName];
          } else if (value != null) {
            if (!(part in value)) {
              if (!allowMissing) {
                throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
              }
              return void undefined2;
            }
            if ($gOPD && i12 + 1 >= parts.length) {
              var desc = $gOPD(value, part);
              isOwn = !!desc;
              if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
                value = desc.get;
              } else {
                value = value[part];
              }
            } else {
              isOwn = hasOwn(value, part);
              value = value[part];
            }
            if (isOwn && !skipFurtherCaching) {
              INTRINSICS[intrinsicRealName] = value;
            }
          }
        }
        return value;
      };
    }
  });

  // node_modules/call-bound/index.js
  var require_call_bound = __commonJS({
    "node_modules/call-bound/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var GetIntrinsic = require_get_intrinsic();
      var callBindBasic = require_call_bind_apply_helpers();
      var $indexOf = callBindBasic([GetIntrinsic("%String.prototype.indexOf%")]);
      module2.exports = function callBoundIntrinsic(name, allowMissing) {
        var intrinsic = (
          /** @type {(this: unknown, ...args: unknown[]) => unknown} */
          GetIntrinsic(name, !!allowMissing)
        );
        if (typeof intrinsic === "function" && $indexOf(name, ".prototype.") > -1) {
          return callBindBasic(
            /** @type {const} */
            [intrinsic]
          );
        }
        return intrinsic;
      };
    }
  });

  // node_modules/side-channel-map/index.js
  var require_side_channel_map = __commonJS({
    "node_modules/side-channel-map/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var GetIntrinsic = require_get_intrinsic();
      var callBound = require_call_bound();
      var inspect = require_object_inspect();
      var $TypeError = require_type();
      var $Map = GetIntrinsic("%Map%", true);
      var $mapGet = callBound("Map.prototype.get", true);
      var $mapSet = callBound("Map.prototype.set", true);
      var $mapHas = callBound("Map.prototype.has", true);
      var $mapDelete = callBound("Map.prototype.delete", true);
      var $mapSize = callBound("Map.prototype.size", true);
      module2.exports = !!$Map && /** @type {Exclude<import('.'), false>} */
      function getSideChannelMap() {
        var $m;
        var channel = {
          assert: function(key) {
            if (!channel.has(key)) {
              throw new $TypeError("Side channel does not contain " + inspect(key));
            }
          },
          "delete": function(key) {
            if ($m) {
              var result = $mapDelete($m, key);
              if ($mapSize($m) === 0) {
                $m = void 0;
              }
              return result;
            }
            return false;
          },
          get: function(key) {
            if ($m) {
              return $mapGet($m, key);
            }
          },
          has: function(key) {
            if ($m) {
              return $mapHas($m, key);
            }
            return false;
          },
          set: function(key, value) {
            if (!$m) {
              $m = new $Map();
            }
            $mapSet($m, key, value);
          }
        };
        return channel;
      };
    }
  });

  // node_modules/side-channel-weakmap/index.js
  var require_side_channel_weakmap = __commonJS({
    "node_modules/side-channel-weakmap/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var GetIntrinsic = require_get_intrinsic();
      var callBound = require_call_bound();
      var inspect = require_object_inspect();
      var getSideChannelMap = require_side_channel_map();
      var $TypeError = require_type();
      var $WeakMap = GetIntrinsic("%WeakMap%", true);
      var $weakMapGet = callBound("WeakMap.prototype.get", true);
      var $weakMapSet = callBound("WeakMap.prototype.set", true);
      var $weakMapHas = callBound("WeakMap.prototype.has", true);
      var $weakMapDelete = callBound("WeakMap.prototype.delete", true);
      module2.exports = $WeakMap ? (
        /** @type {Exclude<import('.'), false>} */
        function getSideChannelWeakMap() {
          var $wm;
          var $m;
          var channel = {
            assert: function(key) {
              if (!channel.has(key)) {
                throw new $TypeError("Side channel does not contain " + inspect(key));
              }
            },
            "delete": function(key) {
              if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
                if ($wm) {
                  return $weakMapDelete($wm, key);
                }
              } else if (getSideChannelMap) {
                if ($m) {
                  return $m["delete"](key);
                }
              }
              return false;
            },
            get: function(key) {
              if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
                if ($wm) {
                  return $weakMapGet($wm, key);
                }
              }
              return $m && $m.get(key);
            },
            has: function(key) {
              if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
                if ($wm) {
                  return $weakMapHas($wm, key);
                }
              }
              return !!$m && $m.has(key);
            },
            set: function(key, value) {
              if ($WeakMap && key && (typeof key === "object" || typeof key === "function")) {
                if (!$wm) {
                  $wm = new $WeakMap();
                }
                $weakMapSet($wm, key, value);
              } else if (getSideChannelMap) {
                if (!$m) {
                  $m = getSideChannelMap();
                }
                $m.set(key, value);
              }
            }
          };
          return channel;
        }
      ) : getSideChannelMap;
    }
  });

  // node_modules/side-channel/index.js
  var require_side_channel = __commonJS({
    "node_modules/side-channel/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var $TypeError = require_type();
      var inspect = require_object_inspect();
      var getSideChannelList = require_side_channel_list();
      var getSideChannelMap = require_side_channel_map();
      var getSideChannelWeakMap = require_side_channel_weakmap();
      var makeChannel = getSideChannelWeakMap || getSideChannelMap || getSideChannelList;
      module2.exports = function getSideChannel() {
        var $channelData;
        var channel = {
          assert: function(key) {
            if (!channel.has(key)) {
              throw new $TypeError("Side channel does not contain " + inspect(key));
            }
          },
          "delete": function(key) {
            return !!$channelData && $channelData["delete"](key);
          },
          get: function(key) {
            return $channelData && $channelData.get(key);
          },
          has: function(key) {
            return !!$channelData && $channelData.has(key);
          },
          set: function(key, value) {
            if (!$channelData) {
              $channelData = makeChannel();
            }
            $channelData.set(key, value);
          }
        };
        return channel;
      };
    }
  });

  // node_modules/qs/lib/formats.js
  var require_formats = __commonJS({
    "node_modules/qs/lib/formats.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var replace = String.prototype.replace;
      var percentTwenties = /%20/g;
      var Format = {
        RFC1738: "RFC1738",
        RFC3986: "RFC3986"
      };
      module2.exports = {
        "default": Format.RFC3986,
        formatters: {
          RFC1738: function(value) {
            return replace.call(value, percentTwenties, "+");
          },
          RFC3986: function(value) {
            return String(value);
          }
        },
        RFC1738: Format.RFC1738,
        RFC3986: Format.RFC3986
      };
    }
  });

  // node_modules/qs/lib/utils.js
  var require_utils = __commonJS({
    "node_modules/qs/lib/utils.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var formats = require_formats();
      var getSideChannel = require_side_channel();
      var has2 = Object.prototype.hasOwnProperty;
      var isArray3 = Array.isArray;
      var overflowChannel = getSideChannel();
      var markOverflow = function markOverflow2(obj, maxIndex) {
        overflowChannel.set(obj, maxIndex);
        return obj;
      };
      var isOverflow = function isOverflow2(obj) {
        return overflowChannel.has(obj);
      };
      var getMaxIndex = function getMaxIndex2(obj) {
        return overflowChannel.get(obj);
      };
      var setMaxIndex = function setMaxIndex2(obj, maxIndex) {
        overflowChannel.set(obj, maxIndex);
      };
      var hexTable = (function() {
        var array = [];
        for (var i12 = 0; i12 < 256; ++i12) {
          array[array.length] = "%" + ((i12 < 16 ? "0" : "") + i12.toString(16)).toUpperCase();
        }
        return array;
      })();
      var compactQueue = function compactQueue2(queue5) {
        while (queue5.length > 1) {
          var item = queue5.pop();
          var obj = item.obj[item.prop];
          if (isArray3(obj)) {
            var compacted = [];
            for (var j7 = 0; j7 < obj.length; ++j7) {
              if (typeof obj[j7] !== "undefined") {
                compacted[compacted.length] = obj[j7];
              }
            }
            item.obj[item.prop] = compacted;
          }
        }
      };
      var arrayToObject2 = function arrayToObject3(source, options) {
        var obj = options && options.plainObjects ? { __proto__: null } : {};
        for (var i12 = 0; i12 < source.length; ++i12) {
          if (typeof source[i12] !== "undefined") {
            obj[i12] = source[i12];
          }
        }
        return obj;
      };
      var merge3 = function merge4(target, source, options) {
        if (!source) {
          return target;
        }
        if (typeof source !== "object" && typeof source !== "function") {
          if (isArray3(target)) {
            var nextIndex = target.length;
            if (options && typeof options.arrayLimit === "number" && nextIndex > options.arrayLimit) {
              return markOverflow(arrayToObject2(target.concat(source), options), nextIndex);
            }
            target[nextIndex] = source;
          } else if (target && typeof target === "object") {
            if (isOverflow(target)) {
              var newIndex = getMaxIndex(target) + 1;
              target[newIndex] = source;
              setMaxIndex(target, newIndex);
            } else if (options && options.strictMerge) {
              return [target, source];
            } else if (options && (options.plainObjects || options.allowPrototypes) || !has2.call(Object.prototype, source)) {
              target[source] = true;
            }
          } else {
            return [target, source];
          }
          return target;
        }
        if (!target || typeof target !== "object") {
          if (isOverflow(source)) {
            var sourceKeys = Object.keys(source);
            var result = options && options.plainObjects ? { __proto__: null, 0: target } : { 0: target };
            for (var m6 = 0; m6 < sourceKeys.length; m6++) {
              var oldKey = parseInt(sourceKeys[m6], 10);
              result[oldKey + 1] = source[sourceKeys[m6]];
            }
            return markOverflow(result, getMaxIndex(source) + 1);
          }
          var combined = [target].concat(source);
          if (options && typeof options.arrayLimit === "number" && combined.length > options.arrayLimit) {
            return markOverflow(arrayToObject2(combined, options), combined.length - 1);
          }
          return combined;
        }
        var mergeTarget = target;
        if (isArray3(target) && !isArray3(source)) {
          mergeTarget = arrayToObject2(target, options);
        }
        if (isArray3(target) && isArray3(source)) {
          source.forEach(function(item, i12) {
            if (has2.call(target, i12)) {
              var targetItem = target[i12];
              if (targetItem && typeof targetItem === "object" && item && typeof item === "object") {
                target[i12] = merge4(targetItem, item, options);
              } else {
                target[target.length] = item;
              }
            } else {
              target[i12] = item;
            }
          });
          return target;
        }
        return Object.keys(source).reduce(function(acc, key) {
          var value = source[key];
          if (has2.call(acc, key)) {
            acc[key] = merge4(acc[key], value, options);
          } else {
            acc[key] = value;
          }
          if (isOverflow(source) && !isOverflow(acc)) {
            markOverflow(acc, getMaxIndex(source));
          }
          if (isOverflow(acc)) {
            var keyNum = parseInt(key, 10);
            if (String(keyNum) === key && keyNum >= 0 && keyNum > getMaxIndex(acc)) {
              setMaxIndex(acc, keyNum);
            }
          }
          return acc;
        }, mergeTarget);
      };
      var assign = function assignSingleSource(target, source) {
        return Object.keys(source).reduce(function(acc, key) {
          acc[key] = source[key];
          return acc;
        }, target);
      };
      var decode = function(str, defaultDecoder, charset) {
        var strWithoutPlus = str.replace(/\+/g, " ");
        if (charset === "iso-8859-1") {
          return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
        }
        try {
          return decodeURIComponent(strWithoutPlus);
        } catch (e6) {
          return strWithoutPlus;
        }
      };
      var limit = 1024;
      var encode3 = function encode4(str, defaultEncoder, charset, kind, format) {
        if (str.length === 0) {
          return str;
        }
        var string = str;
        if (typeof str === "symbol") {
          string = Symbol.prototype.toString.call(str);
        } else if (typeof str !== "string") {
          string = String(str);
        }
        if (charset === "iso-8859-1") {
          return escape(string).replace(/%u[0-9a-f]{4}/gi, function($0) {
            return "%26%23" + parseInt($0.slice(2), 16) + "%3B";
          });
        }
        var out = "";
        for (var j7 = 0; j7 < string.length; j7 += limit) {
          var segment = string.length >= limit ? string.slice(j7, j7 + limit) : string;
          var arr = [];
          for (var i12 = 0; i12 < segment.length; ++i12) {
            var c12 = segment.charCodeAt(i12);
            if (c12 === 45 || c12 === 46 || c12 === 95 || c12 === 126 || c12 >= 48 && c12 <= 57 || c12 >= 65 && c12 <= 90 || c12 >= 97 && c12 <= 122 || format === formats.RFC1738 && (c12 === 40 || c12 === 41)) {
              arr[arr.length] = segment.charAt(i12);
              continue;
            }
            if (c12 < 128) {
              arr[arr.length] = hexTable[c12];
              continue;
            }
            if (c12 < 2048) {
              arr[arr.length] = hexTable[192 | c12 >> 6] + hexTable[128 | c12 & 63];
              continue;
            }
            if (c12 < 55296 || c12 >= 57344) {
              arr[arr.length] = hexTable[224 | c12 >> 12] + hexTable[128 | c12 >> 6 & 63] + hexTable[128 | c12 & 63];
              continue;
            }
            i12 += 1;
            c12 = 65536 + ((c12 & 1023) << 10 | segment.charCodeAt(i12) & 1023);
            arr[arr.length] = hexTable[240 | c12 >> 18] + hexTable[128 | c12 >> 12 & 63] + hexTable[128 | c12 >> 6 & 63] + hexTable[128 | c12 & 63];
          }
          out += arr.join("");
        }
        return out;
      };
      var compact = function compact2(value) {
        var queue5 = [{ obj: { o: value }, prop: "o" }];
        var refs = [];
        for (var i12 = 0; i12 < queue5.length; ++i12) {
          var item = queue5[i12];
          var obj = item.obj[item.prop];
          var keys2 = Object.keys(obj);
          for (var j7 = 0; j7 < keys2.length; ++j7) {
            var key = keys2[j7];
            var val = obj[key];
            if (typeof val === "object" && val !== null && refs.indexOf(val) === -1) {
              queue5[queue5.length] = { obj, prop: key };
              refs[refs.length] = val;
            }
          }
        }
        compactQueue(queue5);
        return value;
      };
      var isRegExp2 = function isRegExp3(obj) {
        return Object.prototype.toString.call(obj) === "[object RegExp]";
      };
      var isBuffer3 = function isBuffer4(obj) {
        if (!obj || typeof obj !== "object") {
          return false;
        }
        return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
      };
      var combine = function combine2(a15, b8, arrayLimit, plainObjects) {
        if (isOverflow(a15)) {
          var newIndex = getMaxIndex(a15) + 1;
          a15[newIndex] = b8;
          setMaxIndex(a15, newIndex);
          return a15;
        }
        var result = [].concat(a15, b8);
        if (result.length > arrayLimit) {
          return markOverflow(arrayToObject2(result, { plainObjects }), result.length - 1);
        }
        return result;
      };
      var maybeMap = function maybeMap2(val, fn) {
        if (isArray3(val)) {
          var mapped = [];
          for (var i12 = 0; i12 < val.length; i12 += 1) {
            mapped[mapped.length] = fn(val[i12]);
          }
          return mapped;
        }
        return fn(val);
      };
      module2.exports = {
        arrayToObject: arrayToObject2,
        assign,
        combine,
        compact,
        decode,
        encode: encode3,
        isBuffer: isBuffer3,
        isOverflow,
        isRegExp: isRegExp2,
        markOverflow,
        maybeMap,
        merge: merge3
      };
    }
  });

  // node_modules/qs/lib/stringify.js
  var require_stringify = __commonJS({
    "node_modules/qs/lib/stringify.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var getSideChannel = require_side_channel();
      var utils = require_utils();
      var formats = require_formats();
      var has2 = Object.prototype.hasOwnProperty;
      var arrayPrefixGenerators = {
        brackets: function brackets(prefix) {
          return prefix + "[]";
        },
        comma: "comma",
        indices: function indices(prefix, key) {
          return prefix + "[" + key + "]";
        },
        repeat: function repeat(prefix) {
          return prefix;
        }
      };
      var isArray3 = Array.isArray;
      var push = Array.prototype.push;
      var pushToArray = function(arr, valueOrArray) {
        push.apply(arr, isArray3(valueOrArray) ? valueOrArray : [valueOrArray]);
      };
      var toISO = Date.prototype.toISOString;
      var defaultFormat = formats["default"];
      var defaults2 = {
        addQueryPrefix: false,
        allowDots: false,
        allowEmptyArrays: false,
        arrayFormat: "indices",
        charset: "utf-8",
        charsetSentinel: false,
        commaRoundTrip: false,
        delimiter: "&",
        encode: true,
        encodeDotInKeys: false,
        encoder: utils.encode,
        encodeValuesOnly: false,
        filter: void 0,
        format: defaultFormat,
        formatter: formats.formatters[defaultFormat],
        // deprecated
        indices: false,
        serializeDate: function serializeDate(date) {
          return toISO.call(date);
        },
        skipNulls: false,
        strictNullHandling: false
      };
      var isNonNullishPrimitive = function isNonNullishPrimitive2(v4) {
        return typeof v4 === "string" || typeof v4 === "number" || typeof v4 === "boolean" || typeof v4 === "symbol" || typeof v4 === "bigint";
      };
      var sentinel = {};
      var stringify2 = function stringify3(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter2, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
        var obj = object;
        var tmpSc = sideChannel;
        var step = 0;
        var findFlag = false;
        while ((tmpSc = tmpSc.get(sentinel)) !== void 0 && !findFlag) {
          var pos = tmpSc.get(object);
          step += 1;
          if (typeof pos !== "undefined") {
            if (pos === step) {
              throw new RangeError("Cyclic object value");
            } else {
              findFlag = true;
            }
          }
          if (typeof tmpSc.get(sentinel) === "undefined") {
            step = 0;
          }
        }
        if (typeof filter2 === "function") {
          obj = filter2(prefix, obj);
        } else if (obj instanceof Date) {
          obj = serializeDate(obj);
        } else if (generateArrayPrefix === "comma" && isArray3(obj)) {
          obj = utils.maybeMap(obj, function(value2) {
            if (value2 instanceof Date) {
              return serializeDate(value2);
            }
            return value2;
          });
        }
        if (obj === null) {
          if (strictNullHandling) {
            return formatter(encoder && !encodeValuesOnly ? encoder(prefix, defaults2.encoder, charset, "key", format) : prefix);
          }
          obj = "";
        }
        if (isNonNullishPrimitive(obj) || utils.isBuffer(obj)) {
          if (encoder) {
            var keyValue = encodeValuesOnly ? prefix : encoder(prefix, defaults2.encoder, charset, "key", format);
            return [formatter(keyValue) + "=" + formatter(encoder(obj, defaults2.encoder, charset, "value", format))];
          }
          return [formatter(prefix) + "=" + formatter(String(obj))];
        }
        var values = [];
        if (typeof obj === "undefined") {
          return values;
        }
        var objKeys;
        if (generateArrayPrefix === "comma" && isArray3(obj)) {
          if (encodeValuesOnly && encoder) {
            obj = utils.maybeMap(obj, function(v4) {
              return v4 == null ? v4 : encoder(v4);
            });
          }
          objKeys = [{ value: obj.length > 0 ? obj.join(",") || null : void 0 }];
        } else if (isArray3(filter2)) {
          objKeys = filter2;
        } else {
          var keys2 = Object.keys(obj);
          objKeys = sort ? keys2.sort(sort) : keys2;
        }
        var encodedPrefix = encodeDotInKeys ? String(prefix).replace(/\./g, "%2E") : String(prefix);
        var adjustedPrefix = commaRoundTrip && isArray3(obj) && obj.length === 1 ? encodedPrefix + "[]" : encodedPrefix;
        if (allowEmptyArrays && isArray3(obj) && obj.length === 0) {
          return adjustedPrefix + "[]";
        }
        for (var j7 = 0; j7 < objKeys.length; ++j7) {
          var key = objKeys[j7];
          var value = typeof key === "object" && key && typeof key.value !== "undefined" ? key.value : obj[key];
          if (skipNulls && value === null) {
            continue;
          }
          var encodedKey = allowDots && encodeDotInKeys ? String(key).replace(/\./g, "%2E") : String(key);
          var keyPrefix = isArray3(obj) ? typeof generateArrayPrefix === "function" ? generateArrayPrefix(adjustedPrefix, encodedKey) : adjustedPrefix : adjustedPrefix + (allowDots ? "." + encodedKey : "[" + encodedKey + "]");
          sideChannel.set(object, step);
          var valueSideChannel = getSideChannel();
          valueSideChannel.set(sentinel, sideChannel);
          pushToArray(values, stringify3(
            value,
            keyPrefix,
            generateArrayPrefix,
            commaRoundTrip,
            allowEmptyArrays,
            strictNullHandling,
            skipNulls,
            encodeDotInKeys,
            generateArrayPrefix === "comma" && encodeValuesOnly && isArray3(obj) ? null : encoder,
            filter2,
            sort,
            allowDots,
            serializeDate,
            format,
            formatter,
            encodeValuesOnly,
            charset,
            valueSideChannel
          ));
        }
        return values;
      };
      var normalizeStringifyOptions = function normalizeStringifyOptions2(opts) {
        if (!opts) {
          return defaults2;
        }
        if (typeof opts.allowEmptyArrays !== "undefined" && typeof opts.allowEmptyArrays !== "boolean") {
          throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
        }
        if (typeof opts.encodeDotInKeys !== "undefined" && typeof opts.encodeDotInKeys !== "boolean") {
          throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
        }
        if (opts.encoder !== null && typeof opts.encoder !== "undefined" && typeof opts.encoder !== "function") {
          throw new TypeError("Encoder has to be a function.");
        }
        var charset = opts.charset || defaults2.charset;
        if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
          throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
        }
        var format = formats["default"];
        if (typeof opts.format !== "undefined") {
          if (!has2.call(formats.formatters, opts.format)) {
            throw new TypeError("Unknown format option provided.");
          }
          format = opts.format;
        }
        var formatter = formats.formatters[format];
        var filter2 = defaults2.filter;
        if (typeof opts.filter === "function" || isArray3(opts.filter)) {
          filter2 = opts.filter;
        }
        var arrayFormat;
        if (opts.arrayFormat in arrayPrefixGenerators) {
          arrayFormat = opts.arrayFormat;
        } else if ("indices" in opts) {
          arrayFormat = opts.indices ? "indices" : "repeat";
        } else {
          arrayFormat = defaults2.arrayFormat;
        }
        if ("commaRoundTrip" in opts && typeof opts.commaRoundTrip !== "boolean") {
          throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
        }
        var allowDots = typeof opts.allowDots === "undefined" ? opts.encodeDotInKeys === true ? true : defaults2.allowDots : !!opts.allowDots;
        return {
          addQueryPrefix: typeof opts.addQueryPrefix === "boolean" ? opts.addQueryPrefix : defaults2.addQueryPrefix,
          allowDots,
          allowEmptyArrays: typeof opts.allowEmptyArrays === "boolean" ? !!opts.allowEmptyArrays : defaults2.allowEmptyArrays,
          arrayFormat,
          charset,
          charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults2.charsetSentinel,
          commaRoundTrip: !!opts.commaRoundTrip,
          delimiter: typeof opts.delimiter === "undefined" ? defaults2.delimiter : opts.delimiter,
          encode: typeof opts.encode === "boolean" ? opts.encode : defaults2.encode,
          encodeDotInKeys: typeof opts.encodeDotInKeys === "boolean" ? opts.encodeDotInKeys : defaults2.encodeDotInKeys,
          encoder: typeof opts.encoder === "function" ? opts.encoder : defaults2.encoder,
          encodeValuesOnly: typeof opts.encodeValuesOnly === "boolean" ? opts.encodeValuesOnly : defaults2.encodeValuesOnly,
          filter: filter2,
          format,
          formatter,
          serializeDate: typeof opts.serializeDate === "function" ? opts.serializeDate : defaults2.serializeDate,
          skipNulls: typeof opts.skipNulls === "boolean" ? opts.skipNulls : defaults2.skipNulls,
          sort: typeof opts.sort === "function" ? opts.sort : null,
          strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults2.strictNullHandling
        };
      };
      module2.exports = function(object, opts) {
        var obj = object;
        var options = normalizeStringifyOptions(opts);
        var objKeys;
        var filter2;
        if (typeof options.filter === "function") {
          filter2 = options.filter;
          obj = filter2("", obj);
        } else if (isArray3(options.filter)) {
          filter2 = options.filter;
          objKeys = filter2;
        }
        var keys2 = [];
        if (typeof obj !== "object" || obj === null) {
          return "";
        }
        var generateArrayPrefix = arrayPrefixGenerators[options.arrayFormat];
        var commaRoundTrip = generateArrayPrefix === "comma" && options.commaRoundTrip;
        if (!objKeys) {
          objKeys = Object.keys(obj);
        }
        if (options.sort) {
          objKeys.sort(options.sort);
        }
        var sideChannel = getSideChannel();
        for (var i12 = 0; i12 < objKeys.length; ++i12) {
          var key = objKeys[i12];
          if (typeof key === "undefined" || key === null) {
            continue;
          }
          var value = obj[key];
          if (options.skipNulls && value === null) {
            continue;
          }
          pushToArray(keys2, stringify2(
            value,
            key,
            generateArrayPrefix,
            commaRoundTrip,
            options.allowEmptyArrays,
            options.strictNullHandling,
            options.skipNulls,
            options.encodeDotInKeys,
            options.encode ? options.encoder : null,
            options.filter,
            options.sort,
            options.allowDots,
            options.serializeDate,
            options.format,
            options.formatter,
            options.encodeValuesOnly,
            options.charset,
            sideChannel
          ));
        }
        var joined = keys2.join(options.delimiter);
        var prefix = options.addQueryPrefix === true ? "?" : "";
        if (options.charsetSentinel) {
          if (options.charset === "iso-8859-1") {
            prefix += "utf8=%26%2310003%3B" + options.delimiter;
          } else {
            prefix += "utf8=%E2%9C%93" + options.delimiter;
          }
        }
        return joined.length > 0 ? prefix + joined : "";
      };
    }
  });

  // node_modules/qs/lib/parse.js
  var require_parse = __commonJS({
    "node_modules/qs/lib/parse.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var utils = require_utils();
      var has2 = Object.prototype.hasOwnProperty;
      var isArray3 = Array.isArray;
      var defaults2 = {
        allowDots: false,
        allowEmptyArrays: false,
        allowPrototypes: false,
        allowSparse: false,
        arrayLimit: 20,
        charset: "utf-8",
        charsetSentinel: false,
        comma: false,
        decodeDotInKeys: false,
        decoder: utils.decode,
        delimiter: "&",
        depth: 5,
        duplicates: "combine",
        ignoreQueryPrefix: false,
        interpretNumericEntities: false,
        parameterLimit: 1e3,
        parseArrays: true,
        plainObjects: false,
        strictDepth: false,
        strictMerge: true,
        strictNullHandling: false,
        throwOnLimitExceeded: false
      };
      var interpretNumericEntities = function(str) {
        return str.replace(/&#(\d+);/g, function($0, numberStr) {
          return String.fromCharCode(parseInt(numberStr, 10));
        });
      };
      var parseArrayValue = function(val, options, currentArrayLength) {
        if (val && typeof val === "string" && options.comma && val.indexOf(",") > -1) {
          return val.split(",");
        }
        if (options.throwOnLimitExceeded && currentArrayLength >= options.arrayLimit) {
          throw new RangeError("Array limit exceeded. Only " + options.arrayLimit + " element" + (options.arrayLimit === 1 ? "" : "s") + " allowed in an array.");
        }
        return val;
      };
      var isoSentinel = "utf8=%26%2310003%3B";
      var charsetSentinel = "utf8=%E2%9C%93";
      var parseValues = function parseQueryStringValues(str, options) {
        var obj = { __proto__: null };
        var cleanStr = options.ignoreQueryPrefix ? str.replace(/^\?/, "") : str;
        cleanStr = cleanStr.replace(/%5B/gi, "[").replace(/%5D/gi, "]");
        var limit = options.parameterLimit === Infinity ? void 0 : options.parameterLimit;
        var parts = cleanStr.split(
          options.delimiter,
          options.throwOnLimitExceeded && typeof limit !== "undefined" ? limit + 1 : limit
        );
        if (options.throwOnLimitExceeded && typeof limit !== "undefined" && parts.length > limit) {
          throw new RangeError("Parameter limit exceeded. Only " + limit + " parameter" + (limit === 1 ? "" : "s") + " allowed.");
        }
        var skipIndex = -1;
        var i12;
        var charset = options.charset;
        if (options.charsetSentinel) {
          for (i12 = 0; i12 < parts.length; ++i12) {
            if (parts[i12].indexOf("utf8=") === 0) {
              if (parts[i12] === charsetSentinel) {
                charset = "utf-8";
              } else if (parts[i12] === isoSentinel) {
                charset = "iso-8859-1";
              }
              skipIndex = i12;
              i12 = parts.length;
            }
          }
        }
        for (i12 = 0; i12 < parts.length; ++i12) {
          if (i12 === skipIndex) {
            continue;
          }
          var part = parts[i12];
          var bracketEqualsPos = part.indexOf("]=");
          var pos = bracketEqualsPos === -1 ? part.indexOf("=") : bracketEqualsPos + 1;
          var key;
          var val;
          if (pos === -1) {
            key = options.decoder(part, defaults2.decoder, charset, "key");
            val = options.strictNullHandling ? null : "";
          } else {
            key = options.decoder(part.slice(0, pos), defaults2.decoder, charset, "key");
            if (key !== null) {
              val = utils.maybeMap(
                parseArrayValue(
                  part.slice(pos + 1),
                  options,
                  isArray3(obj[key]) ? obj[key].length : 0
                ),
                function(encodedVal) {
                  return options.decoder(encodedVal, defaults2.decoder, charset, "value");
                }
              );
            }
          }
          if (val && options.interpretNumericEntities && charset === "iso-8859-1") {
            val = interpretNumericEntities(String(val));
          }
          if (part.indexOf("[]=") > -1) {
            val = isArray3(val) ? [val] : val;
          }
          if (options.comma && isArray3(val) && val.length > options.arrayLimit) {
            if (options.throwOnLimitExceeded) {
              throw new RangeError("Array limit exceeded. Only " + options.arrayLimit + " element" + (options.arrayLimit === 1 ? "" : "s") + " allowed in an array.");
            }
            val = utils.combine([], val, options.arrayLimit, options.plainObjects);
          }
          if (key !== null) {
            var existing = has2.call(obj, key);
            if (existing && (options.duplicates === "combine" || part.indexOf("[]=") > -1)) {
              obj[key] = utils.combine(
                obj[key],
                val,
                options.arrayLimit,
                options.plainObjects
              );
            } else if (!existing || options.duplicates === "last") {
              obj[key] = val;
            }
          }
        }
        return obj;
      };
      var parseObject = function(chain, val, options, valuesParsed) {
        var currentArrayLength = 0;
        if (chain.length > 0 && chain[chain.length - 1] === "[]") {
          var parentKey = chain.slice(0, -1).join("");
          currentArrayLength = Array.isArray(val) && val[parentKey] ? val[parentKey].length : 0;
        }
        var leaf = valuesParsed ? val : parseArrayValue(val, options, currentArrayLength);
        for (var i12 = chain.length - 1; i12 >= 0; --i12) {
          var obj;
          var root2 = chain[i12];
          if (root2 === "[]" && options.parseArrays) {
            if (utils.isOverflow(leaf)) {
              obj = leaf;
            } else {
              obj = options.allowEmptyArrays && (leaf === "" || options.strictNullHandling && leaf === null) ? [] : utils.combine(
                [],
                leaf,
                options.arrayLimit,
                options.plainObjects
              );
            }
          } else {
            obj = options.plainObjects ? { __proto__: null } : {};
            var cleanRoot = root2.charAt(0) === "[" && root2.charAt(root2.length - 1) === "]" ? root2.slice(1, -1) : root2;
            var decodedRoot = options.decodeDotInKeys ? cleanRoot.replace(/%2E/g, ".") : cleanRoot;
            var index = parseInt(decodedRoot, 10);
            var isValidArrayIndex = !isNaN(index) && root2 !== decodedRoot && String(index) === decodedRoot && index >= 0 && options.parseArrays;
            if (!options.parseArrays && decodedRoot === "") {
              obj = { 0: leaf };
            } else if (isValidArrayIndex && index < options.arrayLimit) {
              obj = [];
              obj[index] = leaf;
            } else if (isValidArrayIndex && options.throwOnLimitExceeded) {
              throw new RangeError("Array limit exceeded. Only " + options.arrayLimit + " element" + (options.arrayLimit === 1 ? "" : "s") + " allowed in an array.");
            } else if (isValidArrayIndex) {
              obj[index] = leaf;
              utils.markOverflow(obj, index);
            } else if (decodedRoot !== "__proto__") {
              obj[decodedRoot] = leaf;
            }
          }
          leaf = obj;
        }
        return leaf;
      };
      var splitKeyIntoSegments = function splitKeyIntoSegments2(originalKey, options) {
        var key = options.allowDots ? originalKey.replace(/\.([^.[]+)/g, "[$1]") : originalKey;
        if (options.depth <= 0) {
          if (!options.plainObjects && has2.call(Object.prototype, key)) {
            if (!options.allowPrototypes) {
              return;
            }
          }
          return [key];
        }
        var segments = [];
        var first = key.indexOf("[");
        var parent = first >= 0 ? key.slice(0, first) : key;
        if (parent) {
          if (!options.plainObjects && has2.call(Object.prototype, parent)) {
            if (!options.allowPrototypes) {
              return;
            }
          }
          segments[segments.length] = parent;
        }
        var n12 = key.length;
        var open = first;
        var collected = 0;
        while (open >= 0 && collected < options.depth) {
          var level = 1;
          var i12 = open + 1;
          var close = -1;
          while (i12 < n12 && close < 0) {
            var cu = key.charCodeAt(i12);
            if (cu === 91) {
              level += 1;
            } else if (cu === 93) {
              level -= 1;
              if (level === 0) {
                close = i12;
              }
            }
            i12 += 1;
          }
          if (close < 0) {
            segments[segments.length] = "[" + key.slice(open) + "]";
            return segments;
          }
          var seg = key.slice(open, close + 1);
          var content = seg.slice(1, -1);
          if (!options.plainObjects && has2.call(Object.prototype, content) && !options.allowPrototypes) {
            return;
          }
          segments[segments.length] = seg;
          collected += 1;
          open = key.indexOf("[", close + 1);
        }
        if (open >= 0) {
          if (options.strictDepth === true) {
            throw new RangeError("Input depth exceeded depth option of " + options.depth + " and strictDepth is true");
          }
          segments[segments.length] = "[" + key.slice(open) + "]";
        }
        return segments;
      };
      var parseKeys = function parseQueryStringKeys(givenKey, val, options, valuesParsed) {
        if (!givenKey) {
          return;
        }
        var keys2 = splitKeyIntoSegments(givenKey, options);
        if (!keys2) {
          return;
        }
        return parseObject(keys2, val, options, valuesParsed);
      };
      var normalizeParseOptions = function normalizeParseOptions2(opts) {
        if (!opts) {
          return defaults2;
        }
        if (typeof opts.allowEmptyArrays !== "undefined" && typeof opts.allowEmptyArrays !== "boolean") {
          throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
        }
        if (typeof opts.decodeDotInKeys !== "undefined" && typeof opts.decodeDotInKeys !== "boolean") {
          throw new TypeError("`decodeDotInKeys` option can only be `true` or `false`, when provided");
        }
        if (opts.decoder !== null && typeof opts.decoder !== "undefined" && typeof opts.decoder !== "function") {
          throw new TypeError("Decoder has to be a function.");
        }
        if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
          throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
        }
        if (typeof opts.throwOnLimitExceeded !== "undefined" && typeof opts.throwOnLimitExceeded !== "boolean") {
          throw new TypeError("`throwOnLimitExceeded` option must be a boolean");
        }
        var charset = typeof opts.charset === "undefined" ? defaults2.charset : opts.charset;
        var duplicates = typeof opts.duplicates === "undefined" ? defaults2.duplicates : opts.duplicates;
        if (duplicates !== "combine" && duplicates !== "first" && duplicates !== "last") {
          throw new TypeError("The duplicates option must be either combine, first, or last");
        }
        var allowDots = typeof opts.allowDots === "undefined" ? opts.decodeDotInKeys === true ? true : defaults2.allowDots : !!opts.allowDots;
        return {
          allowDots,
          allowEmptyArrays: typeof opts.allowEmptyArrays === "boolean" ? !!opts.allowEmptyArrays : defaults2.allowEmptyArrays,
          allowPrototypes: typeof opts.allowPrototypes === "boolean" ? opts.allowPrototypes : defaults2.allowPrototypes,
          allowSparse: typeof opts.allowSparse === "boolean" ? opts.allowSparse : defaults2.allowSparse,
          arrayLimit: typeof opts.arrayLimit === "number" ? opts.arrayLimit : defaults2.arrayLimit,
          charset,
          charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults2.charsetSentinel,
          comma: typeof opts.comma === "boolean" ? opts.comma : defaults2.comma,
          decodeDotInKeys: typeof opts.decodeDotInKeys === "boolean" ? opts.decodeDotInKeys : defaults2.decodeDotInKeys,
          decoder: typeof opts.decoder === "function" ? opts.decoder : defaults2.decoder,
          delimiter: typeof opts.delimiter === "string" || utils.isRegExp(opts.delimiter) ? opts.delimiter : defaults2.delimiter,
          // eslint-disable-next-line no-implicit-coercion, no-extra-parens
          depth: typeof opts.depth === "number" || opts.depth === false ? +opts.depth : defaults2.depth,
          duplicates,
          ignoreQueryPrefix: opts.ignoreQueryPrefix === true,
          interpretNumericEntities: typeof opts.interpretNumericEntities === "boolean" ? opts.interpretNumericEntities : defaults2.interpretNumericEntities,
          parameterLimit: typeof opts.parameterLimit === "number" ? opts.parameterLimit : defaults2.parameterLimit,
          parseArrays: opts.parseArrays !== false,
          plainObjects: typeof opts.plainObjects === "boolean" ? opts.plainObjects : defaults2.plainObjects,
          strictDepth: typeof opts.strictDepth === "boolean" ? !!opts.strictDepth : defaults2.strictDepth,
          strictMerge: typeof opts.strictMerge === "boolean" ? !!opts.strictMerge : defaults2.strictMerge,
          strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults2.strictNullHandling,
          throwOnLimitExceeded: typeof opts.throwOnLimitExceeded === "boolean" ? opts.throwOnLimitExceeded : false
        };
      };
      module2.exports = function(str, opts) {
        var options = normalizeParseOptions(opts);
        if (str === "" || str === null || typeof str === "undefined") {
          return options.plainObjects ? { __proto__: null } : {};
        }
        var tempObj = typeof str === "string" ? parseValues(str, options) : str;
        var obj = options.plainObjects ? { __proto__: null } : {};
        var keys2 = Object.keys(tempObj);
        for (var i12 = 0; i12 < keys2.length; ++i12) {
          var key = keys2[i12];
          var newObj = parseKeys(key, tempObj[key], options, typeof str === "string");
          obj = utils.merge(obj, newObj, options);
        }
        if (options.allowSparse === true) {
          return obj;
        }
        return utils.compact(obj);
      };
    }
  });

  // node_modules/qs/lib/index.js
  var require_lib = __commonJS({
    "node_modules/qs/lib/index.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var stringify2 = require_stringify();
      var parse2 = require_parse();
      var formats = require_formats();
      module2.exports = {
        formats,
        parse: parse2,
        stringify: stringify2
      };
    }
  });

  // node_modules/qrcode/lib/can-promise.js
  var require_can_promise = __commonJS({
    "node_modules/qrcode/lib/can-promise.js"(exports2, module2) {
      init_define_import_meta_env();
      module2.exports = function() {
        return typeof Promise === "function" && Promise.prototype && Promise.prototype.then;
      };
    }
  });

  // node_modules/qrcode/lib/core/utils.js
  var require_utils2 = __commonJS({
    "node_modules/qrcode/lib/core/utils.js"(exports2) {
      init_define_import_meta_env();
      var toSJISFunction;
      var CODEWORDS_COUNT = [
        0,
        // Not used
        26,
        44,
        70,
        100,
        134,
        172,
        196,
        242,
        292,
        346,
        404,
        466,
        532,
        581,
        655,
        733,
        815,
        901,
        991,
        1085,
        1156,
        1258,
        1364,
        1474,
        1588,
        1706,
        1828,
        1921,
        2051,
        2185,
        2323,
        2465,
        2611,
        2761,
        2876,
        3034,
        3196,
        3362,
        3532,
        3706
      ];
      exports2.getSymbolSize = function getSymbolSize(version) {
        if (!version) throw new Error('"version" cannot be null or undefined');
        if (version < 1 || version > 40) throw new Error('"version" should be in range from 1 to 40');
        return version * 4 + 17;
      };
      exports2.getSymbolTotalCodewords = function getSymbolTotalCodewords(version) {
        return CODEWORDS_COUNT[version];
      };
      exports2.getBCHDigit = function(data) {
        let digit = 0;
        while (data !== 0) {
          digit++;
          data >>>= 1;
        }
        return digit;
      };
      exports2.setToSJISFunction = function setToSJISFunction(f11) {
        if (typeof f11 !== "function") {
          throw new Error('"toSJISFunc" is not a valid function.');
        }
        toSJISFunction = f11;
      };
      exports2.isKanjiModeEnabled = function() {
        return typeof toSJISFunction !== "undefined";
      };
      exports2.toSJIS = function toSJIS(kanji) {
        return toSJISFunction(kanji);
      };
    }
  });

  // node_modules/qrcode/lib/core/error-correction-level.js
  var require_error_correction_level = __commonJS({
    "node_modules/qrcode/lib/core/error-correction-level.js"(exports2) {
      init_define_import_meta_env();
      exports2.L = { bit: 1 };
      exports2.M = { bit: 0 };
      exports2.Q = { bit: 3 };
      exports2.H = { bit: 2 };
      function fromString(string) {
        if (typeof string !== "string") {
          throw new Error("Param is not a string");
        }
        const lcStr = string.toLowerCase();
        switch (lcStr) {
          case "l":
          case "low":
            return exports2.L;
          case "m":
          case "medium":
            return exports2.M;
          case "q":
          case "quartile":
            return exports2.Q;
          case "h":
          case "high":
            return exports2.H;
          default:
            throw new Error("Unknown EC Level: " + string);
        }
      }
      exports2.isValid = function isValid(level) {
        return level && typeof level.bit !== "undefined" && level.bit >= 0 && level.bit < 4;
      };
      exports2.from = function from(value, defaultValue) {
        if (exports2.isValid(value)) {
          return value;
        }
        try {
          return fromString(value);
        } catch (e6) {
          return defaultValue;
        }
      };
    }
  });

  // node_modules/qrcode/lib/core/bit-buffer.js
  var require_bit_buffer = __commonJS({
    "node_modules/qrcode/lib/core/bit-buffer.js"(exports2, module2) {
      init_define_import_meta_env();
      function BitBuffer() {
        this.buffer = [];
        this.length = 0;
      }
      BitBuffer.prototype = {
        get: function(index) {
          const bufIndex = Math.floor(index / 8);
          return (this.buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
        },
        put: function(num, length) {
          for (let i12 = 0; i12 < length; i12++) {
            this.putBit((num >>> length - i12 - 1 & 1) === 1);
          }
        },
        getLengthInBits: function() {
          return this.length;
        },
        putBit: function(bit) {
          const bufIndex = Math.floor(this.length / 8);
          if (this.buffer.length <= bufIndex) {
            this.buffer.push(0);
          }
          if (bit) {
            this.buffer[bufIndex] |= 128 >>> this.length % 8;
          }
          this.length++;
        }
      };
      module2.exports = BitBuffer;
    }
  });

  // node_modules/qrcode/lib/core/bit-matrix.js
  var require_bit_matrix = __commonJS({
    "node_modules/qrcode/lib/core/bit-matrix.js"(exports2, module2) {
      init_define_import_meta_env();
      function BitMatrix(size) {
        if (!size || size < 1) {
          throw new Error("BitMatrix size must be defined and greater than 0");
        }
        this.size = size;
        this.data = new Uint8Array(size * size);
        this.reservedBit = new Uint8Array(size * size);
      }
      BitMatrix.prototype.set = function(row, col, value, reserved) {
        const index = row * this.size + col;
        this.data[index] = value;
        if (reserved) this.reservedBit[index] = true;
      };
      BitMatrix.prototype.get = function(row, col) {
        return this.data[row * this.size + col];
      };
      BitMatrix.prototype.xor = function(row, col, value) {
        this.data[row * this.size + col] ^= value;
      };
      BitMatrix.prototype.isReserved = function(row, col) {
        return this.reservedBit[row * this.size + col];
      };
      module2.exports = BitMatrix;
    }
  });

  // node_modules/qrcode/lib/core/alignment-pattern.js
  var require_alignment_pattern = __commonJS({
    "node_modules/qrcode/lib/core/alignment-pattern.js"(exports2) {
      init_define_import_meta_env();
      var getSymbolSize = require_utils2().getSymbolSize;
      exports2.getRowColCoords = function getRowColCoords(version) {
        if (version === 1) return [];
        const posCount = Math.floor(version / 7) + 2;
        const size = getSymbolSize(version);
        const intervals = size === 145 ? 26 : Math.ceil((size - 13) / (2 * posCount - 2)) * 2;
        const positions = [size - 7];
        for (let i12 = 1; i12 < posCount - 1; i12++) {
          positions[i12] = positions[i12 - 1] - intervals;
        }
        positions.push(6);
        return positions.reverse();
      };
      exports2.getPositions = function getPositions(version) {
        const coords = [];
        const pos = exports2.getRowColCoords(version);
        const posLength = pos.length;
        for (let i12 = 0; i12 < posLength; i12++) {
          for (let j7 = 0; j7 < posLength; j7++) {
            if (i12 === 0 && j7 === 0 || // top-left
            i12 === 0 && j7 === posLength - 1 || // bottom-left
            i12 === posLength - 1 && j7 === 0) {
              continue;
            }
            coords.push([pos[i12], pos[j7]]);
          }
        }
        return coords;
      };
    }
  });

  // node_modules/qrcode/lib/core/finder-pattern.js
  var require_finder_pattern = __commonJS({
    "node_modules/qrcode/lib/core/finder-pattern.js"(exports2) {
      init_define_import_meta_env();
      var getSymbolSize = require_utils2().getSymbolSize;
      var FINDER_PATTERN_SIZE = 7;
      exports2.getPositions = function getPositions(version) {
        const size = getSymbolSize(version);
        return [
          // top-left
          [0, 0],
          // top-right
          [size - FINDER_PATTERN_SIZE, 0],
          // bottom-left
          [0, size - FINDER_PATTERN_SIZE]
        ];
      };
    }
  });

  // node_modules/qrcode/lib/core/mask-pattern.js
  var require_mask_pattern = __commonJS({
    "node_modules/qrcode/lib/core/mask-pattern.js"(exports2) {
      init_define_import_meta_env();
      exports2.Patterns = {
        PATTERN000: 0,
        PATTERN001: 1,
        PATTERN010: 2,
        PATTERN011: 3,
        PATTERN100: 4,
        PATTERN101: 5,
        PATTERN110: 6,
        PATTERN111: 7
      };
      var PenaltyScores = {
        N1: 3,
        N2: 3,
        N3: 40,
        N4: 10
      };
      exports2.isValid = function isValid(mask) {
        return mask != null && mask !== "" && !isNaN(mask) && mask >= 0 && mask <= 7;
      };
      exports2.from = function from(value) {
        return exports2.isValid(value) ? parseInt(value, 10) : void 0;
      };
      exports2.getPenaltyN1 = function getPenaltyN1(data) {
        const size = data.size;
        let points = 0;
        let sameCountCol = 0;
        let sameCountRow = 0;
        let lastCol = null;
        let lastRow = null;
        for (let row = 0; row < size; row++) {
          sameCountCol = sameCountRow = 0;
          lastCol = lastRow = null;
          for (let col = 0; col < size; col++) {
            let module3 = data.get(row, col);
            if (module3 === lastCol) {
              sameCountCol++;
            } else {
              if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
              lastCol = module3;
              sameCountCol = 1;
            }
            module3 = data.get(col, row);
            if (module3 === lastRow) {
              sameCountRow++;
            } else {
              if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
              lastRow = module3;
              sameCountRow = 1;
            }
          }
          if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
          if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
        }
        return points;
      };
      exports2.getPenaltyN2 = function getPenaltyN2(data) {
        const size = data.size;
        let points = 0;
        for (let row = 0; row < size - 1; row++) {
          for (let col = 0; col < size - 1; col++) {
            const last = data.get(row, col) + data.get(row, col + 1) + data.get(row + 1, col) + data.get(row + 1, col + 1);
            if (last === 4 || last === 0) points++;
          }
        }
        return points * PenaltyScores.N2;
      };
      exports2.getPenaltyN3 = function getPenaltyN3(data) {
        const size = data.size;
        let points = 0;
        let bitsCol = 0;
        let bitsRow = 0;
        for (let row = 0; row < size; row++) {
          bitsCol = bitsRow = 0;
          for (let col = 0; col < size; col++) {
            bitsCol = bitsCol << 1 & 2047 | data.get(row, col);
            if (col >= 10 && (bitsCol === 1488 || bitsCol === 93)) points++;
            bitsRow = bitsRow << 1 & 2047 | data.get(col, row);
            if (col >= 10 && (bitsRow === 1488 || bitsRow === 93)) points++;
          }
        }
        return points * PenaltyScores.N3;
      };
      exports2.getPenaltyN4 = function getPenaltyN4(data) {
        let darkCount = 0;
        const modulesCount = data.data.length;
        for (let i12 = 0; i12 < modulesCount; i12++) darkCount += data.data[i12];
        const k6 = Math.abs(Math.ceil(darkCount * 100 / modulesCount / 5) - 10);
        return k6 * PenaltyScores.N4;
      };
      function getMaskAt(maskPattern, i12, j7) {
        switch (maskPattern) {
          case exports2.Patterns.PATTERN000:
            return (i12 + j7) % 2 === 0;
          case exports2.Patterns.PATTERN001:
            return i12 % 2 === 0;
          case exports2.Patterns.PATTERN010:
            return j7 % 3 === 0;
          case exports2.Patterns.PATTERN011:
            return (i12 + j7) % 3 === 0;
          case exports2.Patterns.PATTERN100:
            return (Math.floor(i12 / 2) + Math.floor(j7 / 3)) % 2 === 0;
          case exports2.Patterns.PATTERN101:
            return i12 * j7 % 2 + i12 * j7 % 3 === 0;
          case exports2.Patterns.PATTERN110:
            return (i12 * j7 % 2 + i12 * j7 % 3) % 2 === 0;
          case exports2.Patterns.PATTERN111:
            return (i12 * j7 % 3 + (i12 + j7) % 2) % 2 === 0;
          default:
            throw new Error("bad maskPattern:" + maskPattern);
        }
      }
      exports2.applyMask = function applyMask(pattern, data) {
        const size = data.size;
        for (let col = 0; col < size; col++) {
          for (let row = 0; row < size; row++) {
            if (data.isReserved(row, col)) continue;
            data.xor(row, col, getMaskAt(pattern, row, col));
          }
        }
      };
      exports2.getBestMask = function getBestMask(data, setupFormatFunc) {
        const numPatterns = Object.keys(exports2.Patterns).length;
        let bestPattern = 0;
        let lowerPenalty = Infinity;
        for (let p6 = 0; p6 < numPatterns; p6++) {
          setupFormatFunc(p6);
          exports2.applyMask(p6, data);
          const penalty = exports2.getPenaltyN1(data) + exports2.getPenaltyN2(data) + exports2.getPenaltyN3(data) + exports2.getPenaltyN4(data);
          exports2.applyMask(p6, data);
          if (penalty < lowerPenalty) {
            lowerPenalty = penalty;
            bestPattern = p6;
          }
        }
        return bestPattern;
      };
    }
  });

  // node_modules/qrcode/lib/core/error-correction-code.js
  var require_error_correction_code = __commonJS({
    "node_modules/qrcode/lib/core/error-correction-code.js"(exports2) {
      init_define_import_meta_env();
      var ECLevel = require_error_correction_level();
      var EC_BLOCKS_TABLE = [
        // L  M  Q  H
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        2,
        2,
        1,
        2,
        2,
        4,
        1,
        2,
        4,
        4,
        2,
        4,
        4,
        4,
        2,
        4,
        6,
        5,
        2,
        4,
        6,
        6,
        2,
        5,
        8,
        8,
        4,
        5,
        8,
        8,
        4,
        5,
        8,
        11,
        4,
        8,
        10,
        11,
        4,
        9,
        12,
        16,
        4,
        9,
        16,
        16,
        6,
        10,
        12,
        18,
        6,
        10,
        17,
        16,
        6,
        11,
        16,
        19,
        6,
        13,
        18,
        21,
        7,
        14,
        21,
        25,
        8,
        16,
        20,
        25,
        8,
        17,
        23,
        25,
        9,
        17,
        23,
        34,
        9,
        18,
        25,
        30,
        10,
        20,
        27,
        32,
        12,
        21,
        29,
        35,
        12,
        23,
        34,
        37,
        12,
        25,
        34,
        40,
        13,
        26,
        35,
        42,
        14,
        28,
        38,
        45,
        15,
        29,
        40,
        48,
        16,
        31,
        43,
        51,
        17,
        33,
        45,
        54,
        18,
        35,
        48,
        57,
        19,
        37,
        51,
        60,
        19,
        38,
        53,
        63,
        20,
        40,
        56,
        66,
        21,
        43,
        59,
        70,
        22,
        45,
        62,
        74,
        24,
        47,
        65,
        77,
        25,
        49,
        68,
        81
      ];
      var EC_CODEWORDS_TABLE = [
        // L  M  Q  H
        7,
        10,
        13,
        17,
        10,
        16,
        22,
        28,
        15,
        26,
        36,
        44,
        20,
        36,
        52,
        64,
        26,
        48,
        72,
        88,
        36,
        64,
        96,
        112,
        40,
        72,
        108,
        130,
        48,
        88,
        132,
        156,
        60,
        110,
        160,
        192,
        72,
        130,
        192,
        224,
        80,
        150,
        224,
        264,
        96,
        176,
        260,
        308,
        104,
        198,
        288,
        352,
        120,
        216,
        320,
        384,
        132,
        240,
        360,
        432,
        144,
        280,
        408,
        480,
        168,
        308,
        448,
        532,
        180,
        338,
        504,
        588,
        196,
        364,
        546,
        650,
        224,
        416,
        600,
        700,
        224,
        442,
        644,
        750,
        252,
        476,
        690,
        816,
        270,
        504,
        750,
        900,
        300,
        560,
        810,
        960,
        312,
        588,
        870,
        1050,
        336,
        644,
        952,
        1110,
        360,
        700,
        1020,
        1200,
        390,
        728,
        1050,
        1260,
        420,
        784,
        1140,
        1350,
        450,
        812,
        1200,
        1440,
        480,
        868,
        1290,
        1530,
        510,
        924,
        1350,
        1620,
        540,
        980,
        1440,
        1710,
        570,
        1036,
        1530,
        1800,
        570,
        1064,
        1590,
        1890,
        600,
        1120,
        1680,
        1980,
        630,
        1204,
        1770,
        2100,
        660,
        1260,
        1860,
        2220,
        720,
        1316,
        1950,
        2310,
        750,
        1372,
        2040,
        2430
      ];
      exports2.getBlocksCount = function getBlocksCount(version, errorCorrectionLevel) {
        switch (errorCorrectionLevel) {
          case ECLevel.L:
            return EC_BLOCKS_TABLE[(version - 1) * 4 + 0];
          case ECLevel.M:
            return EC_BLOCKS_TABLE[(version - 1) * 4 + 1];
          case ECLevel.Q:
            return EC_BLOCKS_TABLE[(version - 1) * 4 + 2];
          case ECLevel.H:
            return EC_BLOCKS_TABLE[(version - 1) * 4 + 3];
          default:
            return void 0;
        }
      };
      exports2.getTotalCodewordsCount = function getTotalCodewordsCount(version, errorCorrectionLevel) {
        switch (errorCorrectionLevel) {
          case ECLevel.L:
            return EC_CODEWORDS_TABLE[(version - 1) * 4 + 0];
          case ECLevel.M:
            return EC_CODEWORDS_TABLE[(version - 1) * 4 + 1];
          case ECLevel.Q:
            return EC_CODEWORDS_TABLE[(version - 1) * 4 + 2];
          case ECLevel.H:
            return EC_CODEWORDS_TABLE[(version - 1) * 4 + 3];
          default:
            return void 0;
        }
      };
    }
  });

  // node_modules/qrcode/lib/core/galois-field.js
  var require_galois_field = __commonJS({
    "node_modules/qrcode/lib/core/galois-field.js"(exports2) {
      init_define_import_meta_env();
      var EXP_TABLE = new Uint8Array(512);
      var LOG_TABLE = new Uint8Array(256);
      (function initTables() {
        let x8 = 1;
        for (let i12 = 0; i12 < 255; i12++) {
          EXP_TABLE[i12] = x8;
          LOG_TABLE[x8] = i12;
          x8 <<= 1;
          if (x8 & 256) {
            x8 ^= 285;
          }
        }
        for (let i12 = 255; i12 < 512; i12++) {
          EXP_TABLE[i12] = EXP_TABLE[i12 - 255];
        }
      })();
      exports2.log = function log(n12) {
        if (n12 < 1) throw new Error("log(" + n12 + ")");
        return LOG_TABLE[n12];
      };
      exports2.exp = function exp(n12) {
        return EXP_TABLE[n12];
      };
      exports2.mul = function mul(x8, y4) {
        if (x8 === 0 || y4 === 0) return 0;
        return EXP_TABLE[LOG_TABLE[x8] + LOG_TABLE[y4]];
      };
    }
  });

  // node_modules/qrcode/lib/core/polynomial.js
  var require_polynomial = __commonJS({
    "node_modules/qrcode/lib/core/polynomial.js"(exports2) {
      init_define_import_meta_env();
      var GF = require_galois_field();
      exports2.mul = function mul(p1, p22) {
        const coeff = new Uint8Array(p1.length + p22.length - 1);
        for (let i12 = 0; i12 < p1.length; i12++) {
          for (let j7 = 0; j7 < p22.length; j7++) {
            coeff[i12 + j7] ^= GF.mul(p1[i12], p22[j7]);
          }
        }
        return coeff;
      };
      exports2.mod = function mod(divident, divisor) {
        let result = new Uint8Array(divident);
        while (result.length - divisor.length >= 0) {
          const coeff = result[0];
          for (let i12 = 0; i12 < divisor.length; i12++) {
            result[i12] ^= GF.mul(divisor[i12], coeff);
          }
          let offset = 0;
          while (offset < result.length && result[offset] === 0) offset++;
          result = result.slice(offset);
        }
        return result;
      };
      exports2.generateECPolynomial = function generateECPolynomial(degree) {
        let poly = new Uint8Array([1]);
        for (let i12 = 0; i12 < degree; i12++) {
          poly = exports2.mul(poly, new Uint8Array([1, GF.exp(i12)]));
        }
        return poly;
      };
    }
  });

  // node_modules/qrcode/lib/core/reed-solomon-encoder.js
  var require_reed_solomon_encoder = __commonJS({
    "node_modules/qrcode/lib/core/reed-solomon-encoder.js"(exports2, module2) {
      init_define_import_meta_env();
      var Polynomial = require_polynomial();
      function ReedSolomonEncoder(degree) {
        this.genPoly = void 0;
        this.degree = degree;
        if (this.degree) this.initialize(this.degree);
      }
      ReedSolomonEncoder.prototype.initialize = function initialize(degree) {
        this.degree = degree;
        this.genPoly = Polynomial.generateECPolynomial(this.degree);
      };
      ReedSolomonEncoder.prototype.encode = function encode3(data) {
        if (!this.genPoly) {
          throw new Error("Encoder not initialized");
        }
        const paddedData = new Uint8Array(data.length + this.degree);
        paddedData.set(data);
        const remainder = Polynomial.mod(paddedData, this.genPoly);
        const start2 = this.degree - remainder.length;
        if (start2 > 0) {
          const buff = new Uint8Array(this.degree);
          buff.set(remainder, start2);
          return buff;
        }
        return remainder;
      };
      module2.exports = ReedSolomonEncoder;
    }
  });

  // node_modules/qrcode/lib/core/version-check.js
  var require_version_check = __commonJS({
    "node_modules/qrcode/lib/core/version-check.js"(exports2) {
      init_define_import_meta_env();
      exports2.isValid = function isValid(version) {
        return !isNaN(version) && version >= 1 && version <= 40;
      };
    }
  });

  // node_modules/qrcode/lib/core/regex.js
  var require_regex = __commonJS({
    "node_modules/qrcode/lib/core/regex.js"(exports2) {
      init_define_import_meta_env();
      var numeric = "[0-9]+";
      var alphanumeric = "[A-Z $%*+\\-./:]+";
      var kanji = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
      kanji = kanji.replace(/u/g, "\\u");
      var byte = "(?:(?![A-Z0-9 $%*+\\-./:]|" + kanji + ")(?:.|[\r\n]))+";
      exports2.KANJI = new RegExp(kanji, "g");
      exports2.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g");
      exports2.BYTE = new RegExp(byte, "g");
      exports2.NUMERIC = new RegExp(numeric, "g");
      exports2.ALPHANUMERIC = new RegExp(alphanumeric, "g");
      var TEST_KANJI = new RegExp("^" + kanji + "$");
      var TEST_NUMERIC = new RegExp("^" + numeric + "$");
      var TEST_ALPHANUMERIC = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
      exports2.testKanji = function testKanji(str) {
        return TEST_KANJI.test(str);
      };
      exports2.testNumeric = function testNumeric(str) {
        return TEST_NUMERIC.test(str);
      };
      exports2.testAlphanumeric = function testAlphanumeric(str) {
        return TEST_ALPHANUMERIC.test(str);
      };
    }
  });

  // node_modules/qrcode/lib/core/mode.js
  var require_mode = __commonJS({
    "node_modules/qrcode/lib/core/mode.js"(exports2) {
      init_define_import_meta_env();
      var VersionCheck = require_version_check();
      var Regex = require_regex();
      exports2.NUMERIC = {
        id: "Numeric",
        bit: 1 << 0,
        ccBits: [10, 12, 14]
      };
      exports2.ALPHANUMERIC = {
        id: "Alphanumeric",
        bit: 1 << 1,
        ccBits: [9, 11, 13]
      };
      exports2.BYTE = {
        id: "Byte",
        bit: 1 << 2,
        ccBits: [8, 16, 16]
      };
      exports2.KANJI = {
        id: "Kanji",
        bit: 1 << 3,
        ccBits: [8, 10, 12]
      };
      exports2.MIXED = {
        bit: -1
      };
      exports2.getCharCountIndicator = function getCharCountIndicator(mode, version) {
        if (!mode.ccBits) throw new Error("Invalid mode: " + mode);
        if (!VersionCheck.isValid(version)) {
          throw new Error("Invalid version: " + version);
        }
        if (version >= 1 && version < 10) return mode.ccBits[0];
        else if (version < 27) return mode.ccBits[1];
        return mode.ccBits[2];
      };
      exports2.getBestModeForData = function getBestModeForData(dataStr) {
        if (Regex.testNumeric(dataStr)) return exports2.NUMERIC;
        else if (Regex.testAlphanumeric(dataStr)) return exports2.ALPHANUMERIC;
        else if (Regex.testKanji(dataStr)) return exports2.KANJI;
        else return exports2.BYTE;
      };
      exports2.toString = function toString4(mode) {
        if (mode && mode.id) return mode.id;
        throw new Error("Invalid mode");
      };
      exports2.isValid = function isValid(mode) {
        return mode && mode.bit && mode.ccBits;
      };
      function fromString(string) {
        if (typeof string !== "string") {
          throw new Error("Param is not a string");
        }
        const lcStr = string.toLowerCase();
        switch (lcStr) {
          case "numeric":
            return exports2.NUMERIC;
          case "alphanumeric":
            return exports2.ALPHANUMERIC;
          case "kanji":
            return exports2.KANJI;
          case "byte":
            return exports2.BYTE;
          default:
            throw new Error("Unknown mode: " + string);
        }
      }
      exports2.from = function from(value, defaultValue) {
        if (exports2.isValid(value)) {
          return value;
        }
        try {
          return fromString(value);
        } catch (e6) {
          return defaultValue;
        }
      };
    }
  });

  // node_modules/qrcode/lib/core/version.js
  var require_version = __commonJS({
    "node_modules/qrcode/lib/core/version.js"(exports2) {
      init_define_import_meta_env();
      var Utils = require_utils2();
      var ECCode = require_error_correction_code();
      var ECLevel = require_error_correction_level();
      var Mode = require_mode();
      var VersionCheck = require_version_check();
      var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
      var G18_BCH = Utils.getBCHDigit(G18);
      function getBestVersionForDataLength(mode, length, errorCorrectionLevel) {
        for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
          if (length <= exports2.getCapacity(currentVersion, errorCorrectionLevel, mode)) {
            return currentVersion;
          }
        }
        return void 0;
      }
      function getReservedBitsCount(mode, version) {
        return Mode.getCharCountIndicator(mode, version) + 4;
      }
      function getTotalBitsFromDataArray(segments, version) {
        let totalBits = 0;
        segments.forEach(function(data) {
          const reservedBits = getReservedBitsCount(data.mode, version);
          totalBits += reservedBits + data.getBitsLength();
        });
        return totalBits;
      }
      function getBestVersionForMixedData(segments, errorCorrectionLevel) {
        for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
          const length = getTotalBitsFromDataArray(segments, currentVersion);
          if (length <= exports2.getCapacity(currentVersion, errorCorrectionLevel, Mode.MIXED)) {
            return currentVersion;
          }
        }
        return void 0;
      }
      exports2.from = function from(value, defaultValue) {
        if (VersionCheck.isValid(value)) {
          return parseInt(value, 10);
        }
        return defaultValue;
      };
      exports2.getCapacity = function getCapacity(version, errorCorrectionLevel, mode) {
        if (!VersionCheck.isValid(version)) {
          throw new Error("Invalid QR Code version");
        }
        if (typeof mode === "undefined") mode = Mode.BYTE;
        const totalCodewords = Utils.getSymbolTotalCodewords(version);
        const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
        const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
        if (mode === Mode.MIXED) return dataTotalCodewordsBits;
        const usableBits = dataTotalCodewordsBits - getReservedBitsCount(mode, version);
        switch (mode) {
          case Mode.NUMERIC:
            return Math.floor(usableBits / 10 * 3);
          case Mode.ALPHANUMERIC:
            return Math.floor(usableBits / 11 * 2);
          case Mode.KANJI:
            return Math.floor(usableBits / 13);
          case Mode.BYTE:
          default:
            return Math.floor(usableBits / 8);
        }
      };
      exports2.getBestVersionForData = function getBestVersionForData(data, errorCorrectionLevel) {
        let seg;
        const ecl = ECLevel.from(errorCorrectionLevel, ECLevel.M);
        if (Array.isArray(data)) {
          if (data.length > 1) {
            return getBestVersionForMixedData(data, ecl);
          }
          if (data.length === 0) {
            return 1;
          }
          seg = data[0];
        } else {
          seg = data;
        }
        return getBestVersionForDataLength(seg.mode, seg.getLength(), ecl);
      };
      exports2.getEncodedBits = function getEncodedBits(version) {
        if (!VersionCheck.isValid(version) || version < 7) {
          throw new Error("Invalid QR Code version");
        }
        let d8 = version << 12;
        while (Utils.getBCHDigit(d8) - G18_BCH >= 0) {
          d8 ^= G18 << Utils.getBCHDigit(d8) - G18_BCH;
        }
        return version << 12 | d8;
      };
    }
  });

  // node_modules/qrcode/lib/core/format-info.js
  var require_format_info = __commonJS({
    "node_modules/qrcode/lib/core/format-info.js"(exports2) {
      init_define_import_meta_env();
      var Utils = require_utils2();
      var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
      var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
      var G15_BCH = Utils.getBCHDigit(G15);
      exports2.getEncodedBits = function getEncodedBits(errorCorrectionLevel, mask) {
        const data = errorCorrectionLevel.bit << 3 | mask;
        let d8 = data << 10;
        while (Utils.getBCHDigit(d8) - G15_BCH >= 0) {
          d8 ^= G15 << Utils.getBCHDigit(d8) - G15_BCH;
        }
        return (data << 10 | d8) ^ G15_MASK;
      };
    }
  });

  // node_modules/qrcode/lib/core/numeric-data.js
  var require_numeric_data = __commonJS({
    "node_modules/qrcode/lib/core/numeric-data.js"(exports2, module2) {
      init_define_import_meta_env();
      var Mode = require_mode();
      function NumericData(data) {
        this.mode = Mode.NUMERIC;
        this.data = data.toString();
      }
      NumericData.getBitsLength = function getBitsLength(length) {
        return 10 * Math.floor(length / 3) + (length % 3 ? length % 3 * 3 + 1 : 0);
      };
      NumericData.prototype.getLength = function getLength() {
        return this.data.length;
      };
      NumericData.prototype.getBitsLength = function getBitsLength() {
        return NumericData.getBitsLength(this.data.length);
      };
      NumericData.prototype.write = function write(bitBuffer) {
        let i12, group, value;
        for (i12 = 0; i12 + 3 <= this.data.length; i12 += 3) {
          group = this.data.substr(i12, 3);
          value = parseInt(group, 10);
          bitBuffer.put(value, 10);
        }
        const remainingNum = this.data.length - i12;
        if (remainingNum > 0) {
          group = this.data.substr(i12);
          value = parseInt(group, 10);
          bitBuffer.put(value, remainingNum * 3 + 1);
        }
      };
      module2.exports = NumericData;
    }
  });

  // node_modules/qrcode/lib/core/alphanumeric-data.js
  var require_alphanumeric_data = __commonJS({
    "node_modules/qrcode/lib/core/alphanumeric-data.js"(exports2, module2) {
      init_define_import_meta_env();
      var Mode = require_mode();
      var ALPHA_NUM_CHARS = [
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        " ",
        "$",
        "%",
        "*",
        "+",
        "-",
        ".",
        "/",
        ":"
      ];
      function AlphanumericData(data) {
        this.mode = Mode.ALPHANUMERIC;
        this.data = data;
      }
      AlphanumericData.getBitsLength = function getBitsLength(length) {
        return 11 * Math.floor(length / 2) + 6 * (length % 2);
      };
      AlphanumericData.prototype.getLength = function getLength() {
        return this.data.length;
      };
      AlphanumericData.prototype.getBitsLength = function getBitsLength() {
        return AlphanumericData.getBitsLength(this.data.length);
      };
      AlphanumericData.prototype.write = function write(bitBuffer) {
        let i12;
        for (i12 = 0; i12 + 2 <= this.data.length; i12 += 2) {
          let value = ALPHA_NUM_CHARS.indexOf(this.data[i12]) * 45;
          value += ALPHA_NUM_CHARS.indexOf(this.data[i12 + 1]);
          bitBuffer.put(value, 11);
        }
        if (this.data.length % 2) {
          bitBuffer.put(ALPHA_NUM_CHARS.indexOf(this.data[i12]), 6);
        }
      };
      module2.exports = AlphanumericData;
    }
  });

  // node_modules/qrcode/lib/core/byte-data.js
  var require_byte_data = __commonJS({
    "node_modules/qrcode/lib/core/byte-data.js"(exports2, module2) {
      init_define_import_meta_env();
      var Mode = require_mode();
      function ByteData(data) {
        this.mode = Mode.BYTE;
        if (typeof data === "string") {
          this.data = new TextEncoder().encode(data);
        } else {
          this.data = new Uint8Array(data);
        }
      }
      ByteData.getBitsLength = function getBitsLength(length) {
        return length * 8;
      };
      ByteData.prototype.getLength = function getLength() {
        return this.data.length;
      };
      ByteData.prototype.getBitsLength = function getBitsLength() {
        return ByteData.getBitsLength(this.data.length);
      };
      ByteData.prototype.write = function(bitBuffer) {
        for (let i12 = 0, l10 = this.data.length; i12 < l10; i12++) {
          bitBuffer.put(this.data[i12], 8);
        }
      };
      module2.exports = ByteData;
    }
  });

  // node_modules/qrcode/lib/core/kanji-data.js
  var require_kanji_data = __commonJS({
    "node_modules/qrcode/lib/core/kanji-data.js"(exports2, module2) {
      init_define_import_meta_env();
      var Mode = require_mode();
      var Utils = require_utils2();
      function KanjiData(data) {
        this.mode = Mode.KANJI;
        this.data = data;
      }
      KanjiData.getBitsLength = function getBitsLength(length) {
        return length * 13;
      };
      KanjiData.prototype.getLength = function getLength() {
        return this.data.length;
      };
      KanjiData.prototype.getBitsLength = function getBitsLength() {
        return KanjiData.getBitsLength(this.data.length);
      };
      KanjiData.prototype.write = function(bitBuffer) {
        let i12;
        for (i12 = 0; i12 < this.data.length; i12++) {
          let value = Utils.toSJIS(this.data[i12]);
          if (value >= 33088 && value <= 40956) {
            value -= 33088;
          } else if (value >= 57408 && value <= 60351) {
            value -= 49472;
          } else {
            throw new Error(
              "Invalid SJIS character: " + this.data[i12] + "\nMake sure your charset is UTF-8"
            );
          }
          value = (value >>> 8 & 255) * 192 + (value & 255);
          bitBuffer.put(value, 13);
        }
      };
      module2.exports = KanjiData;
    }
  });

  // node_modules/dijkstrajs/dijkstra.js
  var require_dijkstra = __commonJS({
    "node_modules/dijkstrajs/dijkstra.js"(exports2, module2) {
      "use strict";
      init_define_import_meta_env();
      var dijkstra = {
        single_source_shortest_paths: function(graph, s11, d8) {
          var predecessors = {};
          var costs = {};
          costs[s11] = 0;
          var open = dijkstra.PriorityQueue.make();
          open.push(s11, 0);
          var closest, u12, v4, cost_of_s_to_u, adjacent_nodes, cost_of_e, cost_of_s_to_u_plus_cost_of_e, cost_of_s_to_v, first_visit;
          while (!open.empty()) {
            closest = open.pop();
            u12 = closest.value;
            cost_of_s_to_u = closest.cost;
            adjacent_nodes = graph[u12] || {};
            for (v4 in adjacent_nodes) {
              if (adjacent_nodes.hasOwnProperty(v4)) {
                cost_of_e = adjacent_nodes[v4];
                cost_of_s_to_u_plus_cost_of_e = cost_of_s_to_u + cost_of_e;
                cost_of_s_to_v = costs[v4];
                first_visit = typeof costs[v4] === "undefined";
                if (first_visit || cost_of_s_to_v > cost_of_s_to_u_plus_cost_of_e) {
                  costs[v4] = cost_of_s_to_u_plus_cost_of_e;
                  open.push(v4, cost_of_s_to_u_plus_cost_of_e);
                  predecessors[v4] = u12;
                }
              }
            }
          }
          if (typeof d8 !== "undefined" && typeof costs[d8] === "undefined") {
            var msg = ["Could not find a path from ", s11, " to ", d8, "."].join("");
            throw new Error(msg);
          }
          return predecessors;
        },
        extract_shortest_path_from_predecessor_list: function(predecessors, d8) {
          var nodes = [];
          var u12 = d8;
          var predecessor;
          while (u12) {
            nodes.push(u12);
            predecessor = predecessors[u12];
            u12 = predecessors[u12];
          }
          nodes.reverse();
          return nodes;
        },
        find_path: function(graph, s11, d8) {
          var predecessors = dijkstra.single_source_shortest_paths(graph, s11, d8);
          return dijkstra.extract_shortest_path_from_predecessor_list(
            predecessors,
            d8
          );
        },
        /**
         * A very naive priority queue implementation.
         */
        PriorityQueue: {
          make: function(opts) {
            var T7 = dijkstra.PriorityQueue, t11 = {}, key;
            opts = opts || {};
            for (key in T7) {
              if (T7.hasOwnProperty(key)) {
                t11[key] = T7[key];
              }
            }
            t11.queue = [];
            t11.sorter = opts.sorter || T7.default_sorter;
            return t11;
          },
          default_sorter: function(a15, b8) {
            return a15.cost - b8.cost;
          },
          /**
           * Add a new item to the queue and ensure the highest priority element
           * is at the front of the queue.
           */
          push: function(value, cost) {
            var item = { value, cost };
            this.queue.push(item);
            this.queue.sort(this.sorter);
          },
          /**
           * Return the highest priority element in the queue.
           */
          pop: function() {
            return this.queue.shift();
          },
          empty: function() {
            return this.queue.length === 0;
          }
        }
      };
      if (typeof module2 !== "undefined") {
        module2.exports = dijkstra;
      }
    }
  });

  // node_modules/qrcode/lib/core/segments.js
  var require_segments = __commonJS({
    "node_modules/qrcode/lib/core/segments.js"(exports2) {
      init_define_import_meta_env();
      var Mode = require_mode();
      var NumericData = require_numeric_data();
      var AlphanumericData = require_alphanumeric_data();
      var ByteData = require_byte_data();
      var KanjiData = require_kanji_data();
      var Regex = require_regex();
      var Utils = require_utils2();
      var dijkstra = require_dijkstra();
      function getStringByteLength(str) {
        return unescape(encodeURIComponent(str)).length;
      }
      function getSegments(regex, mode, str) {
        const segments = [];
        let result;
        while ((result = regex.exec(str)) !== null) {
          segments.push({
            data: result[0],
            index: result.index,
            mode,
            length: result[0].length
          });
        }
        return segments;
      }
      function getSegmentsFromString(dataStr) {
        const numSegs = getSegments(Regex.NUMERIC, Mode.NUMERIC, dataStr);
        const alphaNumSegs = getSegments(Regex.ALPHANUMERIC, Mode.ALPHANUMERIC, dataStr);
        let byteSegs;
        let kanjiSegs;
        if (Utils.isKanjiModeEnabled()) {
          byteSegs = getSegments(Regex.BYTE, Mode.BYTE, dataStr);
          kanjiSegs = getSegments(Regex.KANJI, Mode.KANJI, dataStr);
        } else {
          byteSegs = getSegments(Regex.BYTE_KANJI, Mode.BYTE, dataStr);
          kanjiSegs = [];
        }
        const segs = numSegs.concat(alphaNumSegs, byteSegs, kanjiSegs);
        return segs.sort(function(s1, s22) {
          return s1.index - s22.index;
        }).map(function(obj) {
          return {
            data: obj.data,
            mode: obj.mode,
            length: obj.length
          };
        });
      }
      function getSegmentBitsLength(length, mode) {
        switch (mode) {
          case Mode.NUMERIC:
            return NumericData.getBitsLength(length);
          case Mode.ALPHANUMERIC:
            return AlphanumericData.getBitsLength(length);
          case Mode.KANJI:
            return KanjiData.getBitsLength(length);
          case Mode.BYTE:
            return ByteData.getBitsLength(length);
        }
      }
      function mergeSegments(segs) {
        return segs.reduce(function(acc, curr) {
          const prevSeg = acc.length - 1 >= 0 ? acc[acc.length - 1] : null;
          if (prevSeg && prevSeg.mode === curr.mode) {
            acc[acc.length - 1].data += curr.data;
            return acc;
          }
          acc.push(curr);
          return acc;
        }, []);
      }
      function buildNodes(segs) {
        const nodes = [];
        for (let i12 = 0; i12 < segs.length; i12++) {
          const seg = segs[i12];
          switch (seg.mode) {
            case Mode.NUMERIC:
              nodes.push([
                seg,
                { data: seg.data, mode: Mode.ALPHANUMERIC, length: seg.length },
                { data: seg.data, mode: Mode.BYTE, length: seg.length }
              ]);
              break;
            case Mode.ALPHANUMERIC:
              nodes.push([
                seg,
                { data: seg.data, mode: Mode.BYTE, length: seg.length }
              ]);
              break;
            case Mode.KANJI:
              nodes.push([
                seg,
                { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
              ]);
              break;
            case Mode.BYTE:
              nodes.push([
                { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
              ]);
          }
        }
        return nodes;
      }
      function buildGraph(nodes, version) {
        const table = {};
        const graph = { start: {} };
        let prevNodeIds = ["start"];
        for (let i12 = 0; i12 < nodes.length; i12++) {
          const nodeGroup = nodes[i12];
          const currentNodeIds = [];
          for (let j7 = 0; j7 < nodeGroup.length; j7++) {
            const node = nodeGroup[j7];
            const key = "" + i12 + j7;
            currentNodeIds.push(key);
            table[key] = { node, lastCount: 0 };
            graph[key] = {};
            for (let n12 = 0; n12 < prevNodeIds.length; n12++) {
              const prevNodeId = prevNodeIds[n12];
              if (table[prevNodeId] && table[prevNodeId].node.mode === node.mode) {
                graph[prevNodeId][key] = getSegmentBitsLength(table[prevNodeId].lastCount + node.length, node.mode) - getSegmentBitsLength(table[prevNodeId].lastCount, node.mode);
                table[prevNodeId].lastCount += node.length;
              } else {
                if (table[prevNodeId]) table[prevNodeId].lastCount = node.length;
                graph[prevNodeId][key] = getSegmentBitsLength(node.length, node.mode) + 4 + Mode.getCharCountIndicator(node.mode, version);
              }
            }
          }
          prevNodeIds = currentNodeIds;
        }
        for (let n12 = 0; n12 < prevNodeIds.length; n12++) {
          graph[prevNodeIds[n12]].end = 0;
        }
        return { map: graph, table };
      }
      function buildSingleSegment(data, modesHint) {
        let mode;
        const bestMode = Mode.getBestModeForData(data);
        mode = Mode.from(modesHint, bestMode);
        if (mode !== Mode.BYTE && mode.bit < bestMode.bit) {
          throw new Error('"' + data + '" cannot be encoded with mode ' + Mode.toString(mode) + ".\n Suggested mode is: " + Mode.toString(bestMode));
        }
        if (mode === Mode.KANJI && !Utils.isKanjiModeEnabled()) {
          mode = Mode.BYTE;
        }
        switch (mode) {
          case Mode.NUMERIC:
            return new NumericData(data);
          case Mode.ALPHANUMERIC:
            return new AlphanumericData(data);
          case Mode.KANJI:
            return new KanjiData(data);
          case Mode.BYTE:
            return new ByteData(data);
        }
      }
      exports2.fromArray = function fromArray(array) {
        return array.reduce(function(acc, seg) {
          if (typeof seg === "string") {
            acc.push(buildSingleSegment(seg, null));
          } else if (seg.data) {
            acc.push(buildSingleSegment(seg.data, seg.mode));
          }
          return acc;
        }, []);
      };
      exports2.fromString = function fromString(data, version) {
        const segs = getSegmentsFromString(data, Utils.isKanjiModeEnabled());
        const nodes = buildNodes(segs);
        const graph = buildGraph(nodes, version);
        const path = dijkstra.find_path(graph.map, "start", "end");
        const optimizedSegs = [];
        for (let i12 = 1; i12 < path.length - 1; i12++) {
          optimizedSegs.push(graph.table[path[i12]].node);
        }
        return exports2.fromArray(mergeSegments(optimizedSegs));
      };
      exports2.rawSplit = function rawSplit(data) {
        return exports2.fromArray(
          getSegmentsFromString(data, Utils.isKanjiModeEnabled())
        );
      };
    }
  });

  // node_modules/qrcode/lib/core/qrcode.js
  var require_qrcode = __commonJS({
    "node_modules/qrcode/lib/core/qrcode.js"(exports2) {
      init_define_import_meta_env();
      var Utils = require_utils2();
      var ECLevel = require_error_correction_level();
      var BitBuffer = require_bit_buffer();
      var BitMatrix = require_bit_matrix();
      var AlignmentPattern = require_alignment_pattern();
      var FinderPattern = require_finder_pattern();
      var MaskPattern = require_mask_pattern();
      var ECCode = require_error_correction_code();
      var ReedSolomonEncoder = require_reed_solomon_encoder();
      var Version = require_version();
      var FormatInfo = require_format_info();
      var Mode = require_mode();
      var Segments = require_segments();
      function setupFinderPattern(matrix, version) {
        const size = matrix.size;
        const pos = FinderPattern.getPositions(version);
        for (let i12 = 0; i12 < pos.length; i12++) {
          const row = pos[i12][0];
          const col = pos[i12][1];
          for (let r13 = -1; r13 <= 7; r13++) {
            if (row + r13 <= -1 || size <= row + r13) continue;
            for (let c12 = -1; c12 <= 7; c12++) {
              if (col + c12 <= -1 || size <= col + c12) continue;
              if (r13 >= 0 && r13 <= 6 && (c12 === 0 || c12 === 6) || c12 >= 0 && c12 <= 6 && (r13 === 0 || r13 === 6) || r13 >= 2 && r13 <= 4 && c12 >= 2 && c12 <= 4) {
                matrix.set(row + r13, col + c12, true, true);
              } else {
                matrix.set(row + r13, col + c12, false, true);
              }
            }
          }
        }
      }
      function setupTimingPattern(matrix) {
        const size = matrix.size;
        for (let r13 = 8; r13 < size - 8; r13++) {
          const value = r13 % 2 === 0;
          matrix.set(r13, 6, value, true);
          matrix.set(6, r13, value, true);
        }
      }
      function setupAlignmentPattern(matrix, version) {
        const pos = AlignmentPattern.getPositions(version);
        for (let i12 = 0; i12 < pos.length; i12++) {
          const row = pos[i12][0];
          const col = pos[i12][1];
          for (let r13 = -2; r13 <= 2; r13++) {
            for (let c12 = -2; c12 <= 2; c12++) {
              if (r13 === -2 || r13 === 2 || c12 === -2 || c12 === 2 || r13 === 0 && c12 === 0) {
                matrix.set(row + r13, col + c12, true, true);
              } else {
                matrix.set(row + r13, col + c12, false, true);
              }
            }
          }
        }
      }
      function setupVersionInfo(matrix, version) {
        const size = matrix.size;
        const bits = Version.getEncodedBits(version);
        let row, col, mod;
        for (let i12 = 0; i12 < 18; i12++) {
          row = Math.floor(i12 / 3);
          col = i12 % 3 + size - 8 - 3;
          mod = (bits >> i12 & 1) === 1;
          matrix.set(row, col, mod, true);
          matrix.set(col, row, mod, true);
        }
      }
      function setupFormatInfo(matrix, errorCorrectionLevel, maskPattern) {
        const size = matrix.size;
        const bits = FormatInfo.getEncodedBits(errorCorrectionLevel, maskPattern);
        let i12, mod;
        for (i12 = 0; i12 < 15; i12++) {
          mod = (bits >> i12 & 1) === 1;
          if (i12 < 6) {
            matrix.set(i12, 8, mod, true);
          } else if (i12 < 8) {
            matrix.set(i12 + 1, 8, mod, true);
          } else {
            matrix.set(size - 15 + i12, 8, mod, true);
          }
          if (i12 < 8) {
            matrix.set(8, size - i12 - 1, mod, true);
          } else if (i12 < 9) {
            matrix.set(8, 15 - i12 - 1 + 1, mod, true);
          } else {
            matrix.set(8, 15 - i12 - 1, mod, true);
          }
        }
        matrix.set(size - 8, 8, 1, true);
      }
      function setupData(matrix, data) {
        const size = matrix.size;
        let inc = -1;
        let row = size - 1;
        let bitIndex = 7;
        let byteIndex = 0;
        for (let col = size - 1; col > 0; col -= 2) {
          if (col === 6) col--;
          while (true) {
            for (let c12 = 0; c12 < 2; c12++) {
              if (!matrix.isReserved(row, col - c12)) {
                let dark = false;
                if (byteIndex < data.length) {
                  dark = (data[byteIndex] >>> bitIndex & 1) === 1;
                }
                matrix.set(row, col - c12, dark);
                bitIndex--;
                if (bitIndex === -1) {
                  byteIndex++;
                  bitIndex = 7;
                }
              }
            }
            row += inc;
            if (row < 0 || size <= row) {
              row -= inc;
              inc = -inc;
              break;
            }
          }
        }
      }
      function createData(version, errorCorrectionLevel, segments) {
        const buffer = new BitBuffer();
        segments.forEach(function(data) {
          buffer.put(data.mode.bit, 4);
          buffer.put(data.getLength(), Mode.getCharCountIndicator(data.mode, version));
          data.write(buffer);
        });
        const totalCodewords = Utils.getSymbolTotalCodewords(version);
        const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
        const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
        if (buffer.getLengthInBits() + 4 <= dataTotalCodewordsBits) {
          buffer.put(0, 4);
        }
        while (buffer.getLengthInBits() % 8 !== 0) {
          buffer.putBit(0);
        }
        const remainingByte = (dataTotalCodewordsBits - buffer.getLengthInBits()) / 8;
        for (let i12 = 0; i12 < remainingByte; i12++) {
          buffer.put(i12 % 2 ? 17 : 236, 8);
        }
        return createCodewords(buffer, version, errorCorrectionLevel);
      }
      function createCodewords(bitBuffer, version, errorCorrectionLevel) {
        const totalCodewords = Utils.getSymbolTotalCodewords(version);
        const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
        const dataTotalCodewords = totalCodewords - ecTotalCodewords;
        const ecTotalBlocks = ECCode.getBlocksCount(version, errorCorrectionLevel);
        const blocksInGroup2 = totalCodewords % ecTotalBlocks;
        const blocksInGroup1 = ecTotalBlocks - blocksInGroup2;
        const totalCodewordsInGroup1 = Math.floor(totalCodewords / ecTotalBlocks);
        const dataCodewordsInGroup1 = Math.floor(dataTotalCodewords / ecTotalBlocks);
        const dataCodewordsInGroup2 = dataCodewordsInGroup1 + 1;
        const ecCount = totalCodewordsInGroup1 - dataCodewordsInGroup1;
        const rs = new ReedSolomonEncoder(ecCount);
        let offset = 0;
        const dcData = new Array(ecTotalBlocks);
        const ecData = new Array(ecTotalBlocks);
        let maxDataSize = 0;
        const buffer = new Uint8Array(bitBuffer.buffer);
        for (let b8 = 0; b8 < ecTotalBlocks; b8++) {
          const dataSize = b8 < blocksInGroup1 ? dataCodewordsInGroup1 : dataCodewordsInGroup2;
          dcData[b8] = buffer.slice(offset, offset + dataSize);
          ecData[b8] = rs.encode(dcData[b8]);
          offset += dataSize;
          maxDataSize = Math.max(maxDataSize, dataSize);
        }
        const data = new Uint8Array(totalCodewords);
        let index = 0;
        let i12, r13;
        for (i12 = 0; i12 < maxDataSize; i12++) {
          for (r13 = 0; r13 < ecTotalBlocks; r13++) {
            if (i12 < dcData[r13].length) {
              data[index++] = dcData[r13][i12];
            }
          }
        }
        for (i12 = 0; i12 < ecCount; i12++) {
          for (r13 = 0; r13 < ecTotalBlocks; r13++) {
            data[index++] = ecData[r13][i12];
          }
        }
        return data;
      }
      function createSymbol(data, version, errorCorrectionLevel, maskPattern) {
        let segments;
        if (Array.isArray(data)) {
          segments = Segments.fromArray(data);
        } else if (typeof data === "string") {
          let estimatedVersion = version;
          if (!estimatedVersion) {
            const rawSegments = Segments.rawSplit(data);
            estimatedVersion = Version.getBestVersionForData(rawSegments, errorCorrectionLevel);
          }
          segments = Segments.fromString(data, estimatedVersion || 40);
        } else {
          throw new Error("Invalid data");
        }
        const bestVersion = Version.getBestVersionForData(segments, errorCorrectionLevel);
        if (!bestVersion) {
          throw new Error("The amount of data is too big to be stored in a QR Code");
        }
        if (!version) {
          version = bestVersion;
        } else if (version < bestVersion) {
          throw new Error(
            "\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + bestVersion + ".\n"
          );
        }
        const dataBits = createData(version, errorCorrectionLevel, segments);
        const moduleCount = Utils.getSymbolSize(version);
        const modules = new BitMatrix(moduleCount);
        setupFinderPattern(modules, version);
        setupTimingPattern(modules);
        setupAlignmentPattern(modules, version);
        setupFormatInfo(modules, errorCorrectionLevel, 0);
        if (version >= 7) {
          setupVersionInfo(modules, version);
        }
        setupData(modules, dataBits);
        if (isNaN(maskPattern)) {
          maskPattern = MaskPattern.getBestMask(
            modules,
            setupFormatInfo.bind(null, modules, errorCorrectionLevel)
          );
        }
        MaskPattern.applyMask(maskPattern, modules);
        setupFormatInfo(modules, errorCorrectionLevel, maskPattern);
        return {
          modules,
          version,
          errorCorrectionLevel,
          maskPattern,
          segments
        };
      }
      exports2.create = function create2(data, options) {
        if (typeof data === "undefined" || data === "") {
          throw new Error("No input text");
        }
        let errorCorrectionLevel = ECLevel.M;
        let version;
        let mask;
        if (typeof options !== "undefined") {
          errorCorrectionLevel = ECLevel.from(options.errorCorrectionLevel, ECLevel.M);
          version = Version.from(options.version);
          mask = MaskPattern.from(options.maskPattern);
          if (options.toSJISFunc) {
            Utils.setToSJISFunction(options.toSJISFunc);
          }
        }
        return createSymbol(data, version, errorCorrectionLevel, mask);
      };
    }
  });

  // node_modules/qrcode/lib/renderer/utils.js
  var require_utils3 = __commonJS({
    "node_modules/qrcode/lib/renderer/utils.js"(exports2) {
      init_define_import_meta_env();
      function hex2rgba(hex) {
        if (typeof hex === "number") {
          hex = hex.toString();
        }
        if (typeof hex !== "string") {
          throw new Error("Color should be defined as hex string");
        }
        let hexCode = hex.slice().replace("#", "").split("");
        if (hexCode.length < 3 || hexCode.length === 5 || hexCode.length > 8) {
          throw new Error("Invalid hex color: " + hex);
        }
        if (hexCode.length === 3 || hexCode.length === 4) {
          hexCode = Array.prototype.concat.apply([], hexCode.map(function(c12) {
            return [c12, c12];
          }));
        }
        if (hexCode.length === 6) hexCode.push("F", "F");
        const hexValue = parseInt(hexCode.join(""), 16);
        return {
          r: hexValue >> 24 & 255,
          g: hexValue >> 16 & 255,
          b: hexValue >> 8 & 255,
          a: hexValue & 255,
          hex: "#" + hexCode.slice(0, 6).join("")
        };
      }
      exports2.getOptions = function getOptions(options) {
        if (!options) options = {};
        if (!options.color) options.color = {};
        const margin = typeof options.margin === "undefined" || options.margin === null || options.margin < 0 ? 4 : options.margin;
        const width = options.width && options.width >= 21 ? options.width : void 0;
        const scale = options.scale || 4;
        return {
          width,
          scale: width ? 4 : scale,
          margin,
          color: {
            dark: hex2rgba(options.color.dark || "#000000ff"),
            light: hex2rgba(options.color.light || "#ffffffff")
          },
          type: options.type,
          rendererOpts: options.rendererOpts || {}
        };
      };
      exports2.getScale = function getScale(qrSize, opts) {
        return opts.width && opts.width >= qrSize + opts.margin * 2 ? opts.width / (qrSize + opts.margin * 2) : opts.scale;
      };
      exports2.getImageWidth = function getImageWidth(qrSize, opts) {
        const scale = exports2.getScale(qrSize, opts);
        return Math.floor((qrSize + opts.margin * 2) * scale);
      };
      exports2.qrToImageData = function qrToImageData(imgData, qr, opts) {
        const size = qr.modules.size;
        const data = qr.modules.data;
        const scale = exports2.getScale(size, opts);
        const symbolSize = Math.floor((size + opts.margin * 2) * scale);
        const scaledMargin = opts.margin * scale;
        const palette = [opts.color.light, opts.color.dark];
        for (let i12 = 0; i12 < symbolSize; i12++) {
          for (let j7 = 0; j7 < symbolSize; j7++) {
            let posDst = (i12 * symbolSize + j7) * 4;
            let pxColor = opts.color.light;
            if (i12 >= scaledMargin && j7 >= scaledMargin && i12 < symbolSize - scaledMargin && j7 < symbolSize - scaledMargin) {
              const iSrc = Math.floor((i12 - scaledMargin) / scale);
              const jSrc = Math.floor((j7 - scaledMargin) / scale);
              pxColor = palette[data[iSrc * size + jSrc] ? 1 : 0];
            }
            imgData[posDst++] = pxColor.r;
            imgData[posDst++] = pxColor.g;
            imgData[posDst++] = pxColor.b;
            imgData[posDst] = pxColor.a;
          }
        }
      };
    }
  });

  // node_modules/qrcode/lib/renderer/canvas.js
  var require_canvas = __commonJS({
    "node_modules/qrcode/lib/renderer/canvas.js"(exports2) {
      init_define_import_meta_env();
      var Utils = require_utils3();
      function clearCanvas(ctx, canvas, size) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (!canvas.style) canvas.style = {};
        canvas.height = size;
        canvas.width = size;
        canvas.style.height = size + "px";
        canvas.style.width = size + "px";
      }
      function getCanvasElement() {
        try {
          return document.createElement("canvas");
        } catch (e6) {
          throw new Error("You need to specify a canvas element");
        }
      }
      exports2.render = function render2(qrData, canvas, options) {
        let opts = options;
        let canvasEl = canvas;
        if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
          opts = canvas;
          canvas = void 0;
        }
        if (!canvas) {
          canvasEl = getCanvasElement();
        }
        opts = Utils.getOptions(opts);
        const size = Utils.getImageWidth(qrData.modules.size, opts);
        const ctx = canvasEl.getContext("2d");
        const image = ctx.createImageData(size, size);
        Utils.qrToImageData(image.data, qrData, opts);
        clearCanvas(ctx, canvasEl, size);
        ctx.putImageData(image, 0, 0);
        return canvasEl;
      };
      exports2.renderToDataURL = function renderToDataURL(qrData, canvas, options) {
        let opts = options;
        if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
          opts = canvas;
          canvas = void 0;
        }
        if (!opts) opts = {};
        const canvasEl = exports2.render(qrData, canvas, opts);
        const type = opts.type || "image/png";
        const rendererOpts = opts.rendererOpts || {};
        return canvasEl.toDataURL(type, rendererOpts.quality);
      };
    }
  });

  // node_modules/qrcode/lib/renderer/svg-tag.js
  var require_svg_tag = __commonJS({
    "node_modules/qrcode/lib/renderer/svg-tag.js"(exports2) {
      init_define_import_meta_env();
      var Utils = require_utils3();
      function getColorAttrib(color, attrib) {
        const alpha = color.a / 255;
        const str = attrib + '="' + color.hex + '"';
        return alpha < 1 ? str + " " + attrib + '-opacity="' + alpha.toFixed(2).slice(1) + '"' : str;
      }
      function svgCmd(cmd, x8, y4) {
        let str = cmd + x8;
        if (typeof y4 !== "undefined") str += " " + y4;
        return str;
      }
      function qrToPath(data, size, margin) {
        let path = "";
        let moveBy = 0;
        let newRow = false;
        let lineLength = 0;
        for (let i12 = 0; i12 < data.length; i12++) {
          const col = Math.floor(i12 % size);
          const row = Math.floor(i12 / size);
          if (!col && !newRow) newRow = true;
          if (data[i12]) {
            lineLength++;
            if (!(i12 > 0 && col > 0 && data[i12 - 1])) {
              path += newRow ? svgCmd("M", col + margin, 0.5 + row + margin) : svgCmd("m", moveBy, 0);
              moveBy = 0;
              newRow = false;
            }
            if (!(col + 1 < size && data[i12 + 1])) {
              path += svgCmd("h", lineLength);
              lineLength = 0;
            }
          } else {
            moveBy++;
          }
        }
        return path;
      }
      exports2.render = function render2(qrData, options, cb) {
        const opts = Utils.getOptions(options);
        const size = qrData.modules.size;
        const data = qrData.modules.data;
        const qrcodesize = size + opts.margin * 2;
        const bg = !opts.color.light.a ? "" : "<path " + getColorAttrib(opts.color.light, "fill") + ' d="M0 0h' + qrcodesize + "v" + qrcodesize + 'H0z"/>';
        const path = "<path " + getColorAttrib(opts.color.dark, "stroke") + ' d="' + qrToPath(data, size, opts.margin) + '"/>';
        const viewBox = 'viewBox="0 0 ' + qrcodesize + " " + qrcodesize + '"';
        const width = !opts.width ? "" : 'width="' + opts.width + '" height="' + opts.width + '" ';
        const svgTag = '<svg xmlns="http://www.w3.org/2000/svg" ' + width + viewBox + ' shape-rendering="crispEdges">' + bg + path + "</svg>\n";
        if (typeof cb === "function") {
          cb(null, svgTag);
        }
        return svgTag;
      };
    }
  });

  // node_modules/qrcode/lib/browser.js
  var require_browser = __commonJS({
    "node_modules/qrcode/lib/browser.js"(exports2) {
      init_define_import_meta_env();
      var canPromise = require_can_promise();
      var QRCode2 = require_qrcode();
      var CanvasRenderer = require_canvas();
      var SvgRenderer = require_svg_tag();
      function renderCanvas(renderFunc, canvas, text, opts, cb) {
        const args = [].slice.call(arguments, 1);
        const argsNum = args.length;
        const isLastArgCb = typeof args[argsNum - 1] === "function";
        if (!isLastArgCb && !canPromise()) {
          throw new Error("Callback required as last argument");
        }
        if (isLastArgCb) {
          if (argsNum < 2) {
            throw new Error("Too few arguments provided");
          }
          if (argsNum === 2) {
            cb = text;
            text = canvas;
            canvas = opts = void 0;
          } else if (argsNum === 3) {
            if (canvas.getContext && typeof cb === "undefined") {
              cb = opts;
              opts = void 0;
            } else {
              cb = opts;
              opts = text;
              text = canvas;
              canvas = void 0;
            }
          }
        } else {
          if (argsNum < 1) {
            throw new Error("Too few arguments provided");
          }
          if (argsNum === 1) {
            text = canvas;
            canvas = opts = void 0;
          } else if (argsNum === 2 && !canvas.getContext) {
            opts = text;
            text = canvas;
            canvas = void 0;
          }
          return new Promise(function(resolve, reject) {
            try {
              const data = QRCode2.create(text, opts);
              resolve(renderFunc(data, canvas, opts));
            } catch (e6) {
              reject(e6);
            }
          });
        }
        try {
          const data = QRCode2.create(text, opts);
          cb(null, renderFunc(data, canvas, opts));
        } catch (e6) {
          cb(e6);
        }
      }
      exports2.create = QRCode2.create;
      exports2.toCanvas = renderCanvas.bind(null, CanvasRenderer.render);
      exports2.toDataURL = renderCanvas.bind(null, CanvasRenderer.renderToDataURL);
      exports2.toString = renderCanvas.bind(null, function(data, _4, opts) {
        return SvgRenderer.render(data, opts);
      });
    }
  });

  // ds-entry.tsx
  var ds_entry_exports = {};
  __export(ds_entry_exports, {
    ApplicationLogo: () => ApplicationLogo,
    AutocompleteInput: () => AutocompleteInput,
    BulletEditor: () => BulletEditor,
    Checkbox: () => Checkbox,
    DangerButton: () => DangerButton,
    Dropdown: () => Dropdown_default,
    InputError: () => InputError,
    InputLabel: () => InputLabel,
    Modal: () => Modal,
    PrimaryButton: () => PrimaryButton,
    QRCodeDisplay: () => QRCodeDisplay,
    SecondaryButton: () => SecondaryButton,
    SkillGroupEditor: () => SkillGroupEditor,
    SkillNarrativeEditor: () => SkillNarrativeEditor,
    TagInput: () => TagInput,
    TextInput: () => TextInput_default
  });
  init_define_import_meta_env();

  // resources/js/Components/ApplicationLogo.tsx
  init_define_import_meta_env();
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  function ApplicationLogo(props) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "svg",
      {
        ...props,
        viewBox: "0 0 316 316",
        xmlns: "http://www.w3.org/2000/svg",
        children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M305.8 81.125C305.77 80.995 305.69 80.885 305.65 80.755C305.56 80.525 305.49 80.285 305.37 80.075C305.29 79.935 305.17 79.815 305.07 79.685C304.94 79.515 304.83 79.325 304.68 79.175C304.55 79.045 304.39 78.955 304.25 78.845C304.09 78.715 303.95 78.575 303.77 78.475L251.32 48.275C249.97 47.495 248.31 47.495 246.96 48.275L194.51 78.475C194.33 78.575 194.19 78.725 194.03 78.845C193.89 78.955 193.73 79.045 193.6 79.175C193.45 79.325 193.34 79.515 193.21 79.685C193.11 79.815 192.99 79.935 192.91 80.075C192.79 80.285 192.71 80.525 192.63 80.755C192.58 80.875 192.51 80.995 192.48 81.125C192.38 81.495 192.33 81.875 192.33 82.265V139.625L148.62 164.795V52.575C148.62 52.185 148.57 51.805 148.47 51.435C148.44 51.305 148.36 51.195 148.32 51.065C148.23 50.835 148.16 50.595 148.04 50.385C147.96 50.245 147.84 50.125 147.74 49.995C147.61 49.825 147.5 49.635 147.35 49.485C147.22 49.355 147.06 49.265 146.92 49.155C146.76 49.025 146.62 48.885 146.44 48.785L93.99 18.585C92.64 17.805 90.98 17.805 89.63 18.585L37.18 48.785C37 48.885 36.86 49.035 36.7 49.155C36.56 49.265 36.4 49.355 36.27 49.485C36.12 49.635 36.01 49.825 35.88 49.995C35.78 50.125 35.66 50.245 35.58 50.385C35.46 50.595 35.38 50.835 35.3 51.065C35.25 51.185 35.18 51.305 35.15 51.435C35.05 51.805 35 52.185 35 52.575V232.235C35 233.795 35.84 235.245 37.19 236.025L142.1 296.425C142.33 296.555 142.58 296.635 142.82 296.725C142.93 296.765 143.04 296.835 143.16 296.865C143.53 296.965 143.9 297.015 144.28 297.015C144.66 297.015 145.03 296.965 145.4 296.865C145.5 296.835 145.59 296.775 145.69 296.745C145.95 296.655 146.21 296.565 146.45 296.435L251.36 236.035C252.72 235.255 253.55 233.815 253.55 232.245V174.885L303.81 145.945C305.17 145.165 306 143.725 306 142.155V82.265C305.95 81.875 305.89 81.495 305.8 81.125ZM144.2 227.205L100.57 202.515L146.39 176.135L196.66 147.195L240.33 172.335L208.29 190.625L144.2 227.205ZM244.75 114.995V164.795L226.39 154.225L201.03 139.625V89.825L219.39 100.395L244.75 114.995ZM249.12 57.105L292.81 82.265L249.12 107.425L205.43 82.265L249.12 57.105ZM114.49 184.425L96.13 194.995V85.305L121.49 70.705L139.85 60.135V169.815L114.49 184.425ZM91.76 27.425L135.45 52.585L91.76 77.745L48.07 52.585L91.76 27.425ZM43.67 60.135L62.03 70.705L87.39 85.305V202.545V202.555V202.565C87.39 202.735 87.44 202.895 87.46 203.055C87.49 203.265 87.49 203.485 87.55 203.695V203.705C87.6 203.875 87.69 204.035 87.76 204.195C87.84 204.375 87.89 204.575 87.99 204.745C87.99 204.745 87.99 204.755 88 204.755C88.09 204.905 88.22 205.035 88.33 205.175C88.45 205.335 88.55 205.495 88.69 205.635L88.7 205.645C88.82 205.765 88.98 205.855 89.12 205.965C89.28 206.085 89.42 206.225 89.59 206.325C89.6 206.325 89.6 206.325 89.61 206.335C89.62 206.335 89.62 206.345 89.63 206.345L139.87 234.775V285.065L43.67 229.705V60.135ZM244.75 229.705L148.58 285.075V234.775L219.8 194.115L244.75 179.875V229.705ZM297.2 139.625L253.49 164.795V114.995L278.85 100.395L297.21 89.825V139.625H297.2Z" })
      }
    );
  }

  // resources/js/Components/AutocompleteInput.tsx
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim(), 1);
  var import_jsx_runtime2 = __toESM(require_react_shim(), 1);
  function AutocompleteInput({
    endpoint,
    value,
    onChange,
    placeholder,
    className,
    name,
    id
  }) {
    const [query, setQuery] = (0, import_react.useState)(value);
    const [suggestions, setSuggestions] = (0, import_react.useState)([]);
    const [activeIndex, setActiveIndex] = (0, import_react.useState)(-1);
    const [open, setOpen] = (0, import_react.useState)(false);
    const containerRef = (0, import_react.useRef)(null);
    const debounceRef = (0, import_react.useRef)();
    (0, import_react.useEffect)(() => {
      setQuery(value);
    }, [value]);
    (0, import_react.useEffect)(() => {
      clearTimeout(debounceRef.current);
      if (query.length < 2) {
        setSuggestions([]);
        setOpen(false);
        return;
      }
      debounceRef.current = setTimeout(async () => {
        try {
          const res = await fetch(
            `/autocomplete/${endpoint}?q=${encodeURIComponent(query)}`,
            { headers: { "X-Requested-With": "XMLHttpRequest" } }
          );
          if (!res.ok) return;
          const data = await res.json();
          setSuggestions(data);
          setOpen(data.length > 0);
          setActiveIndex(-1);
        } catch {
        }
      }, 150);
      return () => clearTimeout(debounceRef.current);
    }, [query, endpoint]);
    (0, import_react.useEffect)(() => {
      const handler = (e6) => {
        if (containerRef.current && !containerRef.current.contains(e6.target)) {
          setOpen(false);
        }
      };
      document.addEventListener("mousedown", handler);
      return () => document.removeEventListener("mousedown", handler);
    }, []);
    const select = (title) => {
      setQuery(title);
      onChange(title);
      setOpen(false);
      setSuggestions([]);
    };
    const handleBlur = async () => {
      setOpen(false);
      if (!query || query.length < 2) return;
      const match = suggestions.find(
        (s11) => s11.title.toLowerCase() === query.toLowerCase()
      );
      if (match) {
        select(match.title);
        return;
      }
      try {
        const res = await fetch(`/autocomplete/${endpoint}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]')?.content ?? "",
            "X-Requested-With": "XMLHttpRequest"
          },
          body: JSON.stringify({ title: query })
        });
        if (res.ok) {
          const { title } = await res.json();
          select(title);
        }
      } catch {
      }
    };
    const handleKeyDown = (e6) => {
      if (!open || suggestions.length === 0) return;
      if (e6.key === "ArrowDown") {
        e6.preventDefault();
        setActiveIndex((i12) => Math.min(i12 + 1, suggestions.length - 1));
      } else if (e6.key === "ArrowUp") {
        e6.preventDefault();
        setActiveIndex((i12) => Math.max(i12 - 1, -1));
      } else if (e6.key === "Enter" && activeIndex >= 0) {
        e6.preventDefault();
        select(suggestions[activeIndex].title);
      } else if (e6.key === "Escape") {
        setOpen(false);
      }
    };
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { ref: containerRef, className: "relative", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "input",
        {
          type: "text",
          name,
          id,
          value: query,
          placeholder,
          className,
          autoComplete: "off",
          onChange: (e6) => {
            setQuery(e6.target.value);
            onChange(e6.target.value);
          },
          onKeyDown: handleKeyDown,
          onBlur: handleBlur
        }
      ),
      open && suggestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("ul", { className: "absolute z-50 top-full left-0 right-0 mt-1 bg-white border border-[#e8e8f0] rounded-lg shadow-lg py-1 max-h-52 overflow-y-auto", children: suggestions.map((s11, i12) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "li",
        {
          onMouseDown: () => select(s11.title),
          className: `px-3 py-2 text-sm cursor-pointer ${i12 === activeIndex ? "bg-[#eef2ff] text-[#4f46e5]" : "text-[#23232d] hover:bg-[#f5f5fb]"}`,
          children: s11.title
        },
        s11.id
      )) })
    ] });
  }

  // resources/js/Components/BulletEditor.tsx
  init_define_import_meta_env();

  // node_modules/@heroicons/react/24/outline/esm/index.js
  init_define_import_meta_env();

  // node_modules/@heroicons/react/24/outline/esm/TrashIcon.js
  init_define_import_meta_env();
  var React = __toESM(require_react_shim(), 1);
  function TrashIcon({
    title,
    titleId,
    ...props
  }, svgRef) {
    return /* @__PURE__ */ React.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: svgRef,
      "aria-labelledby": titleId
    }, props), title ? /* @__PURE__ */ React.createElement("title", {
      id: titleId
    }, title) : null, /* @__PURE__ */ React.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
    }));
  }
  var ForwardRef = /* @__PURE__ */ React.forwardRef(TrashIcon);
  var TrashIcon_default = ForwardRef;

  // resources/js/Components/BulletEditor.tsx
  var import_react2 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime3 = __toESM(require_react_shim(), 1);
  function BulletEditor({ bullets, onChange, onBlur }) {
    const rows = bullets.length ? bullets : [""];
    const refs = (0, import_react2.useRef)([]);
    (0, import_react2.useEffect)(() => {
      refs.current.forEach((el) => {
        if (el) {
          el.style.height = "auto";
          el.style.height = `${el.scrollHeight}px`;
        }
      });
    }, [rows]);
    const update = (idx, val) => {
      const next = [...rows];
      next[idx] = val;
      onChange(next.filter((_4, i12) => i12 !== idx || val !== "" || rows.length === 1));
    };
    const handlePaste = (e6, idx) => {
      const text = e6.clipboardData.getData("text");
      const lines = text.split("\n").map((l10) => l10.replace(/\r$/, "").trim().replace(/^[•\-–—*]\s*/, "").replace(/^\d+[.)]\s*/, "")).filter((l10) => l10 !== "");
      if (lines.length === 0) return;
      e6.preventDefault();
      if (lines.length === 1) {
        update(idx, lines[0]);
        return;
      }
      const before = rows.slice(0, idx);
      const after = rows.slice(idx + 1);
      const updated = [...before, ...lines, ...after].filter((l10, i12, arr) => l10 !== "" || arr.length === 1);
      onChange(updated);
      setTimeout(() => refs.current[idx + lines.length - 1]?.focus(), 0);
    };
    const deleteBullet = (idx) => {
      if (rows.length === 1) {
        onChange([""]);
      } else {
        const next = rows.filter((_4, i12) => i12 !== idx);
        onChange(next);
        setTimeout(() => refs.current[Math.max(0, idx - 1)]?.focus(), 0);
      }
    };
    const handleKey = (e6, idx) => {
      if (e6.key === "Enter") {
        e6.preventDefault();
        const next = [...rows.slice(0, idx + 1), "", ...rows.slice(idx + 1)];
        onChange(next);
        setTimeout(() => refs.current[idx + 1]?.focus(), 0);
      } else if (e6.key === "Backspace" && rows[idx] === "" && rows.length > 1) {
        e6.preventDefault();
        onChange(rows.filter((_4, i12) => i12 !== idx));
        setTimeout(() => refs.current[Math.max(0, idx - 1)]?.focus(), 0);
      }
    };
    return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "flex flex-col gap-0.5", children: rows.map((bullet, idx) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "flex items-start gap-1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "mt-[7px] text-xs text-gray-400 select-none", children: "\u2022" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        "textarea",
        {
          ref: (el) => {
            refs.current[idx] = el;
          },
          value: bullet,
          rows: 1,
          onChange: (e6) => {
            update(idx, e6.target.value);
            e6.target.style.height = "auto";
            e6.target.style.height = `${e6.target.scrollHeight}px`;
          },
          onPaste: (e6) => handlePaste(e6, idx),
          onKeyDown: (e6) => handleKey(e6, idx),
          onBlur,
          placeholder: "Start with an action verb\u2026",
          className: "flex-1 resize-none overflow-hidden rounded border-gray-200 bg-gray-50 text-sm shadow-none focus:border-indigo-400 focus:ring-0 focus:bg-white"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        "button",
        {
          type: "button",
          onClick: () => deleteBullet(idx),
          className: "mt-[6px] text-gray-300 hover:text-red-500 transition-colors",
          tabIndex: -1,
          "aria-label": "Delete bullet",
          children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(TrashIcon_default, { className: "h-3.5 w-3.5" })
        }
      )
    ] }, idx)) });
  }

  // resources/js/Components/Checkbox.tsx
  init_define_import_meta_env();
  var import_jsx_runtime4 = __toESM(require_react_shim(), 1);
  function Checkbox({
    className = "",
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "input",
      {
        ...props,
        type: "checkbox",
        className: "rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500 " + className
      }
    );
  }

  // resources/js/Components/DangerButton.tsx
  init_define_import_meta_env();
  var import_jsx_runtime5 = __toESM(require_react_shim(), 1);
  function DangerButton({
    className = "",
    disabled,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
      "button",
      {
        ...props,
        className: `inline-flex items-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-xs font-semibold uppercase tracking-widest text-white transition duration-150 ease-in-out hover:bg-red-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 active:bg-red-700 ${disabled && "opacity-25"} ` + className,
        disabled,
        children
      }
    );
  }

  // resources/js/Components/Dropdown.tsx
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/utils/owner.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/utils/env.js
  init_define_import_meta_env();
  var i = Object.defineProperty;
  var d = (t11, e6, n12) => e6 in t11 ? i(t11, e6, { enumerable: true, configurable: true, writable: true, value: n12 }) : t11[e6] = n12;
  var r = (t11, e6, n12) => (d(t11, typeof e6 != "symbol" ? e6 + "" : e6, n12), n12);
  var o = class {
    constructor() {
      r(this, "current", this.detect());
      r(this, "handoffState", "pending");
      r(this, "currentId", 0);
    }
    set(e6) {
      this.current !== e6 && (this.handoffState = "pending", this.currentId = 0, this.current = e6);
    }
    reset() {
      this.set(this.detect());
    }
    nextId() {
      return ++this.currentId;
    }
    get isServer() {
      return this.current === "server";
    }
    get isClient() {
      return this.current === "client";
    }
    detect() {
      return typeof window == "undefined" || typeof document == "undefined" ? "server" : "client";
    }
    handoff() {
      this.handoffState === "pending" && (this.handoffState = "complete");
    }
    get isHandoffComplete() {
      return this.handoffState === "complete";
    }
  };
  var s = new o();

  // node_modules/@headlessui/react/dist/utils/owner.js
  function l(n12) {
    var u12;
    return s.isServer ? null : n12 == null ? document : (u12 = n12 == null ? void 0 : n12.ownerDocument) != null ? u12 : document;
  }
  function r2(n12) {
    var u12, o12;
    return s.isServer ? null : n12 == null ? document : (o12 = (u12 = n12 == null ? void 0 : n12.getRootNode) == null ? void 0 : u12.call(n12)) != null ? o12 : document;
  }
  function e(n12) {
    var u12, o12;
    return (o12 = (u12 = r2(n12)) == null ? void 0 : u12.activeElement) != null ? o12 : null;
  }
  function d2(n12) {
    return e(n12) === n12;
  }

  // node_modules/@headlessui/react/dist/hooks/use-disposables.js
  init_define_import_meta_env();
  var import_react3 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/utils/disposables.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/utils/micro-task.js
  init_define_import_meta_env();
  function t(e6) {
    typeof queueMicrotask == "function" ? queueMicrotask(e6) : Promise.resolve().then(e6).catch((o12) => setTimeout(() => {
      throw o12;
    }));
  }

  // node_modules/@headlessui/react/dist/utils/disposables.js
  function o2() {
    let s11 = [], r13 = { addEventListener(e6, t11, n12, i12) {
      return e6.addEventListener(t11, n12, i12), r13.add(() => e6.removeEventListener(t11, n12, i12));
    }, requestAnimationFrame(...e6) {
      let t11 = requestAnimationFrame(...e6);
      return r13.add(() => cancelAnimationFrame(t11));
    }, nextFrame(...e6) {
      return r13.requestAnimationFrame(() => r13.requestAnimationFrame(...e6));
    }, setTimeout(...e6) {
      let t11 = setTimeout(...e6);
      return r13.add(() => clearTimeout(t11));
    }, microTask(...e6) {
      let t11 = { current: true };
      return t(() => {
        t11.current && e6[0]();
      }), r13.add(() => {
        t11.current = false;
      });
    }, style(e6, t11, n12) {
      let i12 = e6.style.getPropertyValue(t11);
      return Object.assign(e6.style, { [t11]: n12 }), this.add(() => {
        Object.assign(e6.style, { [t11]: i12 });
      });
    }, group(e6) {
      let t11 = o2();
      return e6(t11), this.add(() => t11.dispose());
    }, add(e6) {
      return s11.includes(e6) || s11.push(e6), () => {
        let t11 = s11.indexOf(e6);
        if (t11 >= 0) for (let n12 of s11.splice(t11, 1)) n12();
      };
    }, dispose() {
      for (let e6 of s11.splice(0)) e6();
    } };
    return r13;
  }

  // node_modules/@headlessui/react/dist/hooks/use-disposables.js
  function p() {
    let [e6] = (0, import_react3.useState)(o2);
    return (0, import_react3.useEffect)(() => () => e6.dispose(), [e6]), e6;
  }

  // node_modules/@headlessui/react/dist/hooks/use-event.js
  init_define_import_meta_env();
  var import_react6 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-latest-value.js
  init_define_import_meta_env();
  var import_react5 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js
  init_define_import_meta_env();
  var import_react4 = __toESM(require_react_shim(), 1);
  var n = (e6, t11) => {
    s.isServer ? (0, import_react4.useEffect)(e6, t11) : (0, import_react4.useLayoutEffect)(e6, t11);
  };

  // node_modules/@headlessui/react/dist/hooks/use-latest-value.js
  function s3(e6) {
    let r13 = (0, import_react5.useRef)(e6);
    return n(() => {
      r13.current = e6;
    }, [e6]), r13;
  }

  // node_modules/@headlessui/react/dist/hooks/use-event.js
  var o4 = function(t11) {
    let e6 = s3(t11);
    return import_react6.default.useCallback((...r13) => e6.current(...r13), [e6]);
  };

  // node_modules/@headlessui/react/dist/hooks/use-slot.js
  init_define_import_meta_env();
  var import_react7 = __toESM(require_react_shim(), 1);
  function n2(e6) {
    return (0, import_react7.useMemo)(() => e6, Object.values(e6));
  }

  // node_modules/@headlessui/react/dist/internal/disabled.js
  init_define_import_meta_env();
  var import_react8 = __toESM(require_react_shim(), 1);
  var e2 = (0, import_react8.createContext)(void 0);
  function a2() {
    return (0, import_react8.useContext)(e2);
  }

  // node_modules/@headlessui/react/dist/utils/render.js
  init_define_import_meta_env();
  var import_react9 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/utils/class-names.js
  init_define_import_meta_env();
  function t4(...r13) {
    return Array.from(new Set(r13.flatMap((n12) => typeof n12 == "string" ? n12.split(" ") : []))).filter(Boolean).join(" ");
  }

  // node_modules/@headlessui/react/dist/utils/match.js
  init_define_import_meta_env();
  function u(r13, n12, ...a15) {
    if (r13 in n12) {
      let e6 = n12[r13];
      return typeof e6 == "function" ? e6(...a15) : e6;
    }
    let t11 = new Error(`Tried to handle "${r13}" but there is no handler defined. Only defined handlers are: ${Object.keys(n12).map((e6) => `"${e6}"`).join(", ")}.`);
    throw Error.captureStackTrace && Error.captureStackTrace(t11, u), t11;
  }

  // node_modules/@headlessui/react/dist/utils/render.js
  var A = ((a15) => (a15[a15.None = 0] = "None", a15[a15.RenderStrategy = 1] = "RenderStrategy", a15[a15.Static = 2] = "Static", a15))(A || {});
  var C = ((t11) => (t11[t11.Unmount = 0] = "Unmount", t11[t11.Hidden = 1] = "Hidden", t11))(C || {});
  function K() {
    let e6 = I();
    return (0, import_react9.useCallback)((r13) => U({ mergeRefs: e6, ...r13 }), [e6]);
  }
  function U({ ourProps: e6, theirProps: r13, slot: t11, defaultTag: a15, features: o12, visible: n12 = true, name: i12, mergeRefs: l10 }) {
    l10 = l10 != null ? l10 : H;
    let s11 = P(r13, e6);
    if (n12) return F(s11, t11, a15, i12, l10);
    let y4 = o12 != null ? o12 : 0;
    if (y4 & 2) {
      let { static: f11 = false, ...u12 } = s11;
      if (f11) return F(u12, t11, a15, i12, l10);
    }
    if (y4 & 1) {
      let { unmount: f11 = true, ...u12 } = s11;
      return u(f11 ? 0 : 1, { [0]() {
        return null;
      }, [1]() {
        return F({ ...u12, hidden: true, style: { display: "none" } }, t11, a15, i12, l10);
      } });
    }
    return F(s11, t11, a15, i12, l10);
  }
  function F(e6, r13 = {}, t11, a15, o12) {
    let { as: n12 = t11, children: i12, refName: l10 = "ref", ...s11 } = h(e6, ["unmount", "static"]), y4 = e6.ref !== void 0 ? { [l10]: e6.ref } : {}, f11 = typeof i12 == "function" ? i12(r13) : i12;
    f11 = E(f11), "className" in s11 && s11.className && typeof s11.className == "function" && (s11.className = s11.className(r13)), s11["aria-labelledby"] && s11["aria-labelledby"] === s11.id && (s11["aria-labelledby"] = void 0);
    let u12 = {};
    if (r13) {
      let d8 = false, p6 = [];
      for (let [c12, T7] of Object.entries(r13)) typeof T7 == "boolean" && (d8 = true), T7 === true && p6.push(c12.replace(/([A-Z])/g, (g2) => `-${g2.toLowerCase()}`));
      if (d8) {
        u12["data-headlessui-state"] = p6.join(" ");
        for (let c12 of p6) u12[`data-${c12}`] = "";
      }
    }
    if (b(n12) && (Object.keys(m(s11)).length > 0 || Object.keys(m(u12)).length > 0)) if (!(0, import_react9.isValidElement)(f11) || Array.isArray(f11) && f11.length > 1 || L(f11)) {
      if (Object.keys(m(s11)).length > 0) throw new Error(['Passing props on "Fragment"!', "", `The current component <${a15} /> is rendering a "Fragment".`, "However we need to passthrough the following props:", Object.keys(m(s11)).concat(Object.keys(m(u12))).map((d8) => `  - ${d8}`).join(`
`), "", "You can apply a few solutions:", ['Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".', "Render a single element as the child so that we can forward the props onto that element."].map((d8) => `  - ${d8}`).join(`
`)].join(`
`));
    } else {
      let d8 = f11.props, p6 = d8 == null ? void 0 : d8.className, c12 = typeof p6 == "function" ? (...R2) => t4(p6(...R2), s11.className) : t4(p6, s11.className), T7 = c12 ? { className: c12 } : {}, g2 = P(f11.props, m(h(s11, ["ref"])));
      for (let R2 in u12) R2 in g2 && delete u12[R2];
      return (0, import_react9.cloneElement)(f11, Object.assign({}, g2, u12, y4, { ref: o12(D(f11), y4.ref) }, T7));
    }
    return (0, import_react9.createElement)(n12, Object.assign({}, h(s11, ["ref"]), !b(n12) && y4, !b(n12) && u12), f11);
  }
  function I() {
    let e6 = (0, import_react9.useRef)([]), r13 = (0, import_react9.useCallback)((t11) => {
      for (let a15 of e6.current) a15 != null && (typeof a15 == "function" ? a15(t11) : a15.current = t11);
    }, []);
    return (...t11) => {
      if (!t11.every((a15) => a15 == null)) return e6.current = t11, r13;
    };
  }
  function H(...e6) {
    return e6.every((r13) => r13 == null) ? void 0 : (r13) => {
      for (let t11 of e6) t11 != null && (typeof t11 == "function" ? t11(r13) : t11.current = r13);
    };
  }
  function P(...e6) {
    var a15;
    if (e6.length === 0) return {};
    if (e6.length === 1) return e6[0];
    let r13 = {}, t11 = {};
    for (let o12 of e6) for (let n12 in o12) n12.startsWith("on") && typeof o12[n12] == "function" ? ((a15 = t11[n12]) != null || (t11[n12] = []), t11[n12].push(o12[n12])) : r13[n12] = o12[n12];
    if (r13.disabled || r13["aria-disabled"]) for (let o12 in t11) /^(on(?:Click|Pointer|Mouse|Key)(?:Down|Up|Press)?)$/.test(o12) && (t11[o12] = [(n12) => {
      var i12;
      return (i12 = n12 == null ? void 0 : n12.preventDefault) == null ? void 0 : i12.call(n12);
    }]);
    for (let o12 in t11) Object.assign(r13, { [o12](n12, ...i12) {
      let l10 = t11[o12];
      for (let s11 of l10) {
        if ((n12 instanceof Event || (n12 == null ? void 0 : n12.nativeEvent) instanceof Event) && n12.defaultPrevented) return;
        s11(n12, ...i12);
      }
    } });
    return r13;
  }
  function Y(e6) {
    var r13;
    return Object.assign((0, import_react9.forwardRef)(e6), { displayName: (r13 = e6.displayName) != null ? r13 : e6.name });
  }
  function m(e6) {
    let r13 = Object.assign({}, e6);
    for (let t11 in r13) r13[t11] === void 0 && delete r13[t11];
    return r13;
  }
  function h(e6, r13 = []) {
    let t11 = Object.assign({}, e6);
    for (let a15 of r13) a15 in t11 && delete t11[a15];
    return t11;
  }
  function D(e6) {
    return import_react9.default.version.split(".")[0] >= "19" ? e6.props.ref : e6.ref;
  }
  function E(e6) {
    if (e6 != null && e6.$$typeof === /* @__PURE__ */ Symbol.for("react.lazy")) {
      let r13 = e6._payload;
      if (r13 != null && r13.status === "fulfilled") return E(r13.value);
    }
    return e6;
  }
  function b(e6) {
    return e6 === import_react9.Fragment || e6 === /* @__PURE__ */ Symbol.for("react.fragment");
  }
  function L(e6) {
    return b(e6.type);
  }

  // node_modules/@headlessui/react/dist/hooks/use-id.js
  init_define_import_meta_env();
  var import_react10 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/internal/hidden.js
  init_define_import_meta_env();
  var a3 = "span";
  var s4 = ((e6) => (e6[e6.None = 1] = "None", e6[e6.Focusable = 2] = "Focusable", e6[e6.Hidden = 4] = "Hidden", e6))(s4 || {});
  function l2(t11, r13) {
    var n12;
    let { features: d8 = 1, ...e6 } = t11, o12 = { ref: r13, "aria-hidden": (d8 & 2) === 2 ? true : (n12 = e6["aria-hidden"]) != null ? n12 : void 0, hidden: (d8 & 4) === 4 ? true : void 0, style: { position: "fixed", top: 1, left: 1, width: 1, height: 0, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", borderWidth: "0", ...(d8 & 4) === 4 && (d8 & 2) !== 2 && { display: "none" } } };
    return K()({ ourProps: o12, theirProps: e6, slot: {}, defaultTag: a3, name: "Hidden" });
  }
  var f2 = Y(l2);

  // node_modules/@headlessui/react/dist/utils/dom.js
  init_define_import_meta_env();
  function o5(e6) {
    return typeof e6 != "object" || e6 === null ? false : "nodeType" in e6;
  }
  function t5(e6) {
    return o5(e6) && "tagName" in e6;
  }
  function n4(e6) {
    return t5(e6) && "accessKey" in e6;
  }
  function i3(e6) {
    return t5(e6) && "tabIndex" in e6;
  }
  function r5(e6) {
    return t5(e6) && "style" in e6;
  }
  function u2(e6) {
    return n4(e6) && e6.nodeName === "IFRAME";
  }
  function l3(e6) {
    return n4(e6) && e6.nodeName === "INPUT";
  }

  // node_modules/@headlessui/react/dist/components/description/description.js
  init_define_import_meta_env();
  var import_react12 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-sync-refs.js
  init_define_import_meta_env();
  var import_react11 = __toESM(require_react_shim(), 1);
  var u3 = /* @__PURE__ */ Symbol();
  function T(t11, n12 = true) {
    return Object.assign(t11, { [u3]: n12 });
  }
  function y(...t11) {
    let n12 = (0, import_react11.useRef)(t11);
    (0, import_react11.useEffect)(() => {
      n12.current = t11;
    }, [t11]);
    let c12 = o4((e6) => {
      for (let o12 of n12.current) o12 != null && (typeof o12 == "function" ? o12(e6) : o12.current = e6);
    });
    return t11.every((e6) => e6 == null || (e6 == null ? void 0 : e6[u3])) ? void 0 : c12;
  }

  // node_modules/@headlessui/react/dist/components/description/description.js
  var a4 = (0, import_react12.createContext)(null);
  a4.displayName = "DescriptionContext";
  function f3() {
    let r13 = (0, import_react12.useContext)(a4);
    if (r13 === null) {
      let e6 = new Error("You used a <Description /> component, but it is not inside a relevant parent.");
      throw Error.captureStackTrace && Error.captureStackTrace(e6, f3), e6;
    }
    return r13;
  }
  function H2() {
    let [r13, e6] = (0, import_react12.useState)([]);
    return [r13.length > 0 ? r13.join(" ") : void 0, (0, import_react12.useMemo)(() => function(t11) {
      let i12 = o4((n12) => (e6((o12) => [...o12, n12]), () => e6((o12) => {
        let s11 = o12.slice(), p6 = s11.indexOf(n12);
        return p6 !== -1 && s11.splice(p6, 1), s11;
      }))), l10 = (0, import_react12.useMemo)(() => ({ register: i12, slot: t11.slot, name: t11.name, props: t11.props, value: t11.value }), [i12, t11.slot, t11.name, t11.props, t11.value]);
      return import_react12.default.createElement(a4.Provider, { value: l10 }, t11.children);
    }, [e6])];
  }
  var I2 = "p";
  function C2(r13, e6) {
    let c12 = (0, import_react10.useId)(), t11 = a2(), { id: i12 = `headlessui-description-${c12}`, ...l10 } = r13, n12 = f3(), o12 = y(e6);
    n(() => n12.register(i12), [i12, n12.register]);
    let s11 = n2({ ...n12.slot, disabled: t11 || false }), p6 = { ref: o12, ...n12.props, id: i12 };
    return K()({ ourProps: p6, theirProps: l10, slot: s11, defaultTag: I2, name: n12.name || "Description" });
  }
  var _ = Y(C2);
  var M2 = Object.assign(_, {});

  // node_modules/@headlessui/react/dist/components/keyboard.js
  init_define_import_meta_env();
  var o6 = ((r13) => (r13.Space = " ", r13.Enter = "Enter", r13.Escape = "Escape", r13.Backspace = "Backspace", r13.Delete = "Delete", r13.ArrowLeft = "ArrowLeft", r13.ArrowUp = "ArrowUp", r13.ArrowRight = "ArrowRight", r13.ArrowDown = "ArrowDown", r13.Home = "Home", r13.End = "End", r13.PageUp = "PageUp", r13.PageDown = "PageDown", r13.Tab = "Tab", r13))(o6 || {});

  // node_modules/@headlessui/react/dist/internal/close-provider.js
  init_define_import_meta_env();
  var import_react13 = __toESM(require_react_shim(), 1);
  var e3 = (0, import_react13.createContext)(() => {
  });
  function C3({ value: t11, children: o12 }) {
    return import_react13.default.createElement(e3.Provider, { value: t11 }, o12);
  }

  // node_modules/@headlessui/react/dist/hooks/use-inert-others.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/hooks/use-is-top-layer.js
  init_define_import_meta_env();
  var import_react14 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/machines/stack-machine.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/machine.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/utils/default-map.js
  init_define_import_meta_env();
  var a5 = class extends Map {
    constructor(t11) {
      super();
      this.factory = t11;
    }
    get(t11) {
      let e6 = super.get(t11);
      return e6 === void 0 && (e6 = this.factory(t11), this.set(t11, e6)), e6;
    }
  };

  // node_modules/@headlessui/react/dist/machine.js
  var h2 = Object.defineProperty;
  var v2 = (t11, e6, r13) => e6 in t11 ? h2(t11, e6, { enumerable: true, configurable: true, writable: true, value: r13 }) : t11[e6] = r13;
  var S2 = (t11, e6, r13) => (v2(t11, typeof e6 != "symbol" ? e6 + "" : e6, r13), r13);
  var b2 = (t11, e6, r13) => {
    if (!e6.has(t11)) throw TypeError("Cannot " + r13);
  };
  var i6 = (t11, e6, r13) => (b2(t11, e6, "read from private field"), r13 ? r13.call(t11) : e6.get(t11));
  var c2 = (t11, e6, r13) => {
    if (e6.has(t11)) throw TypeError("Cannot add the same private member more than once");
    e6 instanceof WeakSet ? e6.add(t11) : e6.set(t11, r13);
  };
  var u5 = (t11, e6, r13, s11) => (b2(t11, e6, "write to private field"), s11 ? s11.call(t11, r13) : e6.set(t11, r13), r13);
  var n6;
  var a6;
  var o7;
  var T3 = class {
    constructor(e6) {
      c2(this, n6, {});
      c2(this, a6, new a5(() => /* @__PURE__ */ new Set()));
      c2(this, o7, /* @__PURE__ */ new Set());
      S2(this, "disposables", o2());
      u5(this, n6, e6), s.isServer && this.disposables.microTask(() => {
        this.dispose();
      });
    }
    dispose() {
      this.disposables.dispose();
    }
    get state() {
      return i6(this, n6);
    }
    subscribe(e6, r13) {
      if (s.isServer) return () => {
      };
      let s11 = { selector: e6, callback: r13, current: e6(i6(this, n6)) };
      return i6(this, o7).add(s11), this.disposables.add(() => {
        i6(this, o7).delete(s11);
      });
    }
    on(e6, r13) {
      return s.isServer ? () => {
      } : (i6(this, a6).get(e6).add(r13), this.disposables.add(() => {
        i6(this, a6).get(e6).delete(r13);
      }));
    }
    send(e6) {
      let r13 = this.reduce(i6(this, n6), e6);
      if (r13 !== i6(this, n6)) {
        u5(this, n6, r13);
        for (let s11 of i6(this, o7)) {
          let l10 = s11.selector(i6(this, n6));
          j2(s11.current, l10) || (s11.current = l10, s11.callback(l10));
        }
        for (let s11 of i6(this, a6).get(e6.type)) s11(i6(this, n6), e6);
      }
    }
  };
  n6 = /* @__PURE__ */ new WeakMap(), a6 = /* @__PURE__ */ new WeakMap(), o7 = /* @__PURE__ */ new WeakMap();
  function j2(t11, e6) {
    return Object.is(t11, e6) ? true : typeof t11 != "object" || t11 === null || typeof e6 != "object" || e6 === null ? false : Array.isArray(t11) && Array.isArray(e6) ? t11.length !== e6.length ? false : f4(t11[Symbol.iterator](), e6[Symbol.iterator]()) : t11 instanceof Map && e6 instanceof Map || t11 instanceof Set && e6 instanceof Set ? t11.size !== e6.size ? false : f4(t11.entries(), e6.entries()) : p2(t11) && p2(e6) ? f4(Object.entries(t11)[Symbol.iterator](), Object.entries(e6)[Symbol.iterator]()) : false;
  }
  function f4(t11, e6) {
    do {
      let r13 = t11.next(), s11 = e6.next();
      if (r13.done && s11.done) return true;
      if (r13.done || s11.done || !Object.is(r13.value, s11.value)) return false;
    } while (true);
  }
  function p2(t11) {
    if (Object.prototype.toString.call(t11) !== "[object Object]") return false;
    let e6 = Object.getPrototypeOf(t11);
    return e6 === null || Object.getPrototypeOf(e6) === null;
  }

  // node_modules/@headlessui/react/dist/machines/stack-machine.js
  var a7 = Object.defineProperty;
  var r7 = (e6, c12, t11) => c12 in e6 ? a7(e6, c12, { enumerable: true, configurable: true, writable: true, value: t11 }) : e6[c12] = t11;
  var p3 = (e6, c12, t11) => (r7(e6, typeof c12 != "symbol" ? c12 + "" : c12, t11), t11);
  var k2 = ((t11) => (t11[t11.Push = 0] = "Push", t11[t11.Pop = 1] = "Pop", t11))(k2 || {});
  var y2 = { [0](e6, c12) {
    let t11 = c12.id, s11 = e6.stack, i12 = e6.stack.indexOf(t11);
    if (i12 !== -1) {
      let n12 = e6.stack.slice();
      return n12.splice(i12, 1), n12.push(t11), s11 = n12, { ...e6, stack: s11 };
    }
    return { ...e6, stack: [...e6.stack, t11] };
  }, [1](e6, c12) {
    let t11 = c12.id, s11 = e6.stack.indexOf(t11);
    if (s11 === -1) return e6;
    let i12 = e6.stack.slice();
    return i12.splice(s11, 1), { ...e6, stack: i12 };
  } };
  var o8 = class _o extends T3 {
    constructor() {
      super(...arguments);
      p3(this, "actions", { push: (t11) => this.send({ type: 0, id: t11 }), pop: (t11) => this.send({ type: 1, id: t11 }) });
      p3(this, "selectors", { isTop: (t11, s11) => t11.stack[t11.stack.length - 1] === s11, inStack: (t11, s11) => t11.stack.includes(s11) });
    }
    static new() {
      return new _o({ stack: [] });
    }
    reduce(t11, s11) {
      return u(s11.type, y2, t11, s11);
    }
  };
  var x2 = new a5(() => o8.new());

  // node_modules/@headlessui/react/dist/react-glue.js
  init_define_import_meta_env();
  var import_with_selector = __toESM(require_with_selector(), 1);
  function S3(e6, n12, r13 = j2) {
    return (0, import_with_selector.useSyncExternalStoreWithSelector)(o4((i12) => e6.subscribe(s5, i12)), o4(() => e6.state), o4(() => e6.state), o4(n12), r13);
  }
  function s5(e6) {
    return e6;
  }

  // node_modules/@headlessui/react/dist/hooks/use-is-top-layer.js
  function I3(o12, s11) {
    let t11 = (0, import_react14.useId)(), r13 = x2.get(s11), [i12, c12] = S3(r13, (0, import_react14.useCallback)((e6) => [r13.selectors.isTop(e6, t11), r13.selectors.inStack(e6, t11)], [r13, t11]));
    return n(() => {
      if (o12) return r13.actions.push(t11), () => r13.actions.pop(t11);
    }, [r13, o12, t11]), o12 ? c12 ? i12 : true : false;
  }

  // node_modules/@headlessui/react/dist/hooks/use-inert-others.js
  var f5 = /* @__PURE__ */ new Map();
  var u7 = /* @__PURE__ */ new Map();
  function h3(t11) {
    var e6;
    let r13 = (e6 = u7.get(t11)) != null ? e6 : 0;
    return u7.set(t11, r13 + 1), r13 !== 0 ? () => m3(t11) : (f5.set(t11, { "aria-hidden": t11.getAttribute("aria-hidden"), inert: t11.inert }), t11.setAttribute("aria-hidden", "true"), t11.inert = true, () => m3(t11));
  }
  function m3(t11) {
    var i12;
    let r13 = (i12 = u7.get(t11)) != null ? i12 : 1;
    if (r13 === 1 ? u7.delete(t11) : u7.set(t11, r13 - 1), r13 !== 1) return;
    let e6 = f5.get(t11);
    e6 && (e6["aria-hidden"] === null ? t11.removeAttribute("aria-hidden") : t11.setAttribute("aria-hidden", e6["aria-hidden"]), t11.inert = e6.inert, f5.delete(t11));
  }
  function y3(t11, { allowed: r13, disallowed: e6 } = {}) {
    let i12 = I3(t11, "inert-others");
    n(() => {
      var d8, c12;
      if (!i12) return;
      let a15 = o2();
      for (let n12 of (d8 = e6 == null ? void 0 : e6()) != null ? d8 : []) n12 && a15.add(h3(n12));
      let s11 = (c12 = r13 == null ? void 0 : r13()) != null ? c12 : [];
      for (let n12 of s11) {
        if (!n12) continue;
        let l10 = l(n12);
        if (!l10) continue;
        let o12 = n12.parentElement;
        for (; o12 && o12 !== l10.body; ) {
          for (let p6 of o12.children) s11.some((E6) => p6.contains(E6)) || a15.add(h3(p6));
          o12 = o12.parentElement;
        }
      }
      return a15.dispose;
    }, [i12, r13, e6]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-on-disappear.js
  init_define_import_meta_env();
  var import_react15 = __toESM(require_react_shim(), 1);
  function p4(s11, n12, o12) {
    let i12 = s3((t11) => {
      let e6 = t11.getBoundingClientRect();
      e6.x === 0 && e6.y === 0 && e6.width === 0 && e6.height === 0 && o12();
    });
    (0, import_react15.useEffect)(() => {
      if (!s11) return;
      let t11 = n12 === null ? null : n4(n12) ? n12 : n12.current;
      if (!t11) return;
      let e6 = o2();
      if (typeof ResizeObserver != "undefined") {
        let r13 = new ResizeObserver(() => i12.current(t11));
        r13.observe(t11), e6.add(() => r13.disconnect());
      }
      if (typeof IntersectionObserver != "undefined") {
        let r13 = new IntersectionObserver(() => i12.current(t11));
        r13.observe(t11), e6.add(() => r13.disconnect());
      }
      return () => e6.dispose();
    }, [n12, i12, s11]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-outside-click.js
  init_define_import_meta_env();
  var import_react18 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/utils/focus-management.js
  init_define_import_meta_env();
  var E2 = ["[contentEditable=true]", "[tabindex]", "a[href]", "area[href]", "button:not([disabled])", "iframe", "input:not([disabled])", "select:not([disabled])", "details>summary", "textarea:not([disabled])"].map((e6) => `${e6}:not([tabindex='-1'])`).join(",");
  var S4 = ["[data-autofocus]"].map((e6) => `${e6}:not([tabindex='-1'])`).join(",");
  var T4 = ((o12) => (o12[o12.First = 1] = "First", o12[o12.Previous = 2] = "Previous", o12[o12.Next = 4] = "Next", o12[o12.Last = 8] = "Last", o12[o12.WrapAround = 16] = "WrapAround", o12[o12.NoScroll = 32] = "NoScroll", o12[o12.AutoFocus = 64] = "AutoFocus", o12))(T4 || {});
  var A2 = ((n12) => (n12[n12.Error = 0] = "Error", n12[n12.Overflow = 1] = "Overflow", n12[n12.Success = 2] = "Success", n12[n12.Underflow = 3] = "Underflow", n12))(A2 || {});
  var O2 = ((t11) => (t11[t11.Previous = -1] = "Previous", t11[t11.Next = 1] = "Next", t11))(O2 || {});
  function x3(e6 = document.body) {
    return e6 == null ? [] : Array.from(e6.querySelectorAll(E2)).sort((r13, t11) => Math.sign((r13.tabIndex || Number.MAX_SAFE_INTEGER) - (t11.tabIndex || Number.MAX_SAFE_INTEGER)));
  }
  function h4(e6 = document.body) {
    return e6 == null ? [] : Array.from(e6.querySelectorAll(S4)).sort((r13, t11) => Math.sign((r13.tabIndex || Number.MAX_SAFE_INTEGER) - (t11.tabIndex || Number.MAX_SAFE_INTEGER)));
  }
  var I4 = ((t11) => (t11[t11.Strict = 0] = "Strict", t11[t11.Loose = 1] = "Loose", t11))(I4 || {});
  function H3(e6, r13 = 0) {
    var t11;
    return e6 === ((t11 = l(e6)) == null ? void 0 : t11.body) ? false : u(r13, { [0]() {
      return e6.matches(E2);
    }, [1]() {
      let l10 = e6;
      for (; l10 !== null; ) {
        if (l10.matches(E2)) return true;
        l10 = l10.parentElement;
      }
      return false;
    } });
  }
  var g = ((t11) => (t11[t11.Keyboard = 0] = "Keyboard", t11[t11.Mouse = 1] = "Mouse", t11))(g || {});
  typeof window != "undefined" && typeof document != "undefined" && (document.addEventListener("keydown", (e6) => {
    e6.metaKey || e6.altKey || e6.ctrlKey || (document.documentElement.dataset.headlessuiFocusVisible = "");
  }, true), document.addEventListener("click", (e6) => {
    e6.detail === 1 ? delete document.documentElement.dataset.headlessuiFocusVisible : e6.detail === 0 && (document.documentElement.dataset.headlessuiFocusVisible = "");
  }, true));
  function w2(e6) {
    e6 == null || e6.focus({ preventScroll: true });
  }
  var _2 = ["textarea", "input"].join(",");
  function P2(e6) {
    var r13, t11;
    return (t11 = (r13 = e6 == null ? void 0 : e6.matches) == null ? void 0 : r13.call(e6, _2)) != null ? t11 : false;
  }
  function G(e6, r13 = (t11) => t11) {
    return e6.slice().sort((t11, l10) => {
      let n12 = r13(t11), a15 = r13(l10);
      if (n12 === null || a15 === null) return 0;
      let u12 = n12.compareDocumentPosition(a15);
      return u12 & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : u12 & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
    });
  }
  function v3(e6, r13, { sorted: t11 = true, relativeTo: l10 = null, skipElements: n12 = [] } = {}) {
    let a15 = Array.isArray(e6) ? e6.length > 0 ? r2(e6[0]) : document : r2(e6), u12 = Array.isArray(e6) ? t11 ? G(e6) : e6 : r13 & 64 ? h4(e6) : x3(e6);
    n12.length > 0 && u12.length > 1 && (u12 = u12.filter((i12) => !n12.some((d8) => d8 != null && "current" in d8 ? (d8 == null ? void 0 : d8.current) === i12 : d8 === i12))), l10 = l10 != null ? l10 : a15 == null ? void 0 : a15.activeElement;
    let o12 = (() => {
      if (r13 & 5) return 1;
      if (r13 & 10) return -1;
      throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
    })(), M6 = (() => {
      if (r13 & 1) return 0;
      if (r13 & 2) return Math.max(0, u12.indexOf(l10)) - 1;
      if (r13 & 4) return Math.max(0, u12.indexOf(l10)) + 1;
      if (r13 & 8) return u12.length - 1;
      throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
    })(), N2 = r13 & 32 ? { preventScroll: true } : {}, m6 = 0, c12 = u12.length, s11;
    do {
      if (m6 >= c12 || m6 + c12 <= 0) return 0;
      let i12 = M6 + m6;
      if (r13 & 16) i12 = (i12 + c12) % c12;
      else {
        if (i12 < 0) return 3;
        if (i12 >= c12) return 1;
      }
      s11 = u12[i12], s11 == null || s11.focus(N2), m6 += o12;
    } while (s11 !== e(s11));
    return r13 & 6 && P2(s11) && s11.select(), 2;
  }

  // node_modules/@headlessui/react/dist/utils/platform.js
  init_define_import_meta_env();
  function t6() {
    return /iPhone/gi.test(window.navigator.platform) || /Mac/gi.test(window.navigator.platform) && window.navigator.maxTouchPoints > 0;
  }
  function i7() {
    return /Android/gi.test(window.navigator.userAgent);
  }
  function n8() {
    return t6() || i7();
  }

  // node_modules/@headlessui/react/dist/hooks/use-document-event.js
  init_define_import_meta_env();
  var import_react16 = __toESM(require_react_shim(), 1);
  function i8(t11, e6, o12, n12) {
    let u12 = s3(o12);
    (0, import_react16.useEffect)(() => {
      if (!t11) return;
      function r13(m6) {
        u12.current(m6);
      }
      return document.addEventListener(e6, r13, n12), () => document.removeEventListener(e6, r13, n12);
    }, [t11, e6, n12]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-window-event.js
  init_define_import_meta_env();
  var import_react17 = __toESM(require_react_shim(), 1);
  function s6(t11, e6, o12, n12) {
    let i12 = s3(o12);
    (0, import_react17.useEffect)(() => {
      if (!t11) return;
      function r13(d8) {
        i12.current(d8);
      }
      return window.addEventListener(e6, r13, n12), () => window.removeEventListener(e6, r13, n12);
    }, [t11, e6, n12]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-outside-click.js
  var C4 = 30;
  function k3(o12, f11, h6) {
    let m6 = s3(h6), s11 = (0, import_react18.useCallback)(function(e6, c12) {
      if (e6.defaultPrevented) return;
      let r13 = c12(e6);
      if (r13 === null || !r13.getRootNode().contains(r13) || !r13.isConnected) return;
      let M6 = (function u12(n12) {
        return typeof n12 == "function" ? u12(n12()) : Array.isArray(n12) || n12 instanceof Set ? n12 : [n12];
      })(f11);
      for (let u12 of M6) if (u12 !== null && (u12.contains(r13) || e6.composed && e6.composedPath().includes(u12))) return;
      return !H3(r13, I4.Loose) && r13.tabIndex !== -1 && e6.preventDefault(), m6.current(e6, r13);
    }, [m6, f11]), i12 = (0, import_react18.useRef)(null);
    i8(o12, "pointerdown", (t11) => {
      var e6, c12;
      n8() || (i12.current = ((c12 = (e6 = t11.composedPath) == null ? void 0 : e6.call(t11)) == null ? void 0 : c12[0]) || t11.target);
    }, true), i8(o12, "pointerup", (t11) => {
      if (n8() || !i12.current) return;
      let e6 = i12.current;
      return i12.current = null, s11(t11, () => e6);
    }, true);
    let l10 = (0, import_react18.useRef)({ x: 0, y: 0 });
    i8(o12, "touchstart", (t11) => {
      l10.current.x = t11.touches[0].clientX, l10.current.y = t11.touches[0].clientY;
    }, true), i8(o12, "touchend", (t11) => {
      let e6 = { x: t11.changedTouches[0].clientX, y: t11.changedTouches[0].clientY };
      if (!(Math.abs(e6.x - l10.current.x) >= C4 || Math.abs(e6.y - l10.current.y) >= C4)) return s11(t11, () => i3(t11.target) ? t11.target : null);
    }, true), s6(o12, "blur", (t11) => s11(t11, () => u2(window.document.activeElement) ? window.document.activeElement : null), true);
  }

  // node_modules/@headlessui/react/dist/hooks/use-owner.js
  init_define_import_meta_env();
  var import_react19 = __toESM(require_react_shim(), 1);
  function u8(...e6) {
    return (0, import_react19.useMemo)(() => l(...e6), [...e6]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-event-listener.js
  init_define_import_meta_env();
  var import_react20 = __toESM(require_react_shim(), 1);
  function E4(n12, e6, a15, t11) {
    let i12 = s3(a15);
    (0, import_react20.useEffect)(() => {
      n12 = n12 != null ? n12 : window;
      function r13(o12) {
        i12.current(o12);
      }
      return n12.addEventListener(e6, r13, t11), () => n12.removeEventListener(e6, r13, t11);
    }, [n12, e6, t11]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-scroll-lock.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/hooks/document-overflow/use-document-overflow.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/hooks/use-store.js
  init_define_import_meta_env();
  var import_react21 = __toESM(require_react_shim(), 1);
  function o10(t11) {
    return (0, import_react21.useSyncExternalStore)(t11.subscribe, t11.getSnapshot, t11.getSnapshot);
  }

  // node_modules/@headlessui/react/dist/hooks/document-overflow/overflow-store.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/utils/store.js
  init_define_import_meta_env();
  function a10(o12, r13) {
    let t11 = o12(), n12 = /* @__PURE__ */ new Set();
    return { getSnapshot() {
      return t11;
    }, subscribe(e6) {
      return n12.add(e6), () => n12.delete(e6);
    }, dispatch(e6, ...s11) {
      let i12 = r13[e6].call(t11, ...s11);
      i12 && (t11 = i12, n12.forEach((c12) => c12()));
    } };
  }

  // node_modules/@headlessui/react/dist/hooks/document-overflow/adjust-scrollbar-padding.js
  init_define_import_meta_env();
  function d5() {
    let r13;
    return { before({ doc: e6 }) {
      var l10;
      let o12 = e6.documentElement, t11 = (l10 = e6.defaultView) != null ? l10 : window;
      r13 = Math.max(0, t11.innerWidth - o12.clientWidth);
    }, after({ doc: e6, d: o12 }) {
      let t11 = e6.documentElement, l10 = Math.max(0, t11.clientWidth - t11.offsetWidth), n12 = Math.max(0, r13 - l10);
      o12.style(t11, "paddingRight", `${n12}px`);
    } };
  }

  // node_modules/@headlessui/react/dist/hooks/document-overflow/handle-ios-locking.js
  init_define_import_meta_env();
  function w3() {
    return t6() ? { before({ doc: o12, d: r13, meta: m6 }) {
      function a15(s11) {
        for (let l10 of m6().containers) for (let c12 of l10()) if (c12.contains(s11)) return true;
        return false;
      }
      r13.microTask(() => {
        var c12;
        if (window.getComputedStyle(o12.documentElement).scrollBehavior !== "auto") {
          let t11 = o2();
          t11.style(o12.documentElement, "scrollBehavior", "auto"), r13.add(() => r13.microTask(() => t11.dispose()));
        }
        let s11 = (c12 = window.scrollY) != null ? c12 : window.pageYOffset, l10 = null;
        r13.addEventListener(o12, "click", (t11) => {
          if (i3(t11.target)) try {
            let e6 = t11.target.closest("a");
            if (!e6) return;
            let { hash: n12 } = new URL(e6.href), f11 = o12.querySelector(n12);
            i3(f11) && !a15(f11) && (l10 = f11);
          } catch {
          }
        }, true), r13.group((t11) => {
          r13.addEventListener(o12, "touchstart", (e6) => {
            if (t11.dispose(), i3(e6.target) && r5(e6.target)) if (a15(e6.target)) {
              let n12 = e6.target;
              for (; n12.parentElement && a15(n12.parentElement); ) n12 = n12.parentElement;
              t11.style(n12, "overscrollBehavior", "contain");
            } else t11.style(e6.target, "touchAction", "none");
          });
        }), r13.addEventListener(o12, "touchmove", (t11) => {
          if (i3(t11.target)) {
            if (l3(t11.target)) return;
            if (a15(t11.target)) {
              let e6 = t11.target;
              for (; e6.parentElement && e6.dataset.headlessuiPortal !== "" && !(e6.scrollHeight > e6.clientHeight || e6.scrollWidth > e6.clientWidth); ) e6 = e6.parentElement;
              e6.dataset.headlessuiPortal === "" && t11.preventDefault();
            } else t11.preventDefault();
          }
        }, { passive: false }), r13.add(() => {
          var e6;
          let t11 = (e6 = window.scrollY) != null ? e6 : window.pageYOffset;
          s11 !== t11 && window.scrollTo(0, s11), l10 && l10.isConnected && (l10.scrollIntoView({ block: "nearest" }), l10 = null);
        });
      });
    } } : {};
  }

  // node_modules/@headlessui/react/dist/hooks/document-overflow/prevent-scroll.js
  init_define_import_meta_env();
  function r8() {
    return { before({ doc: e6, d: o12 }) {
      o12.style(e6.documentElement, "overflow", "hidden");
    } };
  }

  // node_modules/@headlessui/react/dist/hooks/document-overflow/overflow-store.js
  function r9(e6) {
    let o12 = {};
    for (let t11 of e6) Object.assign(o12, t11(o12));
    return o12;
  }
  var c4 = a10(() => /* @__PURE__ */ new Map(), { PUSH(e6, o12) {
    var n12;
    let t11 = (n12 = this.get(e6)) != null ? n12 : { doc: e6, count: 0, d: o2(), meta: /* @__PURE__ */ new Set(), computedMeta: {} };
    return t11.count++, t11.meta.add(o12), t11.computedMeta = r9(t11.meta), this.set(e6, t11), this;
  }, POP(e6, o12) {
    let t11 = this.get(e6);
    return t11 && (t11.count--, t11.meta.delete(o12), t11.computedMeta = r9(t11.meta)), this;
  }, SCROLL_PREVENT(e6) {
    let o12 = { doc: e6.doc, d: e6.d, meta() {
      return e6.computedMeta;
    } }, t11 = [w3(), d5(), r8()];
    t11.forEach(({ before: n12 }) => n12 == null ? void 0 : n12(o12)), t11.forEach(({ after: n12 }) => n12 == null ? void 0 : n12(o12));
  }, SCROLL_ALLOW({ d: e6 }) {
    e6.dispose();
  }, TEARDOWN({ doc: e6 }) {
    this.delete(e6);
  } });
  c4.subscribe(() => {
    let e6 = c4.getSnapshot(), o12 = /* @__PURE__ */ new Map();
    for (let [t11] of e6) o12.set(t11, t11.documentElement.style.overflow);
    for (let t11 of e6.values()) {
      let n12 = o12.get(t11.doc) === "hidden", a15 = t11.count !== 0;
      (a15 && !n12 || !a15 && n12) && c4.dispatch(t11.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", t11), t11.count === 0 && c4.dispatch("TEARDOWN", t11);
    }
  });

  // node_modules/@headlessui/react/dist/hooks/document-overflow/use-document-overflow.js
  function a11(r13, e6, n12 = () => ({ containers: [] })) {
    let f11 = o10(c4), o12 = e6 ? f11.get(e6) : void 0, i12 = o12 ? o12.count > 0 : false;
    return n(() => {
      if (!(!e6 || !r13)) return c4.dispatch("PUSH", e6, n12), () => c4.dispatch("POP", e6, n12);
    }, [r13, e6]), i12;
  }

  // node_modules/@headlessui/react/dist/hooks/use-scroll-lock.js
  function f6(e6, c12, n12 = () => [document.body]) {
    let r13 = I3(e6, "scroll-lock");
    a11(r13, c12, (t11) => {
      var o12;
      return { containers: [...(o12 = t11.containers) != null ? o12 : [], n12] };
    });
  }

  // node_modules/@headlessui/react/dist/hooks/use-transition.js
  init_define_import_meta_env();
  var import_react23 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-flags.js
  init_define_import_meta_env();
  var import_react22 = __toESM(require_react_shim(), 1);
  function c5(u12 = 0) {
    let [r13, a15] = (0, import_react22.useState)(u12), g2 = (0, import_react22.useCallback)((e6) => a15(e6), []), s11 = (0, import_react22.useCallback)((e6) => a15((l10) => l10 | e6), []), m6 = (0, import_react22.useCallback)((e6) => (r13 & e6) === e6, [r13]), n12 = (0, import_react22.useCallback)((e6) => a15((l10) => l10 & ~e6), []), F3 = (0, import_react22.useCallback)((e6) => a15((l10) => l10 ^ e6), []);
    return { flags: r13, setFlag: g2, addFlag: s11, hasFlag: m6, removeFlag: n12, toggleFlag: F3 };
  }

  // node_modules/@headlessui/react/dist/hooks/use-transition.js
  var T6;
  var S5;
  typeof process != "undefined" && typeof globalThis != "undefined" && typeof Element != "undefined" && ((T6 = process == null ? void 0 : process.env) == null ? void 0 : T6["NODE_ENV"]) === "test" && typeof ((S5 = Element == null ? void 0 : Element.prototype) == null ? void 0 : S5.getAnimations) == "undefined" && (Element.prototype.getAnimations = function() {
    return console.warn(["Headless UI has polyfilled `Element.prototype.getAnimations` for your tests.", "Please install a proper polyfill e.g. `jsdom-testing-mocks`, to silence these warnings.", "", "Example usage:", "```js", "import { mockAnimationsApi } from 'jsdom-testing-mocks'", "mockAnimationsApi()", "```"].join(`
`)), [];
  });
  var A3 = ((i12) => (i12[i12.None = 0] = "None", i12[i12.Closed = 1] = "Closed", i12[i12.Enter = 2] = "Enter", i12[i12.Leave = 4] = "Leave", i12))(A3 || {});
  function x4(e6) {
    let r13 = {};
    for (let t11 in e6) e6[t11] === true && (r13[`data-${t11}`] = "");
    return r13;
  }
  function N(e6, r13, t11, n12) {
    let [i12, a15] = (0, import_react23.useState)(t11), { hasFlag: s11, addFlag: o12, removeFlag: l10 } = c5(e6 && i12 ? 3 : 0), u12 = (0, import_react23.useRef)(false), f11 = (0, import_react23.useRef)(false), E6 = p();
    return n(() => {
      var d8;
      if (e6) {
        if (t11 && a15(true), !r13) {
          t11 && o12(3);
          return;
        }
        return (d8 = n12 == null ? void 0 : n12.start) == null || d8.call(n12, t11), C5(r13, { inFlight: u12, prepare() {
          f11.current ? f11.current = false : f11.current = u12.current, u12.current = true, !f11.current && (t11 ? (o12(3), l10(4)) : (o12(4), l10(2)));
        }, run() {
          f11.current ? t11 ? (l10(3), o12(4)) : (l10(4), o12(3)) : t11 ? l10(1) : o12(1);
        }, done() {
          var p6;
          f11.current && D3(r13) || (u12.current = false, l10(7), t11 || a15(false), (p6 = n12 == null ? void 0 : n12.end) == null || p6.call(n12, t11));
        } });
      }
    }, [e6, t11, r13, E6]), e6 ? [i12, { closed: s11(1), enter: s11(2), leave: s11(4), transition: s11(2) || s11(4) }] : [t11, { closed: void 0, enter: void 0, leave: void 0, transition: void 0 }];
  }
  function C5(e6, { prepare: r13, run: t11, done: n12, inFlight: i12 }) {
    let a15 = o2();
    return j3(e6, { prepare: r13, inFlight: i12 }), a15.nextFrame(() => {
      t11(), a15.requestAnimationFrame(() => {
        a15.add(M3(e6, n12));
      });
    }), a15.dispose;
  }
  function M3(e6, r13) {
    var a15, s11;
    let t11 = o2();
    if (!e6) return t11.dispose;
    let n12 = false;
    t11.add(() => {
      n12 = true;
    });
    let i12 = (s11 = (a15 = e6.getAnimations) == null ? void 0 : a15.call(e6).filter((o12) => o12 instanceof CSSTransition)) != null ? s11 : [];
    return i12.length === 0 ? (r13(), t11.dispose) : (Promise.allSettled(i12.map((o12) => o12.finished)).then(() => {
      n12 || r13();
    }), t11.dispose);
  }
  function j3(e6, { inFlight: r13, prepare: t11 }) {
    if (r13 != null && r13.current) {
      t11();
      return;
    }
    let n12 = e6.style.transition;
    e6.style.transition = "none", t11(), e6.offsetHeight, e6.style.transition = n12;
  }
  function D3(e6) {
    var t11, n12;
    return ((n12 = (t11 = e6.getAnimations) == null ? void 0 : t11.call(e6)) != null ? n12 : []).some((i12) => i12 instanceof CSSTransition && i12.playState !== "finished");
  }

  // node_modules/@headlessui/react/dist/hooks/use-watch.js
  init_define_import_meta_env();
  var import_react24 = __toESM(require_react_shim(), 1);
  function m4(u12, t11) {
    let e6 = (0, import_react24.useRef)([]), r13 = o4(u12);
    (0, import_react24.useEffect)(() => {
      let o12 = [...e6.current];
      for (let [a15, l10] of t11.entries()) if (e6.current[a15] !== l10) {
        let n12 = r13(t11, o12);
        return e6.current = t11, n12;
      }
    }, [r13, ...t11]);
  }

  // node_modules/@headlessui/react/dist/internal/open-closed.js
  init_define_import_meta_env();
  var import_react25 = __toESM(require_react_shim(), 1);
  var n9 = (0, import_react25.createContext)(null);
  n9.displayName = "OpenClosedContext";
  var i9 = ((e6) => (e6[e6.Open = 1] = "Open", e6[e6.Closed = 2] = "Closed", e6[e6.Closing = 4] = "Closing", e6[e6.Opening = 8] = "Opening", e6))(i9 || {});
  function u9() {
    return (0, import_react25.useContext)(n9);
  }
  function c7({ value: o12, children: t11 }) {
    return import_react25.default.createElement(n9.Provider, { value: o12 }, t11);
  }
  function s8({ children: o12 }) {
    return import_react25.default.createElement(n9.Provider, { value: null }, o12);
  }

  // node_modules/@headlessui/react/dist/utils/active-element-history.js
  init_define_import_meta_env();

  // node_modules/@headlessui/react/dist/utils/document-ready.js
  init_define_import_meta_env();
  function t8(n12) {
    function e6() {
      document.readyState !== "loading" && (n12(), document.removeEventListener("DOMContentLoaded", e6));
    }
    typeof window != "undefined" && typeof document != "undefined" && (document.addEventListener("DOMContentLoaded", e6), e6());
  }

  // node_modules/@headlessui/react/dist/utils/active-element-history.js
  var n10 = [];
  t8(() => {
    function e6(t11) {
      if (!i3(t11.target) || t11.target === document.body || n10[0] === t11.target) return;
      let r13 = t11.target;
      r13 = r13.closest(E2), n10.unshift(r13 != null ? r13 : t11.target), n10 = n10.filter((o12) => o12 != null && o12.isConnected), n10.splice(10);
    }
    window.addEventListener("click", e6, { capture: true }), window.addEventListener("mousedown", e6, { capture: true }), window.addEventListener("focus", e6, { capture: true }), document.body.addEventListener("click", e6, { capture: true }), document.body.addEventListener("mousedown", e6, { capture: true }), document.body.addEventListener("focus", e6, { capture: true });
  });

  // node_modules/@headlessui/react/dist/components/portal/portal.js
  init_define_import_meta_env();
  var import_react28 = __toESM(require_react_shim(), 1);
  var import_react_dom = __toESM(require_react_dom_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-on-unmount.js
  init_define_import_meta_env();
  var import_react26 = __toESM(require_react_shim(), 1);
  function c8(t11) {
    let r13 = o4(t11), e6 = (0, import_react26.useRef)(false);
    (0, import_react26.useEffect)(() => (e6.current = false, () => {
      e6.current = true, t(() => {
        e6.current && r13();
      });
    }), [r13]);
  }

  // node_modules/@headlessui/react/dist/hooks/use-server-handoff-complete.js
  init_define_import_meta_env();
  var t9 = __toESM(require_react_shim(), 1);
  function s9() {
    let r13 = typeof document == "undefined";
    return "useSyncExternalStore" in t9 ? ((o12) => o12.useSyncExternalStore)(t9)(() => () => {
    }, () => false, () => !r13) : false;
  }
  function l7() {
    let r13 = s9(), [e6, n12] = t9.useState(s.isHandoffComplete);
    return e6 && s.isHandoffComplete === false && n12(false), t9.useEffect(() => {
      e6 !== true && n12(true);
    }, [e6]), t9.useEffect(() => s.handoff(), []), r13 ? false : e6;
  }

  // node_modules/@headlessui/react/dist/internal/portal-force-root.js
  init_define_import_meta_env();
  var import_react27 = __toESM(require_react_shim(), 1);
  var e5 = (0, import_react27.createContext)(false);
  function a12() {
    return (0, import_react27.useContext)(e5);
  }
  function l8(o12) {
    return import_react27.default.createElement(e5.Provider, { value: o12.force }, o12.children);
  }

  // node_modules/@headlessui/react/dist/components/portal/portal.js
  function j4(e6) {
    let o12 = a12(), l10 = (0, import_react28.useContext)(c10), [r13, p6] = (0, import_react28.useState)(() => {
      var s11;
      if (!o12 && l10 !== null) return (s11 = l10.current) != null ? s11 : null;
      if (s.isServer) return null;
      let t11 = e6 == null ? void 0 : e6.getElementById("headlessui-portal-root");
      if (t11) return t11;
      if (e6 === null) return null;
      let n12 = e6.createElement("div");
      return n12.setAttribute("id", "headlessui-portal-root"), e6.body.appendChild(n12);
    });
    return (0, import_react28.useEffect)(() => {
      r13 !== null && (e6 != null && e6.body.contains(r13) || e6 == null || e6.body.appendChild(r13));
    }, [r13, e6]), (0, import_react28.useEffect)(() => {
      o12 || l10 !== null && p6(l10.current);
    }, [l10, p6, o12]), r13;
  }
  var _3 = import_react28.Fragment;
  var I5 = Y(function(o12, l10) {
    let { ownerDocument: r13 = null, ...p6 } = o12, t11 = (0, import_react28.useRef)(null), n12 = y(T((a15) => {
      t11.current = a15;
    }), l10), s11 = u8(t11.current), C6 = r13 != null ? r13 : s11, u12 = j4(C6), y4 = (0, import_react28.useContext)(m5), g2 = p(), v4 = l7(), M6 = K();
    return c8(() => {
      var a15;
      u12 && u12.childNodes.length <= 0 && ((a15 = u12.parentElement) == null || a15.removeChild(u12));
    }), !u12 || !v4 ? null : (0, import_react_dom.createPortal)(import_react28.default.createElement("div", { "data-headlessui-portal": "", ref: (a15) => {
      g2.dispose(), y4 && a15 && g2.add(y4.register(a15));
    } }, M6({ ourProps: { ref: n12 }, theirProps: p6, slot: {}, defaultTag: _3, name: "Portal" })), u12);
  });
  function D4(e6, o12) {
    let l10 = y(o12), { enabled: r13 = true, ownerDocument: p6, ...t11 } = e6, n12 = K();
    return r13 ? import_react28.default.createElement(I5, { ...t11, ownerDocument: p6, ref: l10 }) : n12({ ourProps: { ref: l10 }, theirProps: t11, slot: {}, defaultTag: _3, name: "Portal" });
  }
  var J = import_react28.Fragment;
  var c10 = (0, import_react28.createContext)(null);
  function X(e6, o12) {
    let { target: l10, ...r13 } = e6, t11 = { ref: y(o12) }, n12 = K();
    return import_react28.default.createElement(c10.Provider, { value: l10 }, n12({ ourProps: t11, theirProps: r13, defaultTag: J, name: "Popover.Group" }));
  }
  var m5 = (0, import_react28.createContext)(null);
  function oe() {
    let e6 = (0, import_react28.useContext)(m5), o12 = (0, import_react28.useRef)([]), l10 = o4((t11) => (o12.current.push(t11), e6 && e6.register(t11), () => r13(t11))), r13 = o4((t11) => {
      let n12 = o12.current.indexOf(t11);
      n12 !== -1 && o12.current.splice(n12, 1), e6 && e6.unregister(t11);
    }), p6 = (0, import_react28.useMemo)(() => ({ register: l10, unregister: r13, portals: o12 }), [l10, r13, o12]);
    return [o12, (0, import_react28.useMemo)(() => function({ children: n12 }) {
      return import_react28.default.createElement(m5.Provider, { value: p6 }, n12);
    }, [p6])];
  }
  var k4 = Y(D4);
  var B = Y(X);
  var le = Object.assign(k4, { Group: B });

  // node_modules/@headlessui/react/dist/components/dialog/dialog.js
  init_define_import_meta_env();
  var import_react35 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-escape.js
  init_define_import_meta_env();
  function a13(o12, r13 = typeof document != "undefined" ? document.defaultView : null, t11) {
    let n12 = I3(o12, "escape");
    E4(r13, "keydown", (e6) => {
      n12 && (e6.defaultPrevented || e6.key === o6.Escape && t11(e6));
    });
  }

  // node_modules/@headlessui/react/dist/hooks/use-is-touch-device.js
  init_define_import_meta_env();
  var import_react29 = __toESM(require_react_shim(), 1);
  function f9() {
    var t11;
    let [e6] = (0, import_react29.useState)(() => typeof window != "undefined" && typeof window.matchMedia == "function" ? window.matchMedia("(pointer: coarse)") : null), [o12, c12] = (0, import_react29.useState)((t11 = e6 == null ? void 0 : e6.matches) != null ? t11 : false);
    return n(() => {
      if (!e6) return;
      function n12(r13) {
        c12(r13.matches);
      }
      return e6.addEventListener("change", n12), () => e6.removeEventListener("change", n12);
    }, [e6]), o12;
  }

  // node_modules/@headlessui/react/dist/hooks/use-root-containers.js
  init_define_import_meta_env();
  var import_react30 = __toESM(require_react_shim(), 1);
  function S6({ defaultContainers: l10 = [], portals: n12, mainTreeNode: o12 } = {}) {
    let c12 = o4(() => {
      var r13, u12;
      let i12 = l(o12), t11 = [];
      for (let e6 of l10) e6 !== null && (t5(e6) ? t11.push(e6) : "current" in e6 && t5(e6.current) && t11.push(e6.current));
      if (n12 != null && n12.current) for (let e6 of n12.current) t11.push(e6);
      for (let e6 of (r13 = i12 == null ? void 0 : i12.querySelectorAll("html > *, body > *")) != null ? r13 : []) e6 !== document.body && e6 !== document.head && t5(e6) && e6.id !== "headlessui-portal-root" && (o12 && (e6.contains(o12) || e6.contains((u12 = o12 == null ? void 0 : o12.getRootNode()) == null ? void 0 : u12.host)) || t11.some((E6) => e6.contains(E6)) || t11.push(e6));
      return t11;
    });
    return { resolveContainers: c12, contains: o4((i12) => c12().some((t11) => t11.contains(i12))) };
  }
  var d7 = (0, import_react30.createContext)(null);
  function j5({ children: l10, node: n12 }) {
    let [o12, c12] = (0, import_react30.useState)(null), i12 = x6(n12 != null ? n12 : o12);
    return import_react30.default.createElement(d7.Provider, { value: i12 }, l10, i12 === null && import_react30.default.createElement(f2, { features: s4.Hidden, ref: (t11) => {
      var r13, u12;
      if (t11) {
        for (let e6 of (u12 = (r13 = l(t11)) == null ? void 0 : r13.querySelectorAll("html > *, body > *")) != null ? u12 : []) if (e6 !== document.body && e6 !== document.head && t5(e6) && e6 != null && e6.contains(t11)) {
          c12(e6);
          break;
        }
      }
    } }));
  }
  function x6(l10 = null) {
    var n12;
    return (n12 = (0, import_react30.useContext)(d7)) != null ? n12 : l10;
  }

  // node_modules/@headlessui/react/dist/components/focus-trap/focus-trap.js
  init_define_import_meta_env();
  var import_react33 = __toESM(require_react_shim(), 1);

  // node_modules/@headlessui/react/dist/hooks/use-is-mounted.js
  init_define_import_meta_env();
  var import_react31 = __toESM(require_react_shim(), 1);
  function f10() {
    let e6 = (0, import_react31.useRef)(false);
    return n(() => (e6.current = true, () => {
      e6.current = false;
    }), []), e6;
  }

  // node_modules/@headlessui/react/dist/hooks/use-tab-direction.js
  init_define_import_meta_env();
  var import_react32 = __toESM(require_react_shim(), 1);
  var a14 = ((r13) => (r13[r13.Forwards = 0] = "Forwards", r13[r13.Backwards = 1] = "Backwards", r13))(a14 || {});
  function u11() {
    let e6 = (0, import_react32.useRef)(0);
    return s6(true, "keydown", (r13) => {
      r13.key === "Tab" && (e6.current = r13.shiftKey ? 1 : 0);
    }, true), e6;
  }

  // node_modules/@headlessui/react/dist/components/focus-trap/focus-trap.js
  function x7(o12) {
    if (!o12) return /* @__PURE__ */ new Set();
    if (typeof o12 == "function") return new Set(o12());
    let t11 = /* @__PURE__ */ new Set();
    for (let e6 of o12.current) t5(e6.current) && t11.add(e6.current);
    return t11;
  }
  var $ = "div";
  var G3 = ((n12) => (n12[n12.None = 0] = "None", n12[n12.InitialFocus = 1] = "InitialFocus", n12[n12.TabLock = 2] = "TabLock", n12[n12.FocusLock = 4] = "FocusLock", n12[n12.RestoreFocus = 8] = "RestoreFocus", n12[n12.AutoFocus = 16] = "AutoFocus", n12))(G3 || {});
  function w4(o12, t11) {
    let e6 = (0, import_react33.useRef)(null), r13 = y(e6, t11), { initialFocus: u12, initialFocusFallback: a15, containers: n12, features: s11 = 15, ...f11 } = o12;
    l7() || (s11 = 0);
    let l10 = u8(e6.current);
    re(s11, { ownerDocument: l10 });
    let T7 = ne(s11, { ownerDocument: l10, container: e6, initialFocus: u12, initialFocusFallback: a15 });
    oe2(s11, { ownerDocument: l10, container: e6, containers: n12, previousActiveElement: T7 });
    let g2 = u11(), A5 = o4((c12) => {
      if (!n4(e6.current)) return;
      let E6 = e6.current;
      ((V2) => V2())(() => {
        u(g2.current, { [a14.Forwards]: () => {
          v3(E6, T4.First, { skipElements: [c12.relatedTarget, a15] });
        }, [a14.Backwards]: () => {
          v3(E6, T4.Last, { skipElements: [c12.relatedTarget, a15] });
        } });
      });
    }), v4 = I3(!!(s11 & 2), "focus-trap#tab-lock"), N2 = p(), b8 = (0, import_react33.useRef)(false), k6 = { ref: r13, onKeyDown(c12) {
      c12.key == "Tab" && (b8.current = true, N2.requestAnimationFrame(() => {
        b8.current = false;
      }));
    }, onBlur(c12) {
      if (!(s11 & 4)) return;
      let E6 = x7(n12);
      n4(e6.current) && E6.add(e6.current);
      let L2 = c12.relatedTarget;
      i3(L2) && L2.dataset.headlessuiFocusGuard !== "true" && (I6(E6, L2) || (b8.current ? v3(e6.current, u(g2.current, { [a14.Forwards]: () => T4.Next, [a14.Backwards]: () => T4.Previous }) | T4.WrapAround, { relativeTo: c12.target }) : i3(c12.target) && w2(c12.target)));
    } }, B2 = K();
    return import_react33.default.createElement(import_react33.default.Fragment, null, v4 && import_react33.default.createElement(f2, { as: "button", type: "button", "data-headlessui-focus-guard": true, onFocus: A5, features: s4.Focusable }), B2({ ourProps: k6, theirProps: f11, defaultTag: $, name: "FocusTrap" }), v4 && import_react33.default.createElement(f2, { as: "button", type: "button", "data-headlessui-focus-guard": true, onFocus: A5, features: s4.Focusable }));
  }
  var ee = Y(w4);
  var ge = Object.assign(ee, { features: G3 });
  function te(o12 = true) {
    let t11 = (0, import_react33.useRef)(n10.slice());
    return m4(([e6], [r13]) => {
      r13 === true && e6 === false && t(() => {
        t11.current.splice(0);
      }), r13 === false && e6 === true && (t11.current = n10.slice());
    }, [o12, n10, t11]), o4(() => {
      var e6;
      return (e6 = t11.current.find((r13) => r13 != null && r13.isConnected)) != null ? e6 : null;
    });
  }
  function re(o12, { ownerDocument: t11 }) {
    let e6 = !!(o12 & 8), r13 = te(e6);
    m4(() => {
      e6 || d2(t11 == null ? void 0 : t11.body) && w2(r13());
    }, [e6]), c8(() => {
      e6 && w2(r13());
    });
  }
  function ne(o12, { ownerDocument: t11, container: e6, initialFocus: r13, initialFocusFallback: u12 }) {
    let a15 = (0, import_react33.useRef)(null), n12 = I3(!!(o12 & 1), "focus-trap#initial-focus"), s11 = f10();
    return m4(() => {
      if (o12 === 0) return;
      if (!n12) {
        u12 != null && u12.current && w2(u12.current);
        return;
      }
      let f11 = e6.current;
      f11 && t(() => {
        if (!s11.current) return;
        let l10 = t11 == null ? void 0 : t11.activeElement;
        if (r13 != null && r13.current) {
          if ((r13 == null ? void 0 : r13.current) === l10) {
            a15.current = l10;
            return;
          }
        } else if (f11.contains(l10)) {
          a15.current = l10;
          return;
        }
        if (r13 != null && r13.current) w2(r13.current);
        else {
          if (o12 & 16) {
            if (v3(f11, T4.First | T4.AutoFocus) !== A2.Error) return;
          } else if (v3(f11, T4.First) !== A2.Error) return;
          if (u12 != null && u12.current && (w2(u12.current), (t11 == null ? void 0 : t11.activeElement) === u12.current)) return;
          console.warn("There are no focusable elements inside the <FocusTrap />");
        }
        a15.current = t11 == null ? void 0 : t11.activeElement;
      });
    }, [u12, n12, o12]), a15;
  }
  function oe2(o12, { ownerDocument: t11, container: e6, containers: r13, previousActiveElement: u12 }) {
    let a15 = f10(), n12 = !!(o12 & 4);
    E4(t11 == null ? void 0 : t11.defaultView, "focus", (s11) => {
      if (!n12 || !a15.current) return;
      let f11 = x7(r13);
      n4(e6.current) && f11.add(e6.current);
      let l10 = u12.current;
      if (!l10) return;
      let T7 = s11.target;
      n4(T7) ? I6(f11, T7) ? (u12.current = T7, w2(T7)) : (s11.preventDefault(), s11.stopPropagation(), w2(l10)) : w2(u12.current);
    }, true);
  }
  function I6(o12, t11) {
    for (let e6 of o12) if (e6.contains(t11)) return true;
    return false;
  }

  // node_modules/@headlessui/react/dist/components/transition/transition.js
  init_define_import_meta_env();
  var import_react34 = __toESM(require_react_shim(), 1);
  function ue(e6) {
    var t11;
    return !!(e6.enter || e6.enterFrom || e6.enterTo || e6.leave || e6.leaveFrom || e6.leaveTo) || !b((t11 = e6.as) != null ? t11 : de) || import_react34.default.Children.count(e6.children) === 1;
  }
  var V = (0, import_react34.createContext)(null);
  V.displayName = "TransitionContext";
  var De = ((n12) => (n12.Visible = "visible", n12.Hidden = "hidden", n12))(De || {});
  function He() {
    let e6 = (0, import_react34.useContext)(V);
    if (e6 === null) throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");
    return e6;
  }
  function Ae() {
    let e6 = (0, import_react34.useContext)(w5);
    if (e6 === null) throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");
    return e6;
  }
  var w5 = (0, import_react34.createContext)(null);
  w5.displayName = "NestingContext";
  function M5(e6) {
    return "children" in e6 ? M5(e6.children) : e6.current.filter(({ el: t11 }) => t11.current !== null).filter(({ state: t11 }) => t11 === "visible").length > 0;
  }
  function Te(e6, t11) {
    let n12 = s3(e6), l10 = (0, import_react34.useRef)([]), S7 = f10(), R2 = p(), d8 = o4((o12, i12 = C.Hidden) => {
      let a15 = l10.current.findIndex(({ el: s11 }) => s11 === o12);
      a15 !== -1 && (u(i12, { [C.Unmount]() {
        l10.current.splice(a15, 1);
      }, [C.Hidden]() {
        l10.current[a15].state = "hidden";
      } }), R2.microTask(() => {
        var s11;
        !M5(l10) && S7.current && ((s11 = n12.current) == null || s11.call(n12));
      }));
    }), y4 = o4((o12) => {
      let i12 = l10.current.find(({ el: a15 }) => a15 === o12);
      return i12 ? i12.state !== "visible" && (i12.state = "visible") : l10.current.push({ el: o12, state: "visible" }), () => d8(o12, C.Unmount);
    }), C6 = (0, import_react34.useRef)([]), p6 = (0, import_react34.useRef)(Promise.resolve()), h6 = (0, import_react34.useRef)({ enter: [], leave: [] }), g2 = o4((o12, i12, a15) => {
      C6.current.splice(0), t11 && (t11.chains.current[i12] = t11.chains.current[i12].filter(([s11]) => s11 !== o12)), t11 == null || t11.chains.current[i12].push([o12, new Promise((s11) => {
        C6.current.push(s11);
      })]), t11 == null || t11.chains.current[i12].push([o12, new Promise((s11) => {
        Promise.all(h6.current[i12].map(([r13, f11]) => f11)).then(() => s11());
      })]), i12 === "enter" ? p6.current = p6.current.then(() => t11 == null ? void 0 : t11.wait.current).then(() => a15(i12)) : a15(i12);
    }), v4 = o4((o12, i12, a15) => {
      Promise.all(h6.current[i12].splice(0).map(([s11, r13]) => r13)).then(() => {
        var s11;
        (s11 = C6.current.shift()) == null || s11();
      }).then(() => a15(i12));
    });
    return (0, import_react34.useMemo)(() => ({ children: l10, register: y4, unregister: d8, onStart: g2, onStop: v4, wait: p6, chains: h6 }), [y4, d8, l10, g2, v4, h6, p6]);
  }
  var de = import_react34.Fragment;
  var fe = A.RenderStrategy;
  function Fe(e6, t11) {
    var ee2, te2;
    let { transition: n12 = true, beforeEnter: l10, afterEnter: S7, beforeLeave: R2, afterLeave: d8, enter: y4, enterFrom: C6, enterTo: p6, entered: h6, leave: g2, leaveFrom: v4, leaveTo: o12, ...i12 } = e6, [a15, s11] = (0, import_react34.useState)(null), r13 = (0, import_react34.useRef)(null), f11 = ue(e6), U2 = y(...f11 ? [r13, t11, s11] : t11 === null ? [] : [t11]), H5 = (ee2 = i12.unmount) == null || ee2 ? C.Unmount : C.Hidden, { show: u12, appear: z2, initial: K2 } = He(), [m6, j7] = (0, import_react34.useState)(u12 ? "visible" : "hidden"), Q = Ae(), { register: A5, unregister: F3 } = Q;
    n(() => A5(r13), [A5, r13]), n(() => {
      if (H5 === C.Hidden && r13.current) {
        if (u12 && m6 !== "visible") {
          j7("visible");
          return;
        }
        return u(m6, { ["hidden"]: () => F3(r13), ["visible"]: () => A5(r13) });
      }
    }, [m6, r13, A5, F3, u12, H5]);
    let G5 = l7();
    n(() => {
      if (f11 && G5 && m6 === "visible" && r13.current === null) throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?");
    }, [r13, m6, G5, f11]);
    let ce = K2 && !z2, Y2 = z2 && u12 && K2, B2 = (0, import_react34.useRef)(false), I7 = Te(() => {
      B2.current || (j7("hidden"), F3(r13));
    }, Q), Z = o4((W) => {
      B2.current = true;
      let L2 = W ? "enter" : "leave";
      I7.onStart(r13, L2, (_4) => {
        _4 === "enter" ? l10 == null || l10() : _4 === "leave" && (R2 == null || R2());
      });
    }), $3 = o4((W) => {
      let L2 = W ? "enter" : "leave";
      B2.current = false, I7.onStop(r13, L2, (_4) => {
        _4 === "enter" ? S7 == null || S7() : _4 === "leave" && (d8 == null || d8());
      }), L2 === "leave" && !M5(I7) && (j7("hidden"), F3(r13));
    });
    (0, import_react34.useEffect)(() => {
      f11 && n12 || (Z(u12), $3(u12));
    }, [u12, f11, n12]);
    let pe2 = /* @__PURE__ */ (() => !(!n12 || !f11 || !G5 || ce))(), [, T7] = N(pe2, a15, u12, { start: Z, end: $3 }), Ce = m({ ref: U2, className: ((te2 = t4(i12.className, Y2 && y4, Y2 && C6, T7.enter && y4, T7.enter && T7.closed && C6, T7.enter && !T7.closed && p6, T7.leave && g2, T7.leave && !T7.closed && v4, T7.leave && T7.closed && o12, !T7.transition && u12 && h6)) == null ? void 0 : te2.trim()) || void 0, ...x4(T7) }), N2 = 0;
    m6 === "visible" && (N2 |= i9.Open), m6 === "hidden" && (N2 |= i9.Closed), u12 && m6 === "hidden" && (N2 |= i9.Opening), !u12 && m6 === "visible" && (N2 |= i9.Closing);
    let he = K();
    return import_react34.default.createElement(w5.Provider, { value: I7 }, import_react34.default.createElement(c7, { value: N2 }, he({ ourProps: Ce, theirProps: i12, defaultTag: de, features: fe, visible: m6 === "visible", name: "Transition.Child" })));
  }
  function Ie(e6, t11) {
    let { show: n12, appear: l10 = false, unmount: S7 = true, ...R2 } = e6, d8 = (0, import_react34.useRef)(null), y4 = ue(e6), C6 = y(...y4 ? [d8, t11] : t11 === null ? [] : [t11]);
    l7();
    let p6 = u9();
    if (n12 === void 0 && p6 !== null && (n12 = (p6 & i9.Open) === i9.Open), n12 === void 0) throw new Error("A <Transition /> is used but it is missing a `show={true | false}` prop.");
    let [h6, g2] = (0, import_react34.useState)(n12 ? "visible" : "hidden"), v4 = Te(() => {
      n12 || g2("hidden");
    }), [o12, i12] = (0, import_react34.useState)(true), a15 = (0, import_react34.useRef)([n12]);
    n(() => {
      o12 !== false && a15.current[a15.current.length - 1] !== n12 && (a15.current.push(n12), i12(false));
    }, [a15, n12]);
    let s11 = (0, import_react34.useMemo)(() => ({ show: n12, appear: l10, initial: o12 }), [n12, l10, o12]);
    n(() => {
      n12 ? g2("visible") : !M5(v4) && d8.current !== null && g2("hidden");
    }, [n12, v4]);
    let r13 = { unmount: S7 }, f11 = o4(() => {
      var u12;
      o12 && i12(false), (u12 = e6.beforeEnter) == null || u12.call(e6);
    }), U2 = o4(() => {
      var u12;
      o12 && i12(false), (u12 = e6.beforeLeave) == null || u12.call(e6);
    }), H5 = K();
    return import_react34.default.createElement(w5.Provider, { value: v4 }, import_react34.default.createElement(V.Provider, { value: s11 }, H5({ ourProps: { ...r13, as: import_react34.Fragment, children: import_react34.default.createElement(me, { ref: C6, ...r13, ...R2, beforeEnter: f11, beforeLeave: U2 }) }, theirProps: {}, defaultTag: import_react34.Fragment, features: fe, visible: h6 === "visible", name: "Transition" })));
  }
  function Le(e6, t11) {
    let n12 = (0, import_react34.useContext)(V) !== null, l10 = u9() !== null;
    return import_react34.default.createElement(import_react34.default.Fragment, null, !n12 && l10 ? import_react34.default.createElement(X2, { ref: t11, ...e6 }) : import_react34.default.createElement(me, { ref: t11, ...e6 }));
  }
  var X2 = Y(Ie);
  var me = Y(Fe);
  var Oe = Y(Le);
  var Ke = Object.assign(X2, { Child: Oe, Root: X2 });

  // node_modules/@headlessui/react/dist/components/dialog/dialog.js
  var we = ((o12) => (o12[o12.Open = 0] = "Open", o12[o12.Closed = 1] = "Closed", o12))(we || {});
  var Be = ((t11) => (t11[t11.SetTitleId = 0] = "SetTitleId", t11))(Be || {});
  var Ue = { [0](e6, t11) {
    return e6.titleId === t11.id ? e6 : { ...e6, titleId: t11.id };
  } };
  var w6 = (0, import_react35.createContext)(null);
  w6.displayName = "DialogContext";
  function O4(e6) {
    let t11 = (0, import_react35.useContext)(w6);
    if (t11 === null) {
      let o12 = new Error(`<${e6} /> is missing a parent <Dialog /> component.`);
      throw Error.captureStackTrace && Error.captureStackTrace(o12, O4), o12;
    }
    return t11;
  }
  function He2(e6, t11) {
    return u(t11.type, Ue, e6, t11);
  }
  var z = Y(function(t11, o12) {
    let a15 = (0, import_react10.useId)(), { id: n12 = `headlessui-dialog-${a15}`, open: i12, onClose: p6, initialFocus: d8, role: s11 = "dialog", autoFocus: f11 = true, __demoMode: u12 = false, unmount: y4 = false, ...S7 } = t11, R2 = (0, import_react35.useRef)(false);
    s11 = (function() {
      return s11 === "dialog" || s11 === "alertdialog" ? s11 : (R2.current || (R2.current = true, console.warn(`Invalid role [${s11}] passed to <Dialog />. Only \`dialog\` and and \`alertdialog\` are supported. Using \`dialog\` instead.`)), "dialog");
    })();
    let g2 = u9();
    i12 === void 0 && g2 !== null && (i12 = (g2 & i9.Open) === i9.Open);
    let T7 = (0, import_react35.useRef)(null), I7 = y(T7, o12), F3 = u8(T7.current), c12 = i12 ? 0 : 1, [b8, Q] = (0, import_react35.useReducer)(He2, { titleId: null, descriptionId: null, panelRef: (0, import_react35.createRef)() }), m6 = o4(() => p6(false)), B2 = o4((r13) => Q({ type: 0, id: r13 })), D5 = l7() ? c12 === 0 : false, [Z, ee2] = oe(), te2 = { get current() {
      var r13;
      return (r13 = b8.panelRef.current) != null ? r13 : T7.current;
    } }, v4 = x6(), { resolveContainers: M6 } = S6({ mainTreeNode: v4, portals: Z, defaultContainers: [te2] }), U2 = g2 !== null ? (g2 & i9.Closing) === i9.Closing : false;
    y3(u12 || U2 ? false : D5, { allowed: o4(() => {
      var r13, W;
      return [(W = (r13 = T7.current) == null ? void 0 : r13.closest("[data-headlessui-portal]")) != null ? W : null];
    }), disallowed: o4(() => {
      var r13;
      return [(r13 = v4 == null ? void 0 : v4.closest("body > *:not(#headlessui-portal-root)")) != null ? r13 : null];
    }) });
    let P3 = x2.get(null);
    n(() => {
      if (D5) return P3.actions.push(n12), () => P3.actions.pop(n12);
    }, [P3, n12, D5]);
    let H5 = S3(P3, (0, import_react35.useCallback)((r13) => P3.selectors.isTop(r13, n12), [P3, n12]));
    k3(H5, M6, (r13) => {
      r13.preventDefault(), m6();
    }), a13(H5, F3 == null ? void 0 : F3.defaultView, (r13) => {
      r13.preventDefault(), r13.stopPropagation(), document.activeElement && "blur" in document.activeElement && typeof document.activeElement.blur == "function" && document.activeElement.blur(), m6();
    }), f6(u12 || U2 ? false : D5, F3, M6), p4(D5, T7, m6);
    let [oe3, ne3] = H2(), re2 = (0, import_react35.useMemo)(() => [{ dialogState: c12, close: m6, setTitleId: B2, unmount: y4 }, b8], [c12, m6, B2, y4, b8]), N2 = n2({ open: c12 === 0 }), le2 = { ref: I7, id: n12, role: s11, tabIndex: -1, "aria-modal": u12 ? void 0 : c12 === 0 ? true : void 0, "aria-labelledby": b8.titleId, "aria-describedby": oe3, unmount: y4 }, ae = !f9(), E6 = G3.None;
    D5 && !u12 && (E6 |= G3.RestoreFocus, E6 |= G3.TabLock, f11 && (E6 |= G3.AutoFocus), ae && (E6 |= G3.InitialFocus));
    let ie2 = K();
    return import_react35.default.createElement(s8, null, import_react35.default.createElement(l8, { force: true }, import_react35.default.createElement(le, null, import_react35.default.createElement(w6.Provider, { value: re2 }, import_react35.default.createElement(B, { target: T7 }, import_react35.default.createElement(l8, { force: false }, import_react35.default.createElement(ne3, { slot: N2 }, import_react35.default.createElement(ee2, null, import_react35.default.createElement(ge, { initialFocus: d8, initialFocusFallback: T7, containers: M6, features: E6 }, import_react35.default.createElement(C3, { value: m6 }, ie2({ ourProps: le2, theirProps: S7, slot: N2, defaultTag: Ne, features: We, visible: c12 === 0, name: "Dialog" })))))))))));
  });
  var Ne = "div";
  var We = A.RenderStrategy | A.Static;
  function $e(e6, t11) {
    let { transition: o12 = false, open: a15, ...n12 } = e6, i12 = u9(), p6 = e6.hasOwnProperty("open") || i12 !== null, d8 = e6.hasOwnProperty("onClose");
    if (!p6 && !d8) throw new Error("You have to provide an `open` and an `onClose` prop to the `Dialog` component.");
    if (!p6) throw new Error("You provided an `onClose` prop to the `Dialog`, but forgot an `open` prop.");
    if (!d8) throw new Error("You provided an `open` prop to the `Dialog`, but forgot an `onClose` prop.");
    if (!i12 && typeof e6.open != "boolean") throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${e6.open}`);
    if (typeof e6.onClose != "function") throw new Error(`You provided an \`onClose\` prop to the \`Dialog\`, but the value is not a function. Received: ${e6.onClose}`);
    return (a15 !== void 0 || o12) && !n12.static ? import_react35.default.createElement(j5, null, import_react35.default.createElement(Ke, { show: a15, transition: o12, unmount: n12.unmount }, import_react35.default.createElement(z, { ref: t11, ...n12 }))) : import_react35.default.createElement(j5, null, import_react35.default.createElement(z, { ref: t11, open: a15, ...n12 }));
  }
  var je = "div";
  function Ye(e6, t11) {
    let o12 = (0, import_react10.useId)(), { id: a15 = `headlessui-dialog-panel-${o12}`, transition: n12 = false, ...i12 } = e6, [{ dialogState: p6, unmount: d8 }, s11] = O4("Dialog.Panel"), f11 = y(t11, s11.panelRef), u12 = n2({ open: p6 === 0 }), y4 = o4((I7) => {
      I7.stopPropagation();
    }), S7 = { ref: f11, id: a15, onClick: y4 }, R2 = n12 ? Oe : import_react35.Fragment, g2 = n12 ? { unmount: d8 } : {}, T7 = K();
    return import_react35.default.createElement(R2, { ...g2 }, T7({ ourProps: S7, theirProps: i12, slot: u12, defaultTag: je, name: "Dialog.Panel" }));
  }
  var Je = "div";
  function Ke2(e6, t11) {
    let { transition: o12 = false, ...a15 } = e6, [{ dialogState: n12, unmount: i12 }] = O4("Dialog.Backdrop"), p6 = n2({ open: n12 === 0 }), d8 = { ref: t11, "aria-hidden": true }, s11 = o12 ? Oe : import_react35.Fragment, f11 = o12 ? { unmount: i12 } : {}, u12 = K();
    return import_react35.default.createElement(s11, { ...f11 }, u12({ ourProps: d8, theirProps: a15, slot: p6, defaultTag: Je, name: "Dialog.Backdrop" }));
  }
  var Xe = "h2";
  function Ve(e6, t11) {
    let o12 = (0, import_react10.useId)(), { id: a15 = `headlessui-dialog-title-${o12}`, ...n12 } = e6, [{ dialogState: i12, setTitleId: p6 }] = O4("Dialog.Title"), d8 = y(t11);
    (0, import_react35.useEffect)(() => (p6(a15), () => p6(null)), [a15, p6]);
    let s11 = n2({ open: i12 === 0 }), f11 = { ref: d8, id: a15 };
    return K()({ ourProps: f11, theirProps: n12, slot: s11, defaultTag: Xe, name: "Dialog.Title" });
  }
  var qe = Y($e);
  var ze = Y(Ye);
  var Lt = Y(Ke2);
  var Qe = Y(Ve);
  var ht = Object.assign(qe, { Panel: ze, Title: Qe, Description: M2 });

  // node_modules/@inertiajs/react/dist/index.esm.js
  init_define_import_meta_env();

  // node_modules/@inertiajs/core/dist/index.esm.js
  init_define_import_meta_env();

  // node_modules/lodash-es/lodash.js
  init_define_import_meta_env();

  // node_modules/lodash-es/isSymbol.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseGetTag.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_Symbol.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_root.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_freeGlobal.js
  init_define_import_meta_env();
  var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
  var freeGlobal_default = freeGlobal;

  // node_modules/lodash-es/_root.js
  var freeSelf = typeof self == "object" && self && self.Object === Object && self;
  var root = freeGlobal_default || freeSelf || Function("return this")();
  var root_default = root;

  // node_modules/lodash-es/_Symbol.js
  var Symbol2 = root_default.Symbol;
  var Symbol_default = Symbol2;

  // node_modules/lodash-es/_getRawTag.js
  init_define_import_meta_env();
  var objectProto = Object.prototype;
  var hasOwnProperty = objectProto.hasOwnProperty;
  var nativeObjectToString = objectProto.toString;
  var symToStringTag = Symbol_default ? Symbol_default.toStringTag : void 0;
  function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
    try {
      value[symToStringTag] = void 0;
      var unmasked = true;
    } catch (e6) {
    }
    var result = nativeObjectToString.call(value);
    if (unmasked) {
      if (isOwn) {
        value[symToStringTag] = tag;
      } else {
        delete value[symToStringTag];
      }
    }
    return result;
  }
  var getRawTag_default = getRawTag;

  // node_modules/lodash-es/_objectToString.js
  init_define_import_meta_env();
  var objectProto2 = Object.prototype;
  var nativeObjectToString2 = objectProto2.toString;
  function objectToString(value) {
    return nativeObjectToString2.call(value);
  }
  var objectToString_default = objectToString;

  // node_modules/lodash-es/_baseGetTag.js
  var nullTag = "[object Null]";
  var undefinedTag = "[object Undefined]";
  var symToStringTag2 = Symbol_default ? Symbol_default.toStringTag : void 0;
  function baseGetTag(value) {
    if (value == null) {
      return value === void 0 ? undefinedTag : nullTag;
    }
    return symToStringTag2 && symToStringTag2 in Object(value) ? getRawTag_default(value) : objectToString_default(value);
  }
  var baseGetTag_default = baseGetTag;

  // node_modules/lodash-es/isObjectLike.js
  init_define_import_meta_env();
  function isObjectLike(value) {
    return value != null && typeof value == "object";
  }
  var isObjectLike_default = isObjectLike;

  // node_modules/lodash-es/isSymbol.js
  var symbolTag = "[object Symbol]";
  function isSymbol(value) {
    return typeof value == "symbol" || isObjectLike_default(value) && baseGetTag_default(value) == symbolTag;
  }
  var isSymbol_default = isSymbol;

  // node_modules/lodash-es/_baseToString.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_arrayMap.js
  init_define_import_meta_env();
  function arrayMap(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length, result = Array(length);
    while (++index < length) {
      result[index] = iteratee(array[index], index, array);
    }
    return result;
  }
  var arrayMap_default = arrayMap;

  // node_modules/lodash-es/isArray.js
  init_define_import_meta_env();
  var isArray = Array.isArray;
  var isArray_default = isArray;

  // node_modules/lodash-es/_baseToString.js
  var INFINITY = 1 / 0;
  var symbolProto = Symbol_default ? Symbol_default.prototype : void 0;
  var symbolToString = symbolProto ? symbolProto.toString : void 0;
  function baseToString(value) {
    if (typeof value == "string") {
      return value;
    }
    if (isArray_default(value)) {
      return arrayMap_default(value, baseToString) + "";
    }
    if (isSymbol_default(value)) {
      return symbolToString ? symbolToString.call(value) : "";
    }
    var result = value + "";
    return result == "0" && 1 / value == -INFINITY ? "-0" : result;
  }
  var baseToString_default = baseToString;

  // node_modules/lodash-es/toNumber.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseTrim.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_trimmedEndIndex.js
  init_define_import_meta_env();
  var reWhitespace = /\s/;
  function trimmedEndIndex(string) {
    var index = string.length;
    while (index-- && reWhitespace.test(string.charAt(index))) {
    }
    return index;
  }
  var trimmedEndIndex_default = trimmedEndIndex;

  // node_modules/lodash-es/_baseTrim.js
  var reTrimStart = /^\s+/;
  function baseTrim(string) {
    return string ? string.slice(0, trimmedEndIndex_default(string) + 1).replace(reTrimStart, "") : string;
  }
  var baseTrim_default = baseTrim;

  // node_modules/lodash-es/isObject.js
  init_define_import_meta_env();
  function isObject(value) {
    var type = typeof value;
    return value != null && (type == "object" || type == "function");
  }
  var isObject_default = isObject;

  // node_modules/lodash-es/toNumber.js
  var NAN = 0 / 0;
  var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
  var reIsBinary = /^0b[01]+$/i;
  var reIsOctal = /^0o[0-7]+$/i;
  var freeParseInt = parseInt;
  function toNumber(value) {
    if (typeof value == "number") {
      return value;
    }
    if (isSymbol_default(value)) {
      return NAN;
    }
    if (isObject_default(value)) {
      var other = typeof value.valueOf == "function" ? value.valueOf() : value;
      value = isObject_default(other) ? other + "" : other;
    }
    if (typeof value != "string") {
      return value === 0 ? value : +value;
    }
    value = baseTrim_default(value);
    var isBinary = reIsBinary.test(value);
    return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
  }
  var toNumber_default = toNumber;

  // node_modules/lodash-es/identity.js
  init_define_import_meta_env();
  function identity(value) {
    return value;
  }
  var identity_default = identity;

  // node_modules/lodash-es/_WeakMap.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_getNative.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseIsNative.js
  init_define_import_meta_env();

  // node_modules/lodash-es/isFunction.js
  init_define_import_meta_env();
  var asyncTag = "[object AsyncFunction]";
  var funcTag = "[object Function]";
  var genTag = "[object GeneratorFunction]";
  var proxyTag = "[object Proxy]";
  function isFunction(value) {
    if (!isObject_default(value)) {
      return false;
    }
    var tag = baseGetTag_default(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
  }
  var isFunction_default = isFunction;

  // node_modules/lodash-es/_isMasked.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_coreJsData.js
  init_define_import_meta_env();
  var coreJsData = root_default["__core-js_shared__"];
  var coreJsData_default = coreJsData;

  // node_modules/lodash-es/_isMasked.js
  var maskSrcKey = (function() {
    var uid2 = /[^.]+$/.exec(coreJsData_default && coreJsData_default.keys && coreJsData_default.keys.IE_PROTO || "");
    return uid2 ? "Symbol(src)_1." + uid2 : "";
  })();
  function isMasked(func) {
    return !!maskSrcKey && maskSrcKey in func;
  }
  var isMasked_default = isMasked;

  // node_modules/lodash-es/_toSource.js
  init_define_import_meta_env();
  var funcProto = Function.prototype;
  var funcToString = funcProto.toString;
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString.call(func);
      } catch (e6) {
      }
      try {
        return func + "";
      } catch (e6) {
      }
    }
    return "";
  }
  var toSource_default = toSource;

  // node_modules/lodash-es/_baseIsNative.js
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  var funcProto2 = Function.prototype;
  var objectProto3 = Object.prototype;
  var funcToString2 = funcProto2.toString;
  var hasOwnProperty2 = objectProto3.hasOwnProperty;
  var reIsNative = RegExp(
    "^" + funcToString2.call(hasOwnProperty2).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
  );
  function baseIsNative(value) {
    if (!isObject_default(value) || isMasked_default(value)) {
      return false;
    }
    var pattern = isFunction_default(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource_default(value));
  }
  var baseIsNative_default = baseIsNative;

  // node_modules/lodash-es/_getValue.js
  init_define_import_meta_env();
  function getValue(object, key) {
    return object == null ? void 0 : object[key];
  }
  var getValue_default = getValue;

  // node_modules/lodash-es/_getNative.js
  function getNative(object, key) {
    var value = getValue_default(object, key);
    return baseIsNative_default(value) ? value : void 0;
  }
  var getNative_default = getNative;

  // node_modules/lodash-es/_WeakMap.js
  var WeakMap2 = getNative_default(root_default, "WeakMap");
  var WeakMap_default = WeakMap2;

  // node_modules/lodash-es/_baseCreate.js
  init_define_import_meta_env();
  var objectCreate = Object.create;
  var baseCreate = /* @__PURE__ */ (function() {
    function object() {
    }
    return function(proto) {
      if (!isObject_default(proto)) {
        return {};
      }
      if (objectCreate) {
        return objectCreate(proto);
      }
      object.prototype = proto;
      var result = new object();
      object.prototype = void 0;
      return result;
    };
  })();
  var baseCreate_default = baseCreate;

  // node_modules/lodash-es/_apply.js
  init_define_import_meta_env();
  function apply(func, thisArg, args) {
    switch (args.length) {
      case 0:
        return func.call(thisArg);
      case 1:
        return func.call(thisArg, args[0]);
      case 2:
        return func.call(thisArg, args[0], args[1]);
      case 3:
        return func.call(thisArg, args[0], args[1], args[2]);
    }
    return func.apply(thisArg, args);
  }
  var apply_default = apply;

  // node_modules/lodash-es/_copyArray.js
  init_define_import_meta_env();
  function copyArray(source, array) {
    var index = -1, length = source.length;
    array || (array = Array(length));
    while (++index < length) {
      array[index] = source[index];
    }
    return array;
  }
  var copyArray_default = copyArray;

  // node_modules/lodash-es/_shortOut.js
  init_define_import_meta_env();
  var HOT_COUNT = 800;
  var HOT_SPAN = 16;
  var nativeNow = Date.now;
  function shortOut(func) {
    var count = 0, lastCalled = 0;
    return function() {
      var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
      lastCalled = stamp;
      if (remaining > 0) {
        if (++count >= HOT_COUNT) {
          return arguments[0];
        }
      } else {
        count = 0;
      }
      return func.apply(void 0, arguments);
    };
  }
  var shortOut_default = shortOut;

  // node_modules/lodash-es/_setToString.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseSetToString.js
  init_define_import_meta_env();

  // node_modules/lodash-es/constant.js
  init_define_import_meta_env();
  function constant(value) {
    return function() {
      return value;
    };
  }
  var constant_default = constant;

  // node_modules/lodash-es/_defineProperty.js
  init_define_import_meta_env();
  var defineProperty = (function() {
    try {
      var func = getNative_default(Object, "defineProperty");
      func({}, "", {});
      return func;
    } catch (e6) {
    }
  })();
  var defineProperty_default = defineProperty;

  // node_modules/lodash-es/_baseSetToString.js
  var baseSetToString = !defineProperty_default ? identity_default : function(func, string) {
    return defineProperty_default(func, "toString", {
      "configurable": true,
      "enumerable": false,
      "value": constant_default(string),
      "writable": true
    });
  };
  var baseSetToString_default = baseSetToString;

  // node_modules/lodash-es/_setToString.js
  var setToString = shortOut_default(baseSetToString_default);
  var setToString_default = setToString;

  // node_modules/lodash-es/_arrayEach.js
  init_define_import_meta_env();
  function arrayEach(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length;
    while (++index < length) {
      if (iteratee(array[index], index, array) === false) {
        break;
      }
    }
    return array;
  }
  var arrayEach_default = arrayEach;

  // node_modules/lodash-es/_isIndex.js
  init_define_import_meta_env();
  var MAX_SAFE_INTEGER = 9007199254740991;
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  function isIndex(value, length) {
    var type = typeof value;
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
  }
  var isIndex_default = isIndex;

  // node_modules/lodash-es/_assignValue.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseAssignValue.js
  init_define_import_meta_env();
  function baseAssignValue(object, key, value) {
    if (key == "__proto__" && defineProperty_default) {
      defineProperty_default(object, key, {
        "configurable": true,
        "enumerable": true,
        "value": value,
        "writable": true
      });
    } else {
      object[key] = value;
    }
  }
  var baseAssignValue_default = baseAssignValue;

  // node_modules/lodash-es/eq.js
  init_define_import_meta_env();
  function eq(value, other) {
    return value === other || value !== value && other !== other;
  }
  var eq_default = eq;

  // node_modules/lodash-es/_assignValue.js
  var objectProto4 = Object.prototype;
  var hasOwnProperty3 = objectProto4.hasOwnProperty;
  function assignValue(object, key, value) {
    var objValue = object[key];
    if (!(hasOwnProperty3.call(object, key) && eq_default(objValue, value)) || value === void 0 && !(key in object)) {
      baseAssignValue_default(object, key, value);
    }
  }
  var assignValue_default = assignValue;

  // node_modules/lodash-es/_copyObject.js
  init_define_import_meta_env();
  function copyObject(source, props, object, customizer) {
    var isNew = !object;
    object || (object = {});
    var index = -1, length = props.length;
    while (++index < length) {
      var key = props[index];
      var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
      if (newValue === void 0) {
        newValue = source[key];
      }
      if (isNew) {
        baseAssignValue_default(object, key, newValue);
      } else {
        assignValue_default(object, key, newValue);
      }
    }
    return object;
  }
  var copyObject_default = copyObject;

  // node_modules/lodash-es/_createAssigner.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseRest.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_overRest.js
  init_define_import_meta_env();
  var nativeMax = Math.max;
  function overRest(func, start2, transform) {
    start2 = nativeMax(start2 === void 0 ? func.length - 1 : start2, 0);
    return function() {
      var args = arguments, index = -1, length = nativeMax(args.length - start2, 0), array = Array(length);
      while (++index < length) {
        array[index] = args[start2 + index];
      }
      index = -1;
      var otherArgs = Array(start2 + 1);
      while (++index < start2) {
        otherArgs[index] = args[index];
      }
      otherArgs[start2] = transform(array);
      return apply_default(func, this, otherArgs);
    };
  }
  var overRest_default = overRest;

  // node_modules/lodash-es/_baseRest.js
  function baseRest(func, start2) {
    return setToString_default(overRest_default(func, start2, identity_default), func + "");
  }
  var baseRest_default = baseRest;

  // node_modules/lodash-es/_isIterateeCall.js
  init_define_import_meta_env();

  // node_modules/lodash-es/isArrayLike.js
  init_define_import_meta_env();

  // node_modules/lodash-es/isLength.js
  init_define_import_meta_env();
  var MAX_SAFE_INTEGER2 = 9007199254740991;
  function isLength(value) {
    return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER2;
  }
  var isLength_default = isLength;

  // node_modules/lodash-es/isArrayLike.js
  function isArrayLike(value) {
    return value != null && isLength_default(value.length) && !isFunction_default(value);
  }
  var isArrayLike_default = isArrayLike;

  // node_modules/lodash-es/_isIterateeCall.js
  function isIterateeCall(value, index, object) {
    if (!isObject_default(object)) {
      return false;
    }
    var type = typeof index;
    if (type == "number" ? isArrayLike_default(object) && isIndex_default(index, object.length) : type == "string" && index in object) {
      return eq_default(object[index], value);
    }
    return false;
  }
  var isIterateeCall_default = isIterateeCall;

  // node_modules/lodash-es/_createAssigner.js
  function createAssigner(assigner) {
    return baseRest_default(function(object, sources) {
      var index = -1, length = sources.length, customizer = length > 1 ? sources[length - 1] : void 0, guard = length > 2 ? sources[2] : void 0;
      customizer = assigner.length > 3 && typeof customizer == "function" ? (length--, customizer) : void 0;
      if (guard && isIterateeCall_default(sources[0], sources[1], guard)) {
        customizer = length < 3 ? void 0 : customizer;
        length = 1;
      }
      object = Object(object);
      while (++index < length) {
        var source = sources[index];
        if (source) {
          assigner(object, source, index, customizer);
        }
      }
      return object;
    });
  }
  var createAssigner_default = createAssigner;

  // node_modules/lodash-es/_isPrototype.js
  init_define_import_meta_env();
  var objectProto5 = Object.prototype;
  function isPrototype(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto5;
    return value === proto;
  }
  var isPrototype_default = isPrototype;

  // node_modules/lodash-es/keys.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_arrayLikeKeys.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseTimes.js
  init_define_import_meta_env();
  function baseTimes(n12, iteratee) {
    var index = -1, result = Array(n12);
    while (++index < n12) {
      result[index] = iteratee(index);
    }
    return result;
  }
  var baseTimes_default = baseTimes;

  // node_modules/lodash-es/isArguments.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseIsArguments.js
  init_define_import_meta_env();
  var argsTag = "[object Arguments]";
  function baseIsArguments(value) {
    return isObjectLike_default(value) && baseGetTag_default(value) == argsTag;
  }
  var baseIsArguments_default = baseIsArguments;

  // node_modules/lodash-es/isArguments.js
  var objectProto6 = Object.prototype;
  var hasOwnProperty4 = objectProto6.hasOwnProperty;
  var propertyIsEnumerable = objectProto6.propertyIsEnumerable;
  var isArguments = baseIsArguments_default(/* @__PURE__ */ (function() {
    return arguments;
  })()) ? baseIsArguments_default : function(value) {
    return isObjectLike_default(value) && hasOwnProperty4.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
  };
  var isArguments_default = isArguments;

  // node_modules/lodash-es/isBuffer.js
  init_define_import_meta_env();

  // node_modules/lodash-es/stubFalse.js
  init_define_import_meta_env();
  function stubFalse() {
    return false;
  }
  var stubFalse_default = stubFalse;

  // node_modules/lodash-es/isBuffer.js
  var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var Buffer2 = moduleExports ? root_default.Buffer : void 0;
  var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
  var isBuffer = nativeIsBuffer || stubFalse_default;
  var isBuffer_default = isBuffer;

  // node_modules/lodash-es/isTypedArray.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseIsTypedArray.js
  init_define_import_meta_env();
  var argsTag2 = "[object Arguments]";
  var arrayTag = "[object Array]";
  var boolTag = "[object Boolean]";
  var dateTag = "[object Date]";
  var errorTag = "[object Error]";
  var funcTag2 = "[object Function]";
  var mapTag = "[object Map]";
  var numberTag = "[object Number]";
  var objectTag = "[object Object]";
  var regexpTag = "[object RegExp]";
  var setTag = "[object Set]";
  var stringTag = "[object String]";
  var weakMapTag = "[object WeakMap]";
  var arrayBufferTag = "[object ArrayBuffer]";
  var dataViewTag = "[object DataView]";
  var float32Tag = "[object Float32Array]";
  var float64Tag = "[object Float64Array]";
  var int8Tag = "[object Int8Array]";
  var int16Tag = "[object Int16Array]";
  var int32Tag = "[object Int32Array]";
  var uint8Tag = "[object Uint8Array]";
  var uint8ClampedTag = "[object Uint8ClampedArray]";
  var uint16Tag = "[object Uint16Array]";
  var uint32Tag = "[object Uint32Array]";
  var typedArrayTags = {};
  typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
  typedArrayTags[argsTag2] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag2] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
  function baseIsTypedArray(value) {
    return isObjectLike_default(value) && isLength_default(value.length) && !!typedArrayTags[baseGetTag_default(value)];
  }
  var baseIsTypedArray_default = baseIsTypedArray;

  // node_modules/lodash-es/_baseUnary.js
  init_define_import_meta_env();
  function baseUnary(func) {
    return function(value) {
      return func(value);
    };
  }
  var baseUnary_default = baseUnary;

  // node_modules/lodash-es/_nodeUtil.js
  init_define_import_meta_env();
  var freeExports2 = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule2 = freeExports2 && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports2 = freeModule2 && freeModule2.exports === freeExports2;
  var freeProcess = moduleExports2 && freeGlobal_default.process;
  var nodeUtil = (function() {
    try {
      var types = freeModule2 && freeModule2.require && freeModule2.require("util").types;
      if (types) {
        return types;
      }
      return freeProcess && freeProcess.binding && freeProcess.binding("util");
    } catch (e6) {
    }
  })();
  var nodeUtil_default = nodeUtil;

  // node_modules/lodash-es/isTypedArray.js
  var nodeIsTypedArray = nodeUtil_default && nodeUtil_default.isTypedArray;
  var isTypedArray = nodeIsTypedArray ? baseUnary_default(nodeIsTypedArray) : baseIsTypedArray_default;
  var isTypedArray_default = isTypedArray;

  // node_modules/lodash-es/_arrayLikeKeys.js
  var objectProto7 = Object.prototype;
  var hasOwnProperty5 = objectProto7.hasOwnProperty;
  function arrayLikeKeys(value, inherited) {
    var isArr = isArray_default(value), isArg = !isArr && isArguments_default(value), isBuff = !isArr && !isArg && isBuffer_default(value), isType = !isArr && !isArg && !isBuff && isTypedArray_default(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes_default(value.length, String) : [], length = result.length;
    for (var key in value) {
      if ((inherited || hasOwnProperty5.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
      (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
      isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
      isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
      isIndex_default(key, length)))) {
        result.push(key);
      }
    }
    return result;
  }
  var arrayLikeKeys_default = arrayLikeKeys;

  // node_modules/lodash-es/_baseKeys.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_nativeKeys.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_overArg.js
  init_define_import_meta_env();
  function overArg(func, transform) {
    return function(arg) {
      return func(transform(arg));
    };
  }
  var overArg_default = overArg;

  // node_modules/lodash-es/_nativeKeys.js
  var nativeKeys = overArg_default(Object.keys, Object);
  var nativeKeys_default = nativeKeys;

  // node_modules/lodash-es/_baseKeys.js
  var objectProto8 = Object.prototype;
  var hasOwnProperty6 = objectProto8.hasOwnProperty;
  function baseKeys(object) {
    if (!isPrototype_default(object)) {
      return nativeKeys_default(object);
    }
    var result = [];
    for (var key in Object(object)) {
      if (hasOwnProperty6.call(object, key) && key != "constructor") {
        result.push(key);
      }
    }
    return result;
  }
  var baseKeys_default = baseKeys;

  // node_modules/lodash-es/keys.js
  function keys(object) {
    return isArrayLike_default(object) ? arrayLikeKeys_default(object) : baseKeys_default(object);
  }
  var keys_default = keys;

  // node_modules/lodash-es/keysIn.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseKeysIn.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_nativeKeysIn.js
  init_define_import_meta_env();
  function nativeKeysIn(object) {
    var result = [];
    if (object != null) {
      for (var key in Object(object)) {
        result.push(key);
      }
    }
    return result;
  }
  var nativeKeysIn_default = nativeKeysIn;

  // node_modules/lodash-es/_baseKeysIn.js
  var objectProto9 = Object.prototype;
  var hasOwnProperty7 = objectProto9.hasOwnProperty;
  function baseKeysIn(object) {
    if (!isObject_default(object)) {
      return nativeKeysIn_default(object);
    }
    var isProto = isPrototype_default(object), result = [];
    for (var key in object) {
      if (!(key == "constructor" && (isProto || !hasOwnProperty7.call(object, key)))) {
        result.push(key);
      }
    }
    return result;
  }
  var baseKeysIn_default = baseKeysIn;

  // node_modules/lodash-es/keysIn.js
  function keysIn(object) {
    return isArrayLike_default(object) ? arrayLikeKeys_default(object, true) : baseKeysIn_default(object);
  }
  var keysIn_default = keysIn;

  // node_modules/lodash-es/get.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseGet.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_castPath.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_isKey.js
  init_define_import_meta_env();
  var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
  var reIsPlainProp = /^\w*$/;
  function isKey(value, object) {
    if (isArray_default(value)) {
      return false;
    }
    var type = typeof value;
    if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol_default(value)) {
      return true;
    }
    return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
  }
  var isKey_default = isKey;

  // node_modules/lodash-es/_stringToPath.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_memoizeCapped.js
  init_define_import_meta_env();

  // node_modules/lodash-es/memoize.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_MapCache.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_mapCacheClear.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_Hash.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_hashClear.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_nativeCreate.js
  init_define_import_meta_env();
  var nativeCreate = getNative_default(Object, "create");
  var nativeCreate_default = nativeCreate;

  // node_modules/lodash-es/_hashClear.js
  function hashClear() {
    this.__data__ = nativeCreate_default ? nativeCreate_default(null) : {};
    this.size = 0;
  }
  var hashClear_default = hashClear;

  // node_modules/lodash-es/_hashDelete.js
  init_define_import_meta_env();
  function hashDelete(key) {
    var result = this.has(key) && delete this.__data__[key];
    this.size -= result ? 1 : 0;
    return result;
  }
  var hashDelete_default = hashDelete;

  // node_modules/lodash-es/_hashGet.js
  init_define_import_meta_env();
  var HASH_UNDEFINED = "__lodash_hash_undefined__";
  var objectProto10 = Object.prototype;
  var hasOwnProperty8 = objectProto10.hasOwnProperty;
  function hashGet(key) {
    var data = this.__data__;
    if (nativeCreate_default) {
      var result = data[key];
      return result === HASH_UNDEFINED ? void 0 : result;
    }
    return hasOwnProperty8.call(data, key) ? data[key] : void 0;
  }
  var hashGet_default = hashGet;

  // node_modules/lodash-es/_hashHas.js
  init_define_import_meta_env();
  var objectProto11 = Object.prototype;
  var hasOwnProperty9 = objectProto11.hasOwnProperty;
  function hashHas(key) {
    var data = this.__data__;
    return nativeCreate_default ? data[key] !== void 0 : hasOwnProperty9.call(data, key);
  }
  var hashHas_default = hashHas;

  // node_modules/lodash-es/_hashSet.js
  init_define_import_meta_env();
  var HASH_UNDEFINED2 = "__lodash_hash_undefined__";
  function hashSet(key, value) {
    var data = this.__data__;
    this.size += this.has(key) ? 0 : 1;
    data[key] = nativeCreate_default && value === void 0 ? HASH_UNDEFINED2 : value;
    return this;
  }
  var hashSet_default = hashSet;

  // node_modules/lodash-es/_Hash.js
  function Hash(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  Hash.prototype.clear = hashClear_default;
  Hash.prototype["delete"] = hashDelete_default;
  Hash.prototype.get = hashGet_default;
  Hash.prototype.has = hashHas_default;
  Hash.prototype.set = hashSet_default;
  var Hash_default = Hash;

  // node_modules/lodash-es/_ListCache.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_listCacheClear.js
  init_define_import_meta_env();
  function listCacheClear() {
    this.__data__ = [];
    this.size = 0;
  }
  var listCacheClear_default = listCacheClear;

  // node_modules/lodash-es/_listCacheDelete.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_assocIndexOf.js
  init_define_import_meta_env();
  function assocIndexOf(array, key) {
    var length = array.length;
    while (length--) {
      if (eq_default(array[length][0], key)) {
        return length;
      }
    }
    return -1;
  }
  var assocIndexOf_default = assocIndexOf;

  // node_modules/lodash-es/_listCacheDelete.js
  var arrayProto = Array.prototype;
  var splice = arrayProto.splice;
  function listCacheDelete(key) {
    var data = this.__data__, index = assocIndexOf_default(data, key);
    if (index < 0) {
      return false;
    }
    var lastIndex = data.length - 1;
    if (index == lastIndex) {
      data.pop();
    } else {
      splice.call(data, index, 1);
    }
    --this.size;
    return true;
  }
  var listCacheDelete_default = listCacheDelete;

  // node_modules/lodash-es/_listCacheGet.js
  init_define_import_meta_env();
  function listCacheGet(key) {
    var data = this.__data__, index = assocIndexOf_default(data, key);
    return index < 0 ? void 0 : data[index][1];
  }
  var listCacheGet_default = listCacheGet;

  // node_modules/lodash-es/_listCacheHas.js
  init_define_import_meta_env();
  function listCacheHas(key) {
    return assocIndexOf_default(this.__data__, key) > -1;
  }
  var listCacheHas_default = listCacheHas;

  // node_modules/lodash-es/_listCacheSet.js
  init_define_import_meta_env();
  function listCacheSet(key, value) {
    var data = this.__data__, index = assocIndexOf_default(data, key);
    if (index < 0) {
      ++this.size;
      data.push([key, value]);
    } else {
      data[index][1] = value;
    }
    return this;
  }
  var listCacheSet_default = listCacheSet;

  // node_modules/lodash-es/_ListCache.js
  function ListCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  ListCache.prototype.clear = listCacheClear_default;
  ListCache.prototype["delete"] = listCacheDelete_default;
  ListCache.prototype.get = listCacheGet_default;
  ListCache.prototype.has = listCacheHas_default;
  ListCache.prototype.set = listCacheSet_default;
  var ListCache_default = ListCache;

  // node_modules/lodash-es/_Map.js
  init_define_import_meta_env();
  var Map2 = getNative_default(root_default, "Map");
  var Map_default = Map2;

  // node_modules/lodash-es/_mapCacheClear.js
  function mapCacheClear() {
    this.size = 0;
    this.__data__ = {
      "hash": new Hash_default(),
      "map": new (Map_default || ListCache_default)(),
      "string": new Hash_default()
    };
  }
  var mapCacheClear_default = mapCacheClear;

  // node_modules/lodash-es/_mapCacheDelete.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_getMapData.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_isKeyable.js
  init_define_import_meta_env();
  function isKeyable(value) {
    var type = typeof value;
    return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
  }
  var isKeyable_default = isKeyable;

  // node_modules/lodash-es/_getMapData.js
  function getMapData(map, key) {
    var data = map.__data__;
    return isKeyable_default(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
  }
  var getMapData_default = getMapData;

  // node_modules/lodash-es/_mapCacheDelete.js
  function mapCacheDelete(key) {
    var result = getMapData_default(this, key)["delete"](key);
    this.size -= result ? 1 : 0;
    return result;
  }
  var mapCacheDelete_default = mapCacheDelete;

  // node_modules/lodash-es/_mapCacheGet.js
  init_define_import_meta_env();
  function mapCacheGet(key) {
    return getMapData_default(this, key).get(key);
  }
  var mapCacheGet_default = mapCacheGet;

  // node_modules/lodash-es/_mapCacheHas.js
  init_define_import_meta_env();
  function mapCacheHas(key) {
    return getMapData_default(this, key).has(key);
  }
  var mapCacheHas_default = mapCacheHas;

  // node_modules/lodash-es/_mapCacheSet.js
  init_define_import_meta_env();
  function mapCacheSet(key, value) {
    var data = getMapData_default(this, key), size = data.size;
    data.set(key, value);
    this.size += data.size == size ? 0 : 1;
    return this;
  }
  var mapCacheSet_default = mapCacheSet;

  // node_modules/lodash-es/_MapCache.js
  function MapCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  MapCache.prototype.clear = mapCacheClear_default;
  MapCache.prototype["delete"] = mapCacheDelete_default;
  MapCache.prototype.get = mapCacheGet_default;
  MapCache.prototype.has = mapCacheHas_default;
  MapCache.prototype.set = mapCacheSet_default;
  var MapCache_default = MapCache;

  // node_modules/lodash-es/memoize.js
  var FUNC_ERROR_TEXT = "Expected a function";
  function memoize(func, resolver) {
    if (typeof func != "function" || resolver != null && typeof resolver != "function") {
      throw new TypeError(FUNC_ERROR_TEXT);
    }
    var memoized = function() {
      var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
      if (cache.has(key)) {
        return cache.get(key);
      }
      var result = func.apply(this, args);
      memoized.cache = cache.set(key, result) || cache;
      return result;
    };
    memoized.cache = new (memoize.Cache || MapCache_default)();
    return memoized;
  }
  memoize.Cache = MapCache_default;
  var memoize_default = memoize;

  // node_modules/lodash-es/_memoizeCapped.js
  var MAX_MEMOIZE_SIZE = 500;
  function memoizeCapped(func) {
    var result = memoize_default(func, function(key) {
      if (cache.size === MAX_MEMOIZE_SIZE) {
        cache.clear();
      }
      return key;
    });
    var cache = result.cache;
    return result;
  }
  var memoizeCapped_default = memoizeCapped;

  // node_modules/lodash-es/_stringToPath.js
  var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
  var reEscapeChar = /\\(\\)?/g;
  var stringToPath = memoizeCapped_default(function(string) {
    var result = [];
    if (string.charCodeAt(0) === 46) {
      result.push("");
    }
    string.replace(rePropName, function(match, number, quote, subString) {
      result.push(quote ? subString.replace(reEscapeChar, "$1") : number || match);
    });
    return result;
  });
  var stringToPath_default = stringToPath;

  // node_modules/lodash-es/toString.js
  init_define_import_meta_env();
  function toString(value) {
    return value == null ? "" : baseToString_default(value);
  }
  var toString_default = toString;

  // node_modules/lodash-es/_castPath.js
  function castPath(value, object) {
    if (isArray_default(value)) {
      return value;
    }
    return isKey_default(value, object) ? [value] : stringToPath_default(toString_default(value));
  }
  var castPath_default = castPath;

  // node_modules/lodash-es/_toKey.js
  init_define_import_meta_env();
  var INFINITY2 = 1 / 0;
  function toKey(value) {
    if (typeof value == "string" || isSymbol_default(value)) {
      return value;
    }
    var result = value + "";
    return result == "0" && 1 / value == -INFINITY2 ? "-0" : result;
  }
  var toKey_default = toKey;

  // node_modules/lodash-es/_baseGet.js
  function baseGet(object, path) {
    path = castPath_default(path, object);
    var index = 0, length = path.length;
    while (object != null && index < length) {
      object = object[toKey_default(path[index++])];
    }
    return index && index == length ? object : void 0;
  }
  var baseGet_default = baseGet;

  // node_modules/lodash-es/get.js
  function get(object, path, defaultValue) {
    var result = object == null ? void 0 : baseGet_default(object, path);
    return result === void 0 ? defaultValue : result;
  }
  var get_default = get;

  // node_modules/lodash-es/_arrayPush.js
  init_define_import_meta_env();
  function arrayPush(array, values) {
    var index = -1, length = values.length, offset = array.length;
    while (++index < length) {
      array[offset + index] = values[index];
    }
    return array;
  }
  var arrayPush_default = arrayPush;

  // node_modules/lodash-es/isPlainObject.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_getPrototype.js
  init_define_import_meta_env();
  var getPrototype = overArg_default(Object.getPrototypeOf, Object);
  var getPrototype_default = getPrototype;

  // node_modules/lodash-es/isPlainObject.js
  var objectTag2 = "[object Object]";
  var funcProto3 = Function.prototype;
  var objectProto12 = Object.prototype;
  var funcToString3 = funcProto3.toString;
  var hasOwnProperty10 = objectProto12.hasOwnProperty;
  var objectCtorString = funcToString3.call(Object);
  function isPlainObject(value) {
    if (!isObjectLike_default(value) || baseGetTag_default(value) != objectTag2) {
      return false;
    }
    var proto = getPrototype_default(value);
    if (proto === null) {
      return true;
    }
    var Ctor = hasOwnProperty10.call(proto, "constructor") && proto.constructor;
    return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString3.call(Ctor) == objectCtorString;
  }
  var isPlainObject_default = isPlainObject;

  // node_modules/lodash-es/_baseClone.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_Stack.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_stackClear.js
  init_define_import_meta_env();
  function stackClear() {
    this.__data__ = new ListCache_default();
    this.size = 0;
  }
  var stackClear_default = stackClear;

  // node_modules/lodash-es/_stackDelete.js
  init_define_import_meta_env();
  function stackDelete(key) {
    var data = this.__data__, result = data["delete"](key);
    this.size = data.size;
    return result;
  }
  var stackDelete_default = stackDelete;

  // node_modules/lodash-es/_stackGet.js
  init_define_import_meta_env();
  function stackGet(key) {
    return this.__data__.get(key);
  }
  var stackGet_default = stackGet;

  // node_modules/lodash-es/_stackHas.js
  init_define_import_meta_env();
  function stackHas(key) {
    return this.__data__.has(key);
  }
  var stackHas_default = stackHas;

  // node_modules/lodash-es/_stackSet.js
  init_define_import_meta_env();
  var LARGE_ARRAY_SIZE = 200;
  function stackSet(key, value) {
    var data = this.__data__;
    if (data instanceof ListCache_default) {
      var pairs = data.__data__;
      if (!Map_default || pairs.length < LARGE_ARRAY_SIZE - 1) {
        pairs.push([key, value]);
        this.size = ++data.size;
        return this;
      }
      data = this.__data__ = new MapCache_default(pairs);
    }
    data.set(key, value);
    this.size = data.size;
    return this;
  }
  var stackSet_default = stackSet;

  // node_modules/lodash-es/_Stack.js
  function Stack(entries) {
    var data = this.__data__ = new ListCache_default(entries);
    this.size = data.size;
  }
  Stack.prototype.clear = stackClear_default;
  Stack.prototype["delete"] = stackDelete_default;
  Stack.prototype.get = stackGet_default;
  Stack.prototype.has = stackHas_default;
  Stack.prototype.set = stackSet_default;
  var Stack_default = Stack;

  // node_modules/lodash-es/_baseAssign.js
  init_define_import_meta_env();
  function baseAssign(object, source) {
    return object && copyObject_default(source, keys_default(source), object);
  }
  var baseAssign_default = baseAssign;

  // node_modules/lodash-es/_baseAssignIn.js
  init_define_import_meta_env();
  function baseAssignIn(object, source) {
    return object && copyObject_default(source, keysIn_default(source), object);
  }
  var baseAssignIn_default = baseAssignIn;

  // node_modules/lodash-es/_cloneBuffer.js
  init_define_import_meta_env();
  var freeExports3 = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule3 = freeExports3 && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports3 = freeModule3 && freeModule3.exports === freeExports3;
  var Buffer3 = moduleExports3 ? root_default.Buffer : void 0;
  var allocUnsafe = Buffer3 ? Buffer3.allocUnsafe : void 0;
  function cloneBuffer(buffer, isDeep) {
    if (isDeep) {
      return buffer.slice();
    }
    var length = buffer.length, result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
    buffer.copy(result);
    return result;
  }
  var cloneBuffer_default = cloneBuffer;

  // node_modules/lodash-es/_copySymbols.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_getSymbols.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_arrayFilter.js
  init_define_import_meta_env();
  function arrayFilter(array, predicate) {
    var index = -1, length = array == null ? 0 : array.length, resIndex = 0, result = [];
    while (++index < length) {
      var value = array[index];
      if (predicate(value, index, array)) {
        result[resIndex++] = value;
      }
    }
    return result;
  }
  var arrayFilter_default = arrayFilter;

  // node_modules/lodash-es/stubArray.js
  init_define_import_meta_env();
  function stubArray() {
    return [];
  }
  var stubArray_default = stubArray;

  // node_modules/lodash-es/_getSymbols.js
  var objectProto13 = Object.prototype;
  var propertyIsEnumerable2 = objectProto13.propertyIsEnumerable;
  var nativeGetSymbols = Object.getOwnPropertySymbols;
  var getSymbols = !nativeGetSymbols ? stubArray_default : function(object) {
    if (object == null) {
      return [];
    }
    object = Object(object);
    return arrayFilter_default(nativeGetSymbols(object), function(symbol) {
      return propertyIsEnumerable2.call(object, symbol);
    });
  };
  var getSymbols_default = getSymbols;

  // node_modules/lodash-es/_copySymbols.js
  function copySymbols(source, object) {
    return copyObject_default(source, getSymbols_default(source), object);
  }
  var copySymbols_default = copySymbols;

  // node_modules/lodash-es/_copySymbolsIn.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_getSymbolsIn.js
  init_define_import_meta_env();
  var nativeGetSymbols2 = Object.getOwnPropertySymbols;
  var getSymbolsIn = !nativeGetSymbols2 ? stubArray_default : function(object) {
    var result = [];
    while (object) {
      arrayPush_default(result, getSymbols_default(object));
      object = getPrototype_default(object);
    }
    return result;
  };
  var getSymbolsIn_default = getSymbolsIn;

  // node_modules/lodash-es/_copySymbolsIn.js
  function copySymbolsIn(source, object) {
    return copyObject_default(source, getSymbolsIn_default(source), object);
  }
  var copySymbolsIn_default = copySymbolsIn;

  // node_modules/lodash-es/_getAllKeys.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseGetAllKeys.js
  init_define_import_meta_env();
  function baseGetAllKeys(object, keysFunc, symbolsFunc) {
    var result = keysFunc(object);
    return isArray_default(object) ? result : arrayPush_default(result, symbolsFunc(object));
  }
  var baseGetAllKeys_default = baseGetAllKeys;

  // node_modules/lodash-es/_getAllKeys.js
  function getAllKeys(object) {
    return baseGetAllKeys_default(object, keys_default, getSymbols_default);
  }
  var getAllKeys_default = getAllKeys;

  // node_modules/lodash-es/_getAllKeysIn.js
  init_define_import_meta_env();
  function getAllKeysIn(object) {
    return baseGetAllKeys_default(object, keysIn_default, getSymbolsIn_default);
  }
  var getAllKeysIn_default = getAllKeysIn;

  // node_modules/lodash-es/_getTag.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_DataView.js
  init_define_import_meta_env();
  var DataView2 = getNative_default(root_default, "DataView");
  var DataView_default = DataView2;

  // node_modules/lodash-es/_Promise.js
  init_define_import_meta_env();
  var Promise2 = getNative_default(root_default, "Promise");
  var Promise_default = Promise2;

  // node_modules/lodash-es/_Set.js
  init_define_import_meta_env();
  var Set2 = getNative_default(root_default, "Set");
  var Set_default = Set2;

  // node_modules/lodash-es/_getTag.js
  var mapTag2 = "[object Map]";
  var objectTag3 = "[object Object]";
  var promiseTag = "[object Promise]";
  var setTag2 = "[object Set]";
  var weakMapTag2 = "[object WeakMap]";
  var dataViewTag2 = "[object DataView]";
  var dataViewCtorString = toSource_default(DataView_default);
  var mapCtorString = toSource_default(Map_default);
  var promiseCtorString = toSource_default(Promise_default);
  var setCtorString = toSource_default(Set_default);
  var weakMapCtorString = toSource_default(WeakMap_default);
  var getTag = baseGetTag_default;
  if (DataView_default && getTag(new DataView_default(new ArrayBuffer(1))) != dataViewTag2 || Map_default && getTag(new Map_default()) != mapTag2 || Promise_default && getTag(Promise_default.resolve()) != promiseTag || Set_default && getTag(new Set_default()) != setTag2 || WeakMap_default && getTag(new WeakMap_default()) != weakMapTag2) {
    getTag = function(value) {
      var result = baseGetTag_default(value), Ctor = result == objectTag3 ? value.constructor : void 0, ctorString = Ctor ? toSource_default(Ctor) : "";
      if (ctorString) {
        switch (ctorString) {
          case dataViewCtorString:
            return dataViewTag2;
          case mapCtorString:
            return mapTag2;
          case promiseCtorString:
            return promiseTag;
          case setCtorString:
            return setTag2;
          case weakMapCtorString:
            return weakMapTag2;
        }
      }
      return result;
    };
  }
  var getTag_default = getTag;

  // node_modules/lodash-es/_initCloneArray.js
  init_define_import_meta_env();
  var objectProto14 = Object.prototype;
  var hasOwnProperty11 = objectProto14.hasOwnProperty;
  function initCloneArray(array) {
    var length = array.length, result = new array.constructor(length);
    if (length && typeof array[0] == "string" && hasOwnProperty11.call(array, "index")) {
      result.index = array.index;
      result.input = array.input;
    }
    return result;
  }
  var initCloneArray_default = initCloneArray;

  // node_modules/lodash-es/_initCloneByTag.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_cloneArrayBuffer.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_Uint8Array.js
  init_define_import_meta_env();
  var Uint8Array2 = root_default.Uint8Array;
  var Uint8Array_default = Uint8Array2;

  // node_modules/lodash-es/_cloneArrayBuffer.js
  function cloneArrayBuffer(arrayBuffer) {
    var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
    new Uint8Array_default(result).set(new Uint8Array_default(arrayBuffer));
    return result;
  }
  var cloneArrayBuffer_default = cloneArrayBuffer;

  // node_modules/lodash-es/_cloneDataView.js
  init_define_import_meta_env();
  function cloneDataView(dataView, isDeep) {
    var buffer = isDeep ? cloneArrayBuffer_default(dataView.buffer) : dataView.buffer;
    return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
  }
  var cloneDataView_default = cloneDataView;

  // node_modules/lodash-es/_cloneRegExp.js
  init_define_import_meta_env();
  var reFlags = /\w*$/;
  function cloneRegExp(regexp) {
    var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
    result.lastIndex = regexp.lastIndex;
    return result;
  }
  var cloneRegExp_default = cloneRegExp;

  // node_modules/lodash-es/_cloneSymbol.js
  init_define_import_meta_env();
  var symbolProto2 = Symbol_default ? Symbol_default.prototype : void 0;
  var symbolValueOf = symbolProto2 ? symbolProto2.valueOf : void 0;
  function cloneSymbol(symbol) {
    return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
  }
  var cloneSymbol_default = cloneSymbol;

  // node_modules/lodash-es/_cloneTypedArray.js
  init_define_import_meta_env();
  function cloneTypedArray(typedArray, isDeep) {
    var buffer = isDeep ? cloneArrayBuffer_default(typedArray.buffer) : typedArray.buffer;
    return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
  }
  var cloneTypedArray_default = cloneTypedArray;

  // node_modules/lodash-es/_initCloneByTag.js
  var boolTag2 = "[object Boolean]";
  var dateTag2 = "[object Date]";
  var mapTag3 = "[object Map]";
  var numberTag2 = "[object Number]";
  var regexpTag2 = "[object RegExp]";
  var setTag3 = "[object Set]";
  var stringTag2 = "[object String]";
  var symbolTag2 = "[object Symbol]";
  var arrayBufferTag2 = "[object ArrayBuffer]";
  var dataViewTag3 = "[object DataView]";
  var float32Tag2 = "[object Float32Array]";
  var float64Tag2 = "[object Float64Array]";
  var int8Tag2 = "[object Int8Array]";
  var int16Tag2 = "[object Int16Array]";
  var int32Tag2 = "[object Int32Array]";
  var uint8Tag2 = "[object Uint8Array]";
  var uint8ClampedTag2 = "[object Uint8ClampedArray]";
  var uint16Tag2 = "[object Uint16Array]";
  var uint32Tag2 = "[object Uint32Array]";
  function initCloneByTag(object, tag, isDeep) {
    var Ctor = object.constructor;
    switch (tag) {
      case arrayBufferTag2:
        return cloneArrayBuffer_default(object);
      case boolTag2:
      case dateTag2:
        return new Ctor(+object);
      case dataViewTag3:
        return cloneDataView_default(object, isDeep);
      case float32Tag2:
      case float64Tag2:
      case int8Tag2:
      case int16Tag2:
      case int32Tag2:
      case uint8Tag2:
      case uint8ClampedTag2:
      case uint16Tag2:
      case uint32Tag2:
        return cloneTypedArray_default(object, isDeep);
      case mapTag3:
        return new Ctor();
      case numberTag2:
      case stringTag2:
        return new Ctor(object);
      case regexpTag2:
        return cloneRegExp_default(object);
      case setTag3:
        return new Ctor();
      case symbolTag2:
        return cloneSymbol_default(object);
    }
  }
  var initCloneByTag_default = initCloneByTag;

  // node_modules/lodash-es/_initCloneObject.js
  init_define_import_meta_env();
  function initCloneObject(object) {
    return typeof object.constructor == "function" && !isPrototype_default(object) ? baseCreate_default(getPrototype_default(object)) : {};
  }
  var initCloneObject_default = initCloneObject;

  // node_modules/lodash-es/isMap.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseIsMap.js
  init_define_import_meta_env();
  var mapTag4 = "[object Map]";
  function baseIsMap(value) {
    return isObjectLike_default(value) && getTag_default(value) == mapTag4;
  }
  var baseIsMap_default = baseIsMap;

  // node_modules/lodash-es/isMap.js
  var nodeIsMap = nodeUtil_default && nodeUtil_default.isMap;
  var isMap = nodeIsMap ? baseUnary_default(nodeIsMap) : baseIsMap_default;
  var isMap_default = isMap;

  // node_modules/lodash-es/isSet.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseIsSet.js
  init_define_import_meta_env();
  var setTag4 = "[object Set]";
  function baseIsSet(value) {
    return isObjectLike_default(value) && getTag_default(value) == setTag4;
  }
  var baseIsSet_default = baseIsSet;

  // node_modules/lodash-es/isSet.js
  var nodeIsSet = nodeUtil_default && nodeUtil_default.isSet;
  var isSet = nodeIsSet ? baseUnary_default(nodeIsSet) : baseIsSet_default;
  var isSet_default = isSet;

  // node_modules/lodash-es/_baseClone.js
  var CLONE_DEEP_FLAG = 1;
  var CLONE_FLAT_FLAG = 2;
  var CLONE_SYMBOLS_FLAG = 4;
  var argsTag3 = "[object Arguments]";
  var arrayTag2 = "[object Array]";
  var boolTag3 = "[object Boolean]";
  var dateTag3 = "[object Date]";
  var errorTag2 = "[object Error]";
  var funcTag3 = "[object Function]";
  var genTag2 = "[object GeneratorFunction]";
  var mapTag5 = "[object Map]";
  var numberTag3 = "[object Number]";
  var objectTag4 = "[object Object]";
  var regexpTag3 = "[object RegExp]";
  var setTag5 = "[object Set]";
  var stringTag3 = "[object String]";
  var symbolTag3 = "[object Symbol]";
  var weakMapTag3 = "[object WeakMap]";
  var arrayBufferTag3 = "[object ArrayBuffer]";
  var dataViewTag4 = "[object DataView]";
  var float32Tag3 = "[object Float32Array]";
  var float64Tag3 = "[object Float64Array]";
  var int8Tag3 = "[object Int8Array]";
  var int16Tag3 = "[object Int16Array]";
  var int32Tag3 = "[object Int32Array]";
  var uint8Tag3 = "[object Uint8Array]";
  var uint8ClampedTag3 = "[object Uint8ClampedArray]";
  var uint16Tag3 = "[object Uint16Array]";
  var uint32Tag3 = "[object Uint32Array]";
  var cloneableTags = {};
  cloneableTags[argsTag3] = cloneableTags[arrayTag2] = cloneableTags[arrayBufferTag3] = cloneableTags[dataViewTag4] = cloneableTags[boolTag3] = cloneableTags[dateTag3] = cloneableTags[float32Tag3] = cloneableTags[float64Tag3] = cloneableTags[int8Tag3] = cloneableTags[int16Tag3] = cloneableTags[int32Tag3] = cloneableTags[mapTag5] = cloneableTags[numberTag3] = cloneableTags[objectTag4] = cloneableTags[regexpTag3] = cloneableTags[setTag5] = cloneableTags[stringTag3] = cloneableTags[symbolTag3] = cloneableTags[uint8Tag3] = cloneableTags[uint8ClampedTag3] = cloneableTags[uint16Tag3] = cloneableTags[uint32Tag3] = true;
  cloneableTags[errorTag2] = cloneableTags[funcTag3] = cloneableTags[weakMapTag3] = false;
  function baseClone(value, bitmask, customizer, key, object, stack) {
    var result, isDeep = bitmask & CLONE_DEEP_FLAG, isFlat = bitmask & CLONE_FLAT_FLAG, isFull = bitmask & CLONE_SYMBOLS_FLAG;
    if (customizer) {
      result = object ? customizer(value, key, object, stack) : customizer(value);
    }
    if (result !== void 0) {
      return result;
    }
    if (!isObject_default(value)) {
      return value;
    }
    var isArr = isArray_default(value);
    if (isArr) {
      result = initCloneArray_default(value);
      if (!isDeep) {
        return copyArray_default(value, result);
      }
    } else {
      var tag = getTag_default(value), isFunc = tag == funcTag3 || tag == genTag2;
      if (isBuffer_default(value)) {
        return cloneBuffer_default(value, isDeep);
      }
      if (tag == objectTag4 || tag == argsTag3 || isFunc && !object) {
        result = isFlat || isFunc ? {} : initCloneObject_default(value);
        if (!isDeep) {
          return isFlat ? copySymbolsIn_default(value, baseAssignIn_default(result, value)) : copySymbols_default(value, baseAssign_default(result, value));
        }
      } else {
        if (!cloneableTags[tag]) {
          return object ? value : {};
        }
        result = initCloneByTag_default(value, tag, isDeep);
      }
    }
    stack || (stack = new Stack_default());
    var stacked = stack.get(value);
    if (stacked) {
      return stacked;
    }
    stack.set(value, result);
    if (isSet_default(value)) {
      value.forEach(function(subValue) {
        result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
      });
    } else if (isMap_default(value)) {
      value.forEach(function(subValue, key2) {
        result.set(key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
      });
    }
    var keysFunc = isFull ? isFlat ? getAllKeysIn_default : getAllKeys_default : isFlat ? keysIn_default : keys_default;
    var props = isArr ? void 0 : keysFunc(value);
    arrayEach_default(props || value, function(subValue, key2) {
      if (props) {
        key2 = subValue;
        subValue = value[key2];
      }
      assignValue_default(result, key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
    });
    return result;
  }
  var baseClone_default = baseClone;

  // node_modules/lodash-es/cloneDeep.js
  init_define_import_meta_env();
  var CLONE_DEEP_FLAG2 = 1;
  var CLONE_SYMBOLS_FLAG2 = 4;
  function cloneDeep(value) {
    return baseClone_default(value, CLONE_DEEP_FLAG2 | CLONE_SYMBOLS_FLAG2);
  }
  var cloneDeep_default = cloneDeep;

  // node_modules/lodash-es/_baseIsEqual.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseIsEqualDeep.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_equalArrays.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_SetCache.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_setCacheAdd.js
  init_define_import_meta_env();
  var HASH_UNDEFINED3 = "__lodash_hash_undefined__";
  function setCacheAdd(value) {
    this.__data__.set(value, HASH_UNDEFINED3);
    return this;
  }
  var setCacheAdd_default = setCacheAdd;

  // node_modules/lodash-es/_setCacheHas.js
  init_define_import_meta_env();
  function setCacheHas(value) {
    return this.__data__.has(value);
  }
  var setCacheHas_default = setCacheHas;

  // node_modules/lodash-es/_SetCache.js
  function SetCache(values) {
    var index = -1, length = values == null ? 0 : values.length;
    this.__data__ = new MapCache_default();
    while (++index < length) {
      this.add(values[index]);
    }
  }
  SetCache.prototype.add = SetCache.prototype.push = setCacheAdd_default;
  SetCache.prototype.has = setCacheHas_default;
  var SetCache_default = SetCache;

  // node_modules/lodash-es/_arraySome.js
  init_define_import_meta_env();
  function arraySome(array, predicate) {
    var index = -1, length = array == null ? 0 : array.length;
    while (++index < length) {
      if (predicate(array[index], index, array)) {
        return true;
      }
    }
    return false;
  }
  var arraySome_default = arraySome;

  // node_modules/lodash-es/_cacheHas.js
  init_define_import_meta_env();
  function cacheHas(cache, key) {
    return cache.has(key);
  }
  var cacheHas_default = cacheHas;

  // node_modules/lodash-es/_equalArrays.js
  var COMPARE_PARTIAL_FLAG = 1;
  var COMPARE_UNORDERED_FLAG = 2;
  function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
    var isPartial = bitmask & COMPARE_PARTIAL_FLAG, arrLength = array.length, othLength = other.length;
    if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
      return false;
    }
    var arrStacked = stack.get(array);
    var othStacked = stack.get(other);
    if (arrStacked && othStacked) {
      return arrStacked == other && othStacked == array;
    }
    var index = -1, result = true, seen = bitmask & COMPARE_UNORDERED_FLAG ? new SetCache_default() : void 0;
    stack.set(array, other);
    stack.set(other, array);
    while (++index < arrLength) {
      var arrValue = array[index], othValue = other[index];
      if (customizer) {
        var compared = isPartial ? customizer(othValue, arrValue, index, other, array, stack) : customizer(arrValue, othValue, index, array, other, stack);
      }
      if (compared !== void 0) {
        if (compared) {
          continue;
        }
        result = false;
        break;
      }
      if (seen) {
        if (!arraySome_default(other, function(othValue2, othIndex) {
          if (!cacheHas_default(seen, othIndex) && (arrValue === othValue2 || equalFunc(arrValue, othValue2, bitmask, customizer, stack))) {
            return seen.push(othIndex);
          }
        })) {
          result = false;
          break;
        }
      } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
        result = false;
        break;
      }
    }
    stack["delete"](array);
    stack["delete"](other);
    return result;
  }
  var equalArrays_default = equalArrays;

  // node_modules/lodash-es/_equalByTag.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_mapToArray.js
  init_define_import_meta_env();
  function mapToArray(map) {
    var index = -1, result = Array(map.size);
    map.forEach(function(value, key) {
      result[++index] = [key, value];
    });
    return result;
  }
  var mapToArray_default = mapToArray;

  // node_modules/lodash-es/_setToArray.js
  init_define_import_meta_env();
  function setToArray(set2) {
    var index = -1, result = Array(set2.size);
    set2.forEach(function(value) {
      result[++index] = value;
    });
    return result;
  }
  var setToArray_default = setToArray;

  // node_modules/lodash-es/_equalByTag.js
  var COMPARE_PARTIAL_FLAG2 = 1;
  var COMPARE_UNORDERED_FLAG2 = 2;
  var boolTag4 = "[object Boolean]";
  var dateTag4 = "[object Date]";
  var errorTag3 = "[object Error]";
  var mapTag6 = "[object Map]";
  var numberTag4 = "[object Number]";
  var regexpTag4 = "[object RegExp]";
  var setTag6 = "[object Set]";
  var stringTag4 = "[object String]";
  var symbolTag4 = "[object Symbol]";
  var arrayBufferTag4 = "[object ArrayBuffer]";
  var dataViewTag5 = "[object DataView]";
  var symbolProto3 = Symbol_default ? Symbol_default.prototype : void 0;
  var symbolValueOf2 = symbolProto3 ? symbolProto3.valueOf : void 0;
  function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
    switch (tag) {
      case dataViewTag5:
        if (object.byteLength != other.byteLength || object.byteOffset != other.byteOffset) {
          return false;
        }
        object = object.buffer;
        other = other.buffer;
      case arrayBufferTag4:
        if (object.byteLength != other.byteLength || !equalFunc(new Uint8Array_default(object), new Uint8Array_default(other))) {
          return false;
        }
        return true;
      case boolTag4:
      case dateTag4:
      case numberTag4:
        return eq_default(+object, +other);
      case errorTag3:
        return object.name == other.name && object.message == other.message;
      case regexpTag4:
      case stringTag4:
        return object == other + "";
      case mapTag6:
        var convert = mapToArray_default;
      case setTag6:
        var isPartial = bitmask & COMPARE_PARTIAL_FLAG2;
        convert || (convert = setToArray_default);
        if (object.size != other.size && !isPartial) {
          return false;
        }
        var stacked = stack.get(object);
        if (stacked) {
          return stacked == other;
        }
        bitmask |= COMPARE_UNORDERED_FLAG2;
        stack.set(object, other);
        var result = equalArrays_default(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
        stack["delete"](object);
        return result;
      case symbolTag4:
        if (symbolValueOf2) {
          return symbolValueOf2.call(object) == symbolValueOf2.call(other);
        }
    }
    return false;
  }
  var equalByTag_default = equalByTag;

  // node_modules/lodash-es/_equalObjects.js
  init_define_import_meta_env();
  var COMPARE_PARTIAL_FLAG3 = 1;
  var objectProto15 = Object.prototype;
  var hasOwnProperty12 = objectProto15.hasOwnProperty;
  function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
    var isPartial = bitmask & COMPARE_PARTIAL_FLAG3, objProps = getAllKeys_default(object), objLength = objProps.length, othProps = getAllKeys_default(other), othLength = othProps.length;
    if (objLength != othLength && !isPartial) {
      return false;
    }
    var index = objLength;
    while (index--) {
      var key = objProps[index];
      if (!(isPartial ? key in other : hasOwnProperty12.call(other, key))) {
        return false;
      }
    }
    var objStacked = stack.get(object);
    var othStacked = stack.get(other);
    if (objStacked && othStacked) {
      return objStacked == other && othStacked == object;
    }
    var result = true;
    stack.set(object, other);
    stack.set(other, object);
    var skipCtor = isPartial;
    while (++index < objLength) {
      key = objProps[index];
      var objValue = object[key], othValue = other[key];
      if (customizer) {
        var compared = isPartial ? customizer(othValue, objValue, key, other, object, stack) : customizer(objValue, othValue, key, object, other, stack);
      }
      if (!(compared === void 0 ? objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack) : compared)) {
        result = false;
        break;
      }
      skipCtor || (skipCtor = key == "constructor");
    }
    if (result && !skipCtor) {
      var objCtor = object.constructor, othCtor = other.constructor;
      if (objCtor != othCtor && ("constructor" in object && "constructor" in other) && !(typeof objCtor == "function" && objCtor instanceof objCtor && typeof othCtor == "function" && othCtor instanceof othCtor)) {
        result = false;
      }
    }
    stack["delete"](object);
    stack["delete"](other);
    return result;
  }
  var equalObjects_default = equalObjects;

  // node_modules/lodash-es/_baseIsEqualDeep.js
  var COMPARE_PARTIAL_FLAG4 = 1;
  var argsTag4 = "[object Arguments]";
  var arrayTag3 = "[object Array]";
  var objectTag5 = "[object Object]";
  var objectProto16 = Object.prototype;
  var hasOwnProperty13 = objectProto16.hasOwnProperty;
  function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
    var objIsArr = isArray_default(object), othIsArr = isArray_default(other), objTag = objIsArr ? arrayTag3 : getTag_default(object), othTag = othIsArr ? arrayTag3 : getTag_default(other);
    objTag = objTag == argsTag4 ? objectTag5 : objTag;
    othTag = othTag == argsTag4 ? objectTag5 : othTag;
    var objIsObj = objTag == objectTag5, othIsObj = othTag == objectTag5, isSameTag = objTag == othTag;
    if (isSameTag && isBuffer_default(object)) {
      if (!isBuffer_default(other)) {
        return false;
      }
      objIsArr = true;
      objIsObj = false;
    }
    if (isSameTag && !objIsObj) {
      stack || (stack = new Stack_default());
      return objIsArr || isTypedArray_default(object) ? equalArrays_default(object, other, bitmask, customizer, equalFunc, stack) : equalByTag_default(object, other, objTag, bitmask, customizer, equalFunc, stack);
    }
    if (!(bitmask & COMPARE_PARTIAL_FLAG4)) {
      var objIsWrapped = objIsObj && hasOwnProperty13.call(object, "__wrapped__"), othIsWrapped = othIsObj && hasOwnProperty13.call(other, "__wrapped__");
      if (objIsWrapped || othIsWrapped) {
        var objUnwrapped = objIsWrapped ? object.value() : object, othUnwrapped = othIsWrapped ? other.value() : other;
        stack || (stack = new Stack_default());
        return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
      }
    }
    if (!isSameTag) {
      return false;
    }
    stack || (stack = new Stack_default());
    return equalObjects_default(object, other, bitmask, customizer, equalFunc, stack);
  }
  var baseIsEqualDeep_default = baseIsEqualDeep;

  // node_modules/lodash-es/_baseIsEqual.js
  function baseIsEqual(value, other, bitmask, customizer, stack) {
    if (value === other) {
      return true;
    }
    if (value == null || other == null || !isObjectLike_default(value) && !isObjectLike_default(other)) {
      return value !== value && other !== other;
    }
    return baseIsEqualDeep_default(value, other, bitmask, customizer, baseIsEqual, stack);
  }
  var baseIsEqual_default = baseIsEqual;

  // node_modules/lodash-es/_hasPath.js
  init_define_import_meta_env();
  function hasPath(object, path, hasFunc) {
    path = castPath_default(path, object);
    var index = -1, length = path.length, result = false;
    while (++index < length) {
      var key = toKey_default(path[index]);
      if (!(result = object != null && hasFunc(object, key))) {
        break;
      }
      object = object[key];
    }
    if (result || ++index != length) {
      return result;
    }
    length = object == null ? 0 : object.length;
    return !!length && isLength_default(length) && isIndex_default(key, length) && (isArray_default(object) || isArguments_default(object));
  }
  var hasPath_default = hasPath;

  // node_modules/lodash-es/_baseFor.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_createBaseFor.js
  init_define_import_meta_env();
  function createBaseFor(fromRight) {
    return function(object, iteratee, keysFunc) {
      var index = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
      while (length--) {
        var key = props[fromRight ? length : ++index];
        if (iteratee(iterable[key], key, iterable) === false) {
          break;
        }
      }
      return object;
    };
  }
  var createBaseFor_default = createBaseFor;

  // node_modules/lodash-es/_baseFor.js
  var baseFor = createBaseFor_default();
  var baseFor_default = baseFor;

  // node_modules/lodash-es/debounce.js
  init_define_import_meta_env();

  // node_modules/lodash-es/now.js
  init_define_import_meta_env();
  var now = function() {
    return root_default.Date.now();
  };
  var now_default = now;

  // node_modules/lodash-es/debounce.js
  var FUNC_ERROR_TEXT2 = "Expected a function";
  var nativeMax2 = Math.max;
  var nativeMin = Math.min;
  function debounce(func, wait, options) {
    var lastArgs, lastThis, maxWait, result, timerId, lastCallTime, lastInvokeTime = 0, leading = false, maxing = false, trailing = true;
    if (typeof func != "function") {
      throw new TypeError(FUNC_ERROR_TEXT2);
    }
    wait = toNumber_default(wait) || 0;
    if (isObject_default(options)) {
      leading = !!options.leading;
      maxing = "maxWait" in options;
      maxWait = maxing ? nativeMax2(toNumber_default(options.maxWait) || 0, wait) : maxWait;
      trailing = "trailing" in options ? !!options.trailing : trailing;
    }
    function invokeFunc(time) {
      var args = lastArgs, thisArg = lastThis;
      lastArgs = lastThis = void 0;
      lastInvokeTime = time;
      result = func.apply(thisArg, args);
      return result;
    }
    function leadingEdge(time) {
      lastInvokeTime = time;
      timerId = setTimeout(timerExpired, wait);
      return leading ? invokeFunc(time) : result;
    }
    function remainingWait(time) {
      var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime, timeWaiting = wait - timeSinceLastCall;
      return maxing ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting;
    }
    function shouldInvoke(time) {
      var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime;
      return lastCallTime === void 0 || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
    }
    function timerExpired() {
      var time = now_default();
      if (shouldInvoke(time)) {
        return trailingEdge(time);
      }
      timerId = setTimeout(timerExpired, remainingWait(time));
    }
    function trailingEdge(time) {
      timerId = void 0;
      if (trailing && lastArgs) {
        return invokeFunc(time);
      }
      lastArgs = lastThis = void 0;
      return result;
    }
    function cancel() {
      if (timerId !== void 0) {
        clearTimeout(timerId);
      }
      lastInvokeTime = 0;
      lastArgs = lastCallTime = lastThis = timerId = void 0;
    }
    function flush() {
      return timerId === void 0 ? result : trailingEdge(now_default());
    }
    function debounced() {
      var time = now_default(), isInvoking = shouldInvoke(time);
      lastArgs = arguments;
      lastThis = this;
      lastCallTime = time;
      if (isInvoking) {
        if (timerId === void 0) {
          return leadingEdge(lastCallTime);
        }
        if (maxing) {
          clearTimeout(timerId);
          timerId = setTimeout(timerExpired, wait);
          return invokeFunc(lastCallTime);
        }
      }
      if (timerId === void 0) {
        timerId = setTimeout(timerExpired, wait);
      }
      return result;
    }
    debounced.cancel = cancel;
    debounced.flush = flush;
    return debounced;
  }
  var debounce_default = debounce;

  // node_modules/lodash-es/_baseMerge.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_assignMergeValue.js
  init_define_import_meta_env();
  function assignMergeValue(object, key, value) {
    if (value !== void 0 && !eq_default(object[key], value) || value === void 0 && !(key in object)) {
      baseAssignValue_default(object, key, value);
    }
  }
  var assignMergeValue_default = assignMergeValue;

  // node_modules/lodash-es/_baseMergeDeep.js
  init_define_import_meta_env();

  // node_modules/lodash-es/isArrayLikeObject.js
  init_define_import_meta_env();
  function isArrayLikeObject(value) {
    return isObjectLike_default(value) && isArrayLike_default(value);
  }
  var isArrayLikeObject_default = isArrayLikeObject;

  // node_modules/lodash-es/_safeGet.js
  init_define_import_meta_env();
  function safeGet(object, key) {
    if (key === "constructor" && typeof object[key] === "function") {
      return;
    }
    if (key == "__proto__") {
      return;
    }
    return object[key];
  }
  var safeGet_default = safeGet;

  // node_modules/lodash-es/toPlainObject.js
  init_define_import_meta_env();
  function toPlainObject(value) {
    return copyObject_default(value, keysIn_default(value));
  }
  var toPlainObject_default = toPlainObject;

  // node_modules/lodash-es/_baseMergeDeep.js
  function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
    var objValue = safeGet_default(object, key), srcValue = safeGet_default(source, key), stacked = stack.get(srcValue);
    if (stacked) {
      assignMergeValue_default(object, key, stacked);
      return;
    }
    var newValue = customizer ? customizer(objValue, srcValue, key + "", object, source, stack) : void 0;
    var isCommon = newValue === void 0;
    if (isCommon) {
      var isArr = isArray_default(srcValue), isBuff = !isArr && isBuffer_default(srcValue), isTyped = !isArr && !isBuff && isTypedArray_default(srcValue);
      newValue = srcValue;
      if (isArr || isBuff || isTyped) {
        if (isArray_default(objValue)) {
          newValue = objValue;
        } else if (isArrayLikeObject_default(objValue)) {
          newValue = copyArray_default(objValue);
        } else if (isBuff) {
          isCommon = false;
          newValue = cloneBuffer_default(srcValue, true);
        } else if (isTyped) {
          isCommon = false;
          newValue = cloneTypedArray_default(srcValue, true);
        } else {
          newValue = [];
        }
      } else if (isPlainObject_default(srcValue) || isArguments_default(srcValue)) {
        newValue = objValue;
        if (isArguments_default(objValue)) {
          newValue = toPlainObject_default(objValue);
        } else if (!isObject_default(objValue) || isFunction_default(objValue)) {
          newValue = initCloneObject_default(srcValue);
        }
      } else {
        isCommon = false;
      }
    }
    if (isCommon) {
      stack.set(srcValue, newValue);
      mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
      stack["delete"](srcValue);
    }
    assignMergeValue_default(object, key, newValue);
  }
  var baseMergeDeep_default = baseMergeDeep;

  // node_modules/lodash-es/_baseMerge.js
  function baseMerge(object, source, srcIndex, customizer, stack) {
    if (object === source) {
      return;
    }
    baseFor_default(source, function(srcValue, key) {
      stack || (stack = new Stack_default());
      if (isObject_default(srcValue)) {
        baseMergeDeep_default(object, source, key, srcIndex, baseMerge, customizer, stack);
      } else {
        var newValue = customizer ? customizer(safeGet_default(object, key), srcValue, key + "", object, source, stack) : void 0;
        if (newValue === void 0) {
          newValue = srcValue;
        }
        assignMergeValue_default(object, key, newValue);
      }
    }, keysIn_default);
  }
  var baseMerge_default = baseMerge;

  // node_modules/lodash-es/has.js
  init_define_import_meta_env();

  // node_modules/lodash-es/_baseHas.js
  init_define_import_meta_env();
  var objectProto17 = Object.prototype;
  var hasOwnProperty14 = objectProto17.hasOwnProperty;
  function baseHas(object, key) {
    return object != null && hasOwnProperty14.call(object, key);
  }
  var baseHas_default = baseHas;

  // node_modules/lodash-es/has.js
  function has(object, path) {
    return object != null && hasPath_default(object, path, baseHas_default);
  }
  var has_default = has;

  // node_modules/lodash-es/isEqual.js
  init_define_import_meta_env();
  function isEqual(value, other) {
    return baseIsEqual_default(value, other);
  }
  var isEqual_default = isEqual;

  // node_modules/lodash-es/merge.js
  init_define_import_meta_env();
  var merge = createAssigner_default(function(object, source, srcIndex) {
    baseMerge_default(object, source, srcIndex);
  });
  var merge_default = merge;

  // node_modules/lodash-es/_baseSet.js
  init_define_import_meta_env();
  function baseSet(object, path, value, customizer) {
    if (!isObject_default(object)) {
      return object;
    }
    path = castPath_default(path, object);
    var index = -1, length = path.length, lastIndex = length - 1, nested = object;
    while (nested != null && ++index < length) {
      var key = toKey_default(path[index]), newValue = value;
      if (key === "__proto__" || key === "constructor" || key === "prototype") {
        return object;
      }
      if (index != lastIndex) {
        var objValue = nested[key];
        newValue = customizer ? customizer(objValue, key, nested) : void 0;
        if (newValue === void 0) {
          newValue = isObject_default(objValue) ? objValue : isIndex_default(path[index + 1]) ? [] : {};
        }
      }
      assignValue_default(nested, key, newValue);
      nested = nested[key];
    }
    return object;
  }
  var baseSet_default = baseSet;

  // node_modules/lodash-es/set.js
  init_define_import_meta_env();
  function set(object, path, value) {
    return object == null ? object : baseSet_default(object, path, value);
  }
  var set_default = set;

  // node_modules/@inertiajs/core/dist/index.esm.js
  var qs = __toESM(require_lib(), 1);

  // node_modules/axios/index.js
  init_define_import_meta_env();

  // node_modules/axios/lib/axios.js
  init_define_import_meta_env();

  // node_modules/axios/lib/utils.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/bind.js
  init_define_import_meta_env();
  function bind(fn, thisArg) {
    return function wrap() {
      return fn.apply(thisArg, arguments);
    };
  }

  // node_modules/axios/lib/utils.js
  var { toString: toString2 } = Object.prototype;
  var { getPrototypeOf } = Object;
  var { iterator, toStringTag } = Symbol;
  var kindOf = /* @__PURE__ */ ((cache) => (thing) => {
    const str = toString2.call(thing);
    return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
  })(/* @__PURE__ */ Object.create(null));
  var kindOfTest = (type) => {
    type = type.toLowerCase();
    return (thing) => kindOf(thing) === type;
  };
  var typeOfTest = (type) => (thing) => typeof thing === type;
  var { isArray: isArray2 } = Array;
  var isUndefined = typeOfTest("undefined");
  function isBuffer2(val) {
    return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction2(val.constructor.isBuffer) && val.constructor.isBuffer(val);
  }
  var isArrayBuffer = kindOfTest("ArrayBuffer");
  function isArrayBufferView(val) {
    let result;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
      result = ArrayBuffer.isView(val);
    } else {
      result = val && val.buffer && isArrayBuffer(val.buffer);
    }
    return result;
  }
  var isString = typeOfTest("string");
  var isFunction2 = typeOfTest("function");
  var isNumber = typeOfTest("number");
  var isObject2 = (thing) => thing !== null && typeof thing === "object";
  var isBoolean = (thing) => thing === true || thing === false;
  var isPlainObject2 = (val) => {
    if (kindOf(val) !== "object") {
      return false;
    }
    const prototype2 = getPrototypeOf(val);
    return (prototype2 === null || prototype2 === Object.prototype || Object.getPrototypeOf(prototype2) === null) && !(toStringTag in val) && !(iterator in val);
  };
  var isEmptyObject = (val) => {
    if (!isObject2(val) || isBuffer2(val)) {
      return false;
    }
    try {
      return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
    } catch (e6) {
      return false;
    }
  };
  var isDate = kindOfTest("Date");
  var isFile = kindOfTest("File");
  var isReactNativeBlob = (value) => {
    return !!(value && typeof value.uri !== "undefined");
  };
  var isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
  var isBlob = kindOfTest("Blob");
  var isFileList = kindOfTest("FileList");
  var isStream = (val) => isObject2(val) && isFunction2(val.pipe);
  function getGlobal() {
    if (typeof globalThis !== "undefined") return globalThis;
    if (typeof self !== "undefined") return self;
    if (typeof window !== "undefined") return window;
    if (typeof global !== "undefined") return global;
    return {};
  }
  var G4 = getGlobal();
  var FormDataCtor = typeof G4.FormData !== "undefined" ? G4.FormData : void 0;
  var isFormData = (thing) => {
    if (!thing) return false;
    if (FormDataCtor && thing instanceof FormDataCtor) return true;
    const proto = getPrototypeOf(thing);
    if (!proto || proto === Object.prototype) return false;
    if (!isFunction2(thing.append)) return false;
    const kind = kindOf(thing);
    return kind === "formdata" || // detect form-data instance
    kind === "object" && isFunction2(thing.toString) && thing.toString() === "[object FormData]";
  };
  var isURLSearchParams = kindOfTest("URLSearchParams");
  var [isReadableStream, isRequest, isResponse, isHeaders] = [
    "ReadableStream",
    "Request",
    "Response",
    "Headers"
  ].map(kindOfTest);
  var trim = (str) => {
    return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  };
  function forEach(obj, fn, { allOwnKeys = false } = {}) {
    if (obj === null || typeof obj === "undefined") {
      return;
    }
    let i12;
    let l10;
    if (typeof obj !== "object") {
      obj = [obj];
    }
    if (isArray2(obj)) {
      for (i12 = 0, l10 = obj.length; i12 < l10; i12++) {
        fn.call(null, obj[i12], i12, obj);
      }
    } else {
      if (isBuffer2(obj)) {
        return;
      }
      const keys2 = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
      const len = keys2.length;
      let key;
      for (i12 = 0; i12 < len; i12++) {
        key = keys2[i12];
        fn.call(null, obj[key], key, obj);
      }
    }
  }
  function findKey(obj, key) {
    if (isBuffer2(obj)) {
      return null;
    }
    key = key.toLowerCase();
    const keys2 = Object.keys(obj);
    let i12 = keys2.length;
    let _key;
    while (i12-- > 0) {
      _key = keys2[i12];
      if (key === _key.toLowerCase()) {
        return _key;
      }
    }
    return null;
  }
  var _global = (() => {
    if (typeof globalThis !== "undefined") return globalThis;
    return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
  })();
  var isContextDefined = (context) => !isUndefined(context) && context !== _global;
  function merge2(...objs) {
    const { caseless, skipUndefined } = isContextDefined(this) && this || {};
    const result = {};
    const assignValue2 = (val, key) => {
      if (key === "__proto__" || key === "constructor" || key === "prototype") {
        return;
      }
      const targetKey = caseless && findKey(result, key) || key;
      const existing = hasOwnProperty15(result, targetKey) ? result[targetKey] : void 0;
      if (isPlainObject2(existing) && isPlainObject2(val)) {
        result[targetKey] = merge2(existing, val);
      } else if (isPlainObject2(val)) {
        result[targetKey] = merge2({}, val);
      } else if (isArray2(val)) {
        result[targetKey] = val.slice();
      } else if (!skipUndefined || !isUndefined(val)) {
        result[targetKey] = val;
      }
    };
    for (let i12 = 0, l10 = objs.length; i12 < l10; i12++) {
      objs[i12] && forEach(objs[i12], assignValue2);
    }
    return result;
  }
  var extend = (a15, b8, thisArg, { allOwnKeys } = {}) => {
    forEach(
      b8,
      (val, key) => {
        if (thisArg && isFunction2(val)) {
          Object.defineProperty(a15, key, {
            // Null-proto descriptor so a polluted Object.prototype.get cannot
            // hijack defineProperty's accessor-vs-data resolution.
            __proto__: null,
            value: bind(val, thisArg),
            writable: true,
            enumerable: true,
            configurable: true
          });
        } else {
          Object.defineProperty(a15, key, {
            __proto__: null,
            value: val,
            writable: true,
            enumerable: true,
            configurable: true
          });
        }
      },
      { allOwnKeys }
    );
    return a15;
  };
  var stripBOM = (content) => {
    if (content.charCodeAt(0) === 65279) {
      content = content.slice(1);
    }
    return content;
  };
  var inherits = (constructor, superConstructor, props, descriptors) => {
    constructor.prototype = Object.create(superConstructor.prototype, descriptors);
    Object.defineProperty(constructor.prototype, "constructor", {
      __proto__: null,
      value: constructor,
      writable: true,
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(constructor, "super", {
      __proto__: null,
      value: superConstructor.prototype
    });
    props && Object.assign(constructor.prototype, props);
  };
  var toFlatObject = (sourceObj, destObj, filter2, propFilter) => {
    let props;
    let i12;
    let prop;
    const merged = {};
    destObj = destObj || {};
    if (sourceObj == null) return destObj;
    do {
      props = Object.getOwnPropertyNames(sourceObj);
      i12 = props.length;
      while (i12-- > 0) {
        prop = props[i12];
        if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
          destObj[prop] = sourceObj[prop];
          merged[prop] = true;
        }
      }
      sourceObj = filter2 !== false && getPrototypeOf(sourceObj);
    } while (sourceObj && (!filter2 || filter2(sourceObj, destObj)) && sourceObj !== Object.prototype);
    return destObj;
  };
  var endsWith = (str, searchString, position) => {
    str = String(str);
    if (position === void 0 || position > str.length) {
      position = str.length;
    }
    position -= searchString.length;
    const lastIndex = str.indexOf(searchString, position);
    return lastIndex !== -1 && lastIndex === position;
  };
  var toArray = (thing) => {
    if (!thing) return null;
    if (isArray2(thing)) return thing;
    let i12 = thing.length;
    if (!isNumber(i12)) return null;
    const arr = new Array(i12);
    while (i12-- > 0) {
      arr[i12] = thing[i12];
    }
    return arr;
  };
  var isTypedArray2 = /* @__PURE__ */ ((TypedArray) => {
    return (thing) => {
      return TypedArray && thing instanceof TypedArray;
    };
  })(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
  var forEachEntry = (obj, fn) => {
    const generator = obj && obj[iterator];
    const _iterator = generator.call(obj);
    let result;
    while ((result = _iterator.next()) && !result.done) {
      const pair = result.value;
      fn.call(obj, pair[0], pair[1]);
    }
  };
  var matchAll = (regExp, str) => {
    let matches;
    const arr = [];
    while ((matches = regExp.exec(str)) !== null) {
      arr.push(matches);
    }
    return arr;
  };
  var isHTMLForm = kindOfTest("HTMLFormElement");
  var toCamelCase = (str) => {
    return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m6, p1, p22) {
      return p1.toUpperCase() + p22;
    });
  };
  var hasOwnProperty15 = (({ hasOwnProperty: hasOwnProperty16 }) => (obj, prop) => hasOwnProperty16.call(obj, prop))(Object.prototype);
  var isRegExp = kindOfTest("RegExp");
  var reduceDescriptors = (obj, reducer) => {
    const descriptors = Object.getOwnPropertyDescriptors(obj);
    const reducedDescriptors = {};
    forEach(descriptors, (descriptor, name) => {
      let ret;
      if ((ret = reducer(descriptor, name, obj)) !== false) {
        reducedDescriptors[name] = ret || descriptor;
      }
    });
    Object.defineProperties(obj, reducedDescriptors);
  };
  var freezeMethods = (obj) => {
    reduceDescriptors(obj, (descriptor, name) => {
      if (isFunction2(obj) && ["arguments", "caller", "callee"].includes(name)) {
        return false;
      }
      const value = obj[name];
      if (!isFunction2(value)) return;
      descriptor.enumerable = false;
      if ("writable" in descriptor) {
        descriptor.writable = false;
        return;
      }
      if (!descriptor.set) {
        descriptor.set = () => {
          throw Error("Can not rewrite read-only method '" + name + "'");
        };
      }
    });
  };
  var toObjectSet = (arrayOrString, delimiter) => {
    const obj = {};
    const define = (arr) => {
      arr.forEach((value) => {
        obj[value] = true;
      });
    };
    isArray2(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
    return obj;
  };
  var noop = () => {
  };
  var toFiniteNumber = (value, defaultValue) => {
    return value != null && Number.isFinite(value = +value) ? value : defaultValue;
  };
  function isSpecCompliantForm(thing) {
    return !!(thing && isFunction2(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
  }
  var toJSONObject = (obj) => {
    const visited = /* @__PURE__ */ new WeakSet();
    const visit = (source) => {
      if (isObject2(source)) {
        if (visited.has(source)) {
          return;
        }
        if (isBuffer2(source)) {
          return source;
        }
        if (!("toJSON" in source)) {
          visited.add(source);
          const target = isArray2(source) ? [] : {};
          forEach(source, (value, key) => {
            const reducedValue = visit(value);
            !isUndefined(reducedValue) && (target[key] = reducedValue);
          });
          visited.delete(source);
          return target;
        }
      }
      return source;
    };
    return visit(obj);
  };
  var isAsyncFn = kindOfTest("AsyncFunction");
  var isThenable = (thing) => thing && (isObject2(thing) || isFunction2(thing)) && isFunction2(thing.then) && isFunction2(thing.catch);
  var _setImmediate = ((setImmediateSupported, postMessageSupported) => {
    if (setImmediateSupported) {
      return setImmediate;
    }
    return postMessageSupported ? ((token, callbacks) => {
      _global.addEventListener(
        "message",
        ({ source, data }) => {
          if (source === _global && data === token) {
            callbacks.length && callbacks.shift()();
          }
        },
        false
      );
      return (cb) => {
        callbacks.push(cb);
        _global.postMessage(token, "*");
      };
    })(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
  })(typeof setImmediate === "function", isFunction2(_global.postMessage));
  var asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
  var isIterable = (thing) => thing != null && isFunction2(thing[iterator]);
  var utils_default = {
    isArray: isArray2,
    isArrayBuffer,
    isBuffer: isBuffer2,
    isFormData,
    isArrayBufferView,
    isString,
    isNumber,
    isBoolean,
    isObject: isObject2,
    isPlainObject: isPlainObject2,
    isEmptyObject,
    isReadableStream,
    isRequest,
    isResponse,
    isHeaders,
    isUndefined,
    isDate,
    isFile,
    isReactNativeBlob,
    isReactNative,
    isBlob,
    isRegExp,
    isFunction: isFunction2,
    isStream,
    isURLSearchParams,
    isTypedArray: isTypedArray2,
    isFileList,
    forEach,
    merge: merge2,
    extend,
    trim,
    stripBOM,
    inherits,
    toFlatObject,
    kindOf,
    kindOfTest,
    endsWith,
    toArray,
    forEachEntry,
    matchAll,
    isHTMLForm,
    hasOwnProperty: hasOwnProperty15,
    hasOwnProp: hasOwnProperty15,
    // an alias to avoid ESLint no-prototype-builtins detection
    reduceDescriptors,
    freezeMethods,
    toObjectSet,
    toCamelCase,
    noop,
    toFiniteNumber,
    findKey,
    global: _global,
    isContextDefined,
    isSpecCompliantForm,
    toJSONObject,
    isAsyncFn,
    isThenable,
    setImmediate: _setImmediate,
    asap,
    isIterable
  };

  // node_modules/axios/lib/core/Axios.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/buildURL.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/AxiosURLSearchParams.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/toFormData.js
  init_define_import_meta_env();

  // node_modules/axios/lib/core/AxiosError.js
  init_define_import_meta_env();

  // node_modules/axios/lib/core/AxiosHeaders.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/parseHeaders.js
  init_define_import_meta_env();
  var ignoreDuplicateOf = utils_default.toObjectSet([
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
  ]);
  var parseHeaders_default = (rawHeaders) => {
    const parsed = {};
    let key;
    let val;
    let i12;
    rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
      i12 = line.indexOf(":");
      key = line.substring(0, i12).trim().toLowerCase();
      val = line.substring(i12 + 1).trim();
      if (!key || parsed[key] && ignoreDuplicateOf[key]) {
        return;
      }
      if (key === "set-cookie") {
        if (parsed[key]) {
          parsed[key].push(val);
        } else {
          parsed[key] = [val];
        }
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
      }
    });
    return parsed;
  };

  // node_modules/axios/lib/helpers/sanitizeHeaderValue.js
  init_define_import_meta_env();
  function trimSPorHTAB(str) {
    let start2 = 0;
    let end = str.length;
    while (start2 < end) {
      const code = str.charCodeAt(start2);
      if (code !== 9 && code !== 32) {
        break;
      }
      start2 += 1;
    }
    while (end > start2) {
      const code = str.charCodeAt(end - 1);
      if (code !== 9 && code !== 32) {
        break;
      }
      end -= 1;
    }
    return start2 === 0 && end === str.length ? str : str.slice(start2, end);
  }
  var INVALID_UNICODE_HEADER_VALUE_CHARS = new RegExp("[\\u0000-\\u0008\\u000a-\\u001f\\u007f]+", "g");
  var INVALID_BYTE_STRING_HEADER_VALUE_CHARS = new RegExp("[^\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+", "g");
  function sanitizeValue(value, invalidChars) {
    if (utils_default.isArray(value)) {
      return value.map((item) => sanitizeValue(item, invalidChars));
    }
    return trimSPorHTAB(String(value).replace(invalidChars, ""));
  }
  var sanitizeHeaderValue = (value) => sanitizeValue(value, INVALID_UNICODE_HEADER_VALUE_CHARS);
  var sanitizeByteStringHeaderValue = (value) => sanitizeValue(value, INVALID_BYTE_STRING_HEADER_VALUE_CHARS);
  function toByteStringHeaderObject(headers) {
    const byteStringHeaders = /* @__PURE__ */ Object.create(null);
    utils_default.forEach(headers.toJSON(), (value, header) => {
      byteStringHeaders[header] = sanitizeByteStringHeaderValue(value);
    });
    return byteStringHeaders;
  }

  // node_modules/axios/lib/core/AxiosHeaders.js
  var $internals = /* @__PURE__ */ Symbol("internals");
  function normalizeHeader(header) {
    return header && String(header).trim().toLowerCase();
  }
  function normalizeValue(value) {
    if (value === false || value == null) {
      return value;
    }
    return utils_default.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
  }
  function parseTokens(str) {
    const tokens = /* @__PURE__ */ Object.create(null);
    const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let match;
    while (match = tokensRE.exec(str)) {
      tokens[match[1]] = match[2];
    }
    return tokens;
  }
  var isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
  function matchHeaderValue(context, value, header, filter2, isHeaderNameFilter) {
    if (utils_default.isFunction(filter2)) {
      return filter2.call(this, value, header);
    }
    if (isHeaderNameFilter) {
      value = header;
    }
    if (!utils_default.isString(value)) return;
    if (utils_default.isString(filter2)) {
      return value.indexOf(filter2) !== -1;
    }
    if (utils_default.isRegExp(filter2)) {
      return filter2.test(value);
    }
  }
  function formatHeader(header) {
    return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w7, char, str) => {
      return char.toUpperCase() + str;
    });
  }
  function buildAccessors(obj, header) {
    const accessorName = utils_default.toCamelCase(" " + header);
    ["get", "set", "has"].forEach((methodName) => {
      Object.defineProperty(obj, methodName + accessorName, {
        // Null-proto descriptor so a polluted Object.prototype.get cannot turn
        // this data descriptor into an accessor descriptor on the way in.
        __proto__: null,
        value: function(arg1, arg2, arg3) {
          return this[methodName].call(this, header, arg1, arg2, arg3);
        },
        configurable: true
      });
    });
  }
  var AxiosHeaders = class {
    constructor(headers) {
      headers && this.set(headers);
    }
    set(header, valueOrRewrite, rewrite) {
      const self2 = this;
      function setHeader(_value, _header, _rewrite) {
        const lHeader = normalizeHeader(_header);
        if (!lHeader) {
          throw new Error("header name must be a non-empty string");
        }
        const key = utils_default.findKey(self2, lHeader);
        if (!key || self2[key] === void 0 || _rewrite === true || _rewrite === void 0 && self2[key] !== false) {
          self2[key || _header] = normalizeValue(_value);
        }
      }
      const setHeaders = (headers, _rewrite) => utils_default.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
      if (utils_default.isPlainObject(header) || header instanceof this.constructor) {
        setHeaders(header, valueOrRewrite);
      } else if (utils_default.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) {
        setHeaders(parseHeaders_default(header), valueOrRewrite);
      } else if (utils_default.isObject(header) && utils_default.isIterable(header)) {
        let obj = {}, dest, key;
        for (const entry of header) {
          if (!utils_default.isArray(entry)) {
            throw TypeError("Object iterator must return a key-value pair");
          }
          obj[key = entry[0]] = (dest = obj[key]) ? utils_default.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]] : entry[1];
        }
        setHeaders(obj, valueOrRewrite);
      } else {
        header != null && setHeader(valueOrRewrite, header, rewrite);
      }
      return this;
    }
    get(header, parser) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils_default.findKey(this, header);
        if (key) {
          const value = this[key];
          if (!parser) {
            return value;
          }
          if (parser === true) {
            return parseTokens(value);
          }
          if (utils_default.isFunction(parser)) {
            return parser.call(this, value, key);
          }
          if (utils_default.isRegExp(parser)) {
            return parser.exec(value);
          }
          throw new TypeError("parser must be boolean|regexp|function");
        }
      }
    }
    has(header, matcher) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils_default.findKey(this, header);
        return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
      }
      return false;
    }
    delete(header, matcher) {
      const self2 = this;
      let deleted = false;
      function deleteHeader(_header) {
        _header = normalizeHeader(_header);
        if (_header) {
          const key = utils_default.findKey(self2, _header);
          if (key && (!matcher || matchHeaderValue(self2, self2[key], key, matcher))) {
            delete self2[key];
            deleted = true;
          }
        }
      }
      if (utils_default.isArray(header)) {
        header.forEach(deleteHeader);
      } else {
        deleteHeader(header);
      }
      return deleted;
    }
    clear(matcher) {
      const keys2 = Object.keys(this);
      let i12 = keys2.length;
      let deleted = false;
      while (i12--) {
        const key = keys2[i12];
        if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
          delete this[key];
          deleted = true;
        }
      }
      return deleted;
    }
    normalize(format) {
      const self2 = this;
      const headers = {};
      utils_default.forEach(this, (value, header) => {
        const key = utils_default.findKey(headers, header);
        if (key) {
          self2[key] = normalizeValue(value);
          delete self2[header];
          return;
        }
        const normalized = format ? formatHeader(header) : String(header).trim();
        if (normalized !== header) {
          delete self2[header];
        }
        self2[normalized] = normalizeValue(value);
        headers[normalized] = true;
      });
      return this;
    }
    concat(...targets) {
      return this.constructor.concat(this, ...targets);
    }
    toJSON(asStrings) {
      const obj = /* @__PURE__ */ Object.create(null);
      utils_default.forEach(this, (value, header) => {
        value != null && value !== false && (obj[header] = asStrings && utils_default.isArray(value) ? value.join(", ") : value);
      });
      return obj;
    }
    [Symbol.iterator]() {
      return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
      return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
    }
    getSetCookie() {
      return this.get("set-cookie") || [];
    }
    get [Symbol.toStringTag]() {
      return "AxiosHeaders";
    }
    static from(thing) {
      return thing instanceof this ? thing : new this(thing);
    }
    static concat(first, ...targets) {
      const computed = new this(first);
      targets.forEach((target) => computed.set(target));
      return computed;
    }
    static accessor(header) {
      const internals = this[$internals] = this[$internals] = {
        accessors: {}
      };
      const accessors = internals.accessors;
      const prototype2 = this.prototype;
      function defineAccessor(_header) {
        const lHeader = normalizeHeader(_header);
        if (!accessors[lHeader]) {
          buildAccessors(prototype2, _header);
          accessors[lHeader] = true;
        }
      }
      utils_default.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
      return this;
    }
  };
  AxiosHeaders.accessor([
    "Content-Type",
    "Content-Length",
    "Accept",
    "Accept-Encoding",
    "User-Agent",
    "Authorization"
  ]);
  utils_default.reduceDescriptors(AxiosHeaders.prototype, ({ value }, key) => {
    let mapped = key[0].toUpperCase() + key.slice(1);
    return {
      get: () => value,
      set(headerValue) {
        this[mapped] = headerValue;
      }
    };
  });
  utils_default.freezeMethods(AxiosHeaders);
  var AxiosHeaders_default = AxiosHeaders;

  // node_modules/axios/lib/core/AxiosError.js
  var REDACTED = "[REDACTED ****]";
  function hasOwnOrPrototypeToJSON(source) {
    if (utils_default.hasOwnProp(source, "toJSON")) {
      return true;
    }
    let prototype2 = Object.getPrototypeOf(source);
    while (prototype2 && prototype2 !== Object.prototype) {
      if (utils_default.hasOwnProp(prototype2, "toJSON")) {
        return true;
      }
      prototype2 = Object.getPrototypeOf(prototype2);
    }
    return false;
  }
  function redactConfig(config3, redactKeys) {
    const lowerKeys = new Set(redactKeys.map((k6) => String(k6).toLowerCase()));
    const seen = [];
    const visit = (source) => {
      if (source === null || typeof source !== "object") return source;
      if (utils_default.isBuffer(source)) return source;
      if (seen.indexOf(source) !== -1) return void 0;
      if (source instanceof AxiosHeaders_default) {
        source = source.toJSON();
      }
      seen.push(source);
      let result;
      if (utils_default.isArray(source)) {
        result = [];
        source.forEach((v4, i12) => {
          const reducedValue = visit(v4);
          if (!utils_default.isUndefined(reducedValue)) {
            result[i12] = reducedValue;
          }
        });
      } else {
        if (!utils_default.isPlainObject(source) && hasOwnOrPrototypeToJSON(source)) {
          seen.pop();
          return source;
        }
        result = /* @__PURE__ */ Object.create(null);
        for (const [key, value] of Object.entries(source)) {
          const reducedValue = lowerKeys.has(key.toLowerCase()) ? REDACTED : visit(value);
          if (!utils_default.isUndefined(reducedValue)) {
            result[key] = reducedValue;
          }
        }
      }
      seen.pop();
      return result;
    };
    return visit(config3);
  }
  var AxiosError = class _AxiosError extends Error {
    static from(error, code, config3, request2, response, customProps) {
      const axiosError = new _AxiosError(error.message, code || error.code, config3, request2, response);
      axiosError.cause = error;
      axiosError.name = error.name;
      if (error.status != null && axiosError.status == null) {
        axiosError.status = error.status;
      }
      customProps && Object.assign(axiosError, customProps);
      return axiosError;
    }
    /**
     * Create an Error with the specified message, config, error code, request and response.
     *
     * @param {string} message The error message.
     * @param {string} [code] The error code (for example, 'ECONNABORTED').
     * @param {Object} [config] The config.
     * @param {Object} [request] The request.
     * @param {Object} [response] The response.
     *
     * @returns {Error} The created error.
     */
    constructor(message, code, config3, request2, response) {
      super(message);
      Object.defineProperty(this, "message", {
        // Null-proto descriptor so a polluted Object.prototype.get cannot turn
        // this data descriptor into an accessor descriptor on the way in.
        __proto__: null,
        value: message,
        enumerable: true,
        writable: true,
        configurable: true
      });
      this.name = "AxiosError";
      this.isAxiosError = true;
      code && (this.code = code);
      config3 && (this.config = config3);
      request2 && (this.request = request2);
      if (response) {
        this.response = response;
        this.status = response.status;
      }
    }
    toJSON() {
      const config3 = this.config;
      const redactKeys = config3 && utils_default.hasOwnProp(config3, "redact") ? config3.redact : void 0;
      const serializedConfig = utils_default.isArray(redactKeys) && redactKeys.length > 0 ? redactConfig(config3, redactKeys) : utils_default.toJSONObject(config3);
      return {
        // Standard
        message: this.message,
        name: this.name,
        // Microsoft
        description: this.description,
        number: this.number,
        // Mozilla
        fileName: this.fileName,
        lineNumber: this.lineNumber,
        columnNumber: this.columnNumber,
        stack: this.stack,
        // Axios
        config: serializedConfig,
        code: this.code,
        status: this.status
      };
    }
  };
  AxiosError.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
  AxiosError.ERR_BAD_OPTION = "ERR_BAD_OPTION";
  AxiosError.ECONNABORTED = "ECONNABORTED";
  AxiosError.ETIMEDOUT = "ETIMEDOUT";
  AxiosError.ECONNREFUSED = "ECONNREFUSED";
  AxiosError.ERR_NETWORK = "ERR_NETWORK";
  AxiosError.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
  AxiosError.ERR_DEPRECATED = "ERR_DEPRECATED";
  AxiosError.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
  AxiosError.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
  AxiosError.ERR_CANCELED = "ERR_CANCELED";
  AxiosError.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
  AxiosError.ERR_INVALID_URL = "ERR_INVALID_URL";
  AxiosError.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
  var AxiosError_default = AxiosError;

  // node_modules/axios/lib/helpers/null.js
  init_define_import_meta_env();
  var null_default = null;

  // node_modules/axios/lib/helpers/toFormData.js
  function isVisitable(thing) {
    return utils_default.isPlainObject(thing) || utils_default.isArray(thing);
  }
  function removeBrackets(key) {
    return utils_default.endsWith(key, "[]") ? key.slice(0, -2) : key;
  }
  function renderKey(path, key, dots) {
    if (!path) return key;
    return path.concat(key).map(function each(token, i12) {
      token = removeBrackets(token);
      return !dots && i12 ? "[" + token + "]" : token;
    }).join(dots ? "." : "");
  }
  function isFlatArray(arr) {
    return utils_default.isArray(arr) && !arr.some(isVisitable);
  }
  var predicates = utils_default.toFlatObject(utils_default, {}, null, function filter(prop) {
    return /^is[A-Z]/.test(prop);
  });
  function toFormData(obj, formData, options) {
    if (!utils_default.isObject(obj)) {
      throw new TypeError("target must be an object");
    }
    formData = formData || new (null_default || FormData)();
    options = utils_default.toFlatObject(
      options,
      {
        metaTokens: true,
        dots: false,
        indexes: false
      },
      false,
      function defined(option, source) {
        return !utils_default.isUndefined(source[option]);
      }
    );
    const metaTokens = options.metaTokens;
    const visitor = options.visitor || defaultVisitor;
    const dots = options.dots;
    const indexes = options.indexes;
    const _Blob = options.Blob || typeof Blob !== "undefined" && Blob;
    const maxDepth = options.maxDepth === void 0 ? 100 : options.maxDepth;
    const useBlob = _Blob && utils_default.isSpecCompliantForm(formData);
    if (!utils_default.isFunction(visitor)) {
      throw new TypeError("visitor must be a function");
    }
    function convertValue(value) {
      if (value === null) return "";
      if (utils_default.isDate(value)) {
        return value.toISOString();
      }
      if (utils_default.isBoolean(value)) {
        return value.toString();
      }
      if (!useBlob && utils_default.isBlob(value)) {
        throw new AxiosError_default("Blob is not supported. Use a Buffer instead.");
      }
      if (utils_default.isArrayBuffer(value) || utils_default.isTypedArray(value)) {
        return useBlob && typeof Blob === "function" ? new Blob([value]) : Buffer.from(value);
      }
      return value;
    }
    function defaultVisitor(value, key, path) {
      let arr = value;
      if (utils_default.isReactNative(formData) && utils_default.isReactNativeBlob(value)) {
        formData.append(renderKey(path, key, dots), convertValue(value));
        return false;
      }
      if (value && !path && typeof value === "object") {
        if (utils_default.endsWith(key, "{}")) {
          key = metaTokens ? key : key.slice(0, -2);
          value = JSON.stringify(value);
        } else if (utils_default.isArray(value) && isFlatArray(value) || (utils_default.isFileList(value) || utils_default.endsWith(key, "[]")) && (arr = utils_default.toArray(value))) {
          key = removeBrackets(key);
          arr.forEach(function each(el, index) {
            !(utils_default.isUndefined(el) || el === null) && formData.append(
              // eslint-disable-next-line no-nested-ternary
              indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]",
              convertValue(el)
            );
          });
          return false;
        }
      }
      if (isVisitable(value)) {
        return true;
      }
      formData.append(renderKey(path, key, dots), convertValue(value));
      return false;
    }
    const stack = [];
    const exposedHelpers = Object.assign(predicates, {
      defaultVisitor,
      convertValue,
      isVisitable
    });
    function build(value, path, depth = 0) {
      if (utils_default.isUndefined(value)) return;
      if (depth > maxDepth) {
        throw new AxiosError_default(
          "Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth,
          AxiosError_default.ERR_FORM_DATA_DEPTH_EXCEEDED
        );
      }
      if (stack.indexOf(value) !== -1) {
        throw Error("Circular reference detected in " + path.join("."));
      }
      stack.push(value);
      utils_default.forEach(value, function each(el, key) {
        const result = !(utils_default.isUndefined(el) || el === null) && visitor.call(formData, el, utils_default.isString(key) ? key.trim() : key, path, exposedHelpers);
        if (result === true) {
          build(el, path ? path.concat(key) : [key], depth + 1);
        }
      });
      stack.pop();
    }
    if (!utils_default.isObject(obj)) {
      throw new TypeError("data must be an object");
    }
    build(obj);
    return formData;
  }
  var toFormData_default = toFormData;

  // node_modules/axios/lib/helpers/AxiosURLSearchParams.js
  function encode(str) {
    const charMap = {
      "!": "%21",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "~": "%7E",
      "%20": "+"
    };
    return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
      return charMap[match];
    });
  }
  function AxiosURLSearchParams(params, options) {
    this._pairs = [];
    params && toFormData_default(params, this, options);
  }
  var prototype = AxiosURLSearchParams.prototype;
  prototype.append = function append(name, value) {
    this._pairs.push([name, value]);
  };
  prototype.toString = function toString3(encoder) {
    const _encode = encoder ? function(value) {
      return encoder.call(this, value, encode);
    } : encode;
    return this._pairs.map(function each(pair) {
      return _encode(pair[0]) + "=" + _encode(pair[1]);
    }, "").join("&");
  };
  var AxiosURLSearchParams_default = AxiosURLSearchParams;

  // node_modules/axios/lib/helpers/buildURL.js
  function encode2(val) {
    return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
  }
  function buildURL(url, params, options) {
    if (!params) {
      return url;
    }
    const _encode = options && options.encode || encode2;
    const _options = utils_default.isFunction(options) ? {
      serialize: options
    } : options;
    const serializeFn = _options && _options.serialize;
    let serializedParams;
    if (serializeFn) {
      serializedParams = serializeFn(params, _options);
    } else {
      serializedParams = utils_default.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams_default(params, _options).toString(_encode);
    }
    if (serializedParams) {
      const hashmarkIndex = url.indexOf("#");
      if (hashmarkIndex !== -1) {
        url = url.slice(0, hashmarkIndex);
      }
      url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
    }
    return url;
  }

  // node_modules/axios/lib/core/InterceptorManager.js
  init_define_import_meta_env();
  var InterceptorManager = class {
    constructor() {
      this.handlers = [];
    }
    /**
     * Add a new interceptor to the stack
     *
     * @param {Function} fulfilled The function to handle `then` for a `Promise`
     * @param {Function} rejected The function to handle `reject` for a `Promise`
     * @param {Object} options The options for the interceptor, synchronous and runWhen
     *
     * @return {Number} An ID used to remove interceptor later
     */
    use(fulfilled, rejected, options) {
      this.handlers.push({
        fulfilled,
        rejected,
        synchronous: options ? options.synchronous : false,
        runWhen: options ? options.runWhen : null
      });
      return this.handlers.length - 1;
    }
    /**
     * Remove an interceptor from the stack
     *
     * @param {Number} id The ID that was returned by `use`
     *
     * @returns {void}
     */
    eject(id) {
      if (this.handlers[id]) {
        this.handlers[id] = null;
      }
    }
    /**
     * Clear all interceptors from the stack
     *
     * @returns {void}
     */
    clear() {
      if (this.handlers) {
        this.handlers = [];
      }
    }
    /**
     * Iterate over all the registered interceptors
     *
     * This method is particularly useful for skipping over any
     * interceptors that may have become `null` calling `eject`.
     *
     * @param {Function} fn The function to call for each interceptor
     *
     * @returns {void}
     */
    forEach(fn) {
      utils_default.forEach(this.handlers, function forEachHandler(h6) {
        if (h6 !== null) {
          fn(h6);
        }
      });
    }
  };
  var InterceptorManager_default = InterceptorManager;

  // node_modules/axios/lib/core/dispatchRequest.js
  init_define_import_meta_env();

  // node_modules/axios/lib/core/transformData.js
  init_define_import_meta_env();

  // node_modules/axios/lib/defaults/index.js
  init_define_import_meta_env();

  // node_modules/axios/lib/defaults/transitional.js
  init_define_import_meta_env();
  var transitional_default = {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false,
    legacyInterceptorReqResOrdering: true
  };

  // node_modules/axios/lib/helpers/toURLEncodedForm.js
  init_define_import_meta_env();

  // node_modules/axios/lib/platform/index.js
  init_define_import_meta_env();

  // node_modules/axios/lib/platform/browser/index.js
  init_define_import_meta_env();

  // node_modules/axios/lib/platform/browser/classes/URLSearchParams.js
  init_define_import_meta_env();
  var URLSearchParams_default = typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams_default;

  // node_modules/axios/lib/platform/browser/classes/FormData.js
  init_define_import_meta_env();
  var FormData_default = typeof FormData !== "undefined" ? FormData : null;

  // node_modules/axios/lib/platform/browser/classes/Blob.js
  init_define_import_meta_env();
  var Blob_default = typeof Blob !== "undefined" ? Blob : null;

  // node_modules/axios/lib/platform/browser/index.js
  var browser_default = {
    isBrowser: true,
    classes: {
      URLSearchParams: URLSearchParams_default,
      FormData: FormData_default,
      Blob: Blob_default
    },
    protocols: ["http", "https", "file", "blob", "url", "data"]
  };

  // node_modules/axios/lib/platform/common/utils.js
  var utils_exports = {};
  __export(utils_exports, {
    hasBrowserEnv: () => hasBrowserEnv,
    hasStandardBrowserEnv: () => hasStandardBrowserEnv,
    hasStandardBrowserWebWorkerEnv: () => hasStandardBrowserWebWorkerEnv,
    navigator: () => _navigator,
    origin: () => origin
  });
  init_define_import_meta_env();
  var hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
  var _navigator = typeof navigator === "object" && navigator || void 0;
  var hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || ["ReactNative", "NativeScript", "NS"].indexOf(_navigator.product) < 0);
  var hasStandardBrowserWebWorkerEnv = (() => {
    return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
    self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
  })();
  var origin = hasBrowserEnv && window.location.href || "http://localhost";

  // node_modules/axios/lib/platform/index.js
  var platform_default = {
    ...utils_exports,
    ...browser_default
  };

  // node_modules/axios/lib/helpers/toURLEncodedForm.js
  function toURLEncodedForm(data, options) {
    return toFormData_default(data, new platform_default.classes.URLSearchParams(), {
      visitor: function(value, key, path, helpers) {
        if (platform_default.isNode && utils_default.isBuffer(value)) {
          this.append(key, value.toString("base64"));
          return false;
        }
        return helpers.defaultVisitor.apply(this, arguments);
      },
      ...options
    });
  }

  // node_modules/axios/lib/helpers/formDataToJSON.js
  init_define_import_meta_env();
  function parsePropPath(name) {
    return utils_default.matchAll(/\w+|\[(\w*)]/g, name).map((match) => {
      return match[0] === "[]" ? "" : match[1] || match[0];
    });
  }
  function arrayToObject(arr) {
    const obj = {};
    const keys2 = Object.keys(arr);
    let i12;
    const len = keys2.length;
    let key;
    for (i12 = 0; i12 < len; i12++) {
      key = keys2[i12];
      obj[key] = arr[key];
    }
    return obj;
  }
  function formDataToJSON(formData) {
    function buildPath(path, value, target, index) {
      let name = path[index++];
      if (name === "__proto__") return true;
      const isNumericKey = Number.isFinite(+name);
      const isLast = index >= path.length;
      name = !name && utils_default.isArray(target) ? target.length : name;
      if (isLast) {
        if (utils_default.hasOwnProp(target, name)) {
          target[name] = utils_default.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
        } else {
          target[name] = value;
        }
        return !isNumericKey;
      }
      if (!utils_default.hasOwnProp(target, name) || !utils_default.isObject(target[name])) {
        target[name] = [];
      }
      const result = buildPath(path, value, target[name], index);
      if (result && utils_default.isArray(target[name])) {
        target[name] = arrayToObject(target[name]);
      }
      return !isNumericKey;
    }
    if (utils_default.isFormData(formData) && utils_default.isFunction(formData.entries)) {
      const obj = {};
      utils_default.forEachEntry(formData, (name, value) => {
        buildPath(parsePropPath(name), value, obj, 0);
      });
      return obj;
    }
    return null;
  }
  var formDataToJSON_default = formDataToJSON;

  // node_modules/axios/lib/defaults/index.js
  var own = (obj, key) => obj != null && utils_default.hasOwnProp(obj, key) ? obj[key] : void 0;
  function stringifySafely(rawValue, parser, encoder) {
    if (utils_default.isString(rawValue)) {
      try {
        (parser || JSON.parse)(rawValue);
        return utils_default.trim(rawValue);
      } catch (e6) {
        if (e6.name !== "SyntaxError") {
          throw e6;
        }
      }
    }
    return (encoder || JSON.stringify)(rawValue);
  }
  var defaults = {
    transitional: transitional_default,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [
      function transformRequest(data, headers) {
        const contentType = headers.getContentType() || "";
        const hasJSONContentType = contentType.indexOf("application/json") > -1;
        const isObjectPayload = utils_default.isObject(data);
        if (isObjectPayload && utils_default.isHTMLForm(data)) {
          data = new FormData(data);
        }
        const isFormData3 = utils_default.isFormData(data);
        if (isFormData3) {
          return hasJSONContentType ? JSON.stringify(formDataToJSON_default(data)) : data;
        }
        if (utils_default.isArrayBuffer(data) || utils_default.isBuffer(data) || utils_default.isStream(data) || utils_default.isFile(data) || utils_default.isBlob(data) || utils_default.isReadableStream(data)) {
          return data;
        }
        if (utils_default.isArrayBufferView(data)) {
          return data.buffer;
        }
        if (utils_default.isURLSearchParams(data)) {
          headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
          return data.toString();
        }
        let isFileList2;
        if (isObjectPayload) {
          const formSerializer = own(this, "formSerializer");
          if (contentType.indexOf("application/x-www-form-urlencoded") > -1) {
            return toURLEncodedForm(data, formSerializer).toString();
          }
          if ((isFileList2 = utils_default.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
            const env = own(this, "env");
            const _FormData = env && env.FormData;
            return toFormData_default(
              isFileList2 ? { "files[]": data } : data,
              _FormData && new _FormData(),
              formSerializer
            );
          }
        }
        if (isObjectPayload || hasJSONContentType) {
          headers.setContentType("application/json", false);
          return stringifySafely(data);
        }
        return data;
      }
    ],
    transformResponse: [
      function transformResponse(data) {
        const transitional2 = own(this, "transitional") || defaults.transitional;
        const forcedJSONParsing = transitional2 && transitional2.forcedJSONParsing;
        const responseType = own(this, "responseType");
        const JSONRequested = responseType === "json";
        if (utils_default.isResponse(data) || utils_default.isReadableStream(data)) {
          return data;
        }
        if (data && utils_default.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
          const silentJSONParsing = transitional2 && transitional2.silentJSONParsing;
          const strictJSONParsing = !silentJSONParsing && JSONRequested;
          try {
            return JSON.parse(data, own(this, "parseReviver"));
          } catch (e6) {
            if (strictJSONParsing) {
              if (e6.name === "SyntaxError") {
                throw AxiosError_default.from(e6, AxiosError_default.ERR_BAD_RESPONSE, this, null, own(this, "response"));
              }
              throw e6;
            }
          }
        }
        return data;
      }
    ],
    /**
     * A timeout in milliseconds to abort a request. If set to 0 (default) a
     * timeout is not created.
     */
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
      FormData: platform_default.classes.FormData,
      Blob: platform_default.classes.Blob
    },
    validateStatus: function validateStatus(status2) {
      return status2 >= 200 && status2 < 300;
    },
    headers: {
      common: {
        Accept: "application/json, text/plain, */*",
        "Content-Type": void 0
      }
    }
  };
  utils_default.forEach(["delete", "get", "head", "post", "put", "patch", "query"], (method) => {
    defaults.headers[method] = {};
  });
  var defaults_default = defaults;

  // node_modules/axios/lib/core/transformData.js
  function transformData(fns, response) {
    const config3 = this || defaults_default;
    const context = response || config3;
    const headers = AxiosHeaders_default.from(context.headers);
    let data = context.data;
    utils_default.forEach(fns, function transform(fn) {
      data = fn.call(config3, data, headers.normalize(), response ? response.status : void 0);
    });
    headers.normalize();
    return data;
  }

  // node_modules/axios/lib/cancel/isCancel.js
  init_define_import_meta_env();
  function isCancel(value) {
    return !!(value && value.__CANCEL__);
  }

  // node_modules/axios/lib/cancel/CanceledError.js
  init_define_import_meta_env();
  var CanceledError = class extends AxiosError_default {
    /**
     * A `CanceledError` is an object that is thrown when an operation is canceled.
     *
     * @param {string=} message The message.
     * @param {Object=} config The config.
     * @param {Object=} request The request.
     *
     * @returns {CanceledError} The created error.
     */
    constructor(message, config3, request2) {
      super(message == null ? "canceled" : message, AxiosError_default.ERR_CANCELED, config3, request2);
      this.name = "CanceledError";
      this.__CANCEL__ = true;
    }
  };
  var CanceledError_default = CanceledError;

  // node_modules/axios/lib/adapters/adapters.js
  init_define_import_meta_env();

  // node_modules/axios/lib/adapters/xhr.js
  init_define_import_meta_env();

  // node_modules/axios/lib/core/settle.js
  init_define_import_meta_env();
  function settle(resolve, reject, response) {
    const validateStatus2 = response.config.validateStatus;
    if (!response.status || !validateStatus2 || validateStatus2(response.status)) {
      resolve(response);
    } else {
      reject(new AxiosError_default(
        "Request failed with status code " + response.status,
        response.status >= 400 && response.status < 500 ? AxiosError_default.ERR_BAD_REQUEST : AxiosError_default.ERR_BAD_RESPONSE,
        response.config,
        response.request,
        response
      ));
    }
  }

  // node_modules/axios/lib/helpers/parseProtocol.js
  init_define_import_meta_env();
  function parseProtocol(url) {
    const match = /^([-+\w]{1,25}):(?:\/\/)?/.exec(url);
    return match && match[1] || "";
  }

  // node_modules/axios/lib/helpers/progressEventReducer.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/speedometer.js
  init_define_import_meta_env();
  function speedometer(samplesCount, min) {
    samplesCount = samplesCount || 10;
    const bytes = new Array(samplesCount);
    const timestamps = new Array(samplesCount);
    let head = 0;
    let tail = 0;
    let firstSampleTS;
    min = min !== void 0 ? min : 1e3;
    return function push(chunkLength) {
      const now2 = Date.now();
      const startedAt = timestamps[tail];
      if (!firstSampleTS) {
        firstSampleTS = now2;
      }
      bytes[head] = chunkLength;
      timestamps[head] = now2;
      let i12 = tail;
      let bytesCount = 0;
      while (i12 !== head) {
        bytesCount += bytes[i12++];
        i12 = i12 % samplesCount;
      }
      head = (head + 1) % samplesCount;
      if (head === tail) {
        tail = (tail + 1) % samplesCount;
      }
      if (now2 - firstSampleTS < min) {
        return;
      }
      const passed = startedAt && now2 - startedAt;
      return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
    };
  }
  var speedometer_default = speedometer;

  // node_modules/axios/lib/helpers/throttle.js
  init_define_import_meta_env();
  function throttle(fn, freq) {
    let timestamp = 0;
    let threshold = 1e3 / freq;
    let lastArgs;
    let timer;
    const invoke = (args, now2 = Date.now()) => {
      timestamp = now2;
      lastArgs = null;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      fn(...args);
    };
    const throttled = (...args) => {
      const now2 = Date.now();
      const passed = now2 - timestamp;
      if (passed >= threshold) {
        invoke(args, now2);
      } else {
        lastArgs = args;
        if (!timer) {
          timer = setTimeout(() => {
            timer = null;
            invoke(lastArgs);
          }, threshold - passed);
        }
      }
    };
    const flush = () => lastArgs && invoke(lastArgs);
    return [throttled, flush];
  }
  var throttle_default = throttle;

  // node_modules/axios/lib/helpers/progressEventReducer.js
  var progressEventReducer = (listener, isDownloadStream, freq = 3) => {
    let bytesNotified = 0;
    const _speedometer = speedometer_default(50, 250);
    return throttle_default((e6) => {
      if (!e6 || typeof e6.loaded !== "number") {
        return;
      }
      const rawLoaded = e6.loaded;
      const total = e6.lengthComputable ? e6.total : void 0;
      const loaded = total != null ? Math.min(rawLoaded, total) : rawLoaded;
      const progressBytes = Math.max(0, loaded - bytesNotified);
      const rate = _speedometer(progressBytes);
      bytesNotified = Math.max(bytesNotified, loaded);
      const data = {
        loaded,
        total,
        progress: total ? loaded / total : void 0,
        bytes: progressBytes,
        rate: rate ? rate : void 0,
        estimated: rate && total ? (total - loaded) / rate : void 0,
        event: e6,
        lengthComputable: total != null,
        [isDownloadStream ? "download" : "upload"]: true
      };
      listener(data);
    }, freq);
  };
  var progressEventDecorator = (total, throttled) => {
    const lengthComputable = total != null;
    return [
      (loaded) => throttled[0]({
        lengthComputable,
        total,
        loaded
      }),
      throttled[1]
    ];
  };
  var asyncDecorator = (fn) => (...args) => utils_default.asap(() => fn(...args));

  // node_modules/axios/lib/helpers/resolveConfig.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/isURLSameOrigin.js
  init_define_import_meta_env();
  var isURLSameOrigin_default = platform_default.hasStandardBrowserEnv ? /* @__PURE__ */ ((origin2, isMSIE) => (url) => {
    url = new URL(url, platform_default.origin);
    return origin2.protocol === url.protocol && origin2.host === url.host && (isMSIE || origin2.port === url.port);
  })(
    new URL(platform_default.origin),
    platform_default.navigator && /(msie|trident)/i.test(platform_default.navigator.userAgent)
  ) : () => true;

  // node_modules/axios/lib/helpers/cookies.js
  init_define_import_meta_env();
  var cookies_default = platform_default.hasStandardBrowserEnv ? (
    // Standard browser envs support document.cookie
    {
      write(name, value, expires, path, domain, secure, sameSite) {
        if (typeof document === "undefined") return;
        const cookie = [`${name}=${encodeURIComponent(value)}`];
        if (utils_default.isNumber(expires)) {
          cookie.push(`expires=${new Date(expires).toUTCString()}`);
        }
        if (utils_default.isString(path)) {
          cookie.push(`path=${path}`);
        }
        if (utils_default.isString(domain)) {
          cookie.push(`domain=${domain}`);
        }
        if (secure === true) {
          cookie.push("secure");
        }
        if (utils_default.isString(sameSite)) {
          cookie.push(`SameSite=${sameSite}`);
        }
        document.cookie = cookie.join("; ");
      },
      read(name) {
        if (typeof document === "undefined") return null;
        const cookies = document.cookie.split(";");
        for (let i12 = 0; i12 < cookies.length; i12++) {
          const cookie = cookies[i12].replace(/^\s+/, "");
          const eq2 = cookie.indexOf("=");
          if (eq2 !== -1 && cookie.slice(0, eq2) === name) {
            return decodeURIComponent(cookie.slice(eq2 + 1));
          }
        }
        return null;
      },
      remove(name) {
        this.write(name, "", Date.now() - 864e5, "/");
      }
    }
  ) : (
    // Non-standard browser env (web workers, react-native) lack needed support.
    {
      write() {
      },
      read() {
        return null;
      },
      remove() {
      }
    }
  );

  // node_modules/axios/lib/core/buildFullPath.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/isAbsoluteURL.js
  init_define_import_meta_env();
  function isAbsoluteURL(url) {
    if (typeof url !== "string") {
      return false;
    }
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
  }

  // node_modules/axios/lib/helpers/combineURLs.js
  init_define_import_meta_env();
  function combineURLs(baseURL, relativeURL) {
    return relativeURL ? baseURL.replace(/\/?\/$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL;
  }

  // node_modules/axios/lib/core/buildFullPath.js
  function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls) {
    let isRelativeUrl = !isAbsoluteURL(requestedURL);
    if (baseURL && (isRelativeUrl || allowAbsoluteUrls === false)) {
      return combineURLs(baseURL, requestedURL);
    }
    return requestedURL;
  }

  // node_modules/axios/lib/core/mergeConfig.js
  init_define_import_meta_env();
  var headersToObject = (thing) => thing instanceof AxiosHeaders_default ? { ...thing } : thing;
  function mergeConfig(config1, config22) {
    config22 = config22 || {};
    const config3 = /* @__PURE__ */ Object.create(null);
    Object.defineProperty(config3, "hasOwnProperty", {
      // Null-proto descriptor so a polluted Object.prototype.get cannot turn
      // this data descriptor into an accessor descriptor on the way in.
      __proto__: null,
      value: Object.prototype.hasOwnProperty,
      enumerable: false,
      writable: true,
      configurable: true
    });
    function getMergedValue(target, source, prop, caseless) {
      if (utils_default.isPlainObject(target) && utils_default.isPlainObject(source)) {
        return utils_default.merge.call({ caseless }, target, source);
      } else if (utils_default.isPlainObject(source)) {
        return utils_default.merge({}, source);
      } else if (utils_default.isArray(source)) {
        return source.slice();
      }
      return source;
    }
    function mergeDeepProperties(a15, b8, prop, caseless) {
      if (!utils_default.isUndefined(b8)) {
        return getMergedValue(a15, b8, prop, caseless);
      } else if (!utils_default.isUndefined(a15)) {
        return getMergedValue(void 0, a15, prop, caseless);
      }
    }
    function valueFromConfig2(a15, b8) {
      if (!utils_default.isUndefined(b8)) {
        return getMergedValue(void 0, b8);
      }
    }
    function defaultToConfig2(a15, b8) {
      if (!utils_default.isUndefined(b8)) {
        return getMergedValue(void 0, b8);
      } else if (!utils_default.isUndefined(a15)) {
        return getMergedValue(void 0, a15);
      }
    }
    function mergeDirectKeys(a15, b8, prop) {
      if (utils_default.hasOwnProp(config22, prop)) {
        return getMergedValue(a15, b8);
      } else if (utils_default.hasOwnProp(config1, prop)) {
        return getMergedValue(void 0, a15);
      }
    }
    const mergeMap = {
      url: valueFromConfig2,
      method: valueFromConfig2,
      data: valueFromConfig2,
      baseURL: defaultToConfig2,
      transformRequest: defaultToConfig2,
      transformResponse: defaultToConfig2,
      paramsSerializer: defaultToConfig2,
      timeout: defaultToConfig2,
      timeoutMessage: defaultToConfig2,
      withCredentials: defaultToConfig2,
      withXSRFToken: defaultToConfig2,
      adapter: defaultToConfig2,
      responseType: defaultToConfig2,
      xsrfCookieName: defaultToConfig2,
      xsrfHeaderName: defaultToConfig2,
      onUploadProgress: defaultToConfig2,
      onDownloadProgress: defaultToConfig2,
      decompress: defaultToConfig2,
      maxContentLength: defaultToConfig2,
      maxBodyLength: defaultToConfig2,
      beforeRedirect: defaultToConfig2,
      transport: defaultToConfig2,
      httpAgent: defaultToConfig2,
      httpsAgent: defaultToConfig2,
      cancelToken: defaultToConfig2,
      socketPath: defaultToConfig2,
      allowedSocketPaths: defaultToConfig2,
      responseEncoding: defaultToConfig2,
      validateStatus: mergeDirectKeys,
      headers: (a15, b8, prop) => mergeDeepProperties(headersToObject(a15), headersToObject(b8), prop, true)
    };
    utils_default.forEach(Object.keys({ ...config1, ...config22 }), function computeConfigValue(prop) {
      if (prop === "__proto__" || prop === "constructor" || prop === "prototype") return;
      const merge3 = utils_default.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
      const a15 = utils_default.hasOwnProp(config1, prop) ? config1[prop] : void 0;
      const b8 = utils_default.hasOwnProp(config22, prop) ? config22[prop] : void 0;
      const configValue = merge3(a15, b8, prop);
      utils_default.isUndefined(configValue) && merge3 !== mergeDirectKeys || (config3[prop] = configValue);
    });
    return config3;
  }

  // node_modules/axios/lib/helpers/resolveConfig.js
  var FORM_DATA_CONTENT_HEADERS = ["content-type", "content-length"];
  function setFormDataHeaders(headers, formHeaders, policy) {
    if (policy !== "content-only") {
      headers.set(formHeaders);
      return;
    }
    Object.entries(formHeaders).forEach(([key, val]) => {
      if (FORM_DATA_CONTENT_HEADERS.includes(key.toLowerCase())) {
        headers.set(key, val);
      }
    });
  }
  var encodeUTF8 = (str) => encodeURIComponent(str).replace(
    /%([0-9A-F]{2})/gi,
    (_4, hex) => String.fromCharCode(parseInt(hex, 16))
  );
  var resolveConfig_default = (config3) => {
    const newConfig = mergeConfig({}, config3);
    const own2 = (key) => utils_default.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
    const data = own2("data");
    let withXSRFToken = own2("withXSRFToken");
    const xsrfHeaderName = own2("xsrfHeaderName");
    const xsrfCookieName = own2("xsrfCookieName");
    let headers = own2("headers");
    const auth = own2("auth");
    const baseURL = own2("baseURL");
    const allowAbsoluteUrls = own2("allowAbsoluteUrls");
    const url = own2("url");
    newConfig.headers = headers = AxiosHeaders_default.from(headers);
    newConfig.url = buildURL(
      buildFullPath(baseURL, url, allowAbsoluteUrls),
      config3.params,
      config3.paramsSerializer
    );
    if (auth) {
      headers.set(
        "Authorization",
        "Basic " + btoa((auth.username || "") + ":" + (auth.password ? encodeUTF8(auth.password) : ""))
      );
    }
    if (utils_default.isFormData(data)) {
      if (platform_default.hasStandardBrowserEnv || platform_default.hasStandardBrowserWebWorkerEnv) {
        headers.setContentType(void 0);
      } else if (utils_default.isFunction(data.getHeaders)) {
        setFormDataHeaders(headers, data.getHeaders(), own2("formDataHeaderPolicy"));
      }
    }
    if (platform_default.hasStandardBrowserEnv) {
      if (utils_default.isFunction(withXSRFToken)) {
        withXSRFToken = withXSRFToken(newConfig);
      }
      const shouldSendXSRF = withXSRFToken === true || withXSRFToken == null && isURLSameOrigin_default(newConfig.url);
      if (shouldSendXSRF) {
        const xsrfValue = xsrfHeaderName && xsrfCookieName && cookies_default.read(xsrfCookieName);
        if (xsrfValue) {
          headers.set(xsrfHeaderName, xsrfValue);
        }
      }
    }
    return newConfig;
  };

  // node_modules/axios/lib/adapters/xhr.js
  var isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
  var xhr_default = isXHRAdapterSupported && function(config3) {
    return new Promise(function dispatchXhrRequest(resolve, reject) {
      const _config = resolveConfig_default(config3);
      let requestData = _config.data;
      const requestHeaders = AxiosHeaders_default.from(_config.headers).normalize();
      let { responseType, onUploadProgress, onDownloadProgress } = _config;
      let onCanceled;
      let uploadThrottled, downloadThrottled;
      let flushUpload, flushDownload;
      function done2() {
        flushUpload && flushUpload();
        flushDownload && flushDownload();
        _config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
        _config.signal && _config.signal.removeEventListener("abort", onCanceled);
      }
      let request2 = new XMLHttpRequest();
      request2.open(_config.method.toUpperCase(), _config.url, true);
      request2.timeout = _config.timeout;
      function onloadend() {
        if (!request2) {
          return;
        }
        const responseHeaders = AxiosHeaders_default.from(
          "getAllResponseHeaders" in request2 && request2.getAllResponseHeaders()
        );
        const responseData = !responseType || responseType === "text" || responseType === "json" ? request2.responseText : request2.response;
        const response = {
          data: responseData,
          status: request2.status,
          statusText: request2.statusText,
          headers: responseHeaders,
          config: config3,
          request: request2
        };
        settle(
          function _resolve(value) {
            resolve(value);
            done2();
          },
          function _reject(err) {
            reject(err);
            done2();
          },
          response
        );
        request2 = null;
      }
      if ("onloadend" in request2) {
        request2.onloadend = onloadend;
      } else {
        request2.onreadystatechange = function handleLoad() {
          if (!request2 || request2.readyState !== 4) {
            return;
          }
          if (request2.status === 0 && !(request2.responseURL && request2.responseURL.startsWith("file:"))) {
            return;
          }
          setTimeout(onloadend);
        };
      }
      request2.onabort = function handleAbort() {
        if (!request2) {
          return;
        }
        reject(new AxiosError_default("Request aborted", AxiosError_default.ECONNABORTED, config3, request2));
        done2();
        request2 = null;
      };
      request2.onerror = function handleError(event) {
        const msg = event && event.message ? event.message : "Network Error";
        const err = new AxiosError_default(msg, AxiosError_default.ERR_NETWORK, config3, request2);
        err.event = event || null;
        reject(err);
        done2();
        request2 = null;
      };
      request2.ontimeout = function handleTimeout() {
        let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
        const transitional2 = _config.transitional || transitional_default;
        if (_config.timeoutErrorMessage) {
          timeoutErrorMessage = _config.timeoutErrorMessage;
        }
        reject(
          new AxiosError_default(
            timeoutErrorMessage,
            transitional2.clarifyTimeoutError ? AxiosError_default.ETIMEDOUT : AxiosError_default.ECONNABORTED,
            config3,
            request2
          )
        );
        done2();
        request2 = null;
      };
      requestData === void 0 && requestHeaders.setContentType(null);
      if ("setRequestHeader" in request2) {
        utils_default.forEach(toByteStringHeaderObject(requestHeaders), function setRequestHeader(val, key) {
          request2.setRequestHeader(key, val);
        });
      }
      if (!utils_default.isUndefined(_config.withCredentials)) {
        request2.withCredentials = !!_config.withCredentials;
      }
      if (responseType && responseType !== "json") {
        request2.responseType = _config.responseType;
      }
      if (onDownloadProgress) {
        [downloadThrottled, flushDownload] = progressEventReducer(onDownloadProgress, true);
        request2.addEventListener("progress", downloadThrottled);
      }
      if (onUploadProgress && request2.upload) {
        [uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
        request2.upload.addEventListener("progress", uploadThrottled);
        request2.upload.addEventListener("loadend", flushUpload);
      }
      if (_config.cancelToken || _config.signal) {
        onCanceled = (cancel) => {
          if (!request2) {
            return;
          }
          reject(!cancel || cancel.type ? new CanceledError_default(null, config3, request2) : cancel);
          request2.abort();
          done2();
          request2 = null;
        };
        _config.cancelToken && _config.cancelToken.subscribe(onCanceled);
        if (_config.signal) {
          _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
        }
      }
      const protocol = parseProtocol(_config.url);
      if (protocol && !platform_default.protocols.includes(protocol)) {
        reject(
          new AxiosError_default(
            "Unsupported protocol " + protocol + ":",
            AxiosError_default.ERR_BAD_REQUEST,
            config3
          )
        );
        return;
      }
      request2.send(requestData || null);
    });
  };

  // node_modules/axios/lib/adapters/fetch.js
  init_define_import_meta_env();

  // node_modules/axios/lib/helpers/composeSignals.js
  init_define_import_meta_env();
  var composeSignals = (signals, timeout) => {
    signals = signals ? signals.filter(Boolean) : [];
    if (!timeout && !signals.length) {
      return;
    }
    const controller = new AbortController();
    let aborted = false;
    const onabort = function(reason) {
      if (!aborted) {
        aborted = true;
        unsubscribe();
        const err = reason instanceof Error ? reason : this.reason;
        controller.abort(
          err instanceof AxiosError_default ? err : new CanceledError_default(err instanceof Error ? err.message : err)
        );
      }
    };
    let timer = timeout && setTimeout(() => {
      timer = null;
      onabort(new AxiosError_default(`timeout of ${timeout}ms exceeded`, AxiosError_default.ETIMEDOUT));
    }, timeout);
    const unsubscribe = () => {
      if (!signals) {
        return;
      }
      timer && clearTimeout(timer);
      timer = null;
      signals.forEach((signal2) => {
        signal2.unsubscribe ? signal2.unsubscribe(onabort) : signal2.removeEventListener("abort", onabort);
      });
      signals = null;
    };
    signals.forEach((signal2) => signal2.addEventListener("abort", onabort));
    const { signal } = controller;
    signal.unsubscribe = () => utils_default.asap(unsubscribe);
    return signal;
  };
  var composeSignals_default = composeSignals;

  // node_modules/axios/lib/helpers/trackStream.js
  init_define_import_meta_env();
  var streamChunk = function* (chunk, chunkSize) {
    let len = chunk.byteLength;
    if (!chunkSize || len < chunkSize) {
      yield chunk;
      return;
    }
    let pos = 0;
    let end;
    while (pos < len) {
      end = pos + chunkSize;
      yield chunk.slice(pos, end);
      pos = end;
    }
  };
  var readBytes = async function* (iterable, chunkSize) {
    for await (const chunk of readStream(iterable)) {
      yield* streamChunk(chunk, chunkSize);
    }
  };
  var readStream = async function* (stream) {
    if (stream[Symbol.asyncIterator]) {
      yield* stream;
      return;
    }
    const reader = stream.getReader();
    try {
      for (; ; ) {
        const { done: done2, value } = await reader.read();
        if (done2) {
          break;
        }
        yield value;
      }
    } finally {
      await reader.cancel();
    }
  };
  var trackStream = (stream, chunkSize, onProgress, onFinish) => {
    const iterator2 = readBytes(stream, chunkSize);
    let bytes = 0;
    let done2;
    let _onFinish = (e6) => {
      if (!done2) {
        done2 = true;
        onFinish && onFinish(e6);
      }
    };
    return new ReadableStream(
      {
        async pull(controller) {
          try {
            const { done: done3, value } = await iterator2.next();
            if (done3) {
              _onFinish();
              controller.close();
              return;
            }
            let len = value.byteLength;
            if (onProgress) {
              let loadedBytes = bytes += len;
              onProgress(loadedBytes);
            }
            controller.enqueue(new Uint8Array(value));
          } catch (err) {
            _onFinish(err);
            throw err;
          }
        },
        cancel(reason) {
          _onFinish(reason);
          return iterator2.return();
        }
      },
      {
        highWaterMark: 2
      }
    );
  };

  // node_modules/axios/lib/helpers/estimateDataURLDecodedBytes.js
  init_define_import_meta_env();
  function estimateDataURLDecodedBytes(url) {
    if (!url || typeof url !== "string") return 0;
    if (!url.startsWith("data:")) return 0;
    const comma = url.indexOf(",");
    if (comma < 0) return 0;
    const meta = url.slice(5, comma);
    const body = url.slice(comma + 1);
    const isBase64 = /;base64/i.test(meta);
    if (isBase64) {
      let effectiveLen = body.length;
      const len = body.length;
      for (let i12 = 0; i12 < len; i12++) {
        if (body.charCodeAt(i12) === 37 && i12 + 2 < len) {
          const a15 = body.charCodeAt(i12 + 1);
          const b8 = body.charCodeAt(i12 + 2);
          const isHex = (a15 >= 48 && a15 <= 57 || a15 >= 65 && a15 <= 70 || a15 >= 97 && a15 <= 102) && (b8 >= 48 && b8 <= 57 || b8 >= 65 && b8 <= 70 || b8 >= 97 && b8 <= 102);
          if (isHex) {
            effectiveLen -= 2;
            i12 += 2;
          }
        }
      }
      let pad = 0;
      let idx = len - 1;
      const tailIsPct3D = (j7) => j7 >= 2 && body.charCodeAt(j7 - 2) === 37 && // '%'
      body.charCodeAt(j7 - 1) === 51 && // '3'
      (body.charCodeAt(j7) === 68 || body.charCodeAt(j7) === 100);
      if (idx >= 0) {
        if (body.charCodeAt(idx) === 61) {
          pad++;
          idx--;
        } else if (tailIsPct3D(idx)) {
          pad++;
          idx -= 3;
        }
      }
      if (pad === 1 && idx >= 0) {
        if (body.charCodeAt(idx) === 61) {
          pad++;
        } else if (tailIsPct3D(idx)) {
          pad++;
        }
      }
      const groups = Math.floor(effectiveLen / 4);
      const bytes2 = groups * 3 - (pad || 0);
      return bytes2 > 0 ? bytes2 : 0;
    }
    if (typeof Buffer !== "undefined" && typeof Buffer.byteLength === "function") {
      return Buffer.byteLength(body, "utf8");
    }
    let bytes = 0;
    for (let i12 = 0, len = body.length; i12 < len; i12++) {
      const c12 = body.charCodeAt(i12);
      if (c12 < 128) {
        bytes += 1;
      } else if (c12 < 2048) {
        bytes += 2;
      } else if (c12 >= 55296 && c12 <= 56319 && i12 + 1 < len) {
        const next = body.charCodeAt(i12 + 1);
        if (next >= 56320 && next <= 57343) {
          bytes += 4;
          i12++;
        } else {
          bytes += 3;
        }
      } else {
        bytes += 3;
      }
    }
    return bytes;
  }

  // node_modules/axios/lib/env/data.js
  init_define_import_meta_env();
  var VERSION = "1.16.1";

  // node_modules/axios/lib/adapters/fetch.js
  var DEFAULT_CHUNK_SIZE = 64 * 1024;
  var { isFunction: isFunction3 } = utils_default;
  var test = (fn, ...args) => {
    try {
      return !!fn(...args);
    } catch (e6) {
      return false;
    }
  };
  var factory = (env) => {
    const globalObject = utils_default.global !== void 0 && utils_default.global !== null ? utils_default.global : globalThis;
    const { ReadableStream: ReadableStream2, TextEncoder: TextEncoder2 } = globalObject;
    env = utils_default.merge.call(
      {
        skipUndefined: true
      },
      {
        Request: globalObject.Request,
        Response: globalObject.Response
      },
      env
    );
    const { fetch: envFetch, Request: Request2, Response: Response2 } = env;
    const isFetchSupported = envFetch ? isFunction3(envFetch) : typeof fetch === "function";
    const isRequestSupported = isFunction3(Request2);
    const isResponseSupported = isFunction3(Response2);
    if (!isFetchSupported) {
      return false;
    }
    const isReadableStreamSupported = isFetchSupported && isFunction3(ReadableStream2);
    const encodeText = isFetchSupported && (typeof TextEncoder2 === "function" ? /* @__PURE__ */ ((encoder) => (str) => encoder.encode(str))(new TextEncoder2()) : async (str) => new Uint8Array(await new Request2(str).arrayBuffer()));
    const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
      let duplexAccessed = false;
      const request2 = new Request2(platform_default.origin, {
        body: new ReadableStream2(),
        method: "POST",
        get duplex() {
          duplexAccessed = true;
          return "half";
        }
      });
      const hasContentType = request2.headers.has("Content-Type");
      if (request2.body != null) {
        request2.body.cancel();
      }
      return duplexAccessed && !hasContentType;
    });
    const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils_default.isReadableStream(new Response2("").body));
    const resolvers = {
      stream: supportsResponseStream && ((res) => res.body)
    };
    isFetchSupported && (() => {
      ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((type) => {
        !resolvers[type] && (resolvers[type] = (res, config3) => {
          let method = res && res[type];
          if (method) {
            return method.call(res);
          }
          throw new AxiosError_default(
            `Response type '${type}' is not supported`,
            AxiosError_default.ERR_NOT_SUPPORT,
            config3
          );
        });
      });
    })();
    const getBodyLength = async (body) => {
      if (body == null) {
        return 0;
      }
      if (utils_default.isBlob(body)) {
        return body.size;
      }
      if (utils_default.isSpecCompliantForm(body)) {
        const _request = new Request2(platform_default.origin, {
          method: "POST",
          body
        });
        return (await _request.arrayBuffer()).byteLength;
      }
      if (utils_default.isArrayBufferView(body) || utils_default.isArrayBuffer(body)) {
        return body.byteLength;
      }
      if (utils_default.isURLSearchParams(body)) {
        body = body + "";
      }
      if (utils_default.isString(body)) {
        return (await encodeText(body)).byteLength;
      }
    };
    const resolveBodyLength = async (headers, body) => {
      const length = utils_default.toFiniteNumber(headers.getContentLength());
      return length == null ? getBodyLength(body) : length;
    };
    return async (config3) => {
      let {
        url,
        method,
        data,
        signal,
        cancelToken,
        timeout,
        onDownloadProgress,
        onUploadProgress,
        responseType,
        headers,
        withCredentials = "same-origin",
        fetchOptions,
        maxContentLength,
        maxBodyLength
      } = resolveConfig_default(config3);
      const hasMaxContentLength = utils_default.isNumber(maxContentLength) && maxContentLength > -1;
      const hasMaxBodyLength = utils_default.isNumber(maxBodyLength) && maxBodyLength > -1;
      let _fetch = envFetch || fetch;
      responseType = responseType ? (responseType + "").toLowerCase() : "text";
      let composedSignal = composeSignals_default(
        [signal, cancelToken && cancelToken.toAbortSignal()],
        timeout
      );
      let request2 = null;
      const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
        composedSignal.unsubscribe();
      });
      let requestContentLength;
      try {
        if (hasMaxContentLength && typeof url === "string" && url.startsWith("data:")) {
          const estimated = estimateDataURLDecodedBytes(url);
          if (estimated > maxContentLength) {
            throw new AxiosError_default(
              "maxContentLength size of " + maxContentLength + " exceeded",
              AxiosError_default.ERR_BAD_RESPONSE,
              config3,
              request2
            );
          }
        }
        if (hasMaxBodyLength && method !== "get" && method !== "head") {
          const outboundLength = await resolveBodyLength(headers, data);
          if (typeof outboundLength === "number" && isFinite(outboundLength) && outboundLength > maxBodyLength) {
            throw new AxiosError_default(
              "Request body larger than maxBodyLength limit",
              AxiosError_default.ERR_BAD_REQUEST,
              config3,
              request2
            );
          }
        }
        if (onUploadProgress && supportsRequestStream && method !== "get" && method !== "head" && (requestContentLength = await resolveBodyLength(headers, data)) !== 0) {
          let _request = new Request2(url, {
            method: "POST",
            body: data,
            duplex: "half"
          });
          let contentTypeHeader;
          if (utils_default.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) {
            headers.setContentType(contentTypeHeader);
          }
          if (_request.body) {
            const [onProgress, flush] = progressEventDecorator(
              requestContentLength,
              progressEventReducer(asyncDecorator(onUploadProgress))
            );
            data = trackStream(_request.body, DEFAULT_CHUNK_SIZE, onProgress, flush);
          }
        }
        if (!utils_default.isString(withCredentials)) {
          withCredentials = withCredentials ? "include" : "omit";
        }
        const isCredentialsSupported = isRequestSupported && "credentials" in Request2.prototype;
        if (utils_default.isFormData(data)) {
          const contentType = headers.getContentType();
          if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) {
            headers.delete("content-type");
          }
        }
        headers.set("User-Agent", "axios/" + VERSION, false);
        const resolvedOptions = {
          ...fetchOptions,
          signal: composedSignal,
          method: method.toUpperCase(),
          headers: toByteStringHeaderObject(headers.normalize()),
          body: data,
          duplex: "half",
          credentials: isCredentialsSupported ? withCredentials : void 0
        };
        request2 = isRequestSupported && new Request2(url, resolvedOptions);
        let response = await (isRequestSupported ? _fetch(request2, fetchOptions) : _fetch(url, resolvedOptions));
        if (hasMaxContentLength) {
          const declaredLength = utils_default.toFiniteNumber(response.headers.get("content-length"));
          if (declaredLength != null && declaredLength > maxContentLength) {
            throw new AxiosError_default(
              "maxContentLength size of " + maxContentLength + " exceeded",
              AxiosError_default.ERR_BAD_RESPONSE,
              config3,
              request2
            );
          }
        }
        const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
        if (supportsResponseStream && response.body && (onDownloadProgress || hasMaxContentLength || isStreamResponse && unsubscribe)) {
          const options = {};
          ["status", "statusText", "headers"].forEach((prop) => {
            options[prop] = response[prop];
          });
          const responseContentLength = utils_default.toFiniteNumber(response.headers.get("content-length"));
          const [onProgress, flush] = onDownloadProgress && progressEventDecorator(
            responseContentLength,
            progressEventReducer(asyncDecorator(onDownloadProgress), true)
          ) || [];
          let bytesRead = 0;
          const onChunkProgress = (loadedBytes) => {
            if (hasMaxContentLength) {
              bytesRead = loadedBytes;
              if (bytesRead > maxContentLength) {
                throw new AxiosError_default(
                  "maxContentLength size of " + maxContentLength + " exceeded",
                  AxiosError_default.ERR_BAD_RESPONSE,
                  config3,
                  request2
                );
              }
            }
            onProgress && onProgress(loadedBytes);
          };
          response = new Response2(
            trackStream(response.body, DEFAULT_CHUNK_SIZE, onChunkProgress, () => {
              flush && flush();
              unsubscribe && unsubscribe();
            }),
            options
          );
        }
        responseType = responseType || "text";
        let responseData = await resolvers[utils_default.findKey(resolvers, responseType) || "text"](
          response,
          config3
        );
        if (hasMaxContentLength && !supportsResponseStream && !isStreamResponse) {
          let materializedSize;
          if (responseData != null) {
            if (typeof responseData.byteLength === "number") {
              materializedSize = responseData.byteLength;
            } else if (typeof responseData.size === "number") {
              materializedSize = responseData.size;
            } else if (typeof responseData === "string") {
              materializedSize = typeof TextEncoder2 === "function" ? new TextEncoder2().encode(responseData).byteLength : responseData.length;
            }
          }
          if (typeof materializedSize === "number" && materializedSize > maxContentLength) {
            throw new AxiosError_default(
              "maxContentLength size of " + maxContentLength + " exceeded",
              AxiosError_default.ERR_BAD_RESPONSE,
              config3,
              request2
            );
          }
        }
        !isStreamResponse && unsubscribe && unsubscribe();
        return await new Promise((resolve, reject) => {
          settle(resolve, reject, {
            data: responseData,
            headers: AxiosHeaders_default.from(response.headers),
            status: response.status,
            statusText: response.statusText,
            config: config3,
            request: request2
          });
        });
      } catch (err) {
        unsubscribe && unsubscribe();
        if (composedSignal && composedSignal.aborted && composedSignal.reason instanceof AxiosError_default) {
          const canceledError = composedSignal.reason;
          canceledError.config = config3;
          request2 && (canceledError.request = request2);
          err !== canceledError && (canceledError.cause = err);
          throw canceledError;
        }
        if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
          throw Object.assign(
            new AxiosError_default(
              "Network Error",
              AxiosError_default.ERR_NETWORK,
              config3,
              request2,
              err && err.response
            ),
            {
              cause: err.cause || err
            }
          );
        }
        throw AxiosError_default.from(err, err && err.code, config3, request2, err && err.response);
      }
    };
  };
  var seedCache = /* @__PURE__ */ new Map();
  var getFetch = (config3) => {
    let env = config3 && config3.env || {};
    const { fetch: fetch2, Request: Request2, Response: Response2 } = env;
    const seeds = [Request2, Response2, fetch2];
    let len = seeds.length, i12 = len, seed, target, map = seedCache;
    while (i12--) {
      seed = seeds[i12];
      target = map.get(seed);
      target === void 0 && map.set(seed, target = i12 ? /* @__PURE__ */ new Map() : factory(env));
      map = target;
    }
    return target;
  };
  var adapter = getFetch();

  // node_modules/axios/lib/adapters/adapters.js
  var knownAdapters = {
    http: null_default,
    xhr: xhr_default,
    fetch: {
      get: getFetch
    }
  };
  utils_default.forEach(knownAdapters, (fn, value) => {
    if (fn) {
      try {
        Object.defineProperty(fn, "name", { __proto__: null, value });
      } catch (e6) {
      }
      Object.defineProperty(fn, "adapterName", { __proto__: null, value });
    }
  });
  var renderReason = (reason) => `- ${reason}`;
  var isResolvedHandle = (adapter2) => utils_default.isFunction(adapter2) || adapter2 === null || adapter2 === false;
  function getAdapter(adapters, config3) {
    adapters = utils_default.isArray(adapters) ? adapters : [adapters];
    const { length } = adapters;
    let nameOrAdapter;
    let adapter2;
    const rejectedReasons = {};
    for (let i12 = 0; i12 < length; i12++) {
      nameOrAdapter = adapters[i12];
      let id;
      adapter2 = nameOrAdapter;
      if (!isResolvedHandle(nameOrAdapter)) {
        adapter2 = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
        if (adapter2 === void 0) {
          throw new AxiosError_default(`Unknown adapter '${id}'`);
        }
      }
      if (adapter2 && (utils_default.isFunction(adapter2) || (adapter2 = adapter2.get(config3)))) {
        break;
      }
      rejectedReasons[id || "#" + i12] = adapter2;
    }
    if (!adapter2) {
      const reasons = Object.entries(rejectedReasons).map(
        ([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build")
      );
      let s11 = length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified";
      throw new AxiosError_default(
        `There is no suitable adapter to dispatch the request ` + s11,
        "ERR_NOT_SUPPORT"
      );
    }
    return adapter2;
  }
  var adapters_default = {
    /**
     * Resolve an adapter from a list of adapter names or functions.
     * @type {Function}
     */
    getAdapter,
    /**
     * Exposes all known adapters
     * @type {Object<string, Function|Object>}
     */
    adapters: knownAdapters
  };

  // node_modules/axios/lib/core/dispatchRequest.js
  function throwIfCancellationRequested(config3) {
    if (config3.cancelToken) {
      config3.cancelToken.throwIfRequested();
    }
    if (config3.signal && config3.signal.aborted) {
      throw new CanceledError_default(null, config3);
    }
  }
  function dispatchRequest(config3) {
    throwIfCancellationRequested(config3);
    config3.headers = AxiosHeaders_default.from(config3.headers);
    config3.data = transformData.call(config3, config3.transformRequest);
    if (["post", "put", "patch"].indexOf(config3.method) !== -1) {
      config3.headers.setContentType("application/x-www-form-urlencoded", false);
    }
    const adapter2 = adapters_default.getAdapter(config3.adapter || defaults_default.adapter, config3);
    return adapter2(config3).then(
      function onAdapterResolution(response) {
        throwIfCancellationRequested(config3);
        config3.response = response;
        try {
          response.data = transformData.call(config3, config3.transformResponse, response);
        } finally {
          delete config3.response;
        }
        response.headers = AxiosHeaders_default.from(response.headers);
        return response;
      },
      function onAdapterRejection(reason) {
        if (!isCancel(reason)) {
          throwIfCancellationRequested(config3);
          if (reason && reason.response) {
            config3.response = reason.response;
            try {
              reason.response.data = transformData.call(
                config3,
                config3.transformResponse,
                reason.response
              );
            } finally {
              delete config3.response;
            }
            reason.response.headers = AxiosHeaders_default.from(reason.response.headers);
          }
        }
        return Promise.reject(reason);
      }
    );
  }

  // node_modules/axios/lib/helpers/validator.js
  init_define_import_meta_env();
  var validators = {};
  ["object", "boolean", "number", "function", "string", "symbol"].forEach((type, i12) => {
    validators[type] = function validator(thing) {
      return typeof thing === type || "a" + (i12 < 1 ? "n " : " ") + type;
    };
  });
  var deprecatedWarnings = {};
  validators.transitional = function transitional(validator, version, message) {
    function formatMessage(opt, desc) {
      return "[Axios v" + VERSION + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
    }
    return (value, opt, opts) => {
      if (validator === false) {
        throw new AxiosError_default(
          formatMessage(opt, " has been removed" + (version ? " in " + version : "")),
          AxiosError_default.ERR_DEPRECATED
        );
      }
      if (version && !deprecatedWarnings[opt]) {
        deprecatedWarnings[opt] = true;
        console.warn(
          formatMessage(
            opt,
            " has been deprecated since v" + version + " and will be removed in the near future"
          )
        );
      }
      return validator ? validator(value, opt, opts) : true;
    };
  };
  validators.spelling = function spelling(correctSpelling) {
    return (value, opt) => {
      console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
      return true;
    };
  };
  function assertOptions(options, schema, allowUnknown) {
    if (typeof options !== "object") {
      throw new AxiosError_default("options must be an object", AxiosError_default.ERR_BAD_OPTION_VALUE);
    }
    const keys2 = Object.keys(options);
    let i12 = keys2.length;
    while (i12-- > 0) {
      const opt = keys2[i12];
      const validator = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
      if (validator) {
        const value = options[opt];
        const result = value === void 0 || validator(value, opt, options);
        if (result !== true) {
          throw new AxiosError_default(
            "option " + opt + " must be " + result,
            AxiosError_default.ERR_BAD_OPTION_VALUE
          );
        }
        continue;
      }
      if (allowUnknown !== true) {
        throw new AxiosError_default("Unknown option " + opt, AxiosError_default.ERR_BAD_OPTION);
      }
    }
  }
  var validator_default = {
    assertOptions,
    validators
  };

  // node_modules/axios/lib/core/Axios.js
  var validators2 = validator_default.validators;
  var Axios = class {
    constructor(instanceConfig) {
      this.defaults = instanceConfig || {};
      this.interceptors = {
        request: new InterceptorManager_default(),
        response: new InterceptorManager_default()
      };
    }
    /**
     * Dispatch a request
     *
     * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
     * @param {?Object} config
     *
     * @returns {Promise} The Promise to be fulfilled
     */
    async request(configOrUrl, config3) {
      try {
        return await this._request(configOrUrl, config3);
      } catch (err) {
        if (err instanceof Error) {
          let dummy = {};
          Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = new Error();
          const stack = (() => {
            if (!dummy.stack) {
              return "";
            }
            const firstNewlineIndex = dummy.stack.indexOf("\n");
            return firstNewlineIndex === -1 ? "" : dummy.stack.slice(firstNewlineIndex + 1);
          })();
          try {
            if (!err.stack) {
              err.stack = stack;
            } else if (stack) {
              const firstNewlineIndex = stack.indexOf("\n");
              const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
              const stackWithoutTwoTopLines = secondNewlineIndex === -1 ? "" : stack.slice(secondNewlineIndex + 1);
              if (!String(err.stack).endsWith(stackWithoutTwoTopLines)) {
                err.stack += "\n" + stack;
              }
            }
          } catch (e6) {
          }
        }
        throw err;
      }
    }
    _request(configOrUrl, config3) {
      if (typeof configOrUrl === "string") {
        config3 = config3 || {};
        config3.url = configOrUrl;
      } else {
        config3 = configOrUrl || {};
      }
      config3 = mergeConfig(this.defaults, config3);
      const { transitional: transitional2, paramsSerializer, headers } = config3;
      if (transitional2 !== void 0) {
        validator_default.assertOptions(
          transitional2,
          {
            silentJSONParsing: validators2.transitional(validators2.boolean),
            forcedJSONParsing: validators2.transitional(validators2.boolean),
            clarifyTimeoutError: validators2.transitional(validators2.boolean),
            legacyInterceptorReqResOrdering: validators2.transitional(validators2.boolean)
          },
          false
        );
      }
      if (paramsSerializer != null) {
        if (utils_default.isFunction(paramsSerializer)) {
          config3.paramsSerializer = {
            serialize: paramsSerializer
          };
        } else {
          validator_default.assertOptions(
            paramsSerializer,
            {
              encode: validators2.function,
              serialize: validators2.function
            },
            true
          );
        }
      }
      if (config3.allowAbsoluteUrls !== void 0) {
      } else if (this.defaults.allowAbsoluteUrls !== void 0) {
        config3.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
      } else {
        config3.allowAbsoluteUrls = true;
      }
      validator_default.assertOptions(
        config3,
        {
          baseUrl: validators2.spelling("baseURL"),
          withXsrfToken: validators2.spelling("withXSRFToken")
        },
        true
      );
      config3.method = (config3.method || this.defaults.method || "get").toLowerCase();
      let contextHeaders = headers && utils_default.merge(headers.common, headers[config3.method]);
      headers && utils_default.forEach(["delete", "get", "head", "post", "put", "patch", "query", "common"], (method) => {
        delete headers[method];
      });
      config3.headers = AxiosHeaders_default.concat(contextHeaders, headers);
      const requestInterceptorChain = [];
      let synchronousRequestInterceptors = true;
      this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
        if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config3) === false) {
          return;
        }
        synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
        const transitional3 = config3.transitional || transitional_default;
        const legacyInterceptorReqResOrdering = transitional3 && transitional3.legacyInterceptorReqResOrdering;
        if (legacyInterceptorReqResOrdering) {
          requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
        } else {
          requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
        }
      });
      const responseInterceptorChain = [];
      this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
        responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
      });
      let promise;
      let i12 = 0;
      let len;
      if (!synchronousRequestInterceptors) {
        const chain = [dispatchRequest.bind(this), void 0];
        chain.unshift(...requestInterceptorChain);
        chain.push(...responseInterceptorChain);
        len = chain.length;
        promise = Promise.resolve(config3);
        while (i12 < len) {
          promise = promise.then(chain[i12++], chain[i12++]);
        }
        return promise;
      }
      len = requestInterceptorChain.length;
      let newConfig = config3;
      while (i12 < len) {
        const onFulfilled = requestInterceptorChain[i12++];
        const onRejected = requestInterceptorChain[i12++];
        try {
          newConfig = onFulfilled(newConfig);
        } catch (error) {
          onRejected.call(this, error);
          break;
        }
      }
      try {
        promise = dispatchRequest.call(this, newConfig);
      } catch (error) {
        return Promise.reject(error);
      }
      i12 = 0;
      len = responseInterceptorChain.length;
      while (i12 < len) {
        promise = promise.then(responseInterceptorChain[i12++], responseInterceptorChain[i12++]);
      }
      return promise;
    }
    getUri(config3) {
      config3 = mergeConfig(this.defaults, config3);
      const fullPath = buildFullPath(config3.baseURL, config3.url, config3.allowAbsoluteUrls);
      return buildURL(fullPath, config3.params, config3.paramsSerializer);
    }
  };
  utils_default.forEach(["delete", "get", "head", "options"], function forEachMethodNoData(method) {
    Axios.prototype[method] = function(url, config3) {
      return this.request(
        mergeConfig(config3 || {}, {
          method,
          url,
          data: (config3 || {}).data
        })
      );
    };
  });
  utils_default.forEach(["post", "put", "patch", "query"], function forEachMethodWithData(method) {
    function generateHTTPMethod(isForm) {
      return function httpMethod(url, data, config3) {
        return this.request(
          mergeConfig(config3 || {}, {
            method,
            headers: isForm ? {
              "Content-Type": "multipart/form-data"
            } : {},
            url,
            data
          })
        );
      };
    }
    Axios.prototype[method] = generateHTTPMethod();
    if (method !== "query") {
      Axios.prototype[method + "Form"] = generateHTTPMethod(true);
    }
  });
  var Axios_default = Axios;

  // node_modules/axios/lib/cancel/CancelToken.js
  init_define_import_meta_env();
  var CancelToken = class _CancelToken {
    constructor(executor) {
      if (typeof executor !== "function") {
        throw new TypeError("executor must be a function.");
      }
      let resolvePromise;
      this.promise = new Promise(function promiseExecutor(resolve) {
        resolvePromise = resolve;
      });
      const token = this;
      this.promise.then((cancel) => {
        if (!token._listeners) return;
        let i12 = token._listeners.length;
        while (i12-- > 0) {
          token._listeners[i12](cancel);
        }
        token._listeners = null;
      });
      this.promise.then = (onfulfilled) => {
        let _resolve;
        const promise = new Promise((resolve) => {
          token.subscribe(resolve);
          _resolve = resolve;
        }).then(onfulfilled);
        promise.cancel = function reject() {
          token.unsubscribe(_resolve);
        };
        return promise;
      };
      executor(function cancel(message, config3, request2) {
        if (token.reason) {
          return;
        }
        token.reason = new CanceledError_default(message, config3, request2);
        resolvePromise(token.reason);
      });
    }
    /**
     * Throws a `CanceledError` if cancellation has been requested.
     */
    throwIfRequested() {
      if (this.reason) {
        throw this.reason;
      }
    }
    /**
     * Subscribe to the cancel signal
     */
    subscribe(listener) {
      if (this.reason) {
        listener(this.reason);
        return;
      }
      if (this._listeners) {
        this._listeners.push(listener);
      } else {
        this._listeners = [listener];
      }
    }
    /**
     * Unsubscribe from the cancel signal
     */
    unsubscribe(listener) {
      if (!this._listeners) {
        return;
      }
      const index = this._listeners.indexOf(listener);
      if (index !== -1) {
        this._listeners.splice(index, 1);
      }
    }
    toAbortSignal() {
      const controller = new AbortController();
      const abort = (err) => {
        controller.abort(err);
      };
      this.subscribe(abort);
      controller.signal.unsubscribe = () => this.unsubscribe(abort);
      return controller.signal;
    }
    /**
     * Returns an object that contains a new `CancelToken` and a function that, when called,
     * cancels the `CancelToken`.
     */
    static source() {
      let cancel;
      const token = new _CancelToken(function executor(c12) {
        cancel = c12;
      });
      return {
        token,
        cancel
      };
    }
  };
  var CancelToken_default = CancelToken;

  // node_modules/axios/lib/helpers/spread.js
  init_define_import_meta_env();
  function spread(callback) {
    return function wrap(arr) {
      return callback.apply(null, arr);
    };
  }

  // node_modules/axios/lib/helpers/isAxiosError.js
  init_define_import_meta_env();
  function isAxiosError(payload) {
    return utils_default.isObject(payload) && payload.isAxiosError === true;
  }

  // node_modules/axios/lib/helpers/HttpStatusCode.js
  init_define_import_meta_env();
  var HttpStatusCode = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511,
    WebServerIsDown: 521,
    ConnectionTimedOut: 522,
    OriginIsUnreachable: 523,
    TimeoutOccurred: 524,
    SslHandshakeFailed: 525,
    InvalidSslCertificate: 526
  };
  Object.entries(HttpStatusCode).forEach(([key, value]) => {
    HttpStatusCode[value] = key;
  });
  var HttpStatusCode_default = HttpStatusCode;

  // node_modules/axios/lib/axios.js
  function createInstance(defaultConfig) {
    const context = new Axios_default(defaultConfig);
    const instance = bind(Axios_default.prototype.request, context);
    utils_default.extend(instance, Axios_default.prototype, context, { allOwnKeys: true });
    utils_default.extend(instance, context, null, { allOwnKeys: true });
    instance.create = function create2(instanceConfig) {
      return createInstance(mergeConfig(defaultConfig, instanceConfig));
    };
    return instance;
  }
  var axios = createInstance(defaults_default);
  axios.Axios = Axios_default;
  axios.CanceledError = CanceledError_default;
  axios.CancelToken = CancelToken_default;
  axios.isCancel = isCancel;
  axios.VERSION = VERSION;
  axios.toFormData = toFormData_default;
  axios.AxiosError = AxiosError_default;
  axios.Cancel = axios.CanceledError;
  axios.all = function all(promises) {
    return Promise.all(promises);
  };
  axios.spread = spread;
  axios.isAxiosError = isAxiosError;
  axios.mergeConfig = mergeConfig;
  axios.AxiosHeaders = AxiosHeaders_default;
  axios.formToJSON = (thing) => formDataToJSON_default(utils_default.isHTMLForm(thing) ? new FormData(thing) : thing);
  axios.getAdapter = adapters_default.getAdapter;
  axios.HttpStatusCode = HttpStatusCode_default;
  axios.default = axios;
  var axios_default = axios;

  // node_modules/axios/index.js
  var {
    Axios: Axios2,
    AxiosError: AxiosError2,
    CanceledError: CanceledError2,
    isCancel: isCancel2,
    CancelToken: CancelToken2,
    VERSION: VERSION2,
    all: all2,
    Cancel,
    isAxiosError: isAxiosError2,
    spread: spread2,
    toFormData: toFormData2,
    AxiosHeaders: AxiosHeaders2,
    HttpStatusCode: HttpStatusCode2,
    formToJSON,
    getAdapter: getAdapter2,
    mergeConfig: mergeConfig2,
    create
  } = axios_default;

  // node_modules/@inertiajs/core/dist/index.esm.js
  var Config = class {
    constructor(defaults2) {
      this.config = {};
      this.defaults = defaults2;
    }
    extend(defaults2) {
      if (defaults2) {
        this.defaults = { ...this.defaults, ...defaults2 };
      }
      return this;
    }
    replace(newConfig) {
      this.config = newConfig;
    }
    get(key) {
      return has_default(this.config, key) ? get_default(this.config, key) : get_default(this.defaults, key);
    }
    set(keyOrValues, value) {
      if (typeof keyOrValues === "string") {
        set_default(this.config, keyOrValues, value);
      } else {
        Object.entries(keyOrValues).forEach(([key, val]) => {
          set_default(this.config, key, val);
        });
      }
    }
  };
  var config = new Config({
    form: {
      recentlySuccessfulDuration: 2e3,
      forceIndicesArrayFormatInFormData: true,
      withAllErrors: false
    },
    future: {
      preserveEqualProps: false,
      useDataInertiaHeadAttribute: false,
      useDialogForErrorModal: false,
      useScriptElementForInitialPage: false
    },
    prefetch: {
      cacheFor: 3e4,
      hoverDelay: 75
    }
  });
  function debounce2(fn, delay) {
    let timeoutID;
    return function(...args) {
      clearTimeout(timeoutID);
      timeoutID = setTimeout(() => fn.apply(this, args), delay);
    };
  }
  function fireEvent(name, options) {
    return document.dispatchEvent(new CustomEvent(`inertia:${name}`, options));
  }
  var fireBeforeEvent = (visit) => {
    return fireEvent("before", { cancelable: true, detail: { visit } });
  };
  var fireErrorEvent = (errors) => {
    return fireEvent("error", { detail: { errors } });
  };
  var fireExceptionEvent = (exception) => {
    return fireEvent("exception", { cancelable: true, detail: { exception } });
  };
  var fireFinishEvent = (visit) => {
    return fireEvent("finish", { detail: { visit } });
  };
  var fireInvalidEvent = (response) => {
    return fireEvent("invalid", { cancelable: true, detail: { response } });
  };
  var fireBeforeUpdateEvent = (page2) => {
    return fireEvent("beforeUpdate", { detail: { page: page2 } });
  };
  var fireNavigateEvent = (page2) => {
    return fireEvent("navigate", { detail: { page: page2 } });
  };
  var fireProgressEvent = (progress3) => {
    return fireEvent("progress", { detail: { progress: progress3 } });
  };
  var fireStartEvent = (visit) => {
    return fireEvent("start", { detail: { visit } });
  };
  var fireSuccessEvent = (page2) => {
    return fireEvent("success", { detail: { page: page2 } });
  };
  var firePrefetchedEvent = (response, visit) => {
    return fireEvent("prefetched", { detail: { fetchedAt: Date.now(), response: response.data, visit } });
  };
  var firePrefetchingEvent = (visit) => {
    return fireEvent("prefetching", { detail: { visit } });
  };
  var fireFlashEvent = (flash) => {
    return fireEvent("flash", { detail: { flash } });
  };
  var SessionStorage = class {
    static set(key, value) {
      if (typeof window !== "undefined") {
        window.sessionStorage.setItem(key, JSON.stringify(value));
      }
    }
    static get(key) {
      if (typeof window !== "undefined") {
        return JSON.parse(window.sessionStorage.getItem(key) || "null");
      }
    }
    static merge(key, value) {
      const existing = this.get(key);
      if (existing === null) {
        this.set(key, value);
      } else {
        this.set(key, { ...existing, ...value });
      }
    }
    static remove(key) {
      if (typeof window !== "undefined") {
        window.sessionStorage.removeItem(key);
      }
    }
    static removeNested(key, nestedKey) {
      const existing = this.get(key);
      if (existing !== null) {
        delete existing[nestedKey];
        this.set(key, existing);
      }
    }
    static exists(key) {
      try {
        return this.get(key) !== null;
      } catch (error) {
        return false;
      }
    }
    static clear() {
      if (typeof window !== "undefined") {
        window.sessionStorage.clear();
      }
    }
  };
  SessionStorage.locationVisitKey = "inertiaLocationVisit";
  var encryptHistory = async (data) => {
    if (typeof window === "undefined") {
      throw new Error("Unable to encrypt history");
    }
    const iv = getIv();
    const storedKey = await getKeyFromSessionStorage();
    const key = await getOrCreateKey(storedKey);
    if (!key) {
      throw new Error("Unable to encrypt history");
    }
    const encrypted = await encryptData(iv, key, data);
    return encrypted;
  };
  var historySessionStorageKeys = {
    key: "historyKey",
    iv: "historyIv"
  };
  var decryptHistory = async (data) => {
    const iv = getIv();
    const storedKey = await getKeyFromSessionStorage();
    if (!storedKey) {
      throw new Error("Unable to decrypt history");
    }
    return await decryptData(iv, storedKey, data);
  };
  var encryptData = async (iv, key, data) => {
    if (typeof window === "undefined") {
      throw new Error("Unable to encrypt history");
    }
    if (typeof window.crypto.subtle === "undefined") {
      console.warn("Encryption is not supported in this environment. SSL is required.");
      return Promise.resolve(data);
    }
    const textEncoder = new TextEncoder();
    const str = JSON.stringify(data);
    const encoded = new Uint8Array(str.length * 3);
    const result = textEncoder.encodeInto(str, encoded);
    return window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      encoded.subarray(0, result.written)
    );
  };
  var decryptData = async (iv, key, data) => {
    if (typeof window.crypto.subtle === "undefined") {
      console.warn("Decryption is not supported in this environment. SSL is required.");
      return Promise.resolve(data);
    }
    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      data
    );
    return JSON.parse(new TextDecoder().decode(decrypted));
  };
  var getIv = () => {
    const ivString = SessionStorage.get(historySessionStorageKeys.iv);
    if (ivString) {
      return new Uint8Array(ivString);
    }
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    SessionStorage.set(historySessionStorageKeys.iv, Array.from(iv));
    return iv;
  };
  var createKey = async () => {
    if (typeof window.crypto.subtle === "undefined") {
      console.warn("Encryption is not supported in this environment. SSL is required.");
      return Promise.resolve(null);
    }
    return window.crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  };
  var saveKey = async (key) => {
    if (typeof window.crypto.subtle === "undefined") {
      console.warn("Encryption is not supported in this environment. SSL is required.");
      return Promise.resolve();
    }
    const keyData = await window.crypto.subtle.exportKey("raw", key);
    SessionStorage.set(historySessionStorageKeys.key, Array.from(new Uint8Array(keyData)));
  };
  var getOrCreateKey = async (key) => {
    if (key) {
      return key;
    }
    const newKey = await createKey();
    if (!newKey) {
      return null;
    }
    await saveKey(newKey);
    return newKey;
  };
  var getKeyFromSessionStorage = async () => {
    const stringKey = SessionStorage.get(historySessionStorageKeys.key);
    if (!stringKey) {
      return null;
    }
    const key = await window.crypto.subtle.importKey(
      "raw",
      new Uint8Array(stringKey),
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
    return key;
  };
  var stripTopLevelUndefined = (obj) => {
    const result = {};
    for (const key of Object.keys(obj)) {
      if (obj[key] !== void 0) {
        result[key] = obj[key];
      }
    }
    return result;
  };
  var objectsAreEqual = (obj1, obj2, excludeKeys) => {
    if (obj1 === obj2) {
      return true;
    }
    for (const key in obj1) {
      if (excludeKeys.includes(key)) {
        continue;
      }
      if (obj1[key] === obj2[key]) {
        continue;
      }
      if (!compareValues(obj1[key], obj2[key])) {
        return false;
      }
    }
    for (const key in obj2) {
      if (excludeKeys.includes(key)) {
        continue;
      }
      if (!(key in obj1)) {
        return false;
      }
    }
    return true;
  };
  var compareValues = (value1, value2) => {
    switch (typeof value1) {
      case "object":
        return objectsAreEqual(value1, value2, []);
      case "function":
        return value1.toString() === value2.toString();
      default:
        return value1 === value2;
    }
  };
  var conversionMap = {
    ms: 1,
    s: 1e3,
    m: 1e3 * 60,
    h: 1e3 * 60 * 60,
    d: 1e3 * 60 * 60 * 24
  };
  var timeToMs = (time) => {
    if (typeof time === "number") {
      return time;
    }
    for (const [unit, conversion] of Object.entries(conversionMap)) {
      if (time.endsWith(unit)) {
        return parseFloat(time) * conversion;
      }
    }
    return parseInt(time);
  };
  var PrefetchedRequests = class {
    constructor() {
      this.cached = [];
      this.inFlightRequests = [];
      this.removalTimers = [];
      this.currentUseId = null;
    }
    add(params, sendFunc, { cacheFor, cacheTags }) {
      const inFlight = this.findInFlight(params);
      if (inFlight) {
        return Promise.resolve();
      }
      const existing = this.findCached(params);
      if (!params.fresh && existing && existing.staleTimestamp > Date.now()) {
        return Promise.resolve();
      }
      const [stale, prefetchExpiresIn] = this.extractStaleValues(cacheFor);
      const promise = new Promise((resolve, reject) => {
        sendFunc({
          ...params,
          onCancel: () => {
            this.remove(params);
            params.onCancel();
            reject();
          },
          onError: (error) => {
            this.remove(params);
            params.onError(error);
            reject();
          },
          onPrefetching(visitParams) {
            params.onPrefetching(visitParams);
          },
          onPrefetched(response, visit) {
            params.onPrefetched(response, visit);
          },
          onPrefetchResponse(response) {
            resolve(response);
          },
          onPrefetchError(error) {
            prefetchedRequests.removeFromInFlight(params);
            reject(error);
          }
        });
      }).then((response) => {
        this.remove(params);
        const pageResponse = response.getPageResponse();
        page.mergeOncePropsIntoResponse(pageResponse);
        this.cached.push({
          params: { ...params },
          staleTimestamp: Date.now() + stale,
          expiresAt: Date.now() + prefetchExpiresIn,
          response: promise,
          singleUse: prefetchExpiresIn === 0,
          timestamp: Date.now(),
          inFlight: false,
          tags: Array.isArray(cacheTags) ? cacheTags : [cacheTags]
        });
        const oncePropExpiresIn = this.getShortestOncePropTtl(pageResponse);
        this.scheduleForRemoval(
          params,
          oncePropExpiresIn ? Math.min(prefetchExpiresIn, oncePropExpiresIn) : prefetchExpiresIn
        );
        this.removeFromInFlight(params);
        response.handlePrefetch();
        return response;
      });
      this.inFlightRequests.push({
        params: { ...params },
        response: promise,
        staleTimestamp: null,
        inFlight: true
      });
      return promise;
    }
    removeAll() {
      this.cached = [];
      this.removalTimers.forEach((removalTimer) => {
        clearTimeout(removalTimer.timer);
      });
      this.removalTimers = [];
    }
    removeByTags(tags) {
      this.cached = this.cached.filter((prefetched) => {
        return !prefetched.tags.some((tag) => tags.includes(tag));
      });
    }
    remove(params) {
      this.cached = this.cached.filter((prefetched) => {
        return !this.paramsAreEqual(prefetched.params, params);
      });
      this.clearTimer(params);
    }
    removeFromInFlight(params) {
      this.inFlightRequests = this.inFlightRequests.filter((prefetching) => {
        return !this.paramsAreEqual(prefetching.params, params);
      });
    }
    extractStaleValues(cacheFor) {
      const [stale, expires] = this.cacheForToStaleAndExpires(cacheFor);
      return [timeToMs(stale), timeToMs(expires)];
    }
    cacheForToStaleAndExpires(cacheFor) {
      if (!Array.isArray(cacheFor)) {
        return [cacheFor, cacheFor];
      }
      switch (cacheFor.length) {
        case 0:
          return [0, 0];
        case 1:
          return [cacheFor[0], cacheFor[0]];
        default:
          return [cacheFor[0], cacheFor[1]];
      }
    }
    clearTimer(params) {
      const timer = this.removalTimers.find((removalTimer) => {
        return this.paramsAreEqual(removalTimer.params, params);
      });
      if (timer) {
        clearTimeout(timer.timer);
        this.removalTimers = this.removalTimers.filter((removalTimer) => removalTimer !== timer);
      }
    }
    scheduleForRemoval(params, expiresIn) {
      if (typeof window === "undefined") {
        return;
      }
      this.clearTimer(params);
      if (expiresIn > 0) {
        const timer = window.setTimeout(() => this.remove(params), expiresIn);
        this.removalTimers.push({
          params,
          timer
        });
      }
    }
    get(params) {
      return this.findCached(params) || this.findInFlight(params);
    }
    use(prefetched, params) {
      const id = `${params.url.pathname}-${Date.now()}-${Math.random().toString(36).substring(7)}`;
      this.currentUseId = id;
      return prefetched.response.then((response) => {
        if (this.currentUseId !== id) {
          return;
        }
        response.mergeParams({ ...params, onPrefetched: () => {
        } });
        this.removeSingleUseItems(params);
        return response.handle();
      });
    }
    removeSingleUseItems(params) {
      this.cached = this.cached.filter((prefetched) => {
        if (!this.paramsAreEqual(prefetched.params, params)) {
          return true;
        }
        return !prefetched.singleUse;
      });
    }
    findCached(params) {
      return this.cached.find((prefetched) => {
        return this.paramsAreEqual(prefetched.params, params);
      }) || null;
    }
    findInFlight(params) {
      return this.inFlightRequests.find((prefetched) => {
        return this.paramsAreEqual(prefetched.params, params);
      }) || null;
    }
    withoutPurposePrefetchHeader(params) {
      const newParams = cloneDeep_default(params);
      if (newParams.headers["Purpose"] === "prefetch") {
        delete newParams.headers["Purpose"];
      }
      return newParams;
    }
    paramsAreEqual(params1, params2) {
      return objectsAreEqual(
        this.withoutPurposePrefetchHeader(params1),
        this.withoutPurposePrefetchHeader(params2),
        [
          "showProgress",
          "replace",
          "prefetch",
          "preserveScroll",
          "preserveState",
          "onBefore",
          "onBeforeUpdate",
          "onStart",
          "onProgress",
          "onFinish",
          "onCancel",
          "onSuccess",
          "onError",
          "onFlash",
          "onPrefetched",
          "onCancelToken",
          "onPrefetching",
          "async",
          "viewTransition"
        ]
      );
    }
    updateCachedOncePropsFromCurrentPage() {
      this.cached.forEach((prefetched) => {
        prefetched.response.then((response) => {
          const pageResponse = response.getPageResponse();
          page.mergeOncePropsIntoResponse(pageResponse, { force: true });
          for (const [group, deferredProps] of Object.entries(pageResponse.deferredProps ?? {})) {
            const remaining = deferredProps.filter((prop) => pageResponse.props[prop] === void 0);
            if (remaining.length > 0) {
              pageResponse.deferredProps[group] = remaining;
            } else {
              delete pageResponse.deferredProps[group];
            }
          }
          const oncePropExpiresIn = this.getShortestOncePropTtl(pageResponse);
          if (oncePropExpiresIn === null) {
            return;
          }
          const prefetchExpiresIn = prefetched.expiresAt - Date.now();
          const expiresIn = Math.min(prefetchExpiresIn, oncePropExpiresIn);
          if (expiresIn > 0) {
            this.scheduleForRemoval(prefetched.params, expiresIn);
          } else {
            this.remove(prefetched.params);
          }
        });
      });
    }
    getShortestOncePropTtl(page2) {
      const expiryTimestamps = Object.values(page2.onceProps ?? {}).map((onceProp) => onceProp.expiresAt).filter((expiresAt) => !!expiresAt);
      if (expiryTimestamps.length === 0) {
        return null;
      }
      return Math.min(...expiryTimestamps) - Date.now();
    }
  };
  var prefetchedRequests = new PrefetchedRequests();
  var elementInViewport = (el) => {
    if (el.offsetParent === null) {
      return false;
    }
    const rect = el.getBoundingClientRect();
    const verticallyVisible = rect.top < window.innerHeight && rect.bottom >= 0;
    const horizontallyVisible = rect.left < window.innerWidth && rect.right >= 0;
    return verticallyVisible && horizontallyVisible;
  };
  var getScrollableParent = (element) => {
    const allowsVerticalScroll = (el) => {
      const computedStyle = window.getComputedStyle(el);
      if (["scroll", "overlay"].includes(computedStyle.overflowY)) {
        return true;
      }
      if (computedStyle.overflowY !== "auto") {
        return false;
      }
      if (["visible", "clip"].includes(computedStyle.overflowX)) {
        return true;
      }
      return hasDimensionConstraint(computedStyle.maxHeight, el.style.height) || isConstrainedByLayout(el, "height");
    };
    const allowsHorizontalScroll = (el) => {
      const computedStyle = window.getComputedStyle(el);
      if (["scroll", "overlay"].includes(computedStyle.overflowX)) {
        return true;
      }
      if (computedStyle.overflowX !== "auto") {
        return false;
      }
      if (["visible", "clip"].includes(computedStyle.overflowY)) {
        return true;
      }
      return hasDimensionConstraint(computedStyle.maxWidth, el.style.width) || isConstrainedByLayout(el, "width");
    };
    const hasDimensionConstraint = (computedMaxDimension, inlineStyleDimension) => {
      if (computedMaxDimension && computedMaxDimension !== "none" && computedMaxDimension !== "0px") {
        return true;
      }
      if (inlineStyleDimension && inlineStyleDimension !== "auto" && inlineStyleDimension !== "0") {
        return true;
      }
      return false;
    };
    const isConstrainedByLayout = (el, dimension) => {
      const parent2 = el.parentElement;
      if (!parent2) {
        return false;
      }
      const parentStyle = window.getComputedStyle(parent2);
      if (["flex", "inline-flex"].includes(parentStyle.display)) {
        const isColumnLayout = ["column", "column-reverse"].includes(parentStyle.flexDirection);
        return dimension === "height" ? isColumnLayout : !isColumnLayout;
      }
      return ["grid", "inline-grid"].includes(parentStyle.display);
    };
    let parent = element?.parentElement;
    while (parent) {
      const allowsScroll = allowsVerticalScroll(parent) || allowsHorizontalScroll(parent);
      if (window.getComputedStyle(parent).display !== "contents" && allowsScroll) {
        return parent;
      }
      parent = parent.parentElement;
    }
    return null;
  };
  var getElementsInViewportFromCollection = (elements, referenceElement) => {
    if (!referenceElement) {
      return elements.filter((element) => elementInViewport(element));
    }
    const referenceIndex = elements.indexOf(referenceElement);
    const upwardElements = [];
    const downwardElements = [];
    for (let i12 = referenceIndex; i12 >= 0; i12--) {
      const element = elements[i12];
      if (elementInViewport(element)) {
        upwardElements.push(element);
      } else {
        break;
      }
    }
    for (let i12 = referenceIndex + 1; i12 < elements.length; i12++) {
      const element = elements[i12];
      if (elementInViewport(element)) {
        downwardElements.push(element);
      } else {
        break;
      }
    }
    return [...upwardElements.reverse(), ...downwardElements];
  };
  var requestAnimationFrame2 = (cb, times = 1) => {
    window.requestAnimationFrame(() => {
      if (times > 1) {
        requestAnimationFrame2(cb, times - 1);
      } else {
        cb();
      }
    });
  };
  var isServer = typeof window === "undefined";
  var isFirefox = !isServer && /Firefox/i.test(window.navigator.userAgent);
  var Scroll = class {
    static save() {
      history.saveScrollPositions(this.getScrollRegions());
    }
    static getScrollRegions() {
      return Array.from(this.regions()).map((region) => ({
        top: region.scrollTop,
        left: region.scrollLeft
      }));
    }
    static regions() {
      return document.querySelectorAll("[scroll-region]");
    }
    static scrollToTop() {
      if (isFirefox && getComputedStyle(document.documentElement).scrollBehavior === "smooth") {
        return requestAnimationFrame2(() => window.scrollTo(0, 0), 2);
      }
      window.scrollTo(0, 0);
    }
    static reset() {
      const anchorHash = isServer ? null : window.location.hash;
      if (!anchorHash) {
        this.scrollToTop();
      }
      this.regions().forEach((region) => {
        if (typeof region.scrollTo === "function") {
          region.scrollTo(0, 0);
        } else {
          region.scrollTop = 0;
          region.scrollLeft = 0;
        }
      });
      this.save();
      this.scrollToAnchor();
    }
    static scrollToAnchor() {
      const anchorHash = isServer ? null : window.location.hash;
      if (anchorHash) {
        setTimeout(() => {
          const anchorElement = document.getElementById(anchorHash.slice(1));
          anchorElement ? anchorElement.scrollIntoView() : this.scrollToTop();
        });
      }
    }
    static restore(scrollRegions) {
      if (isServer) {
        return;
      }
      window.requestAnimationFrame(() => {
        this.restoreDocument();
        this.restoreScrollRegions(scrollRegions);
      });
    }
    static restoreScrollRegions(scrollRegions) {
      if (isServer) {
        return;
      }
      this.regions().forEach((region, index) => {
        const scrollPosition = scrollRegions[index];
        if (!scrollPosition) {
          return;
        }
        if (typeof region.scrollTo === "function") {
          region.scrollTo(scrollPosition.left, scrollPosition.top);
        } else {
          region.scrollTop = scrollPosition.top;
          region.scrollLeft = scrollPosition.left;
        }
      });
    }
    static restoreDocument() {
      const scrollPosition = history.getDocumentScrollPosition();
      window.scrollTo(scrollPosition.left, scrollPosition.top);
    }
    static onScroll(event) {
      const target = event.target;
      if (typeof target.hasAttribute === "function" && target.hasAttribute("scroll-region")) {
        this.save();
      }
    }
    static onWindowScroll() {
      history.saveDocumentScrollPosition({
        top: window.scrollY,
        left: window.scrollX
      });
    }
  };
  var isFile2 = (value) => typeof File !== "undefined" && value instanceof File || value instanceof Blob || typeof FileList !== "undefined" && value instanceof FileList && value.length > 0;
  function hasFiles(data) {
    return isFile2(data) || data instanceof FormData && Array.from(data.values()).some((value) => hasFiles(value)) || typeof data === "object" && data !== null && Object.values(data).some((value) => hasFiles(value));
  }
  var isFormData2 = (value) => value instanceof FormData;
  function objectToFormData(source, form = new FormData(), parentKey = null, queryStringArrayFormat = "brackets") {
    source = source || {};
    for (const key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        append2(form, composeKey(parentKey, key, "indices"), source[key], queryStringArrayFormat);
      }
    }
    return form;
  }
  function composeKey(parent, key, format) {
    if (!parent) {
      return key;
    }
    return format === "brackets" ? `${parent}[]` : `${parent}[${key}]`;
  }
  function append2(form, key, value, format) {
    if (Array.isArray(value)) {
      return Array.from(value.keys()).forEach(
        (index) => append2(form, composeKey(key, index.toString(), format), value[index], format)
      );
    } else if (value instanceof Date) {
      return form.append(key, value.toISOString());
    } else if (value instanceof File) {
      return form.append(key, value, value.name);
    } else if (value instanceof Blob) {
      return form.append(key, value);
    } else if (typeof value === "boolean") {
      return form.append(key, value ? "1" : "0");
    } else if (typeof value === "string") {
      return form.append(key, value);
    } else if (typeof value === "number") {
      return form.append(key, `${value}`);
    } else if (value === null || value === void 0) {
      return form.append(key, "");
    }
    objectToFormData(value, form, key, format);
  }
  function hrefToUrl(href) {
    return new URL(href.toString(), typeof window === "undefined" ? void 0 : window.location.toString());
  }
  var transformUrlAndData = (href, data, method, forceFormData, queryStringArrayFormat) => {
    let url = typeof href === "string" ? hrefToUrl(href) : href;
    if ((hasFiles(data) || forceFormData) && !isFormData2(data)) {
      if (config.get("form.forceIndicesArrayFormatInFormData")) {
        queryStringArrayFormat = "indices";
      }
      data = objectToFormData(data, new FormData(), null, queryStringArrayFormat);
    }
    if (isFormData2(data)) {
      return [url, data];
    }
    const [_href, _data] = mergeDataIntoQueryString(method, url, data, queryStringArrayFormat);
    return [hrefToUrl(_href), _data];
  };
  function mergeDataIntoQueryString(method, href, data, qsArrayFormat = "brackets") {
    const hasDataForQueryString = method === "get" && !isFormData2(data) && Object.keys(data).length > 0;
    const hasHost = urlHasProtocol(href.toString());
    const hasAbsolutePath = hasHost || href.toString().startsWith("/") || href.toString() === "";
    const hasRelativePath = !hasAbsolutePath && !href.toString().startsWith("#") && !href.toString().startsWith("?");
    const hasRelativePathWithDotPrefix = /^[.]{1,2}([/]|$)/.test(href.toString());
    const hasSearch = href.toString().includes("?") || hasDataForQueryString;
    const hasHash = href.toString().includes("#");
    const url = new URL(href.toString(), typeof window === "undefined" ? "http://localhost" : window.location.toString());
    if (hasDataForQueryString) {
      const hasIndices = /\[\d+\]/.test(decodeURIComponent(url.search));
      const parseOptions = { ignoreQueryPrefix: true, allowSparse: true };
      url.search = qs.stringify(
        { ...qs.parse(url.search, parseOptions), ...data },
        {
          encodeValuesOnly: true,
          arrayFormat: hasIndices ? "indices" : qsArrayFormat
        }
      );
    }
    return [
      [
        hasHost ? `${url.protocol}//${url.host}` : "",
        hasAbsolutePath ? url.pathname : "",
        hasRelativePath ? url.pathname.substring(hasRelativePathWithDotPrefix ? 0 : 1) : "",
        hasSearch ? url.search : "",
        hasHash ? url.hash : ""
      ].join(""),
      hasDataForQueryString ? {} : data
    ];
  }
  function urlWithoutHash(url) {
    url = new URL(url.href);
    url.hash = "";
    return url;
  }
  var setHashIfSameUrl = (originUrl, destinationUrl) => {
    if (originUrl.hash && !destinationUrl.hash && urlWithoutHash(originUrl).href === destinationUrl.href) {
      destinationUrl.hash = originUrl.hash;
    }
  };
  var isSameUrlWithoutHash = (url1, url2) => {
    return urlWithoutHash(url1).href === urlWithoutHash(url2).href;
  };
  var isSameUrlWithoutQueryOrHash = (url1, url2) => {
    return url1.origin === url2.origin && url1.pathname === url2.pathname;
  };
  function isUrlMethodPair(href) {
    return href !== null && typeof href === "object" && href !== void 0 && "url" in href && "method" in href;
  }
  function urlHasProtocol(url) {
    return /^([a-z][a-z0-9+.-]*:)?\/\/[^/]/i.test(url);
  }
  function urlToString(url, absolute) {
    const urlObj = typeof url === "string" ? hrefToUrl(url) : url;
    return absolute ? `${urlObj.protocol}//${urlObj.host}${urlObj.pathname}${urlObj.search}${urlObj.hash}` : `${urlObj.pathname}${urlObj.search}${urlObj.hash}`;
  }
  var CurrentPage = class {
    constructor() {
      this.componentId = {};
      this.listeners = [];
      this.isFirstPageLoad = true;
      this.cleared = false;
      this.pendingDeferredProps = null;
      this.historyQuotaExceeded = false;
    }
    init({
      initialPage,
      swapComponent: swapComponent2,
      resolveComponent,
      onFlash
    }) {
      this.page = { ...initialPage, flash: initialPage.flash ?? {} };
      this.swapComponent = swapComponent2;
      this.resolveComponent = resolveComponent;
      this.onFlashCallback = onFlash;
      eventHandler.on("historyQuotaExceeded", () => {
        this.historyQuotaExceeded = true;
      });
      return this;
    }
    set(page2, {
      replace = false,
      preserveScroll = false,
      preserveState = false,
      viewTransition = false
    } = {}) {
      if (Object.keys(page2.deferredProps || {}).length) {
        this.pendingDeferredProps = {
          deferredProps: page2.deferredProps,
          component: page2.component,
          url: page2.url
        };
        if (page2.initialDeferredProps === void 0) {
          page2.initialDeferredProps = page2.deferredProps;
        }
      }
      this.componentId = {};
      const componentId = this.componentId;
      if (page2.clearHistory) {
        history.clear();
      }
      return this.resolve(page2.component).then((component) => {
        if (componentId !== this.componentId) {
          return;
        }
        page2.rememberedState ?? (page2.rememberedState = {});
        const isServer3 = typeof window === "undefined";
        const location = !isServer3 ? window.location : new URL(page2.url);
        const scrollRegions = !isServer3 && preserveScroll ? Scroll.getScrollRegions() : [];
        replace = replace || isSameUrlWithoutHash(hrefToUrl(page2.url), location);
        const pageForHistory = { ...page2, flash: {} };
        return new Promise(
          (resolve) => replace ? history.replaceState(pageForHistory, resolve) : history.pushState(pageForHistory, resolve)
        ).then(() => {
          const isNewComponent = !this.isTheSame(page2);
          if (!isNewComponent && Object.keys(page2.props.errors || {}).length > 0) {
            viewTransition = false;
          }
          this.page = page2;
          this.cleared = false;
          if (this.hasOnceProps()) {
            prefetchedRequests.updateCachedOncePropsFromCurrentPage();
          }
          if (isNewComponent) {
            this.fireEventsFor("newComponent");
          }
          if (this.isFirstPageLoad) {
            this.fireEventsFor("firstLoad");
          }
          this.isFirstPageLoad = false;
          if (this.historyQuotaExceeded) {
            this.historyQuotaExceeded = false;
            return;
          }
          return this.swap({
            component,
            page: page2,
            preserveState,
            viewTransition
          }).then(() => {
            if (preserveScroll) {
              window.requestAnimationFrame(() => Scroll.restoreScrollRegions(scrollRegions));
            } else {
              Scroll.reset();
            }
            if (this.pendingDeferredProps && this.pendingDeferredProps.component === page2.component && this.pendingDeferredProps.url === page2.url) {
              eventHandler.fireInternalEvent("loadDeferredProps", this.pendingDeferredProps.deferredProps);
            }
            this.pendingDeferredProps = null;
            if (!replace) {
              fireNavigateEvent(page2);
            }
          });
        });
      });
    }
    setQuietly(page2, {
      preserveState = false
    } = {}) {
      return this.resolve(page2.component).then((component) => {
        this.page = page2;
        this.cleared = false;
        history.setCurrent(page2);
        return this.swap({ component, page: page2, preserveState, viewTransition: false });
      });
    }
    clear() {
      this.cleared = true;
    }
    isCleared() {
      return this.cleared;
    }
    get() {
      return this.page;
    }
    getWithoutFlashData() {
      return { ...this.page, flash: {} };
    }
    hasOnceProps() {
      return Object.keys(this.page.onceProps ?? {}).length > 0;
    }
    merge(data) {
      this.page = { ...this.page, ...data };
    }
    setFlash(flash) {
      this.page = { ...this.page, flash };
      this.onFlashCallback?.(flash);
    }
    setUrlHash(hash) {
      if (!this.page.url.includes(hash)) {
        this.page.url += hash;
      }
    }
    remember(data) {
      this.page.rememberedState = data;
    }
    swap({
      component,
      page: page2,
      preserveState,
      viewTransition
    }) {
      const doSwap = () => this.swapComponent({ component, page: page2, preserveState });
      if (!viewTransition || !document?.startViewTransition || document.visibilityState === "hidden") {
        return doSwap();
      }
      const viewTransitionCallback = typeof viewTransition === "boolean" ? () => null : viewTransition;
      return new Promise((resolve) => {
        const transitionResult = document.startViewTransition(() => doSwap().then(resolve));
        viewTransitionCallback(transitionResult);
      });
    }
    resolve(component) {
      return Promise.resolve(this.resolveComponent(component));
    }
    isTheSame(page2) {
      return this.page.component === page2.component;
    }
    on(event, callback) {
      this.listeners.push({ event, callback });
      return () => {
        this.listeners = this.listeners.filter((listener) => listener.event !== event && listener.callback !== callback);
      };
    }
    fireEventsFor(event) {
      this.listeners.filter((listener) => listener.event === event).forEach((listener) => listener.callback());
    }
    mergeOncePropsIntoResponse(response, { force = false } = {}) {
      Object.entries(response.onceProps ?? {}).forEach(([key, onceProp]) => {
        const existingOnceProp = this.page.onceProps?.[key];
        if (existingOnceProp === void 0) {
          return;
        }
        if (force || response.props[onceProp.prop] === void 0) {
          response.props[onceProp.prop] = this.page.props[existingOnceProp.prop];
          response.onceProps[key].expiresAt = existingOnceProp.expiresAt;
        }
      });
    }
  };
  var page = new CurrentPage();
  var Queue = class {
    constructor() {
      this.items = [];
      this.processingPromise = null;
    }
    add(item) {
      this.items.push(item);
      return this.process();
    }
    process() {
      this.processingPromise ?? (this.processingPromise = this.processNext().finally(() => {
        this.processingPromise = null;
      }));
      return this.processingPromise;
    }
    processNext() {
      const next = this.items.shift();
      if (next) {
        return Promise.resolve(next()).then(() => this.processNext());
      }
      return Promise.resolve();
    }
  };
  var isServer2 = typeof window === "undefined";
  var queue = new Queue();
  var isChromeIOS = !isServer2 && /CriOS/.test(window.navigator.userAgent);
  var History = class {
    constructor() {
      this.rememberedState = "rememberedState";
      this.scrollRegions = "scrollRegions";
      this.preserveUrl = false;
      this.current = {};
      this.initialState = null;
    }
    remember(data, key) {
      this.replaceState({
        ...page.getWithoutFlashData(),
        rememberedState: {
          ...page.get()?.rememberedState ?? {},
          [key]: data
        }
      });
    }
    restore(key) {
      if (!isServer2) {
        return this.current[this.rememberedState]?.[key] !== void 0 ? this.current[this.rememberedState]?.[key] : this.initialState?.[this.rememberedState]?.[key];
      }
    }
    pushState(page2, cb = null) {
      if (isServer2) {
        return;
      }
      if (this.preserveUrl) {
        cb && cb();
        return;
      }
      this.current = page2;
      queue.add(() => {
        return this.getPageData(page2).then((data) => {
          const doPush = () => this.doPushState({ page: data }, page2.url).then(() => cb?.());
          if (isChromeIOS) {
            return new Promise((resolve) => {
              setTimeout(() => doPush().then(resolve));
            });
          }
          return doPush();
        });
      });
    }
    clonePageProps(page2) {
      try {
        structuredClone(page2.props);
        return page2;
      } catch {
        return {
          ...page2,
          props: cloneDeep_default(page2.props)
        };
      }
    }
    getPageData(page2) {
      const pageWithClonedProps = this.clonePageProps(page2);
      return new Promise((resolve) => {
        return page2.encryptHistory ? encryptHistory(pageWithClonedProps).then(resolve) : resolve(pageWithClonedProps);
      });
    }
    processQueue() {
      return queue.process();
    }
    decrypt(page2 = null) {
      if (isServer2) {
        return Promise.resolve(page2 ?? page.get());
      }
      const pageData = page2 ?? window.history.state?.page;
      return this.decryptPageData(pageData).then((data) => {
        if (!data) {
          throw new Error("Unable to decrypt history");
        }
        if (this.initialState === null) {
          this.initialState = data ?? void 0;
        } else {
          this.current = data ?? {};
        }
        return data;
      });
    }
    decryptPageData(pageData) {
      return pageData instanceof ArrayBuffer ? decryptHistory(pageData) : Promise.resolve(pageData);
    }
    saveScrollPositions(scrollRegions) {
      queue.add(() => {
        return Promise.resolve().then(() => {
          if (!window.history.state?.page) {
            return;
          }
          if (isEqual_default(this.getScrollRegions(), scrollRegions)) {
            return;
          }
          return this.doReplaceState({
            page: window.history.state.page,
            scrollRegions
          });
        });
      });
    }
    saveDocumentScrollPosition(scrollRegion) {
      queue.add(() => {
        return Promise.resolve().then(() => {
          if (!window.history.state?.page) {
            return;
          }
          if (isEqual_default(this.getDocumentScrollPosition(), scrollRegion)) {
            return;
          }
          return this.doReplaceState({
            page: window.history.state.page,
            documentScrollPosition: scrollRegion
          });
        });
      });
    }
    getScrollRegions() {
      return window.history.state?.scrollRegions || [];
    }
    getDocumentScrollPosition() {
      return window.history.state?.documentScrollPosition || { top: 0, left: 0 };
    }
    replaceState(page2, cb = null) {
      if (isEqual_default(this.current, page2)) {
        cb && cb();
        return;
      }
      const { flash, ...pageWithoutFlash } = page2;
      page.merge(pageWithoutFlash);
      if (isServer2) {
        return;
      }
      if (this.preserveUrl) {
        cb && cb();
        return;
      }
      this.current = page2;
      queue.add(() => {
        return this.getPageData(page2).then((data) => {
          const doReplace = () => this.doReplaceState({ page: data }, page2.url).then(() => cb?.());
          if (isChromeIOS) {
            return new Promise((resolve) => {
              setTimeout(() => doReplace().then(resolve));
            });
          }
          return doReplace();
        });
      });
    }
    isHistoryThrottleError(error) {
      return error instanceof Error && error.name === "SecurityError" && (error.message.includes("history.pushState") || error.message.includes("history.replaceState"));
    }
    isQuotaExceededError(error) {
      return error instanceof Error && error.name === "QuotaExceededError";
    }
    withThrottleProtection(cb) {
      return Promise.resolve().then(() => {
        try {
          return cb();
        } catch (error) {
          if (!this.isHistoryThrottleError(error)) {
            throw error;
          }
          console.error(error.message);
        }
      });
    }
    doReplaceState(data, url) {
      return this.withThrottleProtection(() => {
        window.history.replaceState(
          {
            ...data,
            scrollRegions: data.scrollRegions ?? window.history.state?.scrollRegions,
            documentScrollPosition: data.documentScrollPosition ?? window.history.state?.documentScrollPosition
          },
          "",
          url
        );
      });
    }
    doPushState(data, url) {
      return this.withThrottleProtection(() => {
        try {
          window.history.pushState(data, "", url);
        } catch (error) {
          if (!this.isQuotaExceededError(error)) {
            throw error;
          }
          eventHandler.fireInternalEvent("historyQuotaExceeded", url);
        }
      });
    }
    getState(key, defaultValue) {
      return this.current?.[key] ?? defaultValue;
    }
    deleteState(key) {
      if (this.current[key] !== void 0) {
        delete this.current[key];
        this.replaceState(this.current);
      }
    }
    clearInitialState(key) {
      if (this.initialState && this.initialState[key] !== void 0) {
        delete this.initialState[key];
      }
    }
    browserHasHistoryEntry() {
      return !isServer2 && !!window.history.state?.page;
    }
    clear() {
      SessionStorage.remove(historySessionStorageKeys.key);
      SessionStorage.remove(historySessionStorageKeys.iv);
    }
    setCurrent(page2) {
      this.current = page2;
    }
    isValidState(state) {
      return !!state.page;
    }
    getAllState() {
      return this.current;
    }
  };
  if (typeof window !== "undefined" && window.history.scrollRestoration) {
    window.history.scrollRestoration = "manual";
  }
  var history = new History();
  var EventHandler = class {
    constructor() {
      this.internalListeners = [];
    }
    init() {
      if (typeof window !== "undefined") {
        window.addEventListener("popstate", this.handlePopstateEvent.bind(this));
        window.addEventListener("pageshow", this.handlePageshowEvent.bind(this));
        window.addEventListener("scroll", debounce2(Scroll.onWindowScroll.bind(Scroll), 100), true);
      }
      if (typeof document !== "undefined") {
        document.addEventListener("scroll", debounce2(Scroll.onScroll.bind(Scroll), 100), true);
      }
    }
    onGlobalEvent(type, callback) {
      const listener = ((event) => {
        const response = callback(event);
        if (event.cancelable && !event.defaultPrevented && response === false) {
          event.preventDefault();
        }
      });
      return this.registerListener(`inertia:${type}`, listener);
    }
    on(event, callback) {
      this.internalListeners.push({ event, listener: callback });
      return () => {
        this.internalListeners = this.internalListeners.filter((listener) => listener.listener !== callback);
      };
    }
    onMissingHistoryItem() {
      page.clear();
      this.fireInternalEvent("missingHistoryItem");
    }
    fireInternalEvent(event, ...args) {
      this.internalListeners.filter((listener) => listener.event === event).forEach((listener) => listener.listener(...args));
    }
    registerListener(type, listener) {
      document.addEventListener(type, listener);
      return () => document.removeEventListener(type, listener);
    }
    // bfcache restores pages without firing `popstate`, so we use `pageshow` to
    // re-validate encrypted history entries after `clearHistory` removed the keys.
    // https://web.dev/articles/bfcache
    handlePageshowEvent(event) {
      if (event.persisted) {
        history.decrypt().catch(() => this.onMissingHistoryItem());
      }
    }
    handlePopstateEvent(event) {
      const state = event.state || null;
      if (state === null) {
        const url = hrefToUrl(page.get().url);
        url.hash = window.location.hash;
        history.replaceState({ ...page.getWithoutFlashData(), url: url.href });
        Scroll.reset();
        return;
      }
      if (!history.isValidState(state)) {
        return this.onMissingHistoryItem();
      }
      history.decrypt(state.page).then((data) => {
        if (page.get().version !== data.version) {
          this.onMissingHistoryItem();
          return;
        }
        router.cancelAll({ prefetch: false });
        page.setQuietly(data, { preserveState: false }).then(() => {
          Scroll.restore(history.getScrollRegions());
          fireNavigateEvent(page.get());
          const pendingDeferred = {};
          const pageProps = page.get().props;
          for (const [group, props] of Object.entries(data.initialDeferredProps ?? data.deferredProps ?? {})) {
            const missing = props.filter((prop) => pageProps[prop] === void 0);
            if (missing.length > 0) {
              pendingDeferred[group] = missing;
            }
          }
          if (Object.keys(pendingDeferred).length > 0) {
            this.fireInternalEvent("loadDeferredProps", pendingDeferred);
          }
        });
      }).catch(() => {
        this.onMissingHistoryItem();
      });
    }
  };
  var eventHandler = new EventHandler();
  var NavigationType = class {
    constructor() {
      this.type = this.resolveType();
    }
    resolveType() {
      if (typeof window === "undefined") {
        return "navigate";
      }
      if (window.performance && window.performance.getEntriesByType && window.performance.getEntriesByType("navigation").length > 0) {
        return window.performance.getEntriesByType("navigation")[0].type;
      }
      return "navigate";
    }
    get() {
      return this.type;
    }
    isBackForward() {
      return this.type === "back_forward";
    }
    isReload() {
      return this.type === "reload";
    }
  };
  var navigationType = new NavigationType();
  var InitialVisit = class {
    static handle() {
      this.clearRememberedStateOnReload();
      const scenarios = [this.handleBackForward, this.handleLocation, this.handleDefault];
      scenarios.find((handler) => handler.bind(this)());
    }
    static clearRememberedStateOnReload() {
      if (navigationType.isReload()) {
        history.deleteState(history.rememberedState);
        history.clearInitialState(history.rememberedState);
      }
    }
    static handleBackForward() {
      if (!navigationType.isBackForward() || !history.browserHasHistoryEntry()) {
        return false;
      }
      const scrollRegions = history.getScrollRegions();
      history.decrypt().then((data) => {
        page.set(data, { preserveScroll: true, preserveState: true }).then(() => {
          Scroll.restore(scrollRegions);
          fireNavigateEvent(page.get());
        });
      }).catch(() => {
        eventHandler.onMissingHistoryItem();
      });
      return true;
    }
    /**
     * @link https://inertiajs.com/redirects#external-redirects
     */
    static handleLocation() {
      if (!SessionStorage.exists(SessionStorage.locationVisitKey)) {
        return false;
      }
      const locationVisit = SessionStorage.get(SessionStorage.locationVisitKey) || {};
      SessionStorage.remove(SessionStorage.locationVisitKey);
      if (typeof window !== "undefined") {
        page.setUrlHash(window.location.hash);
      }
      history.decrypt(page.get()).then(() => {
        const rememberedState = history.getState(history.rememberedState, {});
        const scrollRegions = history.getScrollRegions();
        page.remember(rememberedState);
        page.set(page.get(), {
          preserveScroll: locationVisit.preserveScroll,
          preserveState: true
        }).then(() => {
          if (locationVisit.preserveScroll) {
            Scroll.restore(scrollRegions);
          }
          fireNavigateEvent(page.get());
        });
      }).catch(() => {
        eventHandler.onMissingHistoryItem();
      });
      return true;
    }
    static handleDefault() {
      if (typeof window !== "undefined") {
        page.setUrlHash(window.location.hash);
      }
      page.set(page.get(), { preserveScroll: true, preserveState: true }).then(() => {
        if (navigationType.isReload()) {
          Scroll.restore(history.getScrollRegions());
        } else {
          Scroll.scrollToAnchor();
        }
        const page2 = page.get();
        fireNavigateEvent(page2);
        const flash = page2.flash;
        if (Object.keys(flash).length > 0) {
          queueMicrotask(() => fireFlashEvent(flash));
        }
      });
    }
  };
  var Poll = class {
    constructor(interval, cb, options) {
      this.intervalId = null;
      this.timeoutId = null;
      this.throttle = false;
      this.keepAlive = false;
      this.cbCount = 0;
      this.inFlight = false;
      this.currentCancel = null;
      this.stopped = true;
      this.instanceId = 0;
      this.keepAlive = options.keepAlive ?? false;
      this.mode = options.mode ?? "overlap";
      this.cb = cb;
      this.interval = interval;
      if (options.autoStart ?? true) {
        this.start();
      }
    }
    stop() {
      this.stopped = true;
      this.instanceId++;
      this.inFlight = false;
      this.currentCancel = null;
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
      if (this.timeoutId) {
        clearTimeout(this.timeoutId);
        this.timeoutId = null;
      }
    }
    start() {
      if (typeof window === "undefined") {
        return;
      }
      this.stop();
      this.stopped = false;
      if (this.mode === "rest") {
        this.scheduleNext();
        return;
      }
      this.intervalId = window.setInterval(() => this.tick(), this.interval);
    }
    isInBackground(hidden) {
      this.throttle = this.keepAlive ? false : hidden;
      if (this.throttle) {
        this.cbCount = 0;
      }
    }
    scheduleNext() {
      if (this.stopped) {
        return;
      }
      this.timeoutId = window.setTimeout(() => {
        this.timeoutId = null;
        this.tick();
      }, this.interval);
    }
    tick() {
      if (!this.throttle || this.cbCount % 10 === 0) {
        this.fire();
      } else if (this.mode === "rest") {
        this.scheduleNext();
      }
      if (this.throttle) {
        this.cbCount++;
      }
    }
    fire() {
      if (this.inFlight && this.mode === "cancel") {
        this.currentCancel?.();
      }
      const instance = this.instanceId;
      this.cb({
        onStart: (cancel) => {
          if (instance !== this.instanceId) {
            return;
          }
          this.inFlight = true;
          this.currentCancel = cancel;
        },
        onFinish: () => {
          if (instance !== this.instanceId) {
            return;
          }
          this.inFlight = false;
          this.currentCancel = null;
          if (this.mode === "rest") {
            this.scheduleNext();
          }
        }
      });
    }
  };
  var Polls = class {
    constructor() {
      this.polls = [];
      this.setupVisibilityListener();
    }
    get count() {
      return this.polls.length;
    }
    add(interval, cb, options) {
      const poll = new Poll(interval, cb, options);
      this.polls.push(poll);
      return {
        stop: () => poll.stop(),
        start: () => poll.start(),
        destroy: () => {
          poll.stop();
          this.polls = this.polls.filter((p6) => p6 !== poll);
        }
      };
    }
    clear() {
      this.polls.forEach((poll) => poll.stop());
      this.polls = [];
    }
    setupVisibilityListener() {
      if (typeof document === "undefined") {
        return;
      }
      document.addEventListener(
        "visibilitychange",
        () => {
          this.polls.forEach((poll) => poll.isInBackground(document.hidden));
        },
        false
      );
    }
  };
  var polls = new Polls();
  var RequestParams = class _RequestParams {
    constructor(params) {
      this.callbacks = [];
      if (!params.prefetch) {
        this.params = params;
      } else {
        const wrappedCallbacks = {
          onBefore: this.wrapCallback(params, "onBefore"),
          onBeforeUpdate: this.wrapCallback(params, "onBeforeUpdate"),
          onStart: this.wrapCallback(params, "onStart"),
          onProgress: this.wrapCallback(params, "onProgress"),
          onFinish: this.wrapCallback(params, "onFinish"),
          onCancel: this.wrapCallback(params, "onCancel"),
          onSuccess: this.wrapCallback(params, "onSuccess"),
          onError: this.wrapCallback(params, "onError"),
          onFlash: this.wrapCallback(params, "onFlash"),
          onCancelToken: this.wrapCallback(params, "onCancelToken"),
          onPrefetched: this.wrapCallback(params, "onPrefetched"),
          onPrefetching: this.wrapCallback(params, "onPrefetching")
        };
        this.params = {
          ...params,
          ...wrappedCallbacks,
          onPrefetchResponse: params.onPrefetchResponse || (() => {
          }),
          onPrefetchError: params.onPrefetchError || (() => {
          })
        };
      }
    }
    static create(params) {
      return new _RequestParams(params);
    }
    data() {
      return this.params.method === "get" ? null : this.params.data;
    }
    queryParams() {
      return this.params.method === "get" ? this.params.data : {};
    }
    isPartial() {
      return this.params.only.length > 0 || this.params.except.length > 0 || this.params.reset.length > 0;
    }
    isPrefetch() {
      return this.params.prefetch === true;
    }
    isDeferredPropsRequest() {
      return this.params.deferredProps === true;
    }
    onCancelToken(cb) {
      this.params.onCancelToken({
        cancel: cb
      });
    }
    markAsFinished() {
      this.params.completed = true;
      this.params.cancelled = false;
      this.params.interrupted = false;
    }
    markAsCancelled({ cancelled = true, interrupted = false }) {
      this.params.onCancel();
      this.params.completed = false;
      this.params.cancelled = cancelled;
      this.params.interrupted = interrupted;
    }
    wasCancelledAtAll() {
      return this.params.cancelled || this.params.interrupted;
    }
    onFinish() {
      this.params.onFinish(this.params);
    }
    onStart() {
      this.params.onStart(this.params);
    }
    onPrefetching() {
      this.params.onPrefetching(this.params);
    }
    onPrefetchResponse(response) {
      if (this.params.onPrefetchResponse) {
        this.params.onPrefetchResponse(response);
      }
    }
    onPrefetchError(error) {
      if (this.params.onPrefetchError) {
        this.params.onPrefetchError(error);
      }
    }
    all() {
      return this.params;
    }
    headers() {
      const headers = {
        ...this.params.headers
      };
      if (this.isPartial()) {
        headers["X-Inertia-Partial-Component"] = page.get().component;
      }
      const only = this.params.only.concat(this.params.reset);
      if (only.length > 0) {
        headers["X-Inertia-Partial-Data"] = only.join(",");
      }
      if (this.params.except.length > 0) {
        headers["X-Inertia-Partial-Except"] = this.params.except.join(",");
      }
      if (this.params.reset.length > 0) {
        headers["X-Inertia-Reset"] = this.params.reset.join(",");
      }
      if (this.params.errorBag && this.params.errorBag.length > 0) {
        headers["X-Inertia-Error-Bag"] = this.params.errorBag;
      }
      return headers;
    }
    setPreserveOptions(page2) {
      this.params.preserveScroll = _RequestParams.resolvePreserveOption(this.params.preserveScroll, page2);
      this.params.preserveState = _RequestParams.resolvePreserveOption(this.params.preserveState, page2);
    }
    runCallbacks() {
      this.callbacks.forEach(({ name, args }) => {
        this.params[name](...args);
      });
    }
    merge(toMerge) {
      this.params = {
        ...this.params,
        ...toMerge
      };
    }
    wrapCallback(params, name) {
      return (...args) => {
        this.recordCallback(name, args);
        params[name](...args);
      };
    }
    recordCallback(name, args) {
      this.callbacks.push({ name, args });
    }
    static resolvePreserveOption(value, page2) {
      if (typeof value === "function") {
        return value(page2);
      }
      if (value === "errors") {
        return Object.keys(page2.props.errors || {}).length > 0;
      }
      return value;
    }
  };
  var modal_default = {
    modal: null,
    listener: null,
    previousBodyOverflow: null,
    createIframeAndPage(html) {
      if (typeof html === "object") {
        html = `All Inertia requests must receive a valid Inertia response, however a plain JSON response was received.<hr>${JSON.stringify(
          html
        )}`;
      }
      const page2 = document.createElement("html");
      page2.innerHTML = html;
      page2.querySelectorAll("a").forEach((a15) => a15.setAttribute("target", "_top"));
      const iframe = document.createElement("iframe");
      iframe.style.backgroundColor = "white";
      iframe.style.borderRadius = "5px";
      iframe.style.width = "100%";
      iframe.style.height = "100%";
      iframe.setAttribute("sandbox", "allow-scripts");
      return { iframe, page: page2 };
    },
    show(html) {
      const { iframe, page: page2 } = this.createIframeAndPage(html);
      this.modal = document.createElement("div");
      this.modal.style.position = "fixed";
      this.modal.style.width = "100vw";
      this.modal.style.height = "100vh";
      this.modal.style.padding = "50px";
      this.modal.style.boxSizing = "border-box";
      this.modal.style.backgroundColor = "rgba(0, 0, 0, .6)";
      this.modal.style.zIndex = 2e5;
      this.modal.addEventListener("click", () => this.hide());
      this.modal.appendChild(iframe);
      document.body.prepend(this.modal);
      this.previousBodyOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      iframe.srcdoc = page2.outerHTML;
      this.listener = this.hideOnEscape.bind(this);
      document.addEventListener("keydown", this.listener);
    },
    hide() {
      this.modal.outerHTML = "";
      this.modal = null;
      document.body.style.overflow = this.previousBodyOverflow ?? "";
      this.previousBodyOverflow = null;
      document.removeEventListener("keydown", this.listener);
    },
    hideOnEscape(event) {
      if (event.keyCode === 27) {
        this.hide();
      }
    }
  };
  var dialog_default = {
    show(html) {
      const { iframe, page: page2 } = modal_default.createIframeAndPage(html);
      iframe.style.boxSizing = "border-box";
      iframe.style.display = "block";
      const dialog = document.createElement("dialog");
      dialog.id = "inertia-error-dialog";
      Object.assign(dialog.style, {
        width: "calc(100vw - 100px)",
        height: "calc(100vh - 100px)",
        padding: "0",
        margin: "auto",
        border: "none",
        backgroundColor: "transparent"
      });
      const dialogStyleElement = document.createElement("style");
      dialogStyleElement.textContent = `
      dialog#inertia-error-dialog::backdrop {
        background-color: rgba(0, 0, 0, 0.6);
      }

      dialog#inertia-error-dialog:focus {
        outline: none;
      }
    `;
      document.head.appendChild(dialogStyleElement);
      dialog.addEventListener("click", (event) => {
        if (event.target === dialog) {
          dialog.close();
        }
      });
      dialog.addEventListener("close", () => {
        dialogStyleElement.remove();
        dialog.remove();
      });
      dialog.appendChild(iframe);
      document.body.prepend(dialog);
      dialog.showModal();
      dialog.focus();
      iframe.srcdoc = page2.outerHTML;
    }
  };
  var queue2 = new Queue();
  var Response = class _Response {
    constructor(requestParams, response, originatingPage) {
      this.requestParams = requestParams;
      this.response = response;
      this.originatingPage = originatingPage;
      this.wasPrefetched = false;
    }
    static create(params, response, originatingPage) {
      return new _Response(params, response, originatingPage);
    }
    async handlePrefetch() {
      if (isSameUrlWithoutHash(this.requestParams.all().url, window.location)) {
        this.handle();
      }
    }
    async handle() {
      return queue2.add(() => this.process());
    }
    async process() {
      if (this.requestParams.all().prefetch) {
        this.wasPrefetched = true;
        this.requestParams.all().prefetch = false;
        this.requestParams.all().onPrefetched(this.response, this.requestParams.all());
        firePrefetchedEvent(this.response, this.requestParams.all());
        return Promise.resolve();
      }
      this.requestParams.runCallbacks();
      if (!this.isInertiaResponse()) {
        return this.handleNonInertiaResponse();
      }
      await history.processQueue();
      history.preserveUrl = this.requestParams.all().preserveUrl;
      await this.setPage();
      const errors = page.get().props.errors || {};
      if (Object.keys(errors).length > 0) {
        const scopedErrors = this.getScopedErrors(errors);
        fireErrorEvent(scopedErrors);
        return this.requestParams.all().onError(scopedErrors);
      }
      router.flushByCacheTags(this.requestParams.all().invalidateCacheTags || []);
      if (!this.wasPrefetched) {
        router.flush(page.get().url);
      }
      const { flash } = page.get();
      if (Object.keys(flash).length > 0 && !this.requestParams.isDeferredPropsRequest()) {
        fireFlashEvent(flash);
        this.requestParams.all().onFlash(flash);
      }
      fireSuccessEvent(page.get());
      await this.requestParams.all().onSuccess(page.get());
      history.preserveUrl = false;
    }
    mergeParams(params) {
      this.requestParams.merge(params);
    }
    getPageResponse() {
      const data = this.getDataFromResponse(this.response.data);
      if (typeof data === "object") {
        return this.response.data = { ...data, flash: data.flash ?? {} };
      }
      return this.response.data = data;
    }
    async handleNonInertiaResponse() {
      if (this.isLocationVisit()) {
        const locationUrl = hrefToUrl(this.getHeader("x-inertia-location"));
        setHashIfSameUrl(this.requestParams.all().url, locationUrl);
        return this.locationVisit(locationUrl);
      }
      const response = {
        ...this.response,
        data: this.getDataFromResponse(this.response.data)
      };
      if (fireInvalidEvent(response)) {
        return config.get("future.useDialogForErrorModal") ? dialog_default.show(response.data) : modal_default.show(response.data);
      }
    }
    isInertiaResponse() {
      return this.hasHeader("x-inertia");
    }
    hasStatus(status2) {
      return this.response.status === status2;
    }
    getHeader(header) {
      return this.response.headers[header];
    }
    hasHeader(header) {
      return this.getHeader(header) !== void 0;
    }
    isLocationVisit() {
      return this.hasStatus(409) && this.hasHeader("x-inertia-location");
    }
    /**
     * @link https://inertiajs.com/redirects#external-redirects
     */
    locationVisit(url) {
      try {
        SessionStorage.set(SessionStorage.locationVisitKey, {
          preserveScroll: this.requestParams.all().preserveScroll === true
        });
        if (typeof window === "undefined") {
          return;
        }
        if (isSameUrlWithoutHash(window.location, url)) {
          window.location.reload();
        } else {
          window.location.href = url.href;
        }
      } catch (error) {
        return false;
      }
    }
    async setPage() {
      const pageResponse = this.getPageResponse();
      if (!this.shouldSetPage(pageResponse)) {
        return Promise.resolve();
      }
      this.mergeProps(pageResponse);
      page.mergeOncePropsIntoResponse(pageResponse);
      this.preserveEqualProps(pageResponse);
      await this.setRememberedState(pageResponse);
      this.requestParams.setPreserveOptions(pageResponse);
      pageResponse.url = history.preserveUrl ? page.get().url : this.pageUrl(pageResponse);
      this.requestParams.all().onBeforeUpdate(pageResponse);
      fireBeforeUpdateEvent(pageResponse);
      return page.set(pageResponse, {
        replace: this.requestParams.all().replace,
        preserveScroll: this.requestParams.all().preserveScroll,
        preserveState: this.requestParams.all().preserveState,
        viewTransition: this.requestParams.all().viewTransition
      });
    }
    getDataFromResponse(response) {
      if (typeof response !== "string") {
        return response;
      }
      try {
        return JSON.parse(response);
      } catch (error) {
        return response;
      }
    }
    shouldSetPage(pageResponse) {
      if (!this.requestParams.all().async) {
        return true;
      }
      if (this.originatingPage.component !== pageResponse.component) {
        return true;
      }
      if (this.originatingPage.component !== page.get().component) {
        return false;
      }
      const originatingUrl = hrefToUrl(this.originatingPage.url);
      const currentPageUrl = hrefToUrl(page.get().url);
      return originatingUrl.origin === currentPageUrl.origin && originatingUrl.pathname === currentPageUrl.pathname;
    }
    pageUrl(pageResponse) {
      const responseUrl = hrefToUrl(pageResponse.url);
      setHashIfSameUrl(this.requestParams.all().url, responseUrl);
      return responseUrl.pathname + responseUrl.search + responseUrl.hash;
    }
    preserveEqualProps(pageResponse) {
      if (pageResponse.component !== page.get().component || config.get("future.preserveEqualProps") !== true) {
        return;
      }
      const currentPageProps = page.get().props;
      Object.entries(pageResponse.props).forEach(([key, value]) => {
        if (isEqual_default(value, currentPageProps[key])) {
          pageResponse.props[key] = currentPageProps[key];
        }
      });
    }
    mergeProps(pageResponse) {
      if (!this.requestParams.isPartial() || pageResponse.component !== page.get().component) {
        return;
      }
      const propsToAppend = pageResponse.mergeProps || [];
      const propsToPrepend = pageResponse.prependProps || [];
      const propsToDeepMerge = pageResponse.deepMergeProps || [];
      const matchPropsOn = pageResponse.matchPropsOn || [];
      const mergeProp = (prop, shouldAppend) => {
        const currentProp = get_default(page.get().props, prop);
        const incomingProp = get_default(pageResponse.props, prop);
        if (Array.isArray(incomingProp)) {
          const newArray = this.mergeOrMatchItems(
            currentProp || [],
            incomingProp,
            prop,
            matchPropsOn,
            shouldAppend
          );
          set_default(pageResponse.props, prop, newArray);
        } else if (typeof incomingProp === "object" && incomingProp !== null) {
          const newObject = {
            ...currentProp || {},
            ...incomingProp
          };
          set_default(pageResponse.props, prop, newObject);
        }
      };
      propsToAppend.forEach((prop) => mergeProp(prop, true));
      propsToPrepend.forEach((prop) => mergeProp(prop, false));
      propsToDeepMerge.forEach((prop) => {
        const currentProp = page.get().props[prop];
        const incomingProp = pageResponse.props[prop];
        const deepMerge = (target, source, matchProp) => {
          if (Array.isArray(source)) {
            return this.mergeOrMatchItems(target, source, matchProp, matchPropsOn);
          }
          if (typeof source === "object" && source !== null) {
            return Object.keys(source).reduce(
              (acc, key) => {
                acc[key] = deepMerge(target ? target[key] : void 0, source[key], `${matchProp}.${key}`);
                return acc;
              },
              { ...target }
            );
          }
          return source;
        };
        pageResponse.props[prop] = deepMerge(currentProp, incomingProp, prop);
      });
      pageResponse.props = { ...page.get().props, ...pageResponse.props };
      if (this.requestParams.isDeferredPropsRequest()) {
        const currentErrors = page.get().props.errors;
        if (currentErrors && Object.keys(currentErrors).length > 0) {
          pageResponse.props.errors = currentErrors;
        }
      }
      if (page.get().scrollProps) {
        pageResponse.scrollProps = {
          ...page.get().scrollProps || {},
          ...pageResponse.scrollProps || {}
        };
      }
      if (page.hasOnceProps()) {
        pageResponse.onceProps = {
          ...page.get().onceProps || {},
          ...pageResponse.onceProps || {}
        };
      }
      if (this.requestParams.isDeferredPropsRequest()) {
        pageResponse.flash = { ...page.get().flash };
      }
      const currentOriginalDeferred = page.get().initialDeferredProps;
      if (currentOriginalDeferred && Object.keys(currentOriginalDeferred).length > 0) {
        pageResponse.initialDeferredProps = currentOriginalDeferred;
      }
    }
    mergeOrMatchItems(existingItems, newItems, matchProp, matchPropsOn, shouldAppend = true) {
      const items = Array.isArray(existingItems) ? existingItems : [];
      const matchingKey = matchPropsOn.find((key) => {
        const keyPath = key.split(".").slice(0, -1).join(".");
        return keyPath === matchProp;
      });
      if (!matchingKey) {
        return shouldAppend ? [...items, ...newItems] : [...newItems, ...items];
      }
      const uniqueProperty = matchingKey.split(".").pop() || "";
      const newItemsMap = /* @__PURE__ */ new Map();
      newItems.forEach((item) => {
        if (this.hasUniqueProperty(item, uniqueProperty)) {
          newItemsMap.set(item[uniqueProperty], item);
        }
      });
      return shouldAppend ? this.appendWithMatching(items, newItems, newItemsMap, uniqueProperty) : this.prependWithMatching(items, newItems, newItemsMap, uniqueProperty);
    }
    appendWithMatching(existingItems, newItems, newItemsMap, uniqueProperty) {
      const updatedExisting = existingItems.map((item) => {
        if (this.hasUniqueProperty(item, uniqueProperty) && newItemsMap.has(item[uniqueProperty])) {
          return newItemsMap.get(item[uniqueProperty]);
        }
        return item;
      });
      const newItemsToAdd = newItems.filter((item) => {
        if (!this.hasUniqueProperty(item, uniqueProperty)) {
          return true;
        }
        return !existingItems.some(
          (existing) => this.hasUniqueProperty(existing, uniqueProperty) && existing[uniqueProperty] === item[uniqueProperty]
        );
      });
      return [...updatedExisting, ...newItemsToAdd];
    }
    prependWithMatching(existingItems, newItems, newItemsMap, uniqueProperty) {
      const untouchedExisting = existingItems.filter((item) => {
        if (this.hasUniqueProperty(item, uniqueProperty)) {
          return !newItemsMap.has(item[uniqueProperty]);
        }
        return true;
      });
      return [...newItems, ...untouchedExisting];
    }
    hasUniqueProperty(item, property) {
      return item && typeof item === "object" && property in item;
    }
    async setRememberedState(pageResponse) {
      const rememberedState = await history.getState(history.rememberedState, {});
      if (this.requestParams.all().preserveState && rememberedState && pageResponse.component === page.get().component) {
        pageResponse.rememberedState = rememberedState;
      }
    }
    getScopedErrors(errors) {
      if (!this.requestParams.all().errorBag) {
        return errors;
      }
      return errors[this.requestParams.all().errorBag || ""] || {};
    }
  };
  var Request = class _Request {
    constructor(params, page2) {
      this.page = page2;
      this.requestHasFinished = false;
      this.requestParams = RequestParams.create(params);
      this.cancelToken = new AbortController();
    }
    static create(params, page2) {
      return new _Request(params, page2);
    }
    isPrefetch() {
      return this.requestParams.isPrefetch();
    }
    async send() {
      this.requestParams.onCancelToken(() => this.cancel({ cancelled: true }));
      fireStartEvent(this.requestParams.all());
      this.requestParams.onStart();
      if (this.requestParams.all().prefetch) {
        this.requestParams.onPrefetching();
        firePrefetchingEvent(this.requestParams.all());
      }
      const originallyPrefetch = this.requestParams.all().prefetch;
      return axios_default({
        method: this.requestParams.all().method,
        url: urlWithoutHash(this.requestParams.all().url).href,
        data: this.requestParams.data(),
        params: this.requestParams.queryParams(),
        signal: this.cancelToken.signal,
        headers: this.getHeaders(),
        onUploadProgress: this.onProgress.bind(this),
        // Why text? This allows us to delay JSON.parse until we're ready to use the response,
        // helps with performance particularly on large responses + history encryption
        responseType: "text"
      }).then((response) => {
        this.response = Response.create(this.requestParams, response, this.page);
        return this.response.handle();
      }).catch((error) => {
        if (error?.response) {
          this.response = Response.create(this.requestParams, error.response, this.page);
          return this.response.handle();
        }
        return Promise.reject(error);
      }).catch((error) => {
        if (axios_default.isCancel(error)) {
          return;
        }
        if (fireExceptionEvent(error)) {
          if (originallyPrefetch) {
            this.requestParams.onPrefetchError(error);
          }
          return Promise.reject(error);
        }
      }).finally(() => {
        this.finish();
        if (originallyPrefetch && this.response) {
          this.requestParams.onPrefetchResponse(this.response);
        }
      });
    }
    finish() {
      if (this.requestParams.wasCancelledAtAll()) {
        return;
      }
      this.requestParams.markAsFinished();
      this.fireFinishEvents();
    }
    fireFinishEvents() {
      if (this.requestHasFinished) {
        return;
      }
      this.requestHasFinished = true;
      fireFinishEvent(this.requestParams.all());
      this.requestParams.onFinish();
    }
    cancel({ cancelled = false, interrupted = false }) {
      if (this.requestHasFinished) {
        return;
      }
      this.cancelToken.abort();
      this.requestParams.markAsCancelled({ cancelled, interrupted });
      this.fireFinishEvents();
    }
    onProgress(progress3) {
      if (this.requestParams.data() instanceof FormData) {
        progress3.percentage = progress3.progress ? Math.round(progress3.progress * 100) : 0;
        fireProgressEvent(progress3);
        this.requestParams.all().onProgress(progress3);
      }
    }
    getHeaders() {
      const headers = {
        ...this.requestParams.headers(),
        Accept: "text/html, application/xhtml+xml",
        "X-Requested-With": "XMLHttpRequest",
        "X-Inertia": true
      };
      const page2 = page.get();
      if (page2.version) {
        headers["X-Inertia-Version"] = page2.version;
      }
      const onceProps = Object.entries(page2.onceProps || {}).filter(([, onceProp]) => {
        if (page2.props[onceProp.prop] === void 0) {
          return false;
        }
        return !onceProp.expiresAt || onceProp.expiresAt > Date.now();
      }).map(([key]) => key);
      if (onceProps.length > 0) {
        headers["X-Inertia-Except-Once-Props"] = onceProps.join(",");
      }
      return headers;
    }
  };
  var RequestStream = class {
    constructor({ maxConcurrent, interruptible }) {
      this.requests = [];
      this.maxConcurrent = maxConcurrent;
      this.interruptible = interruptible;
    }
    send(request2) {
      this.requests.push(request2);
      request2.send().finally(() => {
        this.requests = this.requests.filter((r13) => r13 !== request2);
      });
    }
    interruptInFlight() {
      this.cancel({ interrupted: true }, false);
    }
    cancelInFlight({ prefetch = true } = {}) {
      this.requests.filter((request2) => prefetch || !request2.isPrefetch()).forEach((request2) => request2.cancel({ cancelled: true }));
    }
    cancel({ cancelled = false, interrupted = false } = {}, force = false) {
      if (!force && !this.shouldCancel()) {
        return;
      }
      const request2 = this.requests.shift();
      request2?.cancel({ cancelled, interrupted });
    }
    shouldCancel() {
      return this.interruptible && this.requests.length >= this.maxConcurrent;
    }
  };
  var Router = class {
    constructor() {
      this.syncRequestStream = new RequestStream({
        maxConcurrent: 1,
        interruptible: true
      });
      this.asyncRequestStream = new RequestStream({
        maxConcurrent: Infinity,
        interruptible: false
      });
      this.clientVisitQueue = new Queue();
    }
    init({
      initialPage,
      resolveComponent,
      swapComponent: swapComponent2,
      onFlash
    }) {
      page.init({
        initialPage,
        resolveComponent,
        swapComponent: swapComponent2,
        onFlash
      });
      InitialVisit.handle();
      eventHandler.init();
      eventHandler.on("missingHistoryItem", () => {
        if (typeof window !== "undefined") {
          this.visit(window.location.href, { preserveState: true, preserveScroll: true, replace: true });
        }
      });
      eventHandler.on("loadDeferredProps", (deferredProps) => {
        this.loadDeferredProps(deferredProps);
      });
      eventHandler.on("historyQuotaExceeded", (url) => {
        window.location.href = url;
      });
    }
    get(url, data = {}, options = {}) {
      return this.visit(url, { ...options, method: "get", data });
    }
    post(url, data = {}, options = {}) {
      return this.visit(url, { preserveState: true, ...options, method: "post", data });
    }
    put(url, data = {}, options = {}) {
      return this.visit(url, { preserveState: true, ...options, method: "put", data });
    }
    patch(url, data = {}, options = {}) {
      return this.visit(url, { preserveState: true, ...options, method: "patch", data });
    }
    delete(url, options = {}) {
      return this.visit(url, { preserveState: true, ...options, method: "delete" });
    }
    reload(options = {}) {
      return this.doReload(options);
    }
    doReload(options = {}) {
      if (typeof window === "undefined") {
        return;
      }
      return this.visit(window.location.href, {
        ...options,
        preserveScroll: true,
        preserveState: true,
        async: true,
        headers: {
          ...options.headers || {},
          "Cache-Control": "no-cache"
        }
      });
    }
    remember(data, key = "default") {
      history.remember(data, key);
    }
    restore(key = "default") {
      return history.restore(key);
    }
    on(type, callback) {
      if (typeof window === "undefined") {
        return () => {
        };
      }
      return eventHandler.onGlobalEvent(type, callback);
    }
    /**
     * @deprecated Use cancelAll() instead.
     */
    cancel() {
      this.syncRequestStream.cancelInFlight();
    }
    get activePolls() {
      return polls.count;
    }
    cancelAll({ async = true, prefetch = true, sync = true } = {}) {
      if (async) {
        this.asyncRequestStream.cancelInFlight({ prefetch });
      }
      if (sync) {
        this.syncRequestStream.cancelInFlight();
      }
    }
    poll(interval, requestOptions = {}, options = {}) {
      return polls.add(
        interval,
        ({ onStart, onFinish }) => {
          const resolved = typeof requestOptions === "function" ? requestOptions() : requestOptions;
          this.reload({
            ...resolved,
            onCancelToken: (token) => {
              onStart(token.cancel);
              resolved.onCancelToken?.(token);
            },
            onFinish: (visit) => {
              onFinish();
              resolved.onFinish?.(visit);
            }
          });
        },
        {
          autoStart: options.autoStart ?? true,
          keepAlive: options.keepAlive ?? false,
          mode: options.mode
        }
      );
    }
    visit(href, options = {}) {
      const visit = this.getPendingVisit(href, {
        ...options,
        showProgress: options.showProgress ?? !options.async
      });
      const events = this.getVisitEvents(options);
      if (events.onBefore(visit) === false || !fireBeforeEvent(visit)) {
        return;
      }
      const currentPageUrl = hrefToUrl(page.get().url);
      const isPartialReload = visit.only.length > 0 || visit.except.length > 0 || visit.reset.length > 0;
      const isSamePage = isPartialReload ? isSameUrlWithoutQueryOrHash(visit.url, currentPageUrl) : isSameUrlWithoutHash(visit.url, currentPageUrl);
      if (!isSamePage) {
        this.asyncRequestStream.cancelInFlight({ prefetch: false });
      }
      if (!visit.async) {
        this.syncRequestStream.interruptInFlight();
      }
      if (!page.isCleared() && !visit.preserveUrl) {
        Scroll.save();
      }
      const requestParams = {
        ...visit,
        ...events
      };
      const prefetched = prefetchedRequests.get(requestParams);
      if (prefetched) {
        progress.reveal(prefetched.inFlight);
        prefetchedRequests.use(prefetched, requestParams);
      } else {
        progress.reveal(true);
        const requestStream = visit.async ? this.asyncRequestStream : this.syncRequestStream;
        requestStream.send(Request.create(requestParams, page.get()));
      }
    }
    getCached(href, options = {}) {
      return prefetchedRequests.findCached(this.getPrefetchParams(href, options));
    }
    flush(href, options = {}) {
      prefetchedRequests.remove(this.getPrefetchParams(href, options));
    }
    flushAll() {
      prefetchedRequests.removeAll();
    }
    flushByCacheTags(tags) {
      prefetchedRequests.removeByTags(Array.isArray(tags) ? tags : [tags]);
    }
    getPrefetching(href, options = {}) {
      return prefetchedRequests.findInFlight(this.getPrefetchParams(href, options));
    }
    prefetch(href, options = {}, prefetchOptions = {}) {
      const method = options.method ?? (isUrlMethodPair(href) ? href.method : "get");
      if (method !== "get") {
        throw new Error("Prefetch requests must use the GET method");
      }
      const visit = this.getPendingVisit(href, {
        ...options,
        async: true,
        showProgress: false,
        prefetch: true,
        viewTransition: false
      });
      const visitUrl = visit.url.origin + visit.url.pathname + visit.url.search;
      const currentUrl = window.location.origin + window.location.pathname + window.location.search;
      if (visitUrl === currentUrl) {
        return;
      }
      const events = this.getVisitEvents(options);
      if (events.onBefore(visit) === false || !fireBeforeEvent(visit)) {
        return;
      }
      progress.hide();
      this.asyncRequestStream.interruptInFlight();
      const requestParams = {
        ...visit,
        ...events
      };
      const ensureCurrentPageIsSet = () => {
        return new Promise((resolve) => {
          const checkIfPageIsDefined = () => {
            if (page.get()) {
              resolve();
            } else {
              setTimeout(checkIfPageIsDefined, 50);
            }
          };
          checkIfPageIsDefined();
        });
      };
      ensureCurrentPageIsSet().then(() => {
        prefetchedRequests.add(
          requestParams,
          (params) => {
            this.asyncRequestStream.send(Request.create(params, page.get()));
          },
          {
            cacheFor: config.get("prefetch.cacheFor"),
            cacheTags: [],
            ...prefetchOptions
          }
        );
      });
    }
    clearHistory() {
      history.clear();
    }
    decryptHistory() {
      return history.decrypt();
    }
    resolveComponent(component) {
      return page.resolve(component);
    }
    replace(params) {
      this.clientVisit(params, { replace: true });
    }
    replaceProp(name, value, options) {
      this.replace({
        preserveScroll: true,
        preserveState: true,
        props(currentProps) {
          const newValue = typeof value === "function" ? value(get_default(currentProps, name), currentProps) : value;
          return set_default(cloneDeep_default(currentProps), name, newValue);
        },
        ...options || {}
      });
    }
    appendToProp(name, value, options) {
      this.replaceProp(
        name,
        (currentValue, currentProps) => {
          const newValue = typeof value === "function" ? value(currentValue, currentProps) : value;
          if (!Array.isArray(currentValue)) {
            currentValue = currentValue !== void 0 ? [currentValue] : [];
          }
          return [...currentValue, newValue];
        },
        options
      );
    }
    prependToProp(name, value, options) {
      this.replaceProp(
        name,
        (currentValue, currentProps) => {
          const newValue = typeof value === "function" ? value(currentValue, currentProps) : value;
          if (!Array.isArray(currentValue)) {
            currentValue = currentValue !== void 0 ? [currentValue] : [];
          }
          return [newValue, ...currentValue];
        },
        options
      );
    }
    push(params) {
      this.clientVisit(params);
    }
    flash(keyOrData, value) {
      const current = page.get().flash;
      let flash;
      if (typeof keyOrData === "function") {
        flash = keyOrData(current);
      } else if (typeof keyOrData === "string") {
        flash = { ...current, [keyOrData]: value };
      } else if (keyOrData && Object.keys(keyOrData).length) {
        flash = { ...current, ...keyOrData };
      } else {
        return;
      }
      page.setFlash(flash);
      if (Object.keys(flash).length) {
        fireFlashEvent(flash);
      }
    }
    clientVisit(params, { replace = false } = {}) {
      this.clientVisitQueue.add(() => this.performClientVisit(params, { replace }));
    }
    performClientVisit(params, { replace = false } = {}) {
      const current = page.get();
      const onceProps = typeof params.props === "function" ? Object.fromEntries(
        Object.values(current.onceProps ?? {}).map((onceProp) => [onceProp.prop, current.props[onceProp.prop]])
      ) : {};
      const props = typeof params.props === "function" ? params.props(current.props, onceProps) : params.props ?? current.props;
      const flash = typeof params.flash === "function" ? params.flash(current.flash) : params.flash;
      const { viewTransition, onError, onFinish, onFlash, onSuccess, ...pageParams } = params;
      const page2 = {
        ...current,
        ...pageParams,
        flash: flash ?? {},
        props
      };
      const preserveScroll = RequestParams.resolvePreserveOption(params.preserveScroll ?? false, page2);
      const preserveState = RequestParams.resolvePreserveOption(params.preserveState ?? false, page2);
      return page.set(page2, {
        replace,
        preserveScroll,
        preserveState,
        viewTransition
      }).then(() => {
        const currentFlash = page.get().flash;
        if (Object.keys(currentFlash).length > 0) {
          fireFlashEvent(currentFlash);
          onFlash?.(currentFlash);
        }
        const errors = page.get().props.errors || {};
        if (Object.keys(errors).length === 0) {
          onSuccess?.(page.get());
          return;
        }
        const scopedErrors = params.errorBag ? errors[params.errorBag || ""] || {} : errors;
        onError?.(scopedErrors);
      }).finally(() => onFinish?.(params));
    }
    getPrefetchParams(href, options) {
      return {
        ...this.getPendingVisit(href, {
          ...options,
          async: true,
          showProgress: false,
          prefetch: true,
          viewTransition: false
        }),
        ...this.getVisitEvents(options)
      };
    }
    getPendingVisit(href, options, pendingVisitOptions = {}) {
      if (isUrlMethodPair(href)) {
        const urlMethodPair = href;
        href = urlMethodPair.url;
        options.method = options.method ?? urlMethodPair.method;
      }
      const defaultVisitOptionsCallback = config.get("visitOptions");
      const configuredOptions = defaultVisitOptionsCallback ? defaultVisitOptionsCallback(href.toString(), cloneDeep_default(options)) || {} : {};
      const mergedOptions = {
        method: "get",
        data: {},
        replace: false,
        preserveScroll: false,
        preserveState: false,
        only: [],
        except: [],
        headers: {},
        errorBag: "",
        forceFormData: false,
        queryStringArrayFormat: "brackets",
        async: false,
        showProgress: true,
        fresh: false,
        reset: [],
        preserveUrl: false,
        prefetch: false,
        invalidateCacheTags: [],
        viewTransition: false,
        ...stripTopLevelUndefined(options),
        ...stripTopLevelUndefined(configuredOptions)
      };
      const [url, _data] = transformUrlAndData(
        href,
        mergedOptions.data,
        mergedOptions.method,
        mergedOptions.forceFormData,
        mergedOptions.queryStringArrayFormat
      );
      const visit = {
        cancelled: false,
        completed: false,
        interrupted: false,
        ...mergedOptions,
        ...pendingVisitOptions,
        url,
        data: _data
      };
      if (visit.prefetch) {
        visit.headers["Purpose"] = "prefetch";
      }
      return visit;
    }
    getVisitEvents(options) {
      return {
        onCancelToken: options.onCancelToken || (() => {
        }),
        onBefore: options.onBefore || (() => {
        }),
        onBeforeUpdate: options.onBeforeUpdate || (() => {
        }),
        onStart: options.onStart || (() => {
        }),
        onProgress: options.onProgress || (() => {
        }),
        onFinish: options.onFinish || (() => {
        }),
        onCancel: options.onCancel || (() => {
        }),
        onSuccess: options.onSuccess || (() => {
        }),
        onError: options.onError || (() => {
        }),
        onFlash: options.onFlash || (() => {
        }),
        onPrefetched: options.onPrefetched || (() => {
        }),
        onPrefetching: options.onPrefetching || (() => {
        })
      };
    }
    loadDeferredProps(deferred) {
      if (deferred) {
        Object.entries(deferred).forEach(([_4, group]) => {
          this.doReload({ only: group, deferredProps: true });
        });
      }
    }
  };
  var UseFormUtils = class {
    /**
     * Creates a callback that returns a UrlMethodPair.
     *
     * createWayfinderCallback(urlMethodPair)
     * createWayfinderCallback(method, url)
     * createWayfinderCallback(() => urlMethodPair)
     * createWayfinderCallback(() => method, () => url)
     */
    static createWayfinderCallback(...args) {
      return () => {
        if (args.length === 1) {
          return isUrlMethodPair(args[0]) ? args[0] : args[0]();
        }
        return {
          method: typeof args[0] === "function" ? args[0]() : args[0],
          url: typeof args[1] === "function" ? args[1]() : args[1]
        };
      };
    }
    /**
     * Parses all useForm() arguments into { rememberKey, data, precognitionEndpoint }.
     *
     * useForm()
     * useForm(data)
     * useForm(rememberKey, data)
     * useForm(method, url, data)
     * useForm(urlMethodPair, data)
     *
     */
    static parseUseFormArguments(...args) {
      if (args.length === 0) {
        return {
          rememberKey: null,
          data: {},
          precognitionEndpoint: null
        };
      }
      if (args.length === 1) {
        return {
          rememberKey: null,
          data: args[0],
          precognitionEndpoint: null
        };
      }
      if (args.length === 2) {
        if (typeof args[0] === "string") {
          return {
            rememberKey: args[0],
            data: args[1],
            precognitionEndpoint: null
          };
        }
        return {
          rememberKey: null,
          data: args[1],
          precognitionEndpoint: this.createWayfinderCallback(args[0])
        };
      }
      return {
        rememberKey: null,
        data: args[2],
        precognitionEndpoint: this.createWayfinderCallback(args[0], args[1])
      };
    }
    /**
     * Parses all submission arguments into { method, url, options }.
     * It uses the Precognition endpoint if no explicit method/url are provided.
     *
     * form.submit(method, url)
     * form.submit(method, url, options)
     * form.submit(urlMethodPair)
     * form.submit(urlMethodPair, options)
     * form.submit()
     * form.submit(options)
     */
    static parseSubmitArguments(args, precognitionEndpoint) {
      if (args.length === 3 || args.length === 2 && typeof args[0] === "string") {
        return { method: args[0], url: args[1], options: args[2] ?? {} };
      }
      if (isUrlMethodPair(args[0])) {
        return { ...args[0], options: args[1] ?? {} };
      }
      return { ...precognitionEndpoint(), options: args[0] ?? {} };
    }
    /**
     * Merges headers into the Precognition validate() arguments.
     */
    static mergeHeadersForValidation(field, config22, headers) {
      const merge3 = (config3) => {
        config3.headers = {
          ...headers ?? {},
          ...config3.headers ?? {}
        };
        return config3;
      };
      if (field && typeof field === "object" && !("target" in field)) {
        field = merge3(field);
      } else if (config22 && typeof config22 === "object") {
        config22 = merge3(config22);
      } else if (typeof field === "string") {
        config22 = merge3(config22 ?? {});
      } else {
        field = merge3(field ?? {});
      }
      return [field, config22];
    }
  };
  function undotKey(key) {
    if (!key.includes(".")) {
      return key;
    }
    const transformSegment = (segment) => {
      if (segment.startsWith("[") && segment.endsWith("]")) {
        return segment;
      }
      return segment.split(".").reduce((result, part, index) => index === 0 ? part : `${result}[${part}]`);
    };
    return key.replace(/\\\./g, "__ESCAPED_DOT__").split(/(\[[^\]]*\])/).filter(Boolean).map(transformSegment).join("").replace(/__ESCAPED_DOT__/g, ".");
  }
  function parseKey(key) {
    const path = [];
    const pattern = /([^\[\]]+)|\[(\d*)\]/g;
    let match;
    while ((match = pattern.exec(key)) !== null) {
      if (match[1] !== void 0) {
        path.push(match[1]);
      } else if (match[2] !== void 0) {
        path.push(match[2] === "" ? "" : Number(match[2]));
      }
    }
    return path;
  }
  function setNestedObject(obj, path, value) {
    let current = obj;
    for (let i12 = 0; i12 < path.length - 1; i12++) {
      if (!(path[i12] in current)) {
        current[path[i12]] = {};
      }
      current = current[path[i12]];
    }
    current[path[path.length - 1]] = value;
  }
  function objectHasSequentialNumericKeys(value) {
    const keys2 = Object.keys(value);
    const numericKeys = keys2.filter((k6) => /^\d+$/.test(k6)).map(Number).sort((a15, b8) => a15 - b8);
    return keys2.length === numericKeys.length && numericKeys.length > 0 && numericKeys[0] === 0 && numericKeys.every((n12, i12) => n12 === i12);
  }
  function convertSequentialObjectsToArrays(value) {
    if (Array.isArray(value)) {
      return value.map(convertSequentialObjectsToArrays);
    }
    if (typeof value !== "object" || value === null || isFile2(value)) {
      return value;
    }
    if (objectHasSequentialNumericKeys(value)) {
      const result2 = [];
      for (let i12 = 0; i12 < Object.keys(value).length; i12++) {
        result2[i12] = convertSequentialObjectsToArrays(value[i12]);
      }
      return result2;
    }
    const result = {};
    for (const key in value) {
      result[key] = convertSequentialObjectsToArrays(value[key]);
    }
    return result;
  }
  function formDataToObject(source) {
    const form = {};
    for (const [key, value] of source.entries()) {
      if (value instanceof File && value.size === 0 && value.name === "") {
        continue;
      }
      const path = parseKey(undotKey(key));
      if (path[path.length - 1] === "") {
        const arrayPath = path.slice(0, -1);
        const existing = get_default(form, arrayPath);
        if (Array.isArray(existing)) {
          existing.push(value);
        } else if (existing && typeof existing === "object" && !isFile2(existing)) {
          const numericKeys = Object.keys(existing).filter((k6) => /^\d+$/.test(k6)).map(Number).sort((a15, b8) => a15 - b8);
          set_default(form, arrayPath, numericKeys.length > 0 ? [...numericKeys.map((k6) => existing[k6]), value] : [value]);
        } else {
          set_default(form, arrayPath, [value]);
        }
        continue;
      }
      setNestedObject(form, path.map(String), value);
    }
    return convertSequentialObjectsToArrays(form);
  }
  var Renderer = {
    preferredAttribute() {
      return config.get("future.useDataInertiaHeadAttribute") ? "data-inertia" : "inertia";
    },
    buildDOMElement(tag) {
      const template = document.createElement("template");
      template.innerHTML = tag;
      const node = template.content.firstChild;
      if (!tag.startsWith("<script ")) {
        return node;
      }
      const script = document.createElement("script");
      script.innerHTML = node.innerHTML;
      node.getAttributeNames().forEach((name) => {
        script.setAttribute(name, node.getAttribute(name) || "");
      });
      return script;
    },
    isInertiaManagedElement(element) {
      return element.nodeType === Node.ELEMENT_NODE && element.getAttribute(this.preferredAttribute()) !== null;
    },
    findMatchingElementIndex(element, elements) {
      const attribute = this.preferredAttribute();
      const key = element.getAttribute(attribute);
      if (key !== null) {
        return elements.findIndex((element2) => element2.getAttribute(attribute) === key);
      }
      return -1;
    },
    update: debounce2(function(elements) {
      const sourceElements = elements.map((element) => this.buildDOMElement(element));
      const targetElements = Array.from(document.head.childNodes).filter(
        (element) => this.isInertiaManagedElement(element)
      );
      targetElements.forEach((targetElement) => {
        const index = this.findMatchingElementIndex(targetElement, sourceElements);
        if (index === -1) {
          targetElement?.parentNode?.removeChild(targetElement);
          return;
        }
        const sourceElement = sourceElements.splice(index, 1)[0];
        if (sourceElement && !targetElement.isEqualNode(sourceElement)) {
          targetElement?.parentNode?.replaceChild(sourceElement, targetElement);
        }
      });
      sourceElements.forEach((element) => document.head.appendChild(element));
    }, 1)
  };
  function createHeadManager(isServer3, titleCallback, onUpdate) {
    const states = {};
    let lastProviderId = 0;
    function connect() {
      const id = lastProviderId += 1;
      states[id] = [];
      return id.toString();
    }
    function disconnect(id) {
      if (id === null || Object.keys(states).indexOf(id) === -1) {
        return;
      }
      delete states[id];
      commit();
    }
    function reconnect(id) {
      if (Object.keys(states).indexOf(id) === -1) {
        states[id] = [];
      }
    }
    function update(id, elements = []) {
      if (id !== null && Object.keys(states).indexOf(id) > -1) {
        states[id] = elements;
      }
      commit();
    }
    function collect() {
      const title = titleCallback("");
      const attribute = Renderer.preferredAttribute();
      const defaults2 = {
        ...title ? { title: `<title ${attribute}="">${title}</title>` } : {}
      };
      const elements = Object.values(states).reduce((carry, elements2) => carry.concat(elements2), []).reduce((carry, element) => {
        if (element.indexOf("<") === -1) {
          return carry;
        }
        if (element.indexOf("<title ") === 0) {
          const title2 = element.match(/(<title [^>]+>)(.*?)(<\/title>)/s);
          carry.title = title2 ? `${title2[1]}${titleCallback(title2[2])}${title2[3]}` : element;
          return carry;
        }
        const match = element.match(attribute === "inertia" ? / inertia="[^"]+"/ : / data-inertia="[^"]+"/);
        if (match) {
          carry[match[0]] = element;
        } else {
          carry[Object.keys(carry).length] = element;
        }
        return carry;
      }, defaults2);
      return Object.values(elements);
    }
    function commit() {
      isServer3 ? onUpdate(collect()) : Renderer.update(collect());
    }
    commit();
    return {
      forceUpdate: commit,
      createProvider: function() {
        const id = connect();
        return {
          preferredAttribute: Renderer.preferredAttribute,
          reconnect: () => reconnect(id),
          update: (elements) => update(id, elements),
          disconnect: () => disconnect(id)
        };
      }
    };
  }
  var MERGE_INTENT_HEADER = "X-Inertia-Infinite-Scroll-Merge-Intent";
  var useInfiniteScrollData = (options) => {
    const getScrollPropFromCurrentPage = () => {
      const scrollProp = page.get().scrollProps?.[options.getPropName()];
      if (scrollProp) {
        return scrollProp;
      }
      throw new Error(`The page object does not contain a scroll prop named "${options.getPropName()}".`);
    };
    const state = {
      component: null,
      loading: false,
      previousPage: null,
      nextPage: null,
      lastLoadedPage: null,
      requestCount: 0
    };
    const resetState = () => {
      const scrollProp = getScrollPropFromCurrentPage();
      state.component = page.get().component;
      state.loading = false;
      state.previousPage = scrollProp.previousPage;
      state.nextPage = scrollProp.nextPage;
      state.lastLoadedPage = scrollProp.currentPage;
      state.requestCount = 0;
    };
    const getRememberKey = () => `inertia:infinite-scroll-data:${options.getPropName()}`;
    if (typeof window !== "undefined") {
      resetState();
      const rememberedState = router.restore(getRememberKey());
      if (rememberedState && typeof rememberedState === "object" && rememberedState.lastLoadedPage === getScrollPropFromCurrentPage().currentPage) {
        state.previousPage = rememberedState.previousPage;
        state.nextPage = rememberedState.nextPage;
        state.lastLoadedPage = rememberedState.lastLoadedPage;
        state.requestCount = rememberedState.requestCount || 0;
      }
    }
    const removeEventListener = router.on("success", (event) => {
      if (state.component === event.detail.page.component && getScrollPropFromCurrentPage().reset) {
        resetState();
        options.onReset?.();
      }
    });
    const getScrollPropKeyForSide = (side) => {
      return side === "next" ? "nextPage" : "previousPage";
    };
    const findPageToLoad = (side) => {
      const pagePropName = getScrollPropKeyForSide(side);
      return state[pagePropName];
    };
    const syncStateOnSuccess = (side) => {
      const scrollProp = getScrollPropFromCurrentPage();
      const paginationProp = getScrollPropKeyForSide(side);
      state.lastLoadedPage = scrollProp.currentPage;
      state[paginationProp] = scrollProp[paginationProp];
      state.requestCount += 1;
      router.remember(
        {
          previousPage: state.previousPage,
          nextPage: state.nextPage,
          lastLoadedPage: state.lastLoadedPage,
          requestCount: state.requestCount
        },
        getRememberKey()
      );
    };
    const getPageName = () => getScrollPropFromCurrentPage().pageName;
    const getRequestCount = () => state.requestCount;
    const fetchPage = (side, reloadOptions = {}) => {
      const page2 = findPageToLoad(side);
      if (state.loading || page2 === null) {
        return;
      }
      state.loading = true;
      router.reload({
        ...reloadOptions,
        data: { [getPageName()]: page2 },
        only: [options.getPropName()],
        preserveUrl: true,
        // we handle URL updates manually via useInfiniteScrollQueryString()
        headers: {
          [MERGE_INTENT_HEADER]: side === "previous" ? "prepend" : "append",
          ...reloadOptions.headers
        },
        onBefore: (visit) => {
          side === "next" ? options.onBeforeNextRequest() : options.onBeforePreviousRequest();
          reloadOptions.onBefore?.(visit);
        },
        onBeforeUpdate: (page3) => {
          options.onBeforeUpdate();
          reloadOptions.onBeforeUpdate?.(page3);
        },
        onSuccess: (page3) => {
          syncStateOnSuccess(side);
          reloadOptions.onSuccess?.(page3);
        },
        onFinish: (visit) => {
          state.loading = false;
          const completed = visit.completed;
          const page3 = completed ? state.lastLoadedPage : null;
          side === "next" ? options.onCompleteNextRequest(page3, { page: page3, completed }) : options.onCompletePreviousRequest(page3, { page: page3, completed });
          reloadOptions.onFinish?.(visit);
        }
      });
    };
    const getLastLoadedPage = () => state.lastLoadedPage;
    const hasPrevious = () => !!state.previousPage;
    const hasNext = () => !!state.nextPage;
    const fetchPrevious = (reloadOptions) => fetchPage("previous", reloadOptions);
    const fetchNext = (reloadOptions) => fetchPage("next", reloadOptions);
    return {
      getLastLoadedPage,
      getPageName,
      getRequestCount,
      hasPrevious,
      hasNext,
      fetchNext,
      fetchPrevious,
      removeEventListener
    };
  };
  var useIntersectionObservers = () => {
    const intersectionObservers = [];
    const newIntersectionObserver = (callback, options = {}) => {
      const observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            callback(entry);
          }
        }
      }, options);
      intersectionObservers.push(observer);
      return observer;
    };
    const flushAll = () => {
      intersectionObservers.forEach((observer) => observer.disconnect());
      intersectionObservers.length = 0;
    };
    return {
      new: newIntersectionObserver,
      flushAll
    };
  };
  var INFINITE_SCROLL_PAGE_KEY = "infiniteScrollPage";
  var INFINITE_SCROLL_IGNORE_KEY = "infiniteScrollIgnore";
  var getPageFromElement = (element) => element.dataset[INFINITE_SCROLL_PAGE_KEY];
  var useInfiniteScrollElementManager = (options) => {
    const intersectionObservers = useIntersectionObservers();
    let itemsObserver;
    let startElementObserver;
    let endElementObserver;
    let itemsMutationObserver;
    let triggersEnabled = false;
    const setupObservers = () => {
      itemsMutationObserver = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType !== Node.ELEMENT_NODE) {
              return;
            }
            addedElements.add(node);
          });
        });
        rememberElementsDebounced();
      });
      itemsMutationObserver.observe(options.getItemsElement(), { childList: true });
      itemsObserver = intersectionObservers.new(
        (entry) => options.onItemIntersected(entry.target)
      );
      const observerOptions = {
        root: options.getScrollableParent(),
        rootMargin: `${Math.max(1, options.getTriggerMargin())}px`
      };
      startElementObserver = intersectionObservers.new(options.onPreviousTriggered, observerOptions);
      endElementObserver = intersectionObservers.new(options.onNextTriggered, observerOptions);
    };
    const enableTriggers = () => {
      if (triggersEnabled) {
        disableTriggers();
      }
      const startElement = options.getStartElement();
      const endElement = options.getEndElement();
      if (startElement && options.shouldFetchPrevious()) {
        startElementObserver.observe(startElement);
      }
      if (endElement && options.shouldFetchNext()) {
        endElementObserver.observe(endElement);
      }
      triggersEnabled = true;
    };
    const disableTriggers = () => {
      if (!triggersEnabled) {
        return;
      }
      startElementObserver.disconnect();
      endElementObserver.disconnect();
      triggersEnabled = false;
    };
    const refreshTriggers = () => {
      if (triggersEnabled) {
        enableTriggers();
      }
    };
    const flushAll = () => {
      disableTriggers();
      intersectionObservers.flushAll();
      itemsMutationObserver?.disconnect();
    };
    const addedElements = /* @__PURE__ */ new Set();
    const elementIsUntagged = (element) => !(INFINITE_SCROLL_PAGE_KEY in element.dataset) && !(INFINITE_SCROLL_IGNORE_KEY in element.dataset);
    const processManuallyAddedElements = () => {
      Array.from(addedElements).forEach((element) => {
        if (elementIsUntagged(element)) {
          element.dataset[INFINITE_SCROLL_IGNORE_KEY] = "true";
        }
        itemsObserver.observe(element);
      });
      addedElements.clear();
    };
    const findUntaggedElements = (containerElement) => {
      return Array.from(
        containerElement.querySelectorAll(
          `:scope > *:not([data-infinite-scroll-page]):not([data-infinite-scroll-ignore])`
        )
      );
    };
    let hasRestoredElements = false;
    const processServerLoadedElements = (loadedPage) => {
      if (!hasRestoredElements) {
        hasRestoredElements = true;
        if (restoreElements()) {
          return;
        }
      }
      findUntaggedElements(options.getItemsElement()).forEach((element) => {
        if (elementIsUntagged(element)) {
          element.dataset[INFINITE_SCROLL_PAGE_KEY] = loadedPage?.toString() || "1";
        }
        itemsObserver.observe(element);
      });
      rememberElements();
    };
    const getElementsRememberKey = () => `inertia:infinite-scroll-elements:${options.getPropName()}`;
    const rememberElements = () => {
      const pageElementRange = {};
      const childNodes = options.getItemsElement().childNodes;
      for (let index = 0; index < childNodes.length; index++) {
        const node = childNodes[index];
        if (node.nodeType !== Node.ELEMENT_NODE) {
          continue;
        }
        const page2 = getPageFromElement(node);
        if (typeof page2 === "undefined") {
          continue;
        }
        if (!(page2 in pageElementRange)) {
          pageElementRange[page2] = { from: index, to: index };
        } else {
          pageElementRange[page2].to = index;
        }
      }
      router.remember(pageElementRange, getElementsRememberKey());
    };
    const rememberElementsDebounced = debounce2(rememberElements, 250);
    const restoreElements = () => {
      const pageElementRange = router.restore(getElementsRememberKey());
      if (!pageElementRange || typeof pageElementRange !== "object") {
        return false;
      }
      const childNodes = options.getItemsElement().childNodes;
      for (let index = 0; index < childNodes.length; index++) {
        const node = childNodes[index];
        if (node.nodeType !== Node.ELEMENT_NODE) {
          continue;
        }
        const element = node;
        let elementPage;
        for (const [page2, range] of Object.entries(pageElementRange)) {
          if (index >= range.from && index <= range.to) {
            elementPage = page2;
            break;
          }
        }
        if (elementPage) {
          element.dataset[INFINITE_SCROLL_PAGE_KEY] = elementPage;
        } else if (!elementIsUntagged(element)) {
          continue;
        } else {
          element.dataset[INFINITE_SCROLL_IGNORE_KEY] = "true";
        }
        itemsObserver.observe(element);
      }
      return true;
    };
    return {
      setupObservers,
      enableTriggers,
      disableTriggers,
      refreshTriggers,
      flushAll,
      processManuallyAddedElements,
      processServerLoadedElements
    };
  };
  var queue3 = new Queue();
  var initialUrl;
  var payloadUrl;
  var initialUrlWasAbsolute = null;
  var useInfiniteScrollQueryString = (options) => {
    let enabled = true;
    const queuePageUpdate = (page2) => {
      queue3.add(() => {
        return new Promise((resolve) => {
          if (!enabled) {
            initialUrl = payloadUrl = null;
            return resolve();
          }
          if (!initialUrl || !payloadUrl) {
            const currentPageUrl = page.get().url;
            initialUrl = hrefToUrl(currentPageUrl);
            payloadUrl = hrefToUrl(currentPageUrl);
            initialUrlWasAbsolute = urlHasProtocol(currentPageUrl);
          }
          const pageName = options.getPageName();
          const searchParams = payloadUrl.searchParams;
          if (page2 === "1") {
            searchParams.delete(pageName);
          } else {
            searchParams.set(pageName, page2);
          }
          setTimeout(() => resolve());
        });
      }).finally(() => {
        if (enabled && initialUrl && payloadUrl && initialUrl.href !== payloadUrl.href && initialUrlWasAbsolute !== null) {
          router.replace({
            url: urlToString(payloadUrl, initialUrlWasAbsolute),
            preserveScroll: true,
            preserveState: true
          });
        }
        initialUrl = payloadUrl = initialUrlWasAbsolute = null;
      });
    };
    const onItemIntersected = debounce2((itemElement) => {
      const itemsElement = options.getItemsElement();
      if (!enabled || options.shouldPreserveUrl() || !itemElement || !itemsElement) {
        return;
      }
      const pageMap = /* @__PURE__ */ new Map();
      const elements = [...itemsElement.children];
      getElementsInViewportFromCollection(elements, itemElement).forEach((element) => {
        const page2 = getPageFromElement(element) ?? "1";
        if (pageMap.has(page2)) {
          pageMap.set(page2, pageMap.get(page2) + 1);
        } else {
          pageMap.set(page2, 1);
        }
      });
      const sortedPages = Array.from(pageMap.entries()).sort((a15, b8) => b8[1] - a15[1]);
      const mostVisiblePage = sortedPages[0]?.[0];
      if (mostVisiblePage !== void 0) {
        queuePageUpdate(mostVisiblePage);
      }
    }, 250);
    return {
      onItemIntersected,
      cancel: () => enabled = false
    };
  };
  var useInfiniteScrollPreservation = (options) => {
    const createCallbacks = () => {
      let currentScrollTop;
      let referenceElement = null;
      let referenceElementTop = 0;
      const captureScrollPosition = () => {
        const scrollableContainer = options.getScrollableParent();
        const itemsElement = options.getItemsElement();
        currentScrollTop = scrollableContainer?.scrollTop || window.scrollY;
        const visibleElements = getElementsInViewportFromCollection([...itemsElement.children]);
        if (visibleElements.length > 0) {
          referenceElement = visibleElements[0];
          const containerRect = scrollableContainer?.getBoundingClientRect() || { top: 0 };
          const containerTop = scrollableContainer ? containerRect.top : 0;
          const rect = referenceElement.getBoundingClientRect();
          referenceElementTop = rect.top - containerTop;
        }
      };
      const restoreScrollPosition = () => {
        if (!referenceElement) {
          return;
        }
        let attempts = 0;
        let restored = false;
        const restore = () => {
          attempts++;
          if (restored || attempts > 10) {
            return false;
          }
          const scrollableContainer = options.getScrollableParent();
          const containerRect = scrollableContainer?.getBoundingClientRect() || { top: 0 };
          const containerTop = scrollableContainer ? containerRect.top : 0;
          const newRect = referenceElement.getBoundingClientRect();
          const newElementTop = newRect.top - containerTop;
          const adjustment = newElementTop - referenceElementTop;
          if (adjustment === 0) {
            window.requestAnimationFrame(restore);
            return;
          }
          if (scrollableContainer) {
            scrollableContainer.scrollTo({ top: currentScrollTop + adjustment });
          } else {
            window.scrollTo(0, window.scrollY + adjustment);
          }
          restored = true;
        };
        window.requestAnimationFrame(restore);
      };
      return {
        captureScrollPosition,
        restoreScrollPosition
      };
    };
    return {
      createCallbacks
    };
  };
  function useInfiniteScroll(options) {
    const queryStringManager = useInfiniteScrollQueryString({ ...options, getPageName: () => dataManager.getPageName() });
    const scrollPreservation = useInfiniteScrollPreservation(options);
    const elementManager = useInfiniteScrollElementManager({
      ...options,
      // As items enter viewport, update URL to reflect the most visible page
      onItemIntersected: queryStringManager.onItemIntersected,
      onPreviousTriggered: () => dataManager.fetchPrevious(),
      onNextTriggered: () => dataManager.fetchNext()
    });
    const dataManager = useInfiniteScrollData({
      ...options,
      // Before updating page data, tag any manually added DOM elements
      // so they don't get confused with server-loaded content
      onBeforeUpdate: elementManager.processManuallyAddedElements,
      // After successful request, tag new server content
      onCompletePreviousRequest: (_4, details) => {
        options.onCompletePreviousRequest(details);
        if (details.completed) {
          requestAnimationFrame2(() => elementManager.processServerLoadedElements(details.page), 2);
        }
      },
      onCompleteNextRequest: (_4, details) => {
        options.onCompleteNextRequest(details);
        if (details.completed) {
          requestAnimationFrame2(() => elementManager.processServerLoadedElements(details.page), 2);
        }
      },
      onReset: options.onDataReset
    });
    const addScrollPreservationCallbacks = (reloadOptions) => {
      const { captureScrollPosition, restoreScrollPosition } = scrollPreservation.createCallbacks();
      const originalOnBeforeUpdate = reloadOptions.onBeforeUpdate || (() => {
      });
      const originalOnSuccess = reloadOptions.onSuccess || (() => {
      });
      reloadOptions.onBeforeUpdate = (page2) => {
        originalOnBeforeUpdate(page2);
        captureScrollPosition();
      };
      reloadOptions.onSuccess = (page2) => {
        originalOnSuccess(page2);
        restoreScrollPosition();
      };
      return reloadOptions;
    };
    const originalFetchNext = dataManager.fetchNext;
    dataManager.fetchNext = (reloadOptions = {}) => {
      if (options.inReverseMode()) {
        reloadOptions = addScrollPreservationCallbacks(reloadOptions);
      }
      originalFetchNext(reloadOptions);
    };
    const originalFetchPrevious = dataManager.fetchPrevious;
    dataManager.fetchPrevious = (reloadOptions = {}) => {
      if (!options.inReverseMode()) {
        reloadOptions = addScrollPreservationCallbacks(reloadOptions);
      }
      originalFetchPrevious(reloadOptions);
    };
    const removeEventListener = router.on("success", () => requestAnimationFrame2(elementManager.refreshTriggers, 2));
    return {
      dataManager,
      elementManager,
      flush: () => {
        removeEventListener();
        dataManager.removeEventListener();
        elementManager.flushAll();
        queryStringManager.cancel();
      }
    };
  }
  function isContentEditableOrPrevented(event) {
    return event.target instanceof HTMLElement && event.target.isContentEditable || event.defaultPrevented;
  }
  function shouldIntercept(event) {
    const isLink = event.currentTarget.tagName.toLowerCase() === "a";
    return !(isContentEditableOrPrevented(event) || isLink && event.altKey || isLink && event.ctrlKey || isLink && event.metaKey || isLink && event.shiftKey || isLink && "button" in event && event.button !== 0);
  }
  function shouldNavigate(event) {
    const isButton = event.currentTarget.tagName.toLowerCase() === "button";
    return !isContentEditableOrPrevented(event) && (event.key === "Enter" || isButton && event.key === " ");
  }
  var baseComponentSelector = "nprogress";
  var progress2;
  var settings = {
    minimum: 0.08,
    easing: "linear",
    positionUsing: "translate3d",
    speed: 200,
    trickle: true,
    trickleSpeed: 200,
    showSpinner: true,
    barSelector: '[role="bar"]',
    spinnerSelector: '[role="spinner"]',
    parent: "body",
    color: "#29d",
    includeCSS: true,
    template: [
      '<div class="bar" role="bar">',
      '<div class="peg"></div>',
      "</div>",
      '<div class="spinner" role="spinner">',
      '<div class="spinner-icon"></div>',
      "</div>"
    ].join("")
  };
  var status = null;
  var configure = (options) => {
    Object.assign(settings, options);
    if (settings.includeCSS) {
      injectCSS(settings.color);
    }
    progress2 = document.createElement("div");
    progress2.id = baseComponentSelector;
    progress2.innerHTML = settings.template;
  };
  var set5 = (n12) => {
    const started = isStarted();
    n12 = clamp(n12, settings.minimum, 1);
    status = n12 === 1 ? null : n12;
    const progress3 = render(!started);
    const bar = progress3.querySelector(settings.barSelector);
    const speed = settings.speed;
    const ease = settings.easing;
    progress3.offsetWidth;
    queue4((next) => {
      const barStyles = (() => {
        if (settings.positionUsing === "translate3d") {
          return {
            transition: `all ${speed}ms ${ease}`,
            transform: `translate3d(${toBarPercentage(n12)}%,0,0)`
          };
        }
        if (settings.positionUsing === "translate") {
          return {
            transition: `all ${speed}ms ${ease}`,
            transform: `translate(${toBarPercentage(n12)}%,0)`
          };
        }
        return { marginLeft: `${toBarPercentage(n12)}%` };
      })();
      for (const key in barStyles) {
        bar.style[key] = barStyles[key];
      }
      if (n12 !== 1) {
        return setTimeout(next, speed);
      }
      progress3.style.transition = "none";
      progress3.style.opacity = "1";
      progress3.offsetWidth;
      setTimeout(() => {
        progress3.style.transition = `all ${speed}ms linear`;
        progress3.style.opacity = "0";
        setTimeout(() => {
          remove();
          progress3.style.transition = "";
          progress3.style.opacity = "";
          next();
        }, speed);
      }, speed);
    });
  };
  var isStarted = () => typeof status === "number";
  var start = () => {
    if (!status) {
      set5(0);
    }
    const work = function() {
      setTimeout(function() {
        if (!status) {
          return;
        }
        increaseByRandom();
        work();
      }, settings.trickleSpeed);
    };
    if (settings.trickle) {
      work();
    }
  };
  var done = (force) => {
    if (!force && !status) {
      return;
    }
    increaseByRandom(0.3 + 0.5 * Math.random());
    set5(1);
  };
  var increaseByRandom = (amount) => {
    const n12 = status;
    if (n12 === null) {
      return start();
    }
    if (n12 > 1) {
      return;
    }
    amount = typeof amount === "number" ? amount : (() => {
      const ranges = {
        0.1: [0, 0.2],
        0.04: [0.2, 0.5],
        0.02: [0.5, 0.8],
        5e-3: [0.8, 0.99]
      };
      for (const r13 in ranges) {
        if (n12 >= ranges[r13][0] && n12 < ranges[r13][1]) {
          return parseFloat(r13);
        }
      }
      return 0;
    })();
    return set5(clamp(n12 + amount, 0, 0.994));
  };
  var render = (fromStart) => {
    if (isRendered()) {
      return document.getElementById(baseComponentSelector);
    }
    document.documentElement.classList.add(`${baseComponentSelector}-busy`);
    const bar = progress2.querySelector(settings.barSelector);
    const perc = fromStart ? "-100" : toBarPercentage(status || 0);
    const parent = getParent();
    bar.style.transition = "all 0 linear";
    bar.style.transform = `translate3d(${perc}%,0,0)`;
    if (!settings.showSpinner) {
      progress2.querySelector(settings.spinnerSelector)?.remove();
    }
    if (parent !== document.body) {
      parent.classList.add(`${baseComponentSelector}-custom-parent`);
    }
    parent.appendChild(progress2);
    return progress2;
  };
  var getParent = () => {
    return isDOM(settings.parent) ? settings.parent : document.querySelector(settings.parent);
  };
  var remove = () => {
    document.documentElement.classList.remove(`${baseComponentSelector}-busy`);
    getParent().classList.remove(`${baseComponentSelector}-custom-parent`);
    progress2?.remove();
  };
  var isRendered = () => {
    return document.getElementById(baseComponentSelector) !== null;
  };
  var isDOM = (obj) => {
    if (typeof HTMLElement === "object") {
      return obj instanceof HTMLElement;
    }
    return obj && typeof obj === "object" && obj.nodeType === 1 && typeof obj.nodeName === "string";
  };
  function clamp(n12, min, max) {
    if (n12 < min) {
      return min;
    }
    if (n12 > max) {
      return max;
    }
    return n12;
  }
  var toBarPercentage = (n12) => (-1 + n12) * 100;
  var queue4 = /* @__PURE__ */ (() => {
    const pending = [];
    const next = () => {
      const fn = pending.shift();
      if (fn) {
        fn(next);
      }
    };
    return (fn) => {
      pending.push(fn);
      if (pending.length === 1) {
        next();
      }
    };
  })();
  var injectCSS = (color) => {
    const element = document.createElement("style");
    element.textContent = `
    #${baseComponentSelector} {
      pointer-events: none;
    }

    #${baseComponentSelector} .bar {
      background: ${color};

      position: fixed;
      z-index: 1031;
      top: 0;
      left: 0;

      width: 100%;
      height: 2px;
    }

    #${baseComponentSelector} .peg {
      display: block;
      position: absolute;
      right: 0px;
      width: 100px;
      height: 100%;
      box-shadow: 0 0 10px ${color}, 0 0 5px ${color};
      opacity: 1.0;

      transform: rotate(3deg) translate(0px, -4px);
    }

    #${baseComponentSelector} .spinner {
      display: block;
      position: fixed;
      z-index: 1031;
      top: 15px;
      right: 15px;
    }

    #${baseComponentSelector} .spinner-icon {
      width: 18px;
      height: 18px;
      box-sizing: border-box;

      border: solid 2px transparent;
      border-top-color: ${color};
      border-left-color: ${color};
      border-radius: 50%;

      animation: ${baseComponentSelector}-spinner 400ms linear infinite;
    }

    .${baseComponentSelector}-custom-parent {
      overflow: hidden;
      position: relative;
    }

    .${baseComponentSelector}-custom-parent #${baseComponentSelector} .spinner,
    .${baseComponentSelector}-custom-parent #${baseComponentSelector} .bar {
      position: absolute;
    }

    @keyframes ${baseComponentSelector}-spinner {
      0%   { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;
    document.head.appendChild(element);
  };
  var show = () => {
    if (progress2) {
      progress2.style.display = "";
    }
  };
  var hide = () => {
    if (progress2) {
      progress2.style.display = "none";
    }
  };
  var progress_component_default = {
    configure,
    isStarted,
    done,
    set: set5,
    remove,
    start,
    status,
    show,
    hide
  };
  var Progress = class {
    constructor() {
      this.hideCount = 0;
    }
    start() {
      progress_component_default.start();
    }
    reveal(force = false) {
      this.hideCount = Math.max(0, this.hideCount - 1);
      if (force || this.hideCount === 0) {
        progress_component_default.show();
      }
    }
    hide() {
      this.hideCount++;
      progress_component_default.hide();
    }
    set(status2) {
      progress_component_default.set(Math.max(0, Math.min(1, status2)));
    }
    finish() {
      progress_component_default.done();
    }
    reset() {
      progress_component_default.set(0);
    }
    remove() {
      progress_component_default.done();
      progress_component_default.remove();
    }
    isStarted() {
      return progress_component_default.isStarted();
    }
    getStatus() {
      return progress_component_default.status;
    }
  };
  var progress = new Progress();
  var reveal = progress.reveal;
  var hide2 = progress.hide;
  var FormComponentResetSymbol = /* @__PURE__ */ Symbol("FormComponentReset");
  function isFormElement(element) {
    return element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement;
  }
  function resetInputElement(input, defaultValues) {
    const oldValue = input.value;
    const oldChecked = input.checked;
    switch (input.type.toLowerCase()) {
      case "checkbox":
        input.checked = defaultValues.includes(input.value);
        break;
      case "radio":
        input.checked = defaultValues[0] === input.value;
        break;
      case "file":
        input.value = "";
        break;
      case "button":
      case "submit":
      case "reset":
      case "image":
        break;
      default:
        input.value = defaultValues[0] !== null && defaultValues[0] !== void 0 ? String(defaultValues[0]) : "";
    }
    return input.value !== oldValue || input.checked !== oldChecked;
  }
  function resetSelectElement(select, defaultValues) {
    const oldValue = select.value;
    const oldSelectedOptions = Array.from(select.selectedOptions).map((opt) => opt.value);
    if (select.multiple) {
      const defaultStrings = defaultValues.map((value) => String(value));
      Array.from(select.options).forEach((option) => {
        option.selected = defaultStrings.includes(option.value);
      });
    } else {
      select.value = defaultValues[0] !== void 0 ? String(defaultValues[0]) : "";
    }
    const newSelectedOptions = Array.from(select.selectedOptions).map((opt) => opt.value);
    const hasChanged = select.multiple ? JSON.stringify(oldSelectedOptions.sort()) !== JSON.stringify(newSelectedOptions.sort()) : select.value !== oldValue;
    return hasChanged;
  }
  function resetFormElement(element, defaultValues) {
    if (element.disabled) {
      if (element instanceof HTMLInputElement) {
        const oldValue = element.value;
        const oldChecked = element.checked;
        switch (element.type.toLowerCase()) {
          case "checkbox":
          case "radio":
            element.checked = element.defaultChecked;
            return element.checked !== oldChecked;
          case "file":
            element.value = "";
            return oldValue !== "";
          case "button":
          case "submit":
          case "reset":
          case "image":
            return false;
          default:
            element.value = element.defaultValue;
            return element.value !== oldValue;
        }
      } else if (element instanceof HTMLSelectElement) {
        const oldSelectedOptions = Array.from(element.selectedOptions).map((opt) => opt.value);
        Array.from(element.options).forEach((option) => {
          option.selected = option.defaultSelected;
        });
        const newSelectedOptions = Array.from(element.selectedOptions).map((opt) => opt.value);
        return JSON.stringify(oldSelectedOptions.sort()) !== JSON.stringify(newSelectedOptions.sort());
      } else if (element instanceof HTMLTextAreaElement) {
        const oldValue = element.value;
        element.value = element.defaultValue;
        return element.value !== oldValue;
      }
      return false;
    }
    if (element instanceof HTMLInputElement) {
      return resetInputElement(element, defaultValues);
    } else if (element instanceof HTMLSelectElement) {
      return resetSelectElement(element, defaultValues);
    } else if (element instanceof HTMLTextAreaElement) {
      const oldValue = element.value;
      element.value = defaultValues[0] !== void 0 ? String(defaultValues[0]) : "";
      return element.value !== oldValue;
    }
    return false;
  }
  function resetFieldElements(elements, defaultValues) {
    let hasChanged = false;
    if (elements instanceof RadioNodeList || elements instanceof HTMLCollection) {
      Array.from(elements).forEach((node, index) => {
        if (node instanceof Element && isFormElement(node)) {
          if (node instanceof HTMLInputElement && ["checkbox", "radio"].includes(node.type.toLowerCase())) {
            if (resetFormElement(node, defaultValues)) {
              hasChanged = true;
            }
          } else {
            const indexedDefaultValues = defaultValues[index] !== void 0 ? [defaultValues[index]] : [defaultValues[0] ?? null].filter(Boolean);
            if (resetFormElement(node, indexedDefaultValues)) {
              hasChanged = true;
            }
          }
        }
      });
    } else if (isFormElement(elements)) {
      hasChanged = resetFormElement(elements, defaultValues);
    }
    return hasChanged;
  }
  function resetFormFields(formElement, defaults2, fieldNames) {
    if (!formElement) {
      return;
    }
    const resetEntireForm = !fieldNames || fieldNames.length === 0;
    if (resetEntireForm) {
      const formData = new FormData(formElement);
      const formElementNames = Array.from(formElement.elements).map((el) => isFormElement(el) ? el.name : "").filter(Boolean);
      fieldNames = [.../* @__PURE__ */ new Set([...defaults2.keys(), ...formData.keys(), ...formElementNames])];
    }
    let hasChanged = false;
    fieldNames.forEach((fieldName) => {
      const elements = formElement.elements.namedItem(fieldName);
      if (elements) {
        if (resetFieldElements(elements, defaults2.getAll(fieldName))) {
          hasChanged = true;
        }
      }
    });
    if (hasChanged && resetEntireForm) {
      formElement.dispatchEvent(
        new CustomEvent("reset", { bubbles: true, cancelable: true, detail: { [FormComponentResetSymbol]: true } })
      );
    }
  }
  var router = new Router();

  // node_modules/@inertiajs/react/dist/index.esm.js
  var import_react36 = __toESM(require_react_shim(), 1);
  var import_react_dom2 = __toESM(require_react_dom_shim(), 1);
  var import_react37 = __toESM(require_react_shim(), 1);
  var import_react38 = __toESM(require_react_shim(), 1);
  var import_react39 = __toESM(require_react_shim(), 1);
  var import_react40 = __toESM(require_react_shim(), 1);
  var import_react41 = __toESM(require_react_shim(), 1);
  var import_react42 = __toESM(require_react_shim(), 1);
  var import_react43 = __toESM(require_react_shim(), 1);

  // node_modules/laravel-precognition/dist/index.js
  init_define_import_meta_env();

  // node_modules/laravel-precognition/dist/client.js
  init_define_import_meta_env();
  var axiosClient = axios_default.create();
  var requestFingerprintResolver = (config3, axios2) => `${config3.method}:${config3.baseURL ?? axios2.defaults.baseURL ?? ""}${config3.url}`;
  var successResolver = (response) => response.status === 204 && response.headers["precognition-success"] === "true";
  var abortControllers = {};
  var client = {
    get: (url, data = {}, config3 = {}) => request(mergeConfig3("get", url, data, config3)),
    post: (url, data = {}, config3 = {}) => request(mergeConfig3("post", url, data, config3)),
    patch: (url, data = {}, config3 = {}) => request(mergeConfig3("patch", url, data, config3)),
    put: (url, data = {}, config3 = {}) => request(mergeConfig3("put", url, data, config3)),
    delete: (url, data = {}, config3 = {}) => request(mergeConfig3("delete", url, data, config3)),
    use(axios2) {
      axiosClient = axios2;
      return client;
    },
    axios() {
      return axiosClient;
    },
    fingerprintRequestsUsing(callback) {
      requestFingerprintResolver = callback === null ? () => null : callback;
      return client;
    },
    determineSuccessUsing(callback) {
      successResolver = callback;
      return client;
    }
  };
  var mergeConfig3 = (method, url, data, config3) => ({
    url,
    method,
    ...config3,
    ...["get", "delete"].includes(method) ? {
      params: merge_default({}, data, config3?.params)
    } : {
      data: merge_default({}, data, config3?.data)
    }
  });
  var request = (userConfig = {}) => {
    const config3 = [
      resolveConfig,
      abortMatchingRequests,
      refreshAbortController
    ].reduce((config4, callback) => callback(config4), userConfig);
    if ((config3.onBefore ?? (() => true))() === false) {
      return Promise.resolve(null);
    }
    (config3.onStart ?? (() => null))();
    return axiosClient.request(config3).then(async (response) => {
      if (config3.precognitive) {
        validatePrecognitionResponse(response);
      }
      const status2 = response.status;
      let payload = response;
      if (config3.precognitive && config3.onPrecognitionSuccess && successResolver(payload)) {
        payload = await Promise.resolve(config3.onPrecognitionSuccess(payload) ?? payload);
      }
      if (config3.onSuccess && isSuccess(status2)) {
        payload = await Promise.resolve(config3.onSuccess(payload) ?? payload);
      }
      const statusHandler = resolveStatusHandler(config3, status2) ?? ((response2) => response2);
      return statusHandler(payload) ?? payload;
    }, (error) => {
      if (isNotServerGeneratedError(error)) {
        return Promise.reject(error);
      }
      if (config3.precognitive) {
        validatePrecognitionResponse(error.response);
      }
      const statusHandler = resolveStatusHandler(config3, error.response.status) ?? ((_4, error2) => Promise.reject(error2));
      return statusHandler(error.response, error);
    }).finally(config3.onFinish ?? (() => null));
  };
  var resolveConfig = (config3) => {
    const only = config3.only ?? config3.validate;
    return {
      ...config3,
      timeout: config3.timeout ?? axiosClient.defaults["timeout"] ?? 3e4,
      precognitive: config3.precognitive !== false,
      fingerprint: typeof config3.fingerprint === "undefined" ? requestFingerprintResolver(config3, axiosClient) : config3.fingerprint,
      headers: {
        ...config3.headers,
        "Content-Type": resolveContentType(config3),
        ...config3.precognitive !== false ? {
          Precognition: true
        } : {},
        ...only ? {
          "Precognition-Validate-Only": Array.from(only).join()
        } : {}
      }
    };
  };
  var isSuccess = (status2) => status2 >= 200 && status2 < 300;
  var abortMatchingRequests = (config3) => {
    if (typeof config3.fingerprint !== "string") {
      return config3;
    }
    abortControllers[config3.fingerprint]?.abort();
    delete abortControllers[config3.fingerprint];
    return config3;
  };
  var refreshAbortController = (config3) => {
    if (typeof config3.fingerprint !== "string" || config3.signal || config3.cancelToken || !config3.precognitive) {
      return config3;
    }
    abortControllers[config3.fingerprint] = new AbortController();
    return {
      ...config3,
      signal: abortControllers[config3.fingerprint].signal
    };
  };
  var validatePrecognitionResponse = (response) => {
    if (response.headers?.precognition !== "true") {
      throw Error("Did not receive a Precognition response. Ensure you have the Precognition middleware in place for the route.");
    }
  };
  var isNotServerGeneratedError = (error) => {
    return !isAxiosError2(error) || typeof error.response?.status !== "number" || isCancel2(error);
  };
  var resolveStatusHandler = (config3, code) => ({
    401: config3.onUnauthorized,
    403: config3.onForbidden,
    404: config3.onNotFound,
    409: config3.onConflict,
    422: config3.onValidationError,
    423: config3.onLocked
  })[code];
  var resolveContentType = (config3) => config3.headers?.["Content-Type"] ?? config3.headers?.["Content-type"] ?? config3.headers?.["content-type"] ?? (hasFiles2(config3.data) ? "multipart/form-data" : "application/json");
  var hasFiles2 = (data) => isFile3(data) || typeof data === "object" && data !== null && Object.values(data).some((value) => hasFiles2(value));
  var isFile3 = (value) => typeof File !== "undefined" && value instanceof File || value instanceof Blob || typeof FileList !== "undefined" && value instanceof FileList && value.length > 0;

  // node_modules/laravel-precognition/dist/validator.js
  init_define_import_meta_env();
  var expandWildcardPaths = (pattern, data) => {
    if (!pattern.includes("*")) {
      return [pattern];
    }
    const parts = pattern.split(".");
    let paths = [""];
    for (const part of parts) {
      if (part === "*") {
        const expanded = [];
        for (const path of paths) {
          const value = path ? get_default(data, path) : data;
          if (Array.isArray(value)) {
            for (let index = 0; index < value.length; index++) {
              expanded.push(path ? `${path}.${index}` : String(index));
            }
          } else if (value !== null && typeof value === "object") {
            for (const key of Object.keys(value)) {
              expanded.push(path ? `${path}.${key}` : key);
            }
          }
        }
        paths = expanded;
      } else {
        paths = paths.map((path) => path ? `${path}.${part}` : part);
      }
    }
    return paths;
  };
  var keyMatchesPattern = (key, pattern) => {
    if (!pattern.includes("*")) {
      return key === pattern;
    }
    const regex = new RegExp("^" + pattern.replace(/\./g, "\\.").replace(/\*/g, "[^.]+") + "$");
    return regex.test(key);
  };
  var omitByPattern = (obj, patterns) => {
    return Object.fromEntries(Object.entries(obj).filter(([key]) => {
      return !patterns.some((pattern) => keyMatchesPattern(key, pattern));
    }));
  };
  var createValidator = (callback, initialData = {}) => {
    const listeners = {
      errorsChanged: [],
      touchedChanged: [],
      validatingChanged: [],
      validatedChanged: []
    };
    let validateFiles = false;
    let validating = false;
    const setValidating = (value) => {
      if (value !== validating) {
        validating = value;
        return listeners.validatingChanged;
      }
      return [];
    };
    let validated = [];
    const setValidated = (value) => {
      const uniqueNames = [...new Set(value)];
      if (validated.length !== uniqueNames.length || !uniqueNames.every((name) => validated.includes(name))) {
        validated = uniqueNames;
        return listeners.validatedChanged;
      }
      return [];
    };
    const valid = () => validated.filter((name) => typeof errors[name] === "undefined");
    let touched = [];
    const setTouched = (value) => {
      const uniqueNames = [...new Set(value)];
      if (touched.length !== uniqueNames.length || !uniqueNames.every((name) => touched.includes(name))) {
        touched = uniqueNames;
        return listeners.touchedChanged;
      }
      return [];
    };
    let errors = {};
    const setErrors = (value) => {
      const prepared = toValidationErrors(value);
      if (!isEqual_default(errors, prepared)) {
        errors = prepared;
        return listeners.errorsChanged;
      }
      return [];
    };
    const forgetError = (name) => {
      const newErrors = { ...errors };
      delete newErrors[resolveName(name)];
      return setErrors(newErrors);
    };
    const hasErrors = () => Object.keys(errors).length > 0;
    let debounceTimeoutDuration = 1500;
    const setDebounceTimeout = (value) => {
      debounceTimeoutDuration = value;
      validator.cancel();
      validator = createValidator2();
    };
    let oldData = initialData;
    let validatingData = null;
    let oldTouched = [];
    let validatingTouched = null;
    const createValidator2 = () => debounce_default((instanceConfig) => {
      callback({
        get: (url, data = {}, globalConfig = {}) => client.get(url, parseData(data), resolveConfig2(globalConfig, instanceConfig, data)),
        post: (url, data = {}, globalConfig = {}) => client.post(url, parseData(data), resolveConfig2(globalConfig, instanceConfig, data)),
        patch: (url, data = {}, globalConfig = {}) => client.patch(url, parseData(data), resolveConfig2(globalConfig, instanceConfig, data)),
        put: (url, data = {}, globalConfig = {}) => client.put(url, parseData(data), resolveConfig2(globalConfig, instanceConfig, data)),
        delete: (url, data = {}, globalConfig = {}) => client.delete(url, parseData(data), resolveConfig2(globalConfig, instanceConfig, data))
      }).catch((error) => {
        if (isCancel2(error)) {
          return null;
        }
        if (isAxiosError2(error) && error.response?.status === 422) {
          return null;
        }
        return Promise.reject(error);
      });
    }, debounceTimeoutDuration, { leading: true, trailing: true });
    let validator = createValidator2();
    const resolveConfig2 = (globalConfig, instanceConfig, data = {}) => {
      const config3 = {
        ...globalConfig,
        ...instanceConfig
      };
      const only = Array.from(config3.only ?? config3.validate ?? touched);
      return {
        ...instanceConfig,
        // Axios has special rules for merging global and local config. We
        // use their merge function here to make sure things like headers
        // merge in an expected way.
        ...mergeConfig2(globalConfig, instanceConfig),
        only,
        timeout: config3.timeout ?? 5e3,
        onValidationError: (response, axiosError) => {
          [
            ...setValidated([...validated, ...only]),
            ...setErrors(merge_default(omitByPattern({ ...errors }, only), response.data.errors))
          ].forEach((listener) => listener());
          return config3.onValidationError ? config3.onValidationError(response, axiosError) : Promise.reject(axiosError);
        },
        onSuccess: (response) => {
          setValidated([...validated, ...only]).forEach((listener) => listener());
          return config3.onSuccess ? config3.onSuccess(response) : response;
        },
        onPrecognitionSuccess: (response) => {
          [
            ...setValidated([...validated, ...only]),
            ...setErrors(omitByPattern({ ...errors }, only))
          ].forEach((listener) => listener());
          return config3.onPrecognitionSuccess ? config3.onPrecognitionSuccess(response) : response;
        },
        onBefore: () => {
          const hasWildcards = touched.some((name) => name.includes("*"));
          const expandedTouched = hasWildcards ? [...new Set(touched.flatMap((name) => expandWildcardPaths(name, data)))] : touched;
          if (config3.onBeforeValidation && config3.onBeforeValidation({ data, touched: expandedTouched }, { data: oldData, touched: oldTouched }) === false) {
            return false;
          }
          const beforeResult = (config3.onBefore || (() => true))();
          if (beforeResult === false) {
            return false;
          }
          if (hasWildcards) {
            setTouched(expandedTouched).forEach((listener) => listener());
          }
          validatingTouched = touched;
          validatingData = data;
          return true;
        },
        onStart: () => {
          setValidating(true).forEach((listener) => listener());
          (config3.onStart ?? (() => null))();
        },
        onFinish: () => {
          setValidating(false).forEach((listener) => listener());
          oldTouched = validatingTouched;
          oldData = validatingData;
          validatingTouched = validatingData = null;
          (config3.onFinish ?? (() => null))();
        }
      };
    };
    const validate = (name, value, config3) => {
      if (typeof name === "undefined") {
        const only = Array.from(config3?.only ?? config3?.validate ?? []);
        setTouched([...touched, ...only]).forEach((listener) => listener());
        validator(config3 ?? {});
        return;
      }
      if (isFile3(value) && !validateFiles) {
        console.warn('Precognition file validation is not active. Call the "validateFiles" function on your form to enable it.');
        return;
      }
      name = resolveName(name);
      if (name.includes("*") || get_default(oldData, name) !== value) {
        setTouched([name, ...touched]).forEach((listener) => listener());
        validator(config3 ?? {});
      }
    };
    const parseData = (data) => validateFiles === false ? forgetFiles(data) : data;
    const form = {
      touched: () => touched,
      validate(name, value, config3) {
        if (typeof name === "object" && !("target" in name)) {
          config3 = name;
          name = value = void 0;
        }
        validate(name, value, config3);
        return form;
      },
      touch(input) {
        const inputs = Array.isArray(input) ? input : [resolveName(input)];
        setTouched([...touched, ...inputs]).forEach((listener) => listener());
        return form;
      },
      validating: () => validating,
      valid,
      errors: () => errors,
      hasErrors,
      setErrors(value) {
        setErrors(value).forEach((listener) => listener());
        return form;
      },
      forgetError(name) {
        forgetError(name).forEach((listener) => listener());
        return form;
      },
      defaults(data) {
        initialData = data;
        oldData = data;
        return form;
      },
      reset(...names) {
        if (names.length === 0) {
          setTouched([]).forEach((listener) => listener());
        } else {
          const newTouched = [...touched];
          names.forEach((name) => {
            if (newTouched.includes(name)) {
              newTouched.splice(newTouched.indexOf(name), 1);
            }
            set_default(oldData, name, get_default(initialData, name));
          });
          setTouched(newTouched).forEach((listener) => listener());
        }
        return form;
      },
      setTimeout(value) {
        setDebounceTimeout(value);
        return form;
      },
      on(event, callback2) {
        listeners[event].push(callback2);
        return form;
      },
      validateFiles() {
        validateFiles = true;
        return form;
      },
      withoutFileValidation() {
        validateFiles = false;
        return form;
      }
    };
    return form;
  };
  var toSimpleValidationErrors = (errors) => {
    return Object.keys(errors).reduce((carry, key) => ({
      ...carry,
      [key]: Array.isArray(errors[key]) ? errors[key][0] : errors[key]
    }), {});
  };
  var toValidationErrors = (errors) => {
    return Object.keys(errors).reduce((carry, key) => ({
      ...carry,
      [key]: typeof errors[key] === "string" ? [errors[key]] : errors[key]
    }), {});
  };
  var resolveName = (name) => {
    return typeof name !== "string" ? name.target.name : name;
  };
  var forgetFiles = (data) => {
    const newData = { ...data };
    Object.keys(newData).forEach((name) => {
      const value = newData[name];
      if (value === null) {
        return;
      }
      if (isFile3(value)) {
        delete newData[name];
        return;
      }
      if (Array.isArray(value)) {
        newData[name] = Object.values(forgetFiles({ ...value }));
        return;
      }
      if (typeof value === "object") {
        newData[name] = forgetFiles(newData[name]);
        return;
      }
    });
    return newData;
  };

  // node_modules/laravel-precognition/dist/types.js
  init_define_import_meta_env();

  // node_modules/@inertiajs/react/dist/index.esm.js
  var import_react44 = __toESM(require_react_shim(), 1);
  var import_react45 = __toESM(require_react_shim(), 1);
  var import_react46 = __toESM(require_react_shim(), 1);
  var import_react47 = __toESM(require_react_shim(), 1);
  var import_react48 = __toESM(require_react_shim(), 1);
  var import_react49 = __toESM(require_react_shim(), 1);
  var import_react50 = __toESM(require_react_shim(), 1);
  var import_react51 = __toESM(require_react_shim(), 1);
  var headContext = (0, import_react37.createContext)(null);
  headContext.displayName = "InertiaHeadContext";
  var HeadContext_default = headContext;
  var pageContext = (0, import_react38.createContext)(null);
  pageContext.displayName = "InertiaPageContext";
  var PageContext_default = pageContext;
  var currentIsInitialPage = true;
  var routerIsInitialized = false;
  var swapComponent = async () => {
    currentIsInitialPage = false;
  };
  function App({
    children,
    initialPage,
    initialComponent,
    resolveComponent,
    titleCallback,
    onHeadUpdate
  }) {
    const [current, setCurrent] = (0, import_react36.useState)({
      component: initialComponent || null,
      page: { ...initialPage, flash: initialPage.flash ?? {} },
      key: null
    });
    const headManager = (0, import_react36.useMemo)(() => {
      return createHeadManager(
        typeof window === "undefined",
        titleCallback || ((title) => title),
        onHeadUpdate || (() => {
        })
      );
    }, []);
    if (!routerIsInitialized) {
      router.init({
        initialPage,
        resolveComponent,
        swapComponent: async (args) => swapComponent(args),
        onFlash: (flash) => {
          setCurrent((current2) => ({
            ...current2,
            page: { ...current2.page, flash }
          }));
        }
      });
      routerIsInitialized = true;
    }
    (0, import_react36.useEffect)(() => {
      swapComponent = async ({ component, page: page2, preserveState }) => {
        if (currentIsInitialPage) {
          currentIsInitialPage = false;
          return;
        }
        (0, import_react_dom2.flushSync)(
          () => setCurrent((current2) => ({
            component,
            page: page2,
            key: preserveState ? current2.key : Date.now()
          }))
        );
      };
      router.on("navigate", () => headManager.forceUpdate());
    }, []);
    if (!current.component) {
      return (0, import_react36.createElement)(
        HeadContext_default.Provider,
        { value: headManager },
        (0, import_react36.createElement)(PageContext_default.Provider, { value: current.page }, null)
      );
    }
    const renderChildren = children || (({ Component, props, key }) => {
      const child = (0, import_react36.createElement)(Component, { key, ...props });
      if (typeof Component.layout === "function") {
        return Component.layout(child);
      }
      if (Array.isArray(Component.layout)) {
        return Component.layout.concat(child).reverse().reduce((children2, Layout) => (0, import_react36.createElement)(Layout, { children: children2, ...props }));
      }
      return child;
    });
    return (0, import_react36.createElement)(
      HeadContext_default.Provider,
      { value: headManager },
      (0, import_react36.createElement)(
        PageContext_default.Provider,
        { value: current.page },
        renderChildren({
          Component: current.component,
          key: current.key,
          props: current.page.props
        })
      )
    );
  }
  App.displayName = "Inertia";
  var isReact19 = typeof import_react42.default.use === "function";
  function usePage() {
    const page2 = isReact19 ? import_react41.default.use(PageContext_default) : import_react41.default.useContext(PageContext_default);
    if (!page2) {
      throw new Error("usePage must be used within the Inertia component");
    }
    return page2;
  }
  var urlWithoutHash2 = (url) => {
    url = new URL(url.href);
    url.hash = "";
    return url;
  };
  var isSameUrlWithoutHash2 = (url1, url2) => {
    return urlWithoutHash2(url1).href === urlWithoutHash2(url2).href;
  };
  var Deferred = ({ children, data, fallback }) => {
    if (!data) {
      throw new Error("`<Deferred>` requires a `data` prop to be a string or array of strings");
    }
    const [loaded, setLoaded] = (0, import_react40.useState)(false);
    const pageProps = usePage().props;
    const keys2 = (0, import_react40.useMemo)(() => Array.isArray(data) ? data : [data], [data]);
    (0, import_react40.useEffect)(() => {
      const removeListener = router3.on("start", (e6) => {
        const isPartialVisit = e6.detail.visit.only.length > 0 || e6.detail.visit.except.length > 0;
        const isReloadingKey = e6.detail.visit.only.find((key) => keys2.includes(key));
        if (isSameUrlWithoutHash2(e6.detail.visit.url, window.location) && (!isPartialVisit || isReloadingKey)) {
          setLoaded(false);
        }
      });
      return () => {
        removeListener();
      };
    }, []);
    (0, import_react40.useEffect)(() => {
      setLoaded(keys2.every((key) => pageProps[key] !== void 0));
    }, [pageProps, keys2]);
    const propsAreDefined = (0, import_react40.useMemo)(() => keys2.every((key) => pageProps[key] !== void 0), [keys2, pageProps]);
    if (loaded && propsAreDefined) {
      return typeof children === "function" ? children() : children;
    }
    return typeof fallback === "function" ? fallback() : fallback;
  };
  Deferred.displayName = "InertiaDeferred";
  function useRemember(initialState, key, excludeKeysRef) {
    const [state, setState] = (0, import_react45.useState)(() => {
      const restored = router.restore(key);
      return restored !== void 0 ? restored : initialState;
    });
    (0, import_react45.useEffect)(() => {
      const keys2 = excludeKeysRef?.current;
      if (keys2 && keys2.length > 0 && typeof state === "object" && state !== null) {
        const filtered = { ...state };
        keys2.forEach((k6) => delete filtered[k6]);
        router.remember(filtered, key);
      } else {
        router.remember(state, key);
      }
    }, [state, key]);
    return [state, setState];
  }
  function useForm(...args) {
    const isMounted = (0, import_react44.useRef)(false);
    const parsedArgs = UseFormUtils.parseUseFormArguments(...args);
    const { rememberKey, data: initialData } = parsedArgs;
    const precognitionEndpoint = (0, import_react44.useRef)(parsedArgs.precognitionEndpoint);
    const [defaults2, setDefaults] = (0, import_react44.useState)(
      typeof initialData === "function" ? cloneDeep_default(initialData()) : cloneDeep_default(initialData)
    );
    const cancelToken = (0, import_react44.useRef)(null);
    const recentlySuccessfulTimeoutId = (0, import_react44.useRef)(void 0);
    const excludeKeysRef = (0, import_react44.useRef)([]);
    const [data, setData] = rememberKey ? useRemember(defaults2, `${rememberKey}:data`, excludeKeysRef) : (0, import_react44.useState)(defaults2);
    const [errors, setErrors] = rememberKey ? useRemember({}, `${rememberKey}:errors`) : (0, import_react44.useState)({});
    const [hasErrors, setHasErrors] = (0, import_react44.useState)(false);
    const [processing, setProcessing] = (0, import_react44.useState)(false);
    const [progress22, setProgress] = (0, import_react44.useState)(null);
    const [wasSuccessful, setWasSuccessful] = (0, import_react44.useState)(false);
    const [recentlySuccessful, setRecentlySuccessful] = (0, import_react44.useState)(false);
    const transform = (0, import_react44.useRef)((data2) => data2);
    const isDirty = (0, import_react44.useMemo)(() => !isEqual_default(data, defaults2), [data, defaults2]);
    const validatorRef = (0, import_react44.useRef)(null);
    const [validating, setValidating] = (0, import_react44.useState)(false);
    const [touchedFields, setTouchedFields] = (0, import_react44.useState)([]);
    const [validFields, setValidFields] = (0, import_react44.useState)([]);
    const withAllErrors = (0, import_react44.useRef)(null);
    (0, import_react44.useEffect)(() => {
      isMounted.current = true;
      return () => {
        isMounted.current = false;
      };
    }, []);
    const setDefaultsCalledInOnSuccess = (0, import_react44.useRef)(false);
    const dataRef = (0, import_react44.useRef)(data);
    (0, import_react44.useEffect)(() => {
      dataRef.current = data;
    });
    const commitData = (0, import_react44.useCallback)(
      (next) => {
        dataRef.current = next;
        setData(next);
      },
      [setData]
    );
    const submit = (0, import_react44.useCallback)(
      (...args2) => {
        const { method, url, options } = UseFormUtils.parseSubmitArguments(args2, precognitionEndpoint.current);
        setDefaultsCalledInOnSuccess.current = false;
        const _options = {
          ...options,
          onCancelToken: (token) => {
            cancelToken.current = token;
            if (options.onCancelToken) {
              return options.onCancelToken(token);
            }
          },
          onBefore: (visit) => {
            setWasSuccessful(false);
            setRecentlySuccessful(false);
            clearTimeout(recentlySuccessfulTimeoutId.current);
            if (options.onBefore) {
              return options.onBefore(visit);
            }
          },
          onStart: (visit) => {
            setProcessing(true);
            if (options.onStart) {
              return options.onStart(visit);
            }
          },
          onProgress: (event) => {
            setProgress(event || null);
            if (options.onProgress) {
              return options.onProgress(event);
            }
          },
          onSuccess: async (page2) => {
            if (isMounted.current) {
              setProcessing(false);
              setProgress(null);
              setErrors({});
              setHasErrors(false);
              setWasSuccessful(true);
              setRecentlySuccessful(true);
              recentlySuccessfulTimeoutId.current = setTimeout(() => {
                if (isMounted.current) {
                  setRecentlySuccessful(false);
                }
              }, config2.get("form.recentlySuccessfulDuration"));
            }
            const onSuccess = options.onSuccess ? await options.onSuccess(page2) : null;
            if (isMounted.current && !setDefaultsCalledInOnSuccess.current) {
              setData((data2) => {
                setDefaults(cloneDeep_default(data2));
                return data2;
              });
            }
            return onSuccess;
          },
          onError: (errors2) => {
            if (isMounted.current) {
              setProcessing(false);
              setProgress(null);
              setErrors(errors2);
              setHasErrors(Object.keys(errors2).length > 0);
              validatorRef.current?.setErrors(errors2);
            }
            if (options.onError) {
              return options.onError(errors2);
            }
          },
          onCancel: () => {
            if (isMounted.current) {
              setProcessing(false);
              setProgress(null);
            }
            if (options.onCancel) {
              return options.onCancel();
            }
          },
          onFinish: (visit) => {
            if (isMounted.current) {
              setProcessing(false);
              setProgress(null);
            }
            cancelToken.current = null;
            if (options.onFinish) {
              return options.onFinish(visit);
            }
          }
        };
        const transformedData = transform.current(dataRef.current);
        if (method === "delete") {
          router.delete(url, { ..._options, data: transformedData });
        } else {
          router[method](url, transformedData, _options);
        }
      },
      [setErrors, transform]
    );
    const setDataFunction = (0, import_react44.useCallback)(
      (keyOrData, maybeValue) => {
        if (typeof keyOrData === "string") {
          commitData(set_default(cloneDeep_default(dataRef.current), keyOrData, maybeValue));
        } else if (typeof keyOrData === "function") {
          commitData(keyOrData(dataRef.current));
        } else {
          commitData(keyOrData);
        }
      },
      [commitData]
    );
    const setDefaultsFunction = (0, import_react44.useCallback)(
      (fieldOrFields, maybeValue) => {
        setDefaultsCalledInOnSuccess.current = true;
        let newDefaults = {};
        if (typeof fieldOrFields === "undefined") {
          newDefaults = { ...dataRef.current };
          setDefaults(dataRef.current);
        } else {
          setDefaults((defaults22) => {
            newDefaults = typeof fieldOrFields === "string" ? set_default(cloneDeep_default(defaults22), fieldOrFields, maybeValue) : Object.assign(cloneDeep_default(defaults22), fieldOrFields);
            return newDefaults;
          });
        }
        validatorRef.current?.defaults(newDefaults);
      },
      [setDefaults]
    );
    const reset = (0, import_react44.useCallback)(
      (...fields) => {
        if (fields.length === 0) {
          commitData(defaults2);
        } else {
          const next = fields.filter((key) => has_default(defaults2, key)).reduce(
            (carry, key) => {
              return set_default(carry, key, get_default(defaults2, key));
            },
            { ...dataRef.current }
          );
          commitData(next);
        }
        validatorRef.current?.reset(...fields);
      },
      [commitData, defaults2]
    );
    const setError = (0, import_react44.useCallback)(
      (fieldOrFields, maybeValue) => {
        setErrors((errors2) => {
          const newErrors = {
            ...errors2,
            ...typeof fieldOrFields === "string" ? { [fieldOrFields]: maybeValue } : fieldOrFields
          };
          setHasErrors(Object.keys(newErrors).length > 0);
          validatorRef.current?.setErrors(newErrors);
          return newErrors;
        });
      },
      [setErrors, setHasErrors]
    );
    const clearErrors = (0, import_react44.useCallback)(
      (...fields) => {
        setErrors((errors2) => {
          const newErrors = Object.keys(errors2).reduce(
            (carry, field) => ({
              ...carry,
              ...fields.length > 0 && !fields.includes(field) ? { [field]: errors2[field] } : {}
            }),
            {}
          );
          setHasErrors(Object.keys(newErrors).length > 0);
          if (validatorRef.current) {
            if (fields.length === 0) {
              validatorRef.current.setErrors({});
            } else {
              fields.forEach(validatorRef.current.forgetError);
            }
          }
          return newErrors;
        });
      },
      [setErrors, setHasErrors]
    );
    const resetAndClearErrors = (0, import_react44.useCallback)(
      (...fields) => {
        reset(...fields);
        clearErrors(...fields);
      },
      [reset, clearErrors]
    );
    const createSubmitMethod = (method) => (url, options = {}) => {
      submit(method, url, options);
    };
    const getMethod = (0, import_react44.useCallback)(createSubmitMethod("get"), [submit]);
    const post = (0, import_react44.useCallback)(createSubmitMethod("post"), [submit]);
    const put = (0, import_react44.useCallback)(createSubmitMethod("put"), [submit]);
    const patch = (0, import_react44.useCallback)(createSubmitMethod("patch"), [submit]);
    const deleteMethod = (0, import_react44.useCallback)(createSubmitMethod("delete"), [submit]);
    const cancel = (0, import_react44.useCallback)(() => {
      if (cancelToken.current) {
        cancelToken.current.cancel();
      }
    }, []);
    const transformFunction = (0, import_react44.useCallback)((callback) => {
      transform.current = callback;
    }, []);
    const form = {
      data,
      setData: setDataFunction,
      isDirty,
      errors,
      hasErrors,
      processing,
      progress: progress22,
      wasSuccessful,
      recentlySuccessful,
      transform: transformFunction,
      setDefaults: setDefaultsFunction,
      reset,
      setError,
      clearErrors,
      resetAndClearErrors,
      submit,
      get: getMethod,
      post,
      put,
      patch,
      delete: deleteMethod,
      cancel,
      dontRemember: (...keys2) => {
        excludeKeysRef.current = keys2;
        return form;
      }
    };
    const tap = (value, callback) => {
      callback(value);
      return value;
    };
    const valid = (0, import_react44.useCallback)(
      (field) => validFields.includes(field),
      [validFields]
    );
    const invalid = (0, import_react44.useCallback)((field) => field in errors, [errors]);
    const touched = (0, import_react44.useCallback)(
      (field) => typeof field === "string" ? touchedFields.includes(field) : touchedFields.length > 0,
      [touchedFields]
    );
    const validate = (field, config3) => {
      if (typeof field === "object" && !("target" in field)) {
        config3 = field;
        field = void 0;
      }
      if (field === void 0) {
        validatorRef.current.validate(config3);
      } else {
        const fieldName = resolveName(field);
        const currentData = dataRef.current;
        const transformedData = transform.current(currentData);
        validatorRef.current.validate(fieldName, get_default(transformedData, fieldName), config3);
      }
      return form;
    };
    const withPrecognition = (...args2) => {
      precognitionEndpoint.current = UseFormUtils.createWayfinderCallback(...args2);
      if (!validatorRef.current) {
        const validator = createValidator((client2) => {
          const { method, url } = precognitionEndpoint.current();
          const currentData = dataRef.current;
          const transformedData = transform.current(currentData);
          return client2[method](url, transformedData);
        }, cloneDeep_default(defaults2));
        validatorRef.current = validator;
        validator.on("validatingChanged", () => {
          setValidating(validator.validating());
        }).on("validatedChanged", () => {
          setValidFields(validator.valid());
        }).on("touchedChanged", () => {
          setTouchedFields(validator.touched());
        }).on("errorsChanged", () => {
          const validationErrors = withAllErrors.current ?? config2.get("form.withAllErrors") ? validator.errors() : toSimpleValidationErrors(validator.errors());
          setErrors(validationErrors);
          setHasErrors(Object.keys(validationErrors).length > 0);
          setValidFields(validator.valid());
        });
      }
      const precognitiveForm = Object.assign(form, {
        validating,
        validator: () => validatorRef.current,
        valid,
        invalid,
        touched,
        withoutFileValidation: () => tap(precognitiveForm, () => validatorRef.current?.withoutFileValidation()),
        touch: (field, ...fields) => {
          if (Array.isArray(field)) {
            validatorRef.current?.touch(field);
          } else if (typeof field === "string") {
            validatorRef.current?.touch([field, ...fields]);
          } else {
            validatorRef.current?.touch(field);
          }
          return precognitiveForm;
        },
        withAllErrors: () => tap(precognitiveForm, () => withAllErrors.current = true),
        setValidationTimeout: (duration) => tap(precognitiveForm, () => validatorRef.current?.setTimeout(duration)),
        validateFiles: () => tap(precognitiveForm, () => validatorRef.current?.validateFiles()),
        validate,
        setErrors: (errors2) => tap(precognitiveForm, () => form.setError(errors2)),
        forgetError: (field) => tap(
          precognitiveForm,
          () => form.clearErrors(resolveName(field))
        )
      });
      return precognitiveForm;
    };
    form.withPrecognition = withPrecognition;
    return precognitionEndpoint.current ? form.withPrecognition(precognitionEndpoint.current) : form;
  }
  var deferStateUpdate = (callback) => {
    typeof import_react43.default.startTransition === "function" ? import_react43.default.startTransition(callback) : setTimeout(callback, 0);
  };
  var noop2 = () => void 0;
  var FormContext = (0, import_react43.createContext)(void 0);
  var Form = (0, import_react43.forwardRef)(
    ({
      action = "",
      method = "get",
      headers = {},
      queryStringArrayFormat = "brackets",
      errorBag = null,
      showProgress = true,
      transform = (data) => data,
      options = {},
      onStart = noop2,
      onProgress = noop2,
      onFinish = noop2,
      onBefore = noop2,
      onCancel = noop2,
      onSuccess = noop2,
      onError = noop2,
      onCancelToken = noop2,
      onSubmitComplete = noop2,
      disableWhileProcessing = false,
      resetOnError = false,
      resetOnSuccess = false,
      setDefaultsOnSuccess = false,
      invalidateCacheTags = [],
      validateFiles = false,
      validationTimeout = 1500,
      withAllErrors = null,
      children,
      ...props
    }, ref) => {
      const getTransformedData = () => {
        const [_url, data] = getUrlAndData();
        return transform(data);
      };
      const form = useForm({}).withPrecognition(
        () => resolvedMethod,
        () => getUrlAndData()[0]
      ).setValidationTimeout(validationTimeout);
      if (validateFiles) {
        form.validateFiles();
      }
      if (withAllErrors ?? config.get("form.withAllErrors")) {
        form.withAllErrors();
      }
      form.transform(getTransformedData);
      const formElement = (0, import_react43.useRef)(void 0);
      const resolvedMethod = (0, import_react43.useMemo)(() => {
        return isUrlMethodPair(action) ? action.method : method.toLowerCase();
      }, [action, method]);
      const [isDirty, setIsDirty] = (0, import_react43.useState)(false);
      const defaultData = (0, import_react43.useRef)(new FormData());
      const getFormData = (submitter) => new FormData(formElement.current, submitter);
      const getData = (submitter) => formDataToObject(getFormData(submitter));
      const getUrlAndData = (submitter) => {
        return mergeDataIntoQueryString(
          resolvedMethod,
          isUrlMethodPair(action) ? action.url : action,
          getData(submitter),
          queryStringArrayFormat
        );
      };
      const updateDirtyState = (event) => {
        if (event.type === "reset" && event.detail?.[FormComponentResetSymbol]) {
          event.preventDefault();
        }
        deferStateUpdate(
          () => setIsDirty(event.type === "reset" ? false : !isEqual_default(getData(), formDataToObject(defaultData.current)))
        );
      };
      const clearErrors = (...names) => {
        form.clearErrors(...names);
        return form;
      };
      (0, import_react43.useEffect)(() => {
        defaultData.current = getFormData();
        form.setDefaults(getData());
        const formEvents = ["input", "change", "reset"];
        formEvents.forEach((e6) => formElement.current.addEventListener(e6, updateDirtyState));
        return () => {
          formEvents.forEach((e6) => formElement.current?.removeEventListener(e6, updateDirtyState));
        };
      }, []);
      (0, import_react43.useEffect)(() => {
        form.setValidationTimeout(validationTimeout);
      }, [validationTimeout]);
      (0, import_react43.useEffect)(() => {
        if (validateFiles) {
          form.validateFiles();
        } else {
          form.withoutFileValidation();
        }
      }, [validateFiles]);
      const reset = (...fields) => {
        if (formElement.current) {
          resetFormFields(formElement.current, defaultData.current, fields);
        }
        form.reset(...fields);
      };
      const resetAndClearErrors = (...fields) => {
        clearErrors(...fields);
        reset(...fields);
      };
      const maybeReset = (resetOption) => {
        if (!resetOption) {
          return;
        }
        if (resetOption === true) {
          reset();
        } else if (resetOption.length > 0) {
          reset(...resetOption);
        }
      };
      const submit = (submitter) => {
        const [url, data] = getUrlAndData(submitter);
        const formTarget = submitter?.getAttribute("formtarget");
        if (formTarget === "_blank" && resolvedMethod === "get") {
          window.open(url, "_blank");
          return;
        }
        const submitOptions = {
          headers,
          queryStringArrayFormat,
          errorBag,
          showProgress,
          invalidateCacheTags,
          onCancelToken,
          onBefore,
          onStart,
          onProgress,
          onFinish,
          onCancel,
          onSuccess: (...args) => {
            onSuccess(...args);
            onSubmitComplete({
              reset,
              defaults: defaults2
            });
            maybeReset(resetOnSuccess);
            if (setDefaultsOnSuccess === true) {
              defaults2();
            }
          },
          onError(...args) {
            onError(...args);
            maybeReset(resetOnError);
          },
          ...options
        };
        form.transform(() => transform(data));
        form.submit(resolvedMethod, url, submitOptions);
        form.transform(getTransformedData);
      };
      const defaults2 = () => {
        defaultData.current = getFormData();
        setIsDirty(false);
      };
      const exposed = {
        errors: form.errors,
        hasErrors: form.hasErrors,
        processing: form.processing,
        progress: form.progress,
        wasSuccessful: form.wasSuccessful,
        recentlySuccessful: form.recentlySuccessful,
        isDirty,
        clearErrors,
        resetAndClearErrors,
        setError: form.setError,
        reset,
        submit,
        defaults: defaults2,
        getData,
        getFormData,
        // Precognition
        validator: () => form.validator(),
        validating: form.validating,
        valid: form.valid,
        invalid: form.invalid,
        validate: (field, config3) => form.validate(...UseFormUtils.mergeHeadersForValidation(field, config3, headers)),
        touch: form.touch,
        touched: form.touched
      };
      (0, import_react43.useImperativeHandle)(ref, () => exposed, [form, isDirty, submit]);
      const formNode = (0, import_react43.createElement)(
        "form",
        {
          ...props,
          ref: formElement,
          action: isUrlMethodPair(action) ? action.url : action,
          method: resolvedMethod,
          onSubmit: (event) => {
            event.preventDefault();
            submit(event.nativeEvent.submitter);
          },
          // React 19 supports passing a boolean to the `inert` attribute, but shows
          // a warning when receiving a string. Earlier versions require the string 'true'.
          // See: https://github.com/inertiajs/inertia/pull/2536
          inert: disableWhileProcessing && form.processing && (isReact19 ? true : "true")
        },
        typeof children === "function" ? children(exposed) : children
      );
      return (0, import_react43.createElement)(FormContext.Provider, { value: exposed }, formNode);
    }
  );
  Form.displayName = "InertiaForm";
  var resolveHTMLElement = (value, fallback) => {
    if (!value) {
      return fallback;
    }
    if (value && typeof value === "object" && "current" in value) {
      return value.current;
    }
    if (typeof value === "string") {
      return document.querySelector(value);
    }
    return fallback;
  };
  var renderSlot = (slotContent, slotProps, fallback = null) => {
    if (!slotContent) {
      return fallback;
    }
    return typeof slotContent === "function" ? slotContent(slotProps) : slotContent;
  };
  var InfiniteScroll = (0, import_react47.forwardRef)(
    ({
      data,
      buffer = 0,
      as = "div",
      manual = false,
      manualAfter = 0,
      preserveUrl = false,
      reverse = false,
      autoScroll,
      children,
      startElement,
      endElement,
      itemsElement,
      previous,
      next,
      loading,
      onlyNext = false,
      onlyPrevious = false,
      ...props
    }, ref) => {
      const [startElementFromRef, setStartElementFromRef] = (0, import_react47.useState)(null);
      const startElementRef = (0, import_react47.useCallback)((node) => setStartElementFromRef(node), []);
      const [endElementFromRef, setEndElementFromRef] = (0, import_react47.useState)(null);
      const endElementRef = (0, import_react47.useCallback)((node) => setEndElementFromRef(node), []);
      const [itemsElementFromRef, setItemsElementFromRef] = (0, import_react47.useState)(null);
      const itemsElementRef = (0, import_react47.useCallback)((node) => setItemsElementFromRef(node), []);
      const scrollProp = usePage().scrollProps?.[data];
      const [loadingPrevious, setLoadingPrevious] = (0, import_react47.useState)(false);
      const [loadingNext, setLoadingNext] = (0, import_react47.useState)(false);
      const [requestCount, setRequestCount] = (0, import_react47.useState)(0);
      const [hasPreviousPage, setHasPreviousPage] = (0, import_react47.useState)(!!scrollProp?.previousPage);
      const [hasNextPage, setHasNextPage] = (0, import_react47.useState)(!!scrollProp?.nextPage);
      const [resolvedStartElement, setResolvedStartElement] = (0, import_react47.useState)(null);
      const [resolvedEndElement, setResolvedEndElement] = (0, import_react47.useState)(null);
      const [resolvedItemsElement, setResolvedItemsElement] = (0, import_react47.useState)(null);
      (0, import_react47.useEffect)(() => {
        const element = startElement ? resolveHTMLElement(startElement, startElementFromRef) : startElementFromRef;
        setResolvedStartElement(element);
      }, [startElement, startElementFromRef]);
      (0, import_react47.useEffect)(() => {
        const element = endElement ? resolveHTMLElement(endElement, endElementFromRef) : endElementFromRef;
        setResolvedEndElement(element);
      }, [endElement, endElementFromRef]);
      (0, import_react47.useEffect)(() => {
        const element = itemsElement ? resolveHTMLElement(itemsElement, itemsElementFromRef) : itemsElementFromRef;
        setResolvedItemsElement(element);
      }, [itemsElement, itemsElementFromRef]);
      const scrollableParent = (0, import_react47.useMemo)(() => getScrollableParent(resolvedItemsElement), [resolvedItemsElement]);
      const callbackPropsRef = (0, import_react47.useRef)({
        buffer,
        onlyNext,
        onlyPrevious,
        reverse,
        preserveUrl
      });
      callbackPropsRef.current = {
        buffer,
        onlyNext,
        onlyPrevious,
        reverse,
        preserveUrl
      };
      const [infiniteScroll, setInfiniteScroll] = (0, import_react47.useState)(null);
      const dataManager = (0, import_react47.useMemo)(() => infiniteScroll?.dataManager, [infiniteScroll]);
      const elementManager = (0, import_react47.useMemo)(() => infiniteScroll?.elementManager, [infiniteScroll]);
      const scrollToBottom = (0, import_react47.useCallback)(() => {
        if (scrollableParent) {
          scrollableParent.scrollTo({
            top: scrollableParent.scrollHeight,
            behavior: "instant"
          });
        } else {
          window.scrollTo({
            top: document.body.scrollHeight,
            behavior: "instant"
          });
        }
      }, [scrollableParent]);
      (0, import_react47.useEffect)(() => {
        if (!resolvedItemsElement) {
          return;
        }
        function syncStateFromDataManager() {
          setRequestCount(infiniteScrollInstance.dataManager.getRequestCount());
          setHasPreviousPage(infiniteScrollInstance.dataManager.hasPrevious());
          setHasNextPage(infiniteScrollInstance.dataManager.hasNext());
        }
        const infiniteScrollInstance = useInfiniteScroll({
          // Data
          getPropName: () => data,
          inReverseMode: () => callbackPropsRef.current.reverse,
          shouldFetchNext: () => !callbackPropsRef.current.onlyPrevious,
          shouldFetchPrevious: () => !callbackPropsRef.current.onlyNext,
          shouldPreserveUrl: () => callbackPropsRef.current.preserveUrl,
          // Elements
          getTriggerMargin: () => callbackPropsRef.current.buffer,
          getStartElement: () => resolvedStartElement,
          getEndElement: () => resolvedEndElement,
          getItemsElement: () => resolvedItemsElement,
          getScrollableParent: () => scrollableParent,
          // Callbacks
          onBeforePreviousRequest: () => setLoadingPrevious(true),
          onBeforeNextRequest: () => setLoadingNext(true),
          onCompletePreviousRequest: ({ completed }) => {
            setLoadingPrevious(false);
            if (completed) {
              syncStateFromDataManager();
            }
          },
          onCompleteNextRequest: ({ completed }) => {
            setLoadingNext(false);
            if (completed) {
              syncStateFromDataManager();
            }
          },
          onDataReset: syncStateFromDataManager
        });
        setInfiniteScroll(infiniteScrollInstance);
        const { dataManager: dataManager2, elementManager: elementManager2 } = infiniteScrollInstance;
        syncStateFromDataManager();
        elementManager2.setupObservers();
        elementManager2.processServerLoadedElements(dataManager2.getLastLoadedPage());
        if (autoLoad) {
          elementManager2.enableTriggers();
        }
        return () => {
          infiniteScrollInstance.flush();
          setInfiniteScroll(null);
        };
      }, [data, resolvedItemsElement, resolvedStartElement, resolvedEndElement, scrollableParent]);
      const manualMode = (0, import_react47.useMemo)(
        () => manual || manualAfter > 0 && requestCount >= manualAfter,
        [manual, manualAfter, requestCount]
      );
      const autoLoad = (0, import_react47.useMemo)(() => !manualMode, [manualMode]);
      (0, import_react47.useEffect)(() => {
        autoLoad ? elementManager?.enableTriggers() : elementManager?.disableTriggers();
      }, [autoLoad, onlyNext, onlyPrevious, resolvedStartElement, resolvedEndElement]);
      (0, import_react47.useEffect)(() => {
        const shouldAutoScroll = autoScroll !== void 0 ? autoScroll : reverse;
        if (shouldAutoScroll) {
          scrollToBottom();
        }
      }, [scrollableParent]);
      (0, import_react47.useImperativeHandle)(
        ref,
        () => ({
          fetchNext: dataManager?.fetchNext || (() => {
          }),
          fetchPrevious: dataManager?.fetchPrevious || (() => {
          }),
          hasPrevious: dataManager?.hasPrevious || (() => false),
          hasNext: dataManager?.hasNext || (() => false)
        }),
        [dataManager]
      );
      const headerAutoMode = autoLoad && !onlyNext;
      const footerAutoMode = autoLoad && !onlyPrevious;
      const sharedExposed = {
        loadingPrevious,
        loadingNext,
        hasPrevious: hasPreviousPage,
        hasNext: hasNextPage
      };
      const exposedPrevious = {
        loading: loadingPrevious,
        fetch: dataManager?.fetchPrevious ?? (() => {
        }),
        autoMode: headerAutoMode,
        manualMode: !headerAutoMode,
        hasMore: hasPreviousPage,
        ...sharedExposed
      };
      const exposedNext = {
        loading: loadingNext,
        fetch: dataManager?.fetchNext ?? (() => {
        }),
        autoMode: footerAutoMode,
        manualMode: !footerAutoMode,
        hasMore: hasNextPage,
        ...sharedExposed
      };
      const exposedSlot = {
        loading: loadingPrevious || loadingNext,
        loadingPrevious,
        loadingNext
      };
      const renderElements = [];
      if (!startElement) {
        renderElements.push(
          (0, import_react47.createElement)(
            "div",
            { ref: startElementRef },
            // Render previous slot or fallback to loading indicator
            renderSlot(previous, exposedPrevious, loadingPrevious ? renderSlot(loading, exposedPrevious) : null)
          )
        );
      }
      renderElements.push(
        (0, import_react47.createElement)(
          as,
          { ...props, ref: itemsElementRef },
          typeof children === "function" ? children(exposedSlot) : children
        )
      );
      if (!endElement) {
        renderElements.push(
          (0, import_react47.createElement)(
            "div",
            { ref: endElementRef },
            // Render next slot or fallback to loading indicator
            renderSlot(next, exposedNext, loadingNext ? renderSlot(loading, exposedNext) : null)
          )
        );
      }
      return (0, import_react47.createElement)(import_react47.default.Fragment, {}, ...reverse ? [...renderElements].reverse() : renderElements);
    }
  );
  InfiniteScroll.displayName = "InertiaInfiniteScroll";
  var noop22 = () => void 0;
  var Link = (0, import_react48.forwardRef)(
    ({
      children,
      as = "a",
      data = {},
      href = "",
      method = "get",
      preserveScroll = false,
      preserveState = null,
      preserveUrl = false,
      replace = false,
      only = [],
      except = [],
      headers = {},
      queryStringArrayFormat = "brackets",
      async = false,
      onClick = noop22,
      onCancelToken = noop22,
      onBefore = noop22,
      onStart = noop22,
      onProgress = noop22,
      onFinish = noop22,
      onCancel = noop22,
      onSuccess = noop22,
      onError = noop22,
      onPrefetching = noop22,
      onPrefetched = noop22,
      prefetch = false,
      cacheFor = 0,
      cacheTags = [],
      viewTransition = false,
      ...props
    }, ref) => {
      const [inFlightCount, setInFlightCount] = (0, import_react48.useState)(0);
      const hoverTimeout = (0, import_react48.useRef)(void 0);
      const _method = (0, import_react48.useMemo)(() => {
        return isUrlMethodPair(href) ? href.method : method.toLowerCase();
      }, [href, method]);
      const _as = (0, import_react48.useMemo)(() => {
        if (typeof as !== "string" || as.toLowerCase() !== "a") {
          return as;
        }
        return _method !== "get" ? "button" : as.toLowerCase();
      }, [as, _method]);
      const mergeDataArray = (0, import_react48.useMemo)(
        () => mergeDataIntoQueryString(_method, isUrlMethodPair(href) ? href.url : href, data, queryStringArrayFormat),
        [href, _method, data, queryStringArrayFormat]
      );
      const url = (0, import_react48.useMemo)(() => mergeDataArray[0], [mergeDataArray]);
      const _data = (0, import_react48.useMemo)(() => mergeDataArray[1], [mergeDataArray]);
      const baseParams = (0, import_react48.useMemo)(
        () => ({
          data: _data,
          method: _method,
          preserveScroll,
          preserveState: preserveState ?? _method !== "get",
          preserveUrl,
          replace,
          only,
          except,
          headers,
          async
        }),
        [_data, _method, preserveScroll, preserveState, preserveUrl, replace, only, except, headers, async]
      );
      const visitParams = (0, import_react48.useMemo)(
        () => ({
          ...baseParams,
          viewTransition,
          onCancelToken,
          onBefore,
          onStart(visit) {
            setInFlightCount((count) => count + 1);
            onStart(visit);
          },
          onProgress,
          onFinish(visit) {
            setInFlightCount((count) => count - 1);
            onFinish(visit);
          },
          onCancel,
          onSuccess,
          onError
        }),
        [
          baseParams,
          viewTransition,
          onCancelToken,
          onBefore,
          onStart,
          onProgress,
          onFinish,
          onCancel,
          onSuccess,
          onError
        ]
      );
      const prefetchModes = (0, import_react48.useMemo)(
        () => {
          if (prefetch === true) {
            return ["hover"];
          }
          if (prefetch === false) {
            return [];
          }
          if (Array.isArray(prefetch)) {
            return prefetch;
          }
          return [prefetch];
        },
        Array.isArray(prefetch) ? prefetch : [prefetch]
      );
      const cacheForValue = (0, import_react48.useMemo)(() => {
        if (cacheFor !== 0) {
          return cacheFor;
        }
        if (prefetchModes.length === 1 && prefetchModes[0] === "click") {
          return 0;
        }
        return config2.get("prefetch.cacheFor");
      }, [cacheFor, prefetchModes]);
      const doPrefetch = (0, import_react48.useMemo)(() => {
        return () => {
          router.prefetch(
            url,
            {
              ...baseParams,
              onPrefetching,
              onPrefetched
            },
            { cacheFor: cacheForValue, cacheTags }
          );
        };
      }, [url, baseParams, onPrefetching, onPrefetched, cacheForValue, cacheTags]);
      (0, import_react48.useEffect)(() => {
        return () => {
          clearTimeout(hoverTimeout.current);
        };
      }, []);
      (0, import_react48.useEffect)(() => {
        if (prefetchModes.includes("mount")) {
          setTimeout(() => doPrefetch());
        }
      }, prefetchModes);
      const regularEvents = {
        onClick: (event) => {
          onClick(event);
          if (shouldIntercept(event)) {
            event.preventDefault();
            router.visit(url, visitParams);
          }
        }
      };
      const prefetchHoverEvents = {
        onMouseEnter: () => {
          hoverTimeout.current = window.setTimeout(() => {
            doPrefetch();
          }, config2.get("prefetch.hoverDelay"));
        },
        onMouseLeave: () => {
          clearTimeout(hoverTimeout.current);
        },
        onClick: regularEvents.onClick
      };
      const prefetchClickEvents = {
        onMouseDown: (event) => {
          if (shouldIntercept(event)) {
            event.preventDefault();
            doPrefetch();
          }
        },
        onKeyDown: (event) => {
          if (shouldNavigate(event)) {
            event.preventDefault();
            doPrefetch();
          }
        },
        onMouseUp: (event) => {
          if (shouldIntercept(event)) {
            event.preventDefault();
            router.visit(url, visitParams);
          }
        },
        onKeyUp: (event) => {
          if (shouldNavigate(event)) {
            event.preventDefault();
            router.visit(url, visitParams);
          }
        },
        onClick: (event) => {
          onClick(event);
          if (shouldIntercept(event)) {
            event.preventDefault();
          }
        }
      };
      const elProps = (0, import_react48.useMemo)(() => {
        if (_as === "button") {
          return { type: "button" };
        }
        if (_as === "a" || typeof _as !== "string") {
          return { href: url };
        }
        return {};
      }, [_as, url]);
      return (0, import_react48.createElement)(
        _as,
        {
          ...props,
          ...elProps,
          ref,
          ...(() => {
            if (prefetchModes.includes("hover")) {
              return prefetchHoverEvents;
            }
            if (prefetchModes.includes("click")) {
              return prefetchClickEvents;
            }
            return regularEvents;
          })(),
          "data-loading": inFlightCount > 0 ? "" : void 0
        },
        children
      );
    }
  );
  Link.displayName = "InertiaLink";
  var Link_default = Link;
  var WhenVisible = ({ children, data, params, buffer, as, always, fallback }) => {
    always = always ?? false;
    as = as ?? "div";
    fallback = fallback ?? null;
    const pageProps = usePage().props;
    const keys2 = (0, import_react51.useMemo)(() => data ? Array.isArray(data) ? data : [data] : [], [data]);
    const [loaded, setLoaded] = (0, import_react51.useState)(() => keys2.length > 0 && keys2.every((key) => pageProps[key] !== void 0));
    const [isFetching, setIsFetching] = (0, import_react51.useState)(false);
    const fetching = (0, import_react51.useRef)(false);
    const ref = (0, import_react51.useRef)(null);
    const observer = (0, import_react51.useRef)(null);
    const getReloadParamsRef = (0, import_react51.useRef)(() => ({}));
    (0, import_react51.useEffect)(() => {
      if (keys2.length > 0) {
        setLoaded(keys2.every((key) => pageProps[key] !== void 0));
      }
    }, [pageProps, keys2]);
    const getReloadParams = (0, import_react51.useCallback)(() => {
      const reloadParams = { ...params };
      if (data) {
        reloadParams.only = Array.isArray(data) ? data : [data];
      }
      return reloadParams;
    }, [params, data]);
    getReloadParamsRef.current = getReloadParams;
    const registerObserver = () => {
      observer.current?.disconnect();
      observer.current = new IntersectionObserver(
        (entries) => {
          if (!entries[0].isIntersecting) {
            return;
          }
          if (fetching.current) {
            return;
          }
          if (!always && loaded) {
            return;
          }
          fetching.current = true;
          setIsFetching(true);
          const reloadParams = getReloadParamsRef.current();
          router.reload({
            ...reloadParams,
            onStart: (e6) => {
              fetching.current = true;
              setIsFetching(true);
              reloadParams.onStart?.(e6);
            },
            onFinish: (e6) => {
              setLoaded(true);
              fetching.current = false;
              setIsFetching(false);
              reloadParams.onFinish?.(e6);
              if (!always) {
                observer.current?.disconnect();
              }
            }
          });
        },
        {
          rootMargin: `${buffer || 0}px`
        }
      );
      observer.current.observe(ref.current);
    };
    (0, import_react51.useEffect)(() => {
      if (!ref.current) {
        return;
      }
      if (loaded && !always) {
        return;
      }
      registerObserver();
      return () => {
        observer.current?.disconnect();
      };
    }, [always, loaded, buffer]);
    const resolveChildren = () => typeof children === "function" ? children({ fetching: isFetching }) : children;
    const resolveFallback = () => typeof fallback === "function" ? fallback() : fallback;
    if (always || !loaded) {
      return (0, import_react51.createElement)(
        as,
        {
          props: null,
          ref
        },
        loaded ? resolveChildren() : resolveFallback()
      );
    }
    return loaded ? resolveChildren() : null;
  };
  WhenVisible.displayName = "InertiaWhenVisible";
  var router3 = router;
  var config2 = config.extend();

  // resources/js/Components/Dropdown.tsx
  var import_react54 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime6 = __toESM(require_react_shim(), 1);
  var DropDownContext = (0, import_react54.createContext)({
    open: false,
    setOpen: () => {
    },
    toggleOpen: () => {
    }
  });
  var Dropdown = ({ children }) => {
    const [open, setOpen] = (0, import_react54.useState)(false);
    const toggleOpen = () => {
      setOpen((previousState) => !previousState);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(DropDownContext.Provider, { value: { open, setOpen, toggleOpen }, children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "relative", children }) });
  };
  var Trigger = ({ children }) => {
    const { open, setOpen, toggleOpen } = (0, import_react54.useContext)(DropDownContext);
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(import_jsx_runtime6.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { onClick: toggleOpen, children }),
      open && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
        "div",
        {
          className: "fixed inset-0 z-40",
          onClick: () => setOpen(false)
        }
      )
    ] });
  };
  var Content = ({
    align = "right",
    width = "48",
    contentClasses = "py-1 bg-white",
    children
  }) => {
    const { open, setOpen } = (0, import_react54.useContext)(DropDownContext);
    let alignmentClasses = "origin-top";
    if (align === "left") {
      alignmentClasses = "ltr:origin-top-left rtl:origin-top-right start-0";
    } else if (align === "right") {
      alignmentClasses = "ltr:origin-top-right rtl:origin-top-left end-0";
    }
    let widthClasses = "";
    if (width === "48") {
      widthClasses = "w-48";
    }
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_jsx_runtime6.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
      Ke,
      {
        show: open,
        enter: "transition ease-out duration-200",
        enterFrom: "opacity-0 scale-95",
        enterTo: "opacity-100 scale-100",
        leave: "transition ease-in duration-75",
        leaveFrom: "opacity-100 scale-100",
        leaveTo: "opacity-0 scale-95",
        children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          "div",
          {
            className: `absolute z-50 mt-2 rounded-md shadow-lg ${alignmentClasses} ${widthClasses}`,
            onClick: () => setOpen(false),
            children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
              "div",
              {
                className: `rounded-md ring-1 ring-black ring-opacity-5 ` + contentClasses,
                children
              }
            )
          }
        )
      }
    ) });
  };
  var DropdownLink = ({
    className = "",
    children,
    ...props
  }) => {
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
      Link_default,
      {
        ...props,
        className: "block w-full px-4 py-2 text-start text-sm leading-5 text-gray-700 transition duration-150 ease-in-out hover:bg-gray-100 focus:bg-gray-100 focus:outline-none " + className,
        children
      }
    );
  };
  Dropdown.Trigger = Trigger;
  Dropdown.Content = Content;
  Dropdown.Link = DropdownLink;
  var Dropdown_default = Dropdown;

  // resources/js/Components/InputError.tsx
  init_define_import_meta_env();
  var import_jsx_runtime7 = __toESM(require_react_shim(), 1);
  function InputError({
    message,
    className = "",
    ...props
  }) {
    return message ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
      "p",
      {
        ...props,
        className: "text-sm text-red-600 " + className,
        children: message
      }
    ) : null;
  }

  // resources/js/Components/InputLabel.tsx
  init_define_import_meta_env();
  var import_jsx_runtime8 = __toESM(require_react_shim(), 1);
  function InputLabel({
    value,
    className = "",
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
      "label",
      {
        ...props,
        className: `block text-sm font-medium text-gray-700 ` + className,
        children: value ? value : children
      }
    );
  }

  // resources/js/Components/Modal.tsx
  init_define_import_meta_env();
  var import_jsx_runtime9 = __toESM(require_react_shim(), 1);
  function Modal({
    children,
    show: show2 = false,
    maxWidth = "2xl",
    closeable = true,
    onClose = () => {
    }
  }) {
    const close = () => {
      if (closeable) {
        onClose();
      }
    };
    const maxWidthClass = {
      sm: "sm:max-w-sm",
      md: "sm:max-w-md",
      lg: "sm:max-w-lg",
      xl: "sm:max-w-xl",
      "2xl": "sm:max-w-2xl"
    }[maxWidth];
    return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Ke, { show: show2, leave: "duration-200", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(
      ht,
      {
        as: "div",
        id: "modal",
        className: "fixed inset-0 z-50 flex transform items-center overflow-y-auto px-4 py-6 transition-all sm:px-0",
        onClose: close,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
            Oe,
            {
              enter: "ease-out duration-300",
              enterFrom: "opacity-0",
              enterTo: "opacity-100",
              leave: "ease-in duration-200",
              leaveFrom: "opacity-100",
              leaveTo: "opacity-0",
              children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "absolute inset-0 bg-gray-500/75" })
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
            Oe,
            {
              enter: "ease-out duration-300",
              enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
              enterTo: "opacity-100 translate-y-0 sm:scale-100",
              leave: "ease-in duration-200",
              leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
              leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
              children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
                ze,
                {
                  className: `mb-6 transform overflow-hidden rounded-lg bg-white shadow-xl transition-all sm:mx-auto sm:w-full ${maxWidthClass}`,
                  children
                }
              )
            }
          )
        ]
      }
    ) });
  }

  // resources/js/Components/PrimaryButton.tsx
  init_define_import_meta_env();
  var import_jsx_runtime10 = __toESM(require_react_shim(), 1);
  function PrimaryButton({
    className = "",
    disabled,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
      "button",
      {
        ...props,
        className: `inline-flex items-center rounded-lg border border-transparent bg-gradient-to-br from-[#4f46e5] to-[#7c3aed] px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-[#4f46e5] focus:ring-offset-2 ${disabled ? "opacity-50 cursor-not-allowed" : ""} ` + className,
        disabled,
        children
      }
    );
  }

  // resources/js/Components/QRCodeDisplay.tsx
  init_define_import_meta_env();
  var import_react56 = __toESM(require_react_shim(), 1);
  var import_qrcode = __toESM(require_browser(), 1);
  var import_jsx_runtime11 = __toESM(require_react_shim(), 1);
  function QRCodeDisplay({ url, size = 128 }) {
    const canvasRef = (0, import_react56.useRef)(null);
    (0, import_react56.useEffect)(() => {
      if (!canvasRef.current || !url) return;
      import_qrcode.default.toCanvas(canvasRef.current, url, {
        width: size,
        margin: 1,
        color: { dark: "#0f0f1a", light: "#ffffff" }
      });
    }, [url, size]);
    const download = () => {
      if (!canvasRef.current) return;
      const link = document.createElement("a");
      link.download = "resume-qr-code.png";
      link.href = canvasRef.current.toDataURL("image/png");
      link.click();
    };
    return /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { className: "flex flex-col items-center gap-2", children: [
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("canvas", { ref: canvasRef, className: "rounded-lg border border-[#eeeef5]" }),
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(
        "button",
        {
          type: "button",
          onClick: download,
          className: "text-xs text-[#a0a0b0] hover:text-[#0f0f1a] underline",
          children: "Download QR Code"
        }
      )
    ] });
  }

  // resources/js/Components/SecondaryButton.tsx
  init_define_import_meta_env();
  var import_jsx_runtime12 = __toESM(require_react_shim(), 1);
  function SecondaryButton({
    className = "",
    disabled,
    children,
    ...props
  }) {
    return /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
      "button",
      {
        ...props,
        className: `inline-flex items-center rounded-lg border border-[#eeeef5] bg-white px-4 py-2 text-sm font-medium text-[#71717a] shadow-sm transition hover:bg-[#fafafe] focus:outline-none focus:ring-2 focus:ring-[#4f46e5] focus:ring-offset-2 ${disabled ? "opacity-50 cursor-not-allowed" : ""} ` + className,
        disabled,
        children
      }
    );
  }

  // resources/js/Components/SkillGroupEditor.tsx
  init_define_import_meta_env();
  var import_react58 = __toESM(require_react_shim(), 1);

  // resources/js/Components/TagInput.tsx
  init_define_import_meta_env();
  var import_react57 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime13 = __toESM(require_react_shim(), 1);
  function TagInput({ tags, onChange, onBlur, placeholder = "Add skill\u2026" }) {
    const [input, setInput] = (0, import_react57.useState)("");
    const inputRef = (0, import_react57.useRef)(null);
    const addTag = (raw) => {
      const trimmed = raw.trim().replace(/,+$/, "");
      if (!trimmed || tags.includes(trimmed)) {
        setInput("");
        return;
      }
      onChange([...tags, trimmed]);
      setInput("");
    };
    const handleKey = (e6) => {
      if (e6.key === "Enter" || e6.key === ",") {
        e6.preventDefault();
        addTag(input);
      } else if (e6.key === "Backspace" && input === "" && tags.length) {
        onChange(tags.slice(0, -1));
      }
    };
    const removeTag = (idx) => onChange(tags.filter((_4, i12) => i12 !== idx));
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(
      "div",
      {
        className: "flex flex-wrap gap-1.5 rounded-md border border-gray-300 bg-white px-2 py-1.5 shadow-sm focus-within:border-indigo-500 focus-within:ring-1 focus-within:ring-indigo-500 cursor-text",
        onClick: () => inputRef.current?.focus(),
        children: [
          tags.map((tag, i12) => /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("span", { className: "flex items-center gap-1 rounded-full bg-indigo-100 px-2 py-0.5 text-xs text-indigo-800", children: [
            tag,
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
              "button",
              {
                type: "button",
                onClick: (e6) => {
                  e6.stopPropagation();
                  removeTag(i12);
                },
                className: "text-indigo-400 hover:text-indigo-700 leading-none",
                children: "\xD7"
              }
            )
          ] }, i12)),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
            "input",
            {
              ref: inputRef,
              value: input,
              onChange: (e6) => setInput(e6.target.value),
              onKeyDown: handleKey,
              onBlur: () => {
                if (input.trim()) addTag(input);
                onBlur?.();
              },
              placeholder: tags.length ? "" : placeholder,
              className: "min-w-[120px] flex-1 border-none p-0 text-sm focus:ring-0 outline-none bg-transparent"
            }
          )
        ]
      }
    );
  }

  // resources/js/Components/SkillGroupEditor.tsx
  var import_jsx_runtime14 = __toESM(require_react_shim(), 1);
  function SkillGroupEditor({ groups, onChange, onBlur }) {
    const uid2 = (0, import_react58.useId)();
    const updateCategory = (idx, category) => {
      onChange(groups.map((g2, i12) => i12 === idx ? { ...g2, category } : g2));
    };
    const updateItems = (idx, items) => {
      onChange(groups.map((g2, i12) => i12 === idx ? { ...g2, items } : g2));
    };
    const addGroup = () => onChange([...groups, { category: "", items: [] }]);
    const removeGroup = (idx) => onChange(groups.filter((_4, i12) => i12 !== idx));
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "flex flex-col gap-3", children: [
      groups.map((group, idx) => /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "rounded-md border border-gray-200 bg-gray-50 p-3", children: [
        /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "mb-2 flex items-center gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
            "input",
            {
              type: "text",
              value: group.category,
              onChange: (e6) => updateCategory(idx, e6.target.value),
              onBlur,
              placeholder: "Category (e.g. Frontend)",
              className: "flex-1 rounded border border-gray-300 bg-white px-2 py-1 text-xs font-medium focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
            "button",
            {
              type: "button",
              onClick: () => removeGroup(idx),
              className: "text-gray-400 hover:text-red-500 text-xs leading-none",
              children: "\u2715"
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
          TagInput,
          {
            tags: group.items,
            onChange: (items) => updateItems(idx, items),
            onBlur,
            placeholder: "Add skill\u2026"
          }
        )
      ] }, `${uid2}-${idx}`)),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
        "button",
        {
          type: "button",
          onClick: addGroup,
          className: "rounded-md border border-dashed border-indigo-300 py-1.5 text-xs text-indigo-600 hover:border-indigo-500 hover:bg-indigo-50",
          children: "+ Add category"
        }
      )
    ] });
  }

  // resources/js/Components/SkillNarrativeEditor.tsx
  init_define_import_meta_env();
  var import_jsx_runtime15 = __toESM(require_react_shim(), 1);
  var uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  var emptyNarrative = () => ({
    id: uid(),
    name: "",
    bullets: [""]
  });
  function SkillNarrativeEditor({ narratives, onChange, onBlur }) {
    const updateName = (idx, name) => onChange(narratives.map((n12, i12) => i12 === idx ? { ...n12, name } : n12));
    const updateBullets = (idx, raw) => onChange(narratives.map((n12, i12) => i12 === idx ? { ...n12, bullets: raw.split("\n") } : n12));
    const remove2 = (idx) => onChange(narratives.filter((_4, i12) => i12 !== idx));
    const add = () => onChange([...narratives, emptyNarrative()]);
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "flex flex-col gap-3", children: [
      narratives.map((n12, idx) => /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "rounded-md border border-gray-200 bg-gray-50 p-3", children: [
        /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "mb-2 flex items-center gap-2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
            "input",
            {
              type: "text",
              value: n12.name,
              onChange: (e6) => updateName(idx, e6.target.value),
              onBlur,
              placeholder: "Skill name (e.g. Proactive Communication)",
              className: "flex-1 rounded border border-gray-300 bg-white px-2 py-1 text-xs font-semibold focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
            "button",
            {
              type: "button",
              onClick: () => remove2(idx),
              className: "text-gray-400 hover:text-red-500 text-xs leading-none",
              children: "\u2715"
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
          "textarea",
          {
            value: n12.bullets.join("\n"),
            onChange: (e6) => updateBullets(idx, e6.target.value),
            onBlur,
            rows: 3,
            placeholder: "One bullet per line\nDemonstrated ability to\u2026\nProficient in\u2026",
            className: "w-full rounded border border-gray-300 bg-white px-2 py-1.5 text-xs focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("p", { className: "mt-0.5 text-[10px] text-gray-400", children: "One bullet point per line" })
      ] }, n12.id)),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
        "button",
        {
          type: "button",
          onClick: add,
          className: "rounded-md border border-dashed border-indigo-300 py-1.5 text-xs text-indigo-600 hover:border-indigo-500 hover:bg-indigo-50",
          children: "+ Add skill"
        }
      )
    ] });
  }

  // resources/js/Components/TextInput.tsx
  init_define_import_meta_env();
  var import_react59 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime16 = __toESM(require_react_shim(), 1);
  var TextInput_default = (0, import_react59.forwardRef)(function TextInput({ type = "text", className = "", isFocused = false, ...props }, ref) {
    const localRef = (0, import_react59.useRef)(null);
    (0, import_react59.useImperativeHandle)(ref, () => ({ focus: () => localRef.current?.focus() }));
    (0, import_react59.useEffect)(() => {
      if (isFocused) localRef.current?.focus();
    }, [isFocused]);
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
      "input",
      {
        ...props,
        type,
        className: "rounded-lg border-[#eeeef5] shadow-sm focus:border-[#4f46e5] focus:ring-[#4f46e5] " + className,
        ref: localRef
      }
    );
  });
  return __toCommonJS(ds_entry_exports);
})();
/*! Bundled license information:

use-sync-external-store/cjs/use-sync-external-store-with-selector.development.js:
  (**
   * @license React
   * use-sync-external-store-with-selector.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

lodash-es/lodash.js:
  (**
   * @license
   * Lodash (Custom Build) <https://lodash.com/>
   * Build: `lodash modularize exports="es" --repo lodash/lodash#4.18.1 -o ./`
   * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
   * Released under MIT license <https://lodash.com/license>
   * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
   * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
   *)

@inertiajs/core/dist/index.esm.js:
  (* NProgress, (c) 2013, 2014 Rico Sta. Cruz - http://ricostacruz.com/nprogress
   * @license MIT *)
*/
window.Resumegen=Resumegen.__dsMainNs?Object.assign({},Resumegen,Resumegen.__dsMainNs,{__dsMainNs:undefined}):Resumegen;
