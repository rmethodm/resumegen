# Guidelines

- [DEPLOYMENT](./docs/DEPLOYMENT.md)
- [resume-builder-competitive-analysis](./docs/resume-builder-competitive-analysis.md)
- [sdd-fix-plan](./docs/sdd-fix-plan.md)
- [TODO](./docs/TODO.md)
