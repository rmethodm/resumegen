"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.Resumegen;
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/previews/Dropdown.tsx
  var Dropdown_exports = {};
  __export(Dropdown_exports, {
    AccountMenu: () => AccountMenu
  });
  init_define_import_meta_env();

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.Resumegen;
  var ds_default = "default" in g ? g.default : g;

  // .design-sync/previews/Dropdown.tsx
  var import_react = __toESM(require_react_shim(), 1);
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  function OpenDropdown({ children }) {
    const ref = (0, import_react.useRef)(null);
    (0, import_react.useEffect)(() => {
      const trigger = ref.current?.querySelector("button");
      if (trigger) trigger.click();
    }, []);
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref, className: "inline-block", children });
  }
  function AccountMenu() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { paddingBottom: "160px" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenDropdown, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ds_exports.Dropdown, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Dropdown.Trigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { className: "flex items-center gap-1 rounded bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm ring-1 ring-gray-300 hover:bg-gray-50", children: [
        "My Account",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { className: "ml-1 h-4 w-4 text-gray-400", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { fillRule: "evenodd", d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z", clipRule: "evenodd" }) })
      ] }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Dropdown.Content, { align: "left", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "py-1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer", children: "Profile" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer", children: "Billing" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "block px-4 py-2 text-sm text-red-600 hover:bg-gray-100 cursor-pointer", children: "Sign Out" })
      ] }) })
    ] }) }) });
  }
  return __toCommonJS(Dropdown_exports);
})();
